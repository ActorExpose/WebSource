<?php
include("includes/header.php");
require("includes/function.php");
require("language/language.php");

	if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}
	
	
     //Get all Wallpaper 
	
      $tableName="tbl_ringtone";   
      $targetpage = "manage_approval_ringtone_list.php"; 
      $limit = 20; 
      
      
      if(isset($_POST['search_value']))
      $query = "SELECT COUNT(*) as num FROM $tableName where status=0 and rname like '%".$_POST['search_value']."%'";
      else $query = "SELECT COUNT(*) as num FROM $tableName where status=0";
      
      
      $total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
      $total_pages = $total_pages['num'];
      
      $stages = 3;
      $page=0;
      if(isset($_GET['page'])){
      $page = mysqli_real_escape_string($mysqli,$_GET['page']);
      }
      if($page){
        $start = ($page - 1) * $limit; 
      }else{
        $start = 0; 
        } 
        
        
    if(isset($_POST['search_value']))
    $quotes_qry1 = "SELECT * FROM tbl_ringtone LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid where tbl_ringtone.status=0 and rname like '%".$_POST['search_value']."%' ORDER BY tbl_ringtone.rid ASC LIMIT $start, $limit";
    else $quotes_qry1 = "SELECT * FROM tbl_ringtone LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid where tbl_ringtone.status=0 ORDER BY tbl_ringtone.rid ASC LIMIT $start, $limit";
    
    
    
    $result = mysqli_query($mysqli,$quotes_qry1); 
 
 
 

if (isset($_GET['video_id']) and $_SESSION['TYPE_USERNAME']!=2 ) 
{
    $img_res = mysqli_query($mysqli, 'SELECT * FROM tbl_ringtone WHERE rid=' . $_GET['video_id'] . '');
    $img_res_row = mysqli_fetch_assoc($img_res);
	
    if($img_res_row['ringtone']!="")
      {
        unlink('ringtone/'.$img_res_row['ringtone']);
      }
	
    Delete('tbl_ringtone', 'rid=' . $_GET['video_id'] . '');
    
	$_SESSION['msg'] = "12";
    header("Location:manage_approval_ringtone_list.php");
    exit;
}

    //Active and Deactive status
 if (isset($_GET['status_deactive_id']) and $_SESSION['TYPE_USERNAME']!=2) {
     $data = array('status' => '0');
     $edit_status = Update('tbl_ringtone', $data, "WHERE rid = '" . $_GET['status_deactive_id'] . "'");
     $_SESSION['msg'] = "14";
     header("Location:manage_approval_ringtone_list.php");
     exit;
 }if (isset($_GET['status_active_id']) and $_SESSION['TYPE_USERNAME']!=2) {
     $data = array('status' => '1');
     $edit_status = Update('tbl_ringtone', $data, "WHERE rid = '" . $_GET['status_active_id'] . "'");
     $_SESSION['msg'] = "13";
     header("Location:manage_approval_ringtone_list.php");
     exit;
 }

?>

<style>
    .bg1{
    background-image: linear-gradient(to left bottom, #482f26, rgb(115, 82, 69)) !important;
}

.bg2{
    background-image: linear-gradient(to left bottom, rgb(193, 114, 203), rgb(114, 133, 203)) !important;
}

.bg3{
    background-image: linear-gradient(to left bottom, rgb(236, 233, 139), rgb(243, 191, 0)) !important;
}

.bg4{
    background-image: linear-gradient(to left bottom, rgb(203, 114, 144), #9C27B0) !important;
}

.bg5{
    background-image: linear-gradient(to left bottom, rgb(96, 131, 208), rgb(58, 210, 226)) !important;
}

.bg6{
    background-image: linear-gradient(to left bottom, #e880a3, #E91E63) !important;
}

.bg7{
    background-image: linear-gradient(to left bottom, #F44336, #ef8f88) !important;
}

.bg8{
    background-image: linear-gradient(to left bottom, rgb(116, 203, 114), rgb(161, 203, 114)) !important;
}

.bg9{
    background-image: linear-gradient(to left bottom, #7498a9, #607D8B) !important;
}

.bg10{
    background-image: linear-gradient(to left bottom, #52cede, #00BCD4) !important;
}


.bg11{
  background-image: linear-gradient(to left bottom, #0dead6, #009688) !important;  
}


.bg12{
    background-image: linear-gradient(to left bottom, #e8ff00, #CDDC39) !important;
}
</style>
    <div class="row">
    <div class="col-xs-12">
        <div class="card mrg_bottom">
            <div class="page_title_block">
                <div class="col-md-5 col-xs-12">
                    <div class="page_title">Manage Unapproval Ringtone</div>
                </div>
                <div class="col-md-7 col-xs-12">
                    <div class="search_list">
                      <div class="search_block">
                      <form  method="post" action="">
                        <input class="form-control input-sm" placeholder="Search..." aria-controls="DataTables_Table_0" type="search" name="search_value" required>
                        <button type="submit" name="user_search" class="btn-search"><i class="fa fa-search"></i></button>
                      </form>  
                    </div>
                     
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="row mrg-top">
                <div class="col-md-12">
                    <div class="col-md-12 col-sm-12">
                        <?php if (isset($_SESSION['msg'])) { ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                            aria-hidden="true">×</span></button>
                                <?php echo $client_lang[$_SESSION['msg']]; ?></a>
                            </div>
                            <?php unset($_SESSION['msg']);
                        } ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mrg-top">
                
                <?php
            
                if(mysqli_num_rows ($result)==0){
                    ?>
                <div class="col-xs-12">
                    <div class="col-xs-12" style="height:200px;background: #eeeeeea6;border-radius: 2px;">
                        <div style="position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-family: 'Open Sans', sans-serif;font-size: 1.2em;font-weight: 300;opacity: .8;">
                            Empty Data :(
                            </div>
                            </div>
                </div> 
                
            <?php }	
                $arrX = array("bg1", "bg2","bg3","bg4", "bg5","bg6", "bg7","bg8", "bg9","bg10", "bg11","bg12");
                $arrX2 = array();
				$i=0;
				$i = 0;
				$arrayId = array();
                    while ($row = mysqli_fetch_array($result))
					{					
			?>
				
                <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12" style="margin-bottom: 30px;">
                    <?php 
                            //trim($row['image'])
                            if(sizeof($arrX)==0) {$arrX = array_merge($arrX, $arrX2); unset($arrX2); $arrX2 = array();}   
                            $randIndex = array_rand($arrX);
                            ?>
                    <div class="card m-b-30 <?php echo $arrX[$randIndex]; array_push($arrX2,$arrX[$randIndex]); unset($arrX[$randIndex]); ?>" >
                        <div class="card-body">
                            <h5 class="card-title font-16 mt-0 text-white" style="text-align: center;height: 19px;text-overflow: ellipsis;flex-shrink: 0;overflow: hidden;white-space: nowrap;">
                                <?php echo $row['rname'].' ( <i class="fa fa-arrow-down text-white" style="font-size: 12px;"></i> '.$row['download'].')';?> </h5>
                            
                        </div>
                        <div style="height: 200px;width: 100%;position: relative;">
                            <div class="card-img-top img-fluid" style="position: absolute;left: 0;top: 0;z-index: 8;background-size: cover;height: 100%;width: 100%;float: left;display: flex;-webkit-box-align: center;align-items: center;-webkit-box-pack: center;justify-content: center;">
                                
                                <div class="mediPlayer">
                                  <audio class="listen" preload="none" data-size="80" src="<?php echo $row['ringtone']; ?>"></audio>
                                </div>
                                <?php 
                                array_push($arrayId, '#myAudio'.$row['rid']);
                                ?> 
                            </div>
                            
                            <!--<div style="position: relative;z-index: 10;background: #221a2f;left: 0;top: 0;height: 100%;width: 100%;opacity: .65;filter: grayscale(80%);background-size: cover;">-->
                            <!--filter: blur(1px);-->
                            <!--</div>-->
                        </div>
                        
                        
                        <div class="card-body" style="text-align: center;opacity: 0.95;">
                            <a href="<?php echo"". $row['ringtone']; ?>" target="_blank" class="btn" title="Preview Song" style="background: #fff;padding: 10px 10px;border-radius: 50%;width: 42px;">
                                <i class="fa fa-external-link " style="color: #2196F3;"></i></a>
                            <?php if($row['tbl_ringtone.status']=="1"){?>
                            <a href="manage_approval_ringtone_list.php?status_deactive_id=<?php echo $row['rid'];?>" title="Disable Visibility" class="btn" style="background: #fff;padding: 10px 10px;border-radius: 50%;width: 42px;">
                                <i class="fa fa-eye" style="color: #18aa4a !important;"></i></a>
                              <?php }else{?>
                            <a href="manage_approval_ringtone_list.php?status_active_id=<?php echo $row['rid'];?>" title="Enable Visibility" class="btn" style="background: #fff;padding: 10px 10px;border-radius: 50%;width: 42px;">
                                <i class="fa fa-eye-slash" style="color: #18aa4a !important;"></i></a>
                            <?php }?>
                            <a href="?video_id=<?php echo $row['rid']; ?>" class="btn" title="Remove" style="background: #fff;padding: 10px 10px;border-radius: 50%;width: 42px;" onclick="return confirm('Are you sure you want to delete this Ringtone or Song?');">
                                <i class="fa fa-trash-o " style="color: #d73727;"></i></a>
                        </div>
                    </div>
                </div>
                <?php
					$i++;}
				?> 
                <!--<table class="table table-striped table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>categories</th>
                        <th>ringtone name</th>
                     <th>ringtone</th>
                      <th>Status</th>
                        <th class="cat_action_list">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 0;
                    while ($row = mysqli_fetch_array($result)) { ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $row['ringtone_cat_name']; ?></td>
                            <td><?php echo $row['rname']; ?></td>
                             <td><?php echo $row['ringtone']; ?></td>
                              <td>
                  <?php if($row['status']!="1"){?>
                  <a href="manage_approval_ringtone_list.php?status_deactive_id=<?php echo $row['rid'];?>" title="Change Status"><span class="badge badge-success badge-icon"><i class="fa fa-check" aria-hidden="true"></i><span>Enable</span></span></a>

                  <?php }else{?>
                  <a href="manage_approval_ringtone_list.php?status_active_id=<?php echo $row['rid'];?>" title="Change Status"><span class="badge badge-danger badge-icon"><i class="fa fa-check" aria-hidden="true"></i><span>Disable </span></span></a>
                  <?php }?>
                  </td>
                        <?php  $file_path = 'http://'.$_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']).'/'; ?>

                            <td> <a  href="?video_id=<?php echo $row['id']; ?>" 	class="btn btn-default"
                                  onclick="return confirm('Are you sure you want to delete this GIF?');">Delete</a>

                                  <a href="<?php echo $file_path.$row['ringtone']; ?>"   target="_blank"   class="btn btn-primary" ">play</a>
                            </td>
                        </tr>
                        <?php $i++;
                    } ?>
                    </tbody>
                </table>-->
            </div>
            <div class="col-md-12 col-xs-12">
                <div class="pagination_item_block">
                    <nav>
                        <?php include("pagination.php"); ?>
                    </nav>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    </div>
<?php
include("includes/footer.php");
?>


<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript" src="assets/js/player.js"></script> 

<script>
     $(document).ready(function () {
        $('.mediPlayer').mediaPlayer();
    });
    
</script>
