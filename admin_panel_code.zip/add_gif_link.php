<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	require_once("thumbnail_images.class.php");

	$cat_qry="SELECT * FROM tbl_gif_cat ORDER BY gif_cat_name";
	$cat_result=mysqli_query($mysqli,$cat_qry); 
	
	if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}
	
	if(isset($_POST['submit']) and isset($_GET['add']) and $_SESSION['TYPE_USERNAME']!=2)
	{
           
       $data = array( 
           	 'gif_name'  =>  $_POST['gif_name'],
	   		/*	 'gid'  =>  $_POST['cat_id'],*/
			    'gif'  =>  $_POST['gif_link'],
			      'download' =>1,
			    'status' =>1
			   
			    );		

 		$qry = Insert('tbl_gif_list',$data);	

 	   
		$_SESSION['msg']="10"; 
		header( "Location:manage_gif_list.php");
		exit;	

		 
		
	}
	
	if(isset($_GET['banner_id']))
	{
			 
			$qry="SELECT * FROM tbl_img_list where id='".$_GET['banner_id']."'";
			$result=mysqli_query($mysqli,$qry);
			$row=mysqli_fetch_assoc($result);

	}
	
	

?>
<div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title"><?php if(isset($_GET['banner_id'])){?>Edit<?php }else{?>Add<?php }?> Live Wallpaper</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom"> 
            <form action="" name="addeditcategory" method="post" class="form form-horizontal" enctype="multipart/form-data">
            	<input  type="hidden" name="banner_id" value="<?php echo $_GET['banner_id'];?>" />

              <div class="section">
                <div class="section-body">
<!--				 <div class="form-group">
                    <label class="col-md-3 control-label">Category :-</label>
                    <div class="col-md-6">
                      <select name="cat_id" id="cat_id" class="select2" required>
                        <option value="">--Select image Category--</option>
          							<?php
          									while($cat_row=mysqli_fetch_array($cat_result))
          									{
          							?>          						 
          							<option value="<?php echo $cat_row['gid'];?>"><?php echo $cat_row['gif_cat_name'];?></option>	          							 
          							<?php
          								}
          							?>
                      </select>
                    </div>
                  </div>-->
                      
                 <div class="form-group">
                    <label class="col-md-3 control-label">Live walllpaper name :</label>
                    <div class="col-md-6">
                      <input type="text" name="gif_name" id="gif_name" value="<?php echo $row['gif_name'];?>" class="form-control" required>
                    </div>
                  </div>   
                                
                  <div class="form-group">
                    <label class="col-md-3 control-label">Live walllpaper URL:</label>
                    <div class="col-md-6">
                      <input type="url" name="gif_link" id="gif_link" value="<?php if(isset($_GET['banner_id'])){echo $row['image_link'];}?>" class="form-control" required>
                    </div>
                  </div>
            
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
