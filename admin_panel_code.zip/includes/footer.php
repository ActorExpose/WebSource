<footer class="app-footer">
      <!--Kingdov &#169; 2019-->
    </footer>
  </div>
</div>
<script type="text/javascript" src="assets/js/vendor.js"></script> 
<script type="text/javascript" src="assets/js/app.js"></script>
<script type="text/javascript" src="assets/js/timer.js"></script>
</body>
</html>