<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	
	   //Get all Wallpaper 
	
      $tableName="tbl_notification";   
      $targetpage = "manage_notification.php"; 
      $limit = 10; 
      
      $query = "SELECT COUNT(*) as num FROM $tableName";
      $total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
      $total_pages = $total_pages['num'];
      
      $stages = 3;
      $page=0;
      if(isset($_GET['page'])){
      $page = mysqli_real_escape_string($mysqli,$_GET['page']);
      }
      if($page){
        $start = ($page - 1) * $limit; 
      }else{
        $start = 0; 
        } 
      
    $quotes_qry="SELECT *  FROM tbl_notification ORDER BY tbl_notification.id DESC ";
 
    $result=mysqli_query($mysqli,$quotes_qry); 
if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}	 

  if(isset($_GET['video_id']) and $_SESSION['TYPE_USERNAME']!=2)
  { 

    $img_res=mysqli_query($mysqli,'SELECT * FROM tbl_notification WHERE id='.$_GET['video_id'].'');
    $img_res_row=mysqli_fetch_assoc($img_res);
           
    if($img_res_row['video_thumbnail']!="")
     {
          unlink('images/thumbs/'.$img_res_row['video_thumbnail']);
          unlink('images/'.$img_res_row['video_thumbnail']);

          unlink($img_res_row['video_url']);
      }
 
    Delete('tbl_notification','id='.$_GET['video_id'].'');
    
    $_SESSION['msg']="12";
		header( "Location:manage_notification.php");
    exit;
    
  }


?>
                
    <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Notification</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                
                <div class="add_btn_primary"> <a href="send_notification.php?add">Sent Notification</a> </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
  <div class="col-xs-12">        
<div class="card-columns">


           <?php
            
            if(mysqli_num_rows ($result)==0){
                ?>
            <div class="col-xs-12">
                <div class="col-xs-12" style="height:200px;background: #eeeeeea6;border-radius: 2px;">
                    <div style="position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-family: 'Open Sans', sans-serif;font-size: 1.2em;font-weight: 300;opacity: .8;">
                        Empty Data :(
                        </div>
                        </div>
            </div> 
            <?php }
                $arrX = array("#3f6ad8", "#16aaff","#3ac47d","#f7b924", "#444054","#d92550");
                $arrX2 = array();
				$i=0;
				while($row=mysqli_fetch_array($result))
				{					
		    ?>
				
        
                <div class="card">
                    <div class="card-img-top">
                        <div class="mb-3 widget-chart" style="background:url(<?php echo str_replace(' ', '%20', $row['image']);?>)no-repeat;padding: 4rem;height: 100%;/* Center and scale the image nicely */background-position: center;background-repeat: no-repeat;background-size: cover;">
                            <?php if(trim($row['image'])==""){
                            //trim($row['image'])
                            if(sizeof($arrX)==0) {$arrX = array_merge($arrX, $arrX2); unset($arrX2); $arrX2 = array();}   
                            $randIndex = array_rand($arrX);
                            ?>
                            <div name="bgcolor" style="background: <?php echo $arrX[$randIndex]; array_push($arrX2,$arrX[$randIndex]); unset($arrX[$randIndex]); ?>;position: absolute;left: 0;top: 0;height: 100%;width: 100%;z-index: 1;background-size: cover;"></div>
                            
                            <?php } else { ?>
                            
                            <div name="bgcolor" style="background: #000000;position: absolute;left: 0;top: 0;height: 100%;width: 100%;z-index: 1;opacity: .75;filter: grayscale(80%);background-size: cover;"></div>
                            
                            <?php } ?>
                            <div class="widget-numbers" style="z-index: 10;color: #fff;position: relative;"><i class="fa fa-bell-o text-white"></i></div>
                            
                            
                        </div>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php if(trim($row['url'])!=""){?>linking Notification<?php } else {?>No Linking Notification <?php }?></h5>
                        <p class="card-text"><?php echo $row['msg'];?>.</p>
                        <p class="card-text"><small class="text-muted"><?php echo $row['date'];?></small> <a href="?video_id=<?php echo $row['id'];?>" onclick="return confirm('Are you sure you want to delete this notification ?');" style="display:inline-block; width:30px;"><small class="text-red">Delete</small></a></p>
                        
                    </div>
                </div>

            <?php
						
					$i++;
			     	}
			?> 
          
          </div>
          </div>
          
          
          
          
          
         
           <div class="col-md-12 col-xs-12">
            <div class="pagination_item_block">
              <nav>
                <?php include("pagination.php");?>                 
              </nav>
            </div>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
