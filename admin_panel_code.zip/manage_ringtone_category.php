<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}	 


	
	//Get all Category 
	//$qry="SELECT * FROM tbl_ringtone_cat";
	//$qry="SELECT tbl_ringtone_cat.*, COUNT(*) as total  FROM tbl_ringtone_cat , tbl_ringtone WHERE tbl_ringtone_cat.rcid = tbl_ringtone.r_cat and tbl_ringtone.status = 1 GROUP BY tbl_ringtone_cat.rcid ORDER BY total DESC";
	$qry= "SELECT tbl_ringtone_cat.*, COUNT(tbl_ringtone.r_cat) as  'total'  FROM tbl_ringtone_cat LEFT JOIN  tbl_ringtone ON tbl_ringtone_cat.rcid = tbl_ringtone.r_cat GROUP BY tbl_ringtone_cat.rcid ORDER BY total DESC";
	$result=mysqli_query($mysqli,$qry);
	
	if(isset($_GET['cat_id'])and $_SESSION['TYPE_USERNAME']!=2)
	{

		
		Delete('tbl_ringtone_cat','rcid='.$_GET['cat_id'].'');
		
      	$_SESSION['msg']="12";
		header( "Location:manage_ringtone_category.php");
		exit;
		
	}	
	
	
	  //Active and Deactive status
  if(isset($_GET['status_deactive_id'])and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('status'  =>  '0');
    
    $edit_status=Update('tbl_ringtone_cat', $data, "WHERE rcid = '".$_GET['status_deactive_id']."'");
    
     $_SESSION['msg']="14";
     header( "Location:manage_ringtone_category.php");
     exit;
  }
  if(isset($_GET['status_active_id'])and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('status'  =>  '1');
    
    $edit_status=Update('tbl_ringtone_cat', $data, "WHERE rcid = '".$_GET['status_active_id']."'");
    
    $_SESSION['msg']="13";
     header( "Location:manage_ringtone_category.php");
     exit;
  }
  
  
  
    //featured categories
  if(isset($_GET['featured_deactive_id'])and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('featured'  =>  '0');
    
    $edit_status=Update('tbl_ringtone_cat', $data, "WHERE rcid = '".$_GET['featured_deactive_id']."'");
    
     $_SESSION['msg']="14";
     header( "Location:manage_ringtone_category.php");
     exit;
  }
  if(isset($_GET['featured_active_id'])and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('featured'  =>  '1');
    
    $edit_status=Update('tbl_ringtone_cat', $data, "WHERE rcid = '".$_GET['featured_active_id']."'");
    
    $_SESSION['msg']="13";
     header( "Location:manage_ringtone_category.php");
     exit;
  }
	 
?>
                
    <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Ringtones Categories</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                
                <div class="add_btn_primary"> <a href="add_ringtone_cat.php?add=yes">Add Ringtones Category</a> </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          
          
          
                      
            <?php
            
            if(mysqli_num_rows ($result)==0){
                ?>
            <div class="col-xs-12">
                <div class="col-xs-12" style="height:200px;background: #eeeeeea6;border-radius: 2px;">
                    <div style="position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-family: 'Open Sans', sans-serif;font-size: 1.2em;font-weight: 300;opacity: .8;">
                        Empty Data :(
                        </div>
                        </div>
            </div> 
            <?php }	
				$i=0;
				while($row=mysqli_fetch_array($result))
				{					
		    ?>
				
                <div class="col-md-4" style="margin-bottom: 30px;">
                    <div class="card mb-3 widget-chart" style="background:url(images/thumbs/<?php echo $row['ringtone_cat_image'];?>)no-repeat;height: 100%;/* Center and scale the image nicely */background-position: center;background-repeat: no-repeat;background-size: cover;">
                        <div style="background: #121213;position: absolute;left: 0;top: 0;height: 100%;width: 100%;z-index: 1;opacity: .65;filter: grayscale(80%);background-size: cover;"></div>
                        <div class="widget-numbers" style="z-index: 10;color: #fff;position: relative;"><?php echo $row['total'];?></div>
                        <div class="widget-subheading" style="z-index: 10;color: #fff;position: relative;opacity: 1;"><?php echo $row['ringtone_cat_name'];?> Songs</div>
                        <div class="widget-description text-danger" style="z-index: 10;color: #fff;position: relative;opacity: .85;">
                            
                            <a href="add_ringtone_cat.php?banner_id=<?php echo $row['rcid'];?>" class="btn btn-transparent" title="Edit" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                <i class="fa fa-edit text-white"></i></a>
                            
                            <?php if($row['status']!="0"){?>
                            <a href="manage_ringtone_category.php?status_deactive_id=<?php echo $row['rcid'];?>"  class="btn btn-transparent" title="Disable Visibility" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                              <i class="fa fa-eye text-green" aria-hidden="true"></i></a>
            
                            <?php }else{?>
                            <a href="manage_ringtone_category.php?status_active_id=<?php echo $row['rcid'];?>" class="btn btn-transparent" title="Enable Visibility" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                              <i class="fa fa-eye-slash text-red" aria-hidden="true"></i></a>
                            <?php }?>
                            
                            <?php if($row['featured']!="0"){?>
                            <a href="manage_ringtone_category.php?featured_deactive_id=<?php echo $row['rcid'];?>" class="btn btn-transparent" title="Disable Featured" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                  <i class="fa fa-rocket text-green" aria-hidden="true"></i></a>
                              
                            <?php }else{?>
                            <a href="manage_ringtone_category.php?featured_active_id=<?php echo $row['rcid'];?>" class="btn btn-transparent" title="Enable Featured" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                  <i class="fa fa-rocket text-red" aria-hidden="true"></i></a>
                                  
                            <?php }?>
                            
                            <a href="?cat_id=<?php echo $row['rcid'];?>" class="btn btn-transparent" title="Remove" onclick="return confirm('Are you sure you want to delete this category and related wallpaper?');" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                <i class="fa fa-trash-o text-white"></i></a>
                        </div>
                    </div>
                </div>
          
          
            <?php
						
					$i++;
			     	}
			?> 
          
          
          
          
          
          
          
          
          
          
          
          <!--
          <div class="col-md-12 mrg-top">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>      
				  <th>id</th>				
                 <th>Category</th>
                 <th>Category Ringtone</th>
                 <th>Status</th>  
                 <th>featured</th>  
                  <th class="cat_action_list">Action</th>
                </tr>
              </thead>
              <tbody>
              	<?php	
						$i=0;
						while($row=mysqli_fetch_array($result))
						{					
				?>
                <tr>                 
			           	<td><?php echo $i+1 ;?></td>
                  <td><?php echo $row['ringtone_cat_name'];?></td>
            <td><span class="category_img"><img src="images/thumbs/<?php echo $row['ringtone_cat_image'];?>" /></span></td>
              <td>
                  <?php if($row['status']!="0"){?>
                  <a href="manage_ringtone_category.php?status_deactive_id=<?php echo $row['rcid'];?>" title="Change Status"><span class="badge badge-success badge-icon"><i class="fa fa-check" aria-hidden="true"></i><span>Enable</span></span></a>

                  <?php }else{?>
                  <a href="manage_ringtone_category.php?status_active_id=<?php echo $row['rcid'];?>" title="Change Status"><span class="badge badge-danger badge-icon"><i class="fa fa-check" aria-hidden="true"></i><span>Disable </span></span></a>
                  <?php }?>
                  </td>
                  
                  <td>
                  <?php if($row['featured']!="0"){?>
                  <a href="manage_ringtone_category.php?featured_deactive_id=<?php echo $row['rcid'];?>" title="Change Status"><span class="badge badge-success badge-icon"><i class="fa fa-check" aria-hidden="true"></i><span>Enable</span></span></a>

                  <?php }else{?>
                  <a href="manage_ringtone_category.php?featured_active_id=<?php echo $row['rcid'];?>" title="Change Status"><span class="badge badge-danger badge-icon"><i class="fa fa-check" aria-hidden="true"></i><span>Disable </span></span></a>
                  <?php }?>
                  </td>
				 
				  <td> 
				
 
 <a href="?cat_id=<?php echo $row['rcid'];?>" class="btn btn-default" onclick="return confirm('Are you sure you want to delete this category and related wallpaper?');">Delete</a>
 
 <a href="add_gif_cat.php?banner_id=<?php echo $row['rcid'];?>" class="btn btn-primary" >EDIT</a>
 
 </td>
                </tr>
                <?php
						
						$i++;
				     	}
				?> 
              </tbody>
            </table>
          </div>
          
          -->
           
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
