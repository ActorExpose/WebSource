<?php

require_once("Rest.inc.php");
require_once("db.php");

class functions extends REST {
    
    private $mysqli = NULL;
    private $db = NULL;
    
    public function __construct($db) {
        parent::__construct();
        $this->db = $db;
        $this->mysqli = $db->mysqli;
        $this->mysqli->query('SET CHARACTER SET utf8mb4');

    }

	public function checkConnection() {
			if (mysqli_ping($this->mysqli)) {
                $respon = array(
                    'status' => 'ok', 'database' => 'connected'
                );
                $this->response($this->json($respon), 200);
			} else {
                $respon = array(
                    'status' => 'failed', 'database' => 'not connected'
                );
                $this->response($this->json($respon), 404);
			}
	}

    // app details
    
    	public function getColorDetails() {
		include "../includes/connection.php";

	   $jsonObj= array();	

		$query="SELECT * FROM tbl_color WHERE cc_id";
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());


		while($data = mysqli_fetch_assoc($sql))
		{
			 
			$row['cc_id'] = $data['cc_id'];
			$row['cc_name'] = $data['cc_name'];
			$row['cc_image'] = $data['cc_image'];
			$row['cc_status'] = $data['cc_status'];
	


			array_push($jsonObj,$row);
		
		}
 
		$set['video-status-image'] = $jsonObj;
		
		//$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
		$this->response($this->json($set), 200);

	}

    

       
    	public function getImageByColorId() 
    	{
        		include "../includes/connection.php";
              
        	   $jsonObj= array();	
        	      $cc_id=$_GET['cc_id'];
        	  
               
        	   	$tableName="tbl_img_list";		
        		$limit = 10; 
        		
        		$query = "SELECT COUNT(*) as num FROM $tableName 
        		                LEFT JOIN tbl_img_cat on tbl_img_cat.cid=tbl_img_list.cid
                                LEFT JOIN tbl_color on tbl_color.cc_id=tbl_img_list.cc_id
                                LEFT JOIN tbl_users on tbl_users.id=tbl_img_list.user_id
                        		WHERE FIND_IN_SET($cc_id,tbl_img_list.cc_id) ";
                        		
                        		
        		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
        		$total_pages = $total_pages['num'];
        		
        		$stages = 3;
        		$page=0;
        		if(isset($_GET['page'])){
        		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
        		}
        		if($page){
        			$start = ($page - 1) * $limit; 
        		}else{
        			$start = 0;	
        			}

           
                
                		$query="SELECT tbl_img_list.* , tbl_users.name , tbl_color.* , tbl_img_cat.*  FROM tbl_img_list
                		LEFT JOIN tbl_img_cat on tbl_img_cat.cid=tbl_img_list.cid
                        LEFT JOIN tbl_color on tbl_color.cc_id=tbl_img_list.cc_id
                        LEFT JOIN tbl_users on tbl_users.id=tbl_img_list.user_id
                		WHERE FIND_IN_SET($cc_id,tbl_img_list.cc_id) LIMIT $start, $limit ";
                		
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			 
			$row['id'] = $data['id'];
			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['color_id'] = $data['cc_id'];
			$row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
			$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
	


			array_push($jsonObj,$row);
		
		}
        $set['page'] = $_GET['page'];
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;
		
		//$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
		$this->response($this->json($set), 200);

	}
    
    
	public function getAppDetails() {
		include "../includes/connection.php";

	   $jsonObj= array();	

		$query="SELECT * FROM tbl_settings WHERE id='1'";
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());


		while($data = mysqli_fetch_assoc($sql))
		{
			 
			$row['app_name'] = $data['app_name'];
			$row['app_logo'] = $data['app_logo'];
			$row['app_version'] = $data['app_version'];
			$row['app_author'] = $data['app_author'];
			$row['app_contact'] = $data['app_contact'];
			$row['app_email'] = $data['app_email'];
			$row['app_website'] = $data['app_website'];
			$row['app_description'] = $data['app_description'];
			$row['app_developed_by'] = $data['app_developed_by'];

			$row['app_privacy_policy'] = stripslashes($data['app_privacy_policy']);
 			
 			$row['ads'] = $data['ads'];
 				$row['click'] = $data['click'];
 			$row['publisher_id'] = $data['publisher_id'];
			$row['interstital_ad_id'] = $data['interstital_ad_id'];
 			$row['banner_ad_id'] = $data['banner_ad_id'];
 			$row['native_ad_id'] = $data['native_ad_id'];
 			
 			$row['fb_publisher_id'] = $data['fb_publisher_id'];
			$row['fb_interstital_ad_id'] = $data['fb_interstital_ad_id'];
 			$row['fb_banner_ad_id'] = $data['fb_banner_ad_id'];
 			$row['fb_native_ad_id'] = $data['fb_native_ad_id'];

			array_push($jsonObj,$row);
		
		}
 
		$set['video-status-image'] = $jsonObj;
		
		//$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
		$this->response($this->json($set), 200);

	}

		
public function postUserSocialLogin() 
	{
		include "../includes/connection.php";
		include('../includes/function.php');

		$email_id = $_POST['email'];
		$device_id = $_POST['device_id'];
		
		$qry = "SELECT * FROM tbl_users WHERE email = '".$email_id."'"; 
		$result = mysqli_query($mysqli,$qry);
		$num_rows = mysqli_num_rows($result);
		$row = mysqli_fetch_assoc($result);
		
    	if ($num_rows > 0)
		{
			$set['video-status-image'][]	=	array(      
                                              'msg' =>'Login Successfully',
			                                   'login_type' 	=>	$row['login_type'],
		     								  'id'	=>	$row['id'],
		     								  'name'	=>	$row['name'],
		     								    'image'	=>	$row['image'],
		     								  'email'	=>	$row['email'],
		     								 'phone'=>$row['phone'],
		     								  'device_id'=>$row['device_id'],
		     								    'status'=>$row['status'],
		     								  'success'=>'1'
		     								);
		    $this->response($this->json($set), 200);
		}		 
		else
		{
		   /* $arr_browsers = ["Firefox", "Chrome", "Safari", "Opera", "MSIE", "Trident", "Edge"];
 
            $agent = $_SERVER['HTTP_USER_AGENT'];
             
            $user_browser = '';
            foreach ($arr_browsers as $browser) {
                if (strpos($agent, $browser) !== false) {
                    $user_browser = $browser;
                    break;
                }   
            }
             

            if($user_browser!="")
    		{
             	$set['video-status-image'][]=array('msg' =>'Please login with correct details','success'=>'0');
 	        	$this->response($this->json($set), 404);
            }else*/
		    {
		        	
            			
            
            		     $qry1="INSERT INTO tbl_users 
            				  (`login_type`,
            				  `name`,
            				  `email`,
            				    `image`,
            				  `password`,
            				   `phone`,
            				    `device_id`,
            				  `status`
            				) VALUES (
            			    	'".$_POST['login_type']."',
            					'".trim($_POST['name'])."',
            					'".trim($_POST['email'])."',
            						'".trim($_POST['image'])."',
            						'',
            						'".trim($_POST['phone'])."',
            							'".$_POST['device_id']."',
            						'1'
            				)"; 
                        
                        $result1 = mysqli_query($mysqli,$qry1);
                        $last_id = mysqli_insert_id($mysqli);  
                        
                        $qrys = "SELECT * FROM tbl_users WHERE id = '".$last_id."'"; 
            			$results = mysqli_query($mysqli,$qrys);
            			$row = mysqli_fetch_assoc($results);
            		
            												 
            			$set['video-status-image'][]	=	array(    
                                                'msg' =>'Login Successfully',
			                                   'login_type' 	=>	$row['login_type'],
		     								  'id'	=>	$row['id'],
		     								  'name'	=>	$row['name'],
		     								      'image'	=>	$row['image'],
		     								  'email'	=>	$row['email'],
		     								 'phone'=>$row['phone'],
		     								  'device_id'=>$row['device_id'],
		     								    'status'=>$row['status'],
		     								  'success'=>'1'
            		     								);
            	  		 
            		
            		$this->response($this->json($set), 200);
             }
 		}
	}
	
	
		
	public function postUseremailLogin() 
	{
		include "../includes/connection.php";
		include('../includes/function.php');
		
		$qry = "SELECT * FROM tbl_users WHERE  email = '".$_POST['email']."'"; 
		$result = mysqli_query($mysqli,$qry);
		$row = mysqli_fetch_assoc($result);
		
		if($row['email']!="")
		{
			$set['ALL_IN_ONE_VIDEO'][]=array('msg' => "Email address already used!",'success'=>'0');
		}
		else
		{ 
  
			$qry1="INSERT INTO tbl_users (`login_type`,`name`,`image`,`email`,`password`,`device_id`,`phone`,`status`) 
			VALUES ('".$_POST['login_type']."','".$_POST['name']."','".$_POST['image']."','".$_POST['email']."','".$_POST['password']."','".$_POST['device_id']."','".$_POST['phone']."','1')"; 
            
            $result1 = mysqli_query($mysqli,$qry1);
                        $last_id = mysqli_insert_id($mysqli);  
                        
                        $qrys = "SELECT * FROM tbl_users WHERE id = '".$last_id."'"; 
            			$results = mysqli_query($mysqli,$qrys);
            			$row = mysqli_fetch_assoc($results);
            		
            												 
            			$set['video-status-image'][]	=	array(    
                                                'msg' =>'Login Successfully',
			                                   'login_type' 	=>	$row['login_type'],
		     								  'id'	=>	$row['id'],
		     								  'name'	=>	$row['name'],
		     								      'image'	=>	$row['image'],
		     								  'email'	=>	$row['email'],
		     								 'phone'=>$row['phone'],
		     								  'device_id'=>$row['device_id'],
		     								    'status'=>$row['status'],
		     								  'success'=>'1'
            		     								);
            	  		 
            		
            		$this->response($this->json($set), 200);
					
		}
	
		$this->response($this->json($set), 200);
	
	
	}
	
	public function postuserstatus() 
	{
		include "../includes/connection.php";
		include('../includes/function.php');

		$email_id = $_POST['email'];
		
		$qry = "SELECT * FROM tbl_users WHERE email = '".$email_id."'"; 
		$result = mysqli_query($mysqli,$qry);
		$num_rows = mysqli_num_rows($result);
		$row = mysqli_fetch_assoc($result);
		
    	if ($num_rows > 0)
		{
			$set['video-status-image'][]	=	array( 
 						  
     		     'user_status'		=>'1',	  
                'login_type' 	=>	$row['login_type'],
 				  'id'	=>	$row['id'],
 				  'name'	=>	$row['name'],
 				  'email'	=>	$row['email'],
 				       'image'	=>	$row['image'],
 				 'phone'=>$row['phone'],
 				  'device_id'=>$row['device_id'],
 				    'status'=>$row['status'],
 				  'success'=>'1'
		     								
		     								
		     								
		   );
		    $this->response($this->json($set), 200);
		}		 
		else
		{
		    	$set['video-status-image'][]	=	array( 
		     								  'user_status'	=>'0'
		     								);
		    		 
			$this->response($this->json($set), 200);
        }
	}
	
	
	
	public function getUserProfile() {
		include "../includes/connection.php";
		include('../includes/function.php');

		$qry = "SELECT * FROM tbl_users WHERE id = '".$_GET['id']."'"; 
		$result = mysqli_query($mysqli,$qry);
		$row = mysqli_fetch_assoc($result);
		
		$qry_video1="SELECT COUNT(*) as num FROM tbl_img_list where status=1 and user_id = '".$_GET['id']."'"; 
        $totalstatuslist = mysqli_fetch_array(mysqli_query($mysqli,$qry_video1));
        $totalimage = $totalstatuslist['num'];

		$qry_video2="SELECT COUNT(*) as num FROM tbl_ringtone where status=1 and user_id = '".$_GET['id']."'"; 
        $totalringtonelist = mysqli_fetch_array(mysqli_query($mysqli,$qry_video2));
        $totalringtone = $totalringtonelist['num'];
	  				 
	    $set['video-status-image'][]=array(
	        
	         'login_type' 	=>	$row['login_type'],
 				  'id'	=>	$row['id'],
 				  'name'	=>	$row['name'],
 				  'email'	=>	$row['email'],
 				       'image'	=>	$row['image'],
 				 'phone'=>$row['phone'],
 				  'device_id'=>$row['device_id'],
 				    'totalimage'=>$totalimage,
 				      'totalringtone'=>$totalringtone,
 				    'status'=>$row['status'],
 				  'success'=>'1'
	        
	        );

	    $this->response($this->json($set), 200);

	}

	public function postUserProfileUpdate() {
		include "../includes/connection.php";
		include('../includes/function.php');

	   if($_FILES['image']['name']!="")
		{
		    
		        $video_url1=rand(0,99999)."_".$_FILES['image']['name'];
        	
        	    $images='images/'.$video_url1;
                  
        		$temp=$_FILES['image']['tmp_name'];
        		$path="../images/".$video_url1;
        		move_uploaded_file($temp,$path);
		    
			$user_edit= "UPDATE tbl_users SET name='".$_POST['name']."',email='".$_POST['email']."',image='".$images."',phone='".$_POST['phone']."' WHERE id = '".$_POST['user_id']."'";	 
		}
		else
		{
			$user_edit= "UPDATE tbl_users SET name='".$_POST['name']."',email='".$_POST['email']."',phone='".$_POST['phone']."' WHERE id = '".$_POST['user_id']."'";	 
		}
   		
   		$user_res = mysqli_query($mysqli,$user_edit);	
	  				 
		$set['video-status-image'][]=array('msg'=>'Updated','success'=>'1');
		$this->response($this->json($set), 200);

	}

/*	public function postuserlogin() {
		include "../includes/connection.php";
		include('../includes/function.php');
	
	 $email = $_POST['email'];
 		$password = $_POST['password'];

	    $qry = "SELECT * FROM tbl_users WHERE  email = '".$email."' and password = '".$password."'";
		$result = mysqli_query($mysqli,$qry);
		$num_rows = mysqli_num_rows($result);
 		$row = mysqli_fetch_assoc($result);
		
		if ($num_rows > 0)
		{ 
		       $set['video-status-image'][]=array(
	        
	         'login_type' 	=>	$row['login_type'],
 				  'id'	=>	$row['id'],
 				  'name'	=>	$row['name'],
 				  'email'	=>	$row['email'],
 				       'image'	=>	$row['image'],
 				 'phone'=>$row['phone'],
 				  'device_id'=>$row['device_id'],
 				    'status'=>$row['status'],
 				  'success'=>'1'
	        
	        );
					 
			  
		}		 
		else
		{
				 
 				$set['video-status-image'][]=array('msg' =>'Login failed','success'=>'0');
 		}
	
		$this->response($this->json($set), 200);

	}
	*/
	
	public function emaillogin() {
		include "../includes/connection.php";
		include('../includes/function.php');
	
	  $email = $_POST['email'];
 		$password = $_POST['password'];

	    $qry = "SELECT * FROM tbl_users WHERE  email = '".$email."' and password = '".$password."'";
		$result = mysqli_query($mysqli,$qry);
		$num_rows = mysqli_num_rows($result);
 		$row = mysqli_fetch_assoc($result);
		
		if ($num_rows > 0)
		{ 
					 
			     $set['video-status-image'][]=array(
			        'msg' =>'Login Successfully',
			         'login_type' 	=>	$row['login_type'],
 				  'id'	=>	$row['id'],
 				  'name'	=>	$row['name'],
 				  'email'	=>	$row['email'],
 				       'image'	=>	$row['image'],
 				 'phone'=>$row['phone'],
 				  'device_id'=>$row['device_id'],
 				    'status'=>$row['status'],
 				  'success'=>'1'
 				  
			         );
 			 
		}		 
		else
		{
				 
 				$set['video-status-image'][]=array('msg' =>'Login failed','success'=>'0');
 		}
 		
	    $this->response($this->json($set), 200);
	
	}
	
    //image

	public function getImageCategory() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
 
		 $query="SELECT * FROM tbl_img_cat where status=1 ORDER BY cid DESC";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['cat_image'] = $data['cat_image'];
		

			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}

	}
	
		public function getfeaturedImageCategory() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
 
		 $query="SELECT * FROM tbl_img_cat where featured=1 and status=1 ORDER BY cid DESC";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['cat_image'] = $data['cat_image'];
		

			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}

	}
	
    
	public function getImageList() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
		$cat_id=$_GET['cat_id'];	
		
		$tableName="tbl_img_list";		
		$limit = 10; 
		
		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_img_list.cid='".$cat_id."' and tbl_img_list.status=1";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
		$total_pages = $total_pages['num'];
		
		$stages = 3;
		$page=0;
		if(isset($_GET['page'])){
		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
		}
		if($page){
			$start = ($page - 1) * $limit; 
		}else{
			$start = 0;	
			}


			 $query="SELECT tbl_img_list.* , tbl_users.name , tbl_img_cat.category_name  FROM tbl_img_list
		LEFT JOIN tbl_img_cat ON tbl_img_list.cid= tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id= tbl_users.id 
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where FIND_IN_SET($cat_id,tbl_img_list.cid) and tbl_img_list.status=1 ORDER BY tbl_img_list.id LIMIT $start, $limit";



		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['category_name'] = $data['category_name'];
			$row['cc_id'] = $data['cc_id'];
			$row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
			$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
			array_push($jsonObj,$row);
		
		}

        $set['page'] = $_GET['page'];
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
		public function gettredningImageList() {
				include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	

		 $query="SELECT tbl_img_list.* , tbl_users.name , tbl_img_cat.category_name  FROM tbl_img_list
		LEFT JOIN tbl_img_cat ON tbl_img_list.cid= tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id= tbl_users.id
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where tbl_img_list.status=1 ORDER BY tbl_img_list.download LIMIT 0, 10";


		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['category_name'] = $data['category_name'];
			$row['cc_id'] = $data['cc_id'];
			$row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
			$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
			
			
			array_push($jsonObj,$row);
		
		}

        $set['page'] = $_GET['page'];
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}

	}
	
	
	
	public function gethomeImageList() {
				include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	

		$tableName="tbl_img_list";		
		$limit = 10; 
		
		$query = "SELECT COUNT(*) as num FROM $tableName ";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
		$total_pages = $total_pages['num'];
		
		$stages = 3;
		$page=0;
		$dataId = array();
		
		
		if(isset($_GET['page'])){
		    $page = mysqli_real_escape_string($mysqli,$_GET['page']);
		    if(isset($_GET['dataId']) && $_GET['page']!=1){
			   $dataId = unserialize($_GET['dataId']);
		    }
		}
			
		
		
		    
		if($page){
			$start = ($page - 1) * $limit; 
		}else{
			$start = 0;	
			}
			
        
        $query="SELECT tbl_img_list.* , tbl_users.name , tbl_img_cat.category_name  FROM tbl_img_list
		LEFT JOIN tbl_img_cat ON tbl_img_list.cid = tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id = tbl_users.id
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where tbl_img_list.id not in ('" . implode( "', '" , $dataId) . "' ) and tbl_img_list.status=1 GROUP BY tbl_img_list.id ORDER BY RAND() LIMIT 0, 10" ;

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			array_push($dataId, $data['id']);
			$row['category_name'] = $data['category_name'];
			$row['cc_id'] = $data['cc_id'];
			$row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
			$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
			array_push($jsonObj,$row);
		
		}

        $set['page'] = $_GET['page'];
        $set['dataId'] = serialize($dataId);
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}

	}
	
	
	
	
	
	
	
		public function gethomeImageListrecent() {
				include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	

		$tableName="tbl_img_list";		
		$limit = 10; 
		
		$query = "SELECT COUNT(*) as num FROM $tableName ";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
		 $total_pages = $total_pages['num'];
		
		$stages = 3;
		$page=0;
		if(isset($_GET['page'])){
		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
		}
		if($page){
			$start = ($page - 1) * $limit; 
		}else{
			$start = 0;	
			}

		 $query="SELECT tbl_img_list.* , tbl_users.name , tbl_img_cat.category_name  FROM tbl_img_list
		LEFT JOIN tbl_img_cat ON tbl_img_list.cid = tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id = tbl_users.id
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where tbl_img_list.status=1 GROUP BY tbl_img_list.id ORDER BY `tbl_img_list`.`id` DESC LIMIT $start, $limit";


		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['category_name'] = $data['category_name'];
			$row['cc_id'] = $data['cc_id'];
			$row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
			$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
			array_push($jsonObj,$row);
		
		}

        $set['page'] = $_GET['page'];
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}

	}
	
	
	
	
	
		public function gethomeImageListpopular() {
				include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	

		$tableName="tbl_img_list";		
		$limit = 10; 
		
		$query = "SELECT COUNT(*) as num FROM $tableName ";
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
		 $total_pages = $total_pages['num'];
		
		$stages = 3;
		$page=0;
		if(isset($_GET['page'])){
		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
		}
		if($page){
			$start = ($page - 1) * $limit; 
		}else{
			$start = 0;	
			}

		 $query="SELECT tbl_img_list.* , tbl_users.name , tbl_img_cat.category_name  FROM tbl_img_list
		LEFT JOIN tbl_img_cat ON tbl_img_list.cid = tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id = tbl_users.id 
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where tbl_img_list.status=1 GROUP BY tbl_img_list.id ORDER BY `tbl_img_list`.`download` ASC LIMIT $start, $limit";


		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['category_name'] = $data['category_name'];
			$row['cc_id'] = $data['cc_id'];
			$row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
			$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
			array_push($jsonObj,$row);
		
		}

        $set['page'] = $_GET['page'];
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}

	}
	
	
	
	public function getImagesearch() {
	    
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	

		$tableName="tbl_img_list";		
		$limit = 10; 
		
	    $query = "SELECT COUNT(*) as num FROM $tableName 
	    LEFT JOIN tbl_img_cat ON tbl_img_list.cid= tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id= tbl_users.id
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where tbl_img_list.status=1 and tbl_img_list.image_name like '%".addslashes($_GET['search_value'])."%' or tbl_img_list.description like '%".addslashes($_GET['search_value'])."%'
		or tbl_img_cat.category_name like '%".addslashes($_GET['search_value'])."%' ";
		
		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
		$total_pages = $total_pages['num'];
		
		$stages = 3;
		$page=0;
		if(isset($_GET['page'])){
		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
		}
		if($page){
			$start = ($page - 1) * $limit; 
		}else{
			$start = 0;	
			}

	     $query="SELECT tbl_img_list.* , tbl_users.name , tbl_img_cat.category_name  FROM tbl_img_list
		LEFT JOIN tbl_img_cat ON tbl_img_list.cid= tbl_img_cat.cid 
		LEFT JOIN tbl_users ON tbl_img_list.user_id= tbl_users.id 
		left join tbl_color on tbl_img_list.cc_id=tbl_color.cc_id
		where tbl_img_list.status=1 and tbl_img_list.image_name like '%".addslashes($_GET['search_value'])."%' or tbl_img_list.description like '%".addslashes($_GET['search_value'])."%'
		or tbl_img_cat.category_name like '%".addslashes($_GET['search_value'])."%'
		ORDER BY tbl_img_list.id DESC LIMIT $start, $limit";


		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['category_name'] = $data['category_name'];
			$row['cc_id'] = $data['cc_id'];
            $row['color_name'] = $data['cc_name'];
			$row['image'] = $data['image'];
			$row['image_name'] = $data['image_name'];
			$row['user_id'] = $data['user_id'];
				$row['name'] = $data['name'];
			$row['description'] = $data['description'];
			$row['download'] = $data['download'];
			$row['status'] = $data['status'];
			array_push($jsonObj,$row);
		
		}

        $set['page'] = $_GET['page'];
        $set['totalimage'] = $total_pages;
        $set['limit'] = '10';
        $set['success'] = '1';
		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
	

	// live wallpaper
	
/*	public function getgifcat() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
 
		$query="SELECT * FROM tbl_gif_cat ORDER BY gid ASC";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
	        $row['gid'] = $data['gid'];
			$row['gif_cat_name'] = $data['gif_cat_name'];
			$row['gid_cat_image'] = $data['gid_cat_image'];
			
			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
	public function getgifList() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
			$cat_id=$_GET['cat_id'];	
			
    		
    		$tableName="tbl_gif_list";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_gif_list.gid='".$cat_id."'";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}

			 $query="SELECT * FROM tbl_gif_list
			LEFT JOIN tbl_gif_cat ON tbl_gif_list.gid= tbl_gif_cat.gid 
			where tbl_gif_list.gid='".$cat_id."' ORDER BY tbl_gif_list.id DESC 	LIMIT $start, $limit";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['id'] = $data['id'];
				$row['gid'] = $data['gid'];
				$row['gif_cat_name'] = $data['gif_cat_name'];
				$row['gif'] = $data['gif'];
				$row['status'] = $data['status'];
				array_push($jsonObj,$row);
			
			}

            $set['page'] = $_GET['page'];
            $set['totalgif'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}*/
	
	
		public function gettrendinggifList() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
		
    		
    		$tableName="tbl_gif_list";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_gif_list.status=1 ";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}

			 $query="SELECT * FROM tbl_gif_list where tbl_gif_list.status=1 ORDER BY `tbl_gif_list`.`download` DESC LIMIT 0, 10";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['id'] = $data['id'];
				$row['gif_name'] = $data['gif_name'];
				$row['gif'] = $data['gif'];
				$row['download'] = $data['download'];
				$row['status'] = $data['status'];
				array_push($jsonObj,$row);
			
			}

            $set['page'] = $_GET['page'];
            $set['totalgif'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
	
	public function gethomgifList() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
		
    		
    		$tableName="tbl_gif_list";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_gif_list.status=1 ";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}

			 $query="SELECT * FROM tbl_gif_list where tbl_gif_list.status=1  ORDER BY tbl_gif_list.id DESC LIMIT $start, $limit";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['id'] = $data['id'];
				$row['gif_name'] = $data['gif_name'];
				$row['gif'] = $data['gif'];
				$row['download'] = $data['download'];
				$row['status'] = $data['status'];
				array_push($jsonObj,$row);
			
			}

            $set['page'] = $_GET['page'];
            $set['totalgif'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}




	// live wallpaper
	
	public function getringtonecat() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
 
		$query="SELECT * FROM tbl_ringtone_cat where status=1 ORDER BY rcid ASC";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
	        $row['rcid'] = $data['rcid'];
			$row['ringtone_cat_name'] = $data['ringtone_cat_name'];
			$row['ringtone_cat_image'] = $data['ringtone_cat_image'];
			
			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
		public function getfeaturedringtonecat() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
 
		$query="SELECT * FROM tbl_ringtone_cat where status=1 and featured=1 ORDER BY rcid ASC";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
	        $row['rcid'] = $data['rcid'];
			$row['ringtone_cat_name'] = $data['ringtone_cat_name'];
			$row['ringtone_cat_image'] = $data['ringtone_cat_image'];
			
			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
	public function getringtoneList() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
			$cat_id=$_GET['cat_id'];	
			
    		
    		$tableName="tbl_ringtone";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_ringtone.r_cat='".$cat_id."' and tbl_ringtone.status=1 ";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}
    	
			 $query="SELECT tbl_ringtone.* , tbl_users.name , tbl_ringtone_cat.ringtone_cat_name  FROM tbl_ringtone
			LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid 
				LEFT JOIN tbl_users ON tbl_ringtone.user_id = tbl_users.id 
			where tbl_ringtone.r_cat='".$cat_id."' and tbl_ringtone.status=1
			ORDER BY tbl_ringtone.rid DESC LIMIT $start, $limit";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['rid'] = $data['rid'];
				$row['r_cat'] = $data['r_cat'];
				$row['ringtone_cat_name'] = $data['ringtone_cat_name'];
				$row['rname'] = $data['rname'];
				$row['ringtone'] = $data['ringtone'];
				$row['user_id'] = $data['user_id'];
					$row['name'] = $data['name'];
				$row['description'] = $data['description'];
				$row['download'] = $data['download'];
				$row['status'] = $data['status'];
				
				array_push($jsonObj,$row);
			
			}

            $set['page'] = $_GET['page'];
            $set['totalringtone'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
	
	public function gethomringtoneList() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
		
    		
    		$tableName="tbl_ringtone";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_ringtone.status=1 ";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}

		
				 $query="SELECT tbl_ringtone.* , tbl_users.name , tbl_ringtone_cat.ringtone_cat_name  FROM tbl_ringtone
			LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid 
				LEFT JOIN tbl_users ON tbl_ringtone.user_id = tbl_users.id 
			where tbl_ringtone.status=1  ORDER BY tbl_ringtone.rid DESC LIMIT $start, $limit";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['rid'] = $data['rid'];
				$row['r_cat'] = $data['r_cat'];
				$row['ringtone_cat_name'] = $data['ringtone_cat_name'];
				$row['rname'] = $data['rname'];
				$row['ringtone'] = $data['ringtone'];
				$row['user_id'] = $data['user_id'];
					$row['name'] = $data['name'];
				$row['description'] = $data['description'];
				$row['download'] = $data['download'];
				$row['status'] = $data['status'];
				
				array_push($jsonObj,$row);
			
			}
		

            $set['page'] = $_GET['page'];
            $set['totalringtone'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}


	public function getringtonesearch() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
			$cat_id=$_GET['cat_id'];	
			
    		
    		$tableName="tbl_ringtone";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName 
    		LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid 
				LEFT JOIN tbl_users ON tbl_ringtone.user_id = tbl_users.id 
    		where tbl_ringtone.status=1 and tbl_ringtone.rname like '%".addslashes($_GET['search_value'])."%' or
    		tbl_ringtone.description like '%".addslashes($_GET['search_value'])."%'
			or tbl_ringtone_cat.ringtone_cat_name like '%".addslashes($_GET['search_value'])."%'";
			
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}
    	
			 $query="SELECT tbl_ringtone.* , tbl_users.name , tbl_ringtone_cat.ringtone_cat_name  FROM tbl_ringtone
			LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid 
				LEFT JOIN tbl_users ON tbl_ringtone.user_id = tbl_users.id 
			where tbl_ringtone.status=1 and tbl_ringtone.rname like '%".addslashes($_GET['search_value'])."%' or tbl_ringtone.description like '%".addslashes($_GET['search_value'])."%'
			or tbl_ringtone_cat.ringtone_cat_name like '%".addslashes($_GET['search_value'])."%'
			ORDER BY tbl_ringtone.rid DESC LIMIT $start, $limit";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['rid'] = $data['rid'];
				$row['r_cat'] = $data['r_cat'];
				$row['ringtone_cat_name'] = $data['ringtone_cat_name'];
				$row['rname'] = $data['rname'];
				$row['ringtone'] = $data['ringtone'];
				$row['user_id'] = $data['user_id'];
					$row['name'] = $data['name'];
				$row['description'] = $data['description'];
				$row['download'] = $data['download'];
				$row['status'] = $data['status'];
				
				array_push($jsonObj,$row);
			
			}

            $set['page'] = $_GET['page'];
            $set['totalringtone'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}



	
    // wallpaper and ringtone upload


	public function imageupload() 
	{
		    include "../includes/connection.php";
		    include('../includes/function.php');
		    
		    $cid =$_POST['cid'];
		      $cc_id =$_POST['cc_id'];
		     $user_id =$_POST['user_id'];
		      $description =$_POST['description'];
		 $image_name =$_POST['image_name'];
		    
            $image=rand(0,99999)."_".$_FILES['image']['name'];
            
            //Main Image
		    $tpath1='../images/'.$image; 		
			$pic1=compress_image($_FILES["image"]["tmp_name"], $tpath1, 80);
		 	$thumbpath='../images/thumbs/'.$image;		
	       	$thumb_pic1=create_thumb_image($tpath1,$thumbpath,'200','200');   
				   
			$qry1="INSERT INTO tbl_img_list (`cid`,`cc_id`,image,image_name, user_id,description,download,status) VALUES ('".$cid."','".$cc_id."','".$image."','".$image_name."','".$user_id."','".$description."',0,0)"; 
						
	           
	       $result1=mysqli_query($mysqli,$qry1);  									 
			$set['video-status-image'][]=array('msg' => "image uploaded successfully...",'success'=>'1');
	       
	 	    $this->response($this->json($set), 200);
	}
		
	
	public function ringtoneupload() 
	{
		    include "../includes/connection.php";
		    include('../includes/function.php');
		    
		    if($_FILES['ringtone']['name'] != ''  and $_POST['rname'] !='' and $_POST['user_id']!='' )
		    {
                 $cat_id =$_POST['cat_id'];
    		     $rname =$_POST['rname'];
    		     $user_id =$_POST['user_id'];
		         $description =$_POST['description'];
    
                $video_url1=rand(0,99999)."_".$_FILES['ringtone']['name'];
        	
        	    $ringtone='ringtone/'.$video_url1;
                  
        		$temp=$_FILES['ringtone']['tmp_name'];
        		$path="../ringtone/".$video_url1;
        		move_uploaded_file($temp,$path);
      
                
                $qry1="INSERT INTO tbl_ringtone (`r_cat`,rname,ringtone,user_id, description, download, status) VALUES ('".$cat_id."','".$rname."','".$ringtone."',
                '".$user_id."','".$description."',0 ,0)"; 
    						
    	        $result1=mysqli_query($mysqli,$qry1);  		
    	        
    			$set['video-status-image'][]=array('msg' => "ringtone uploaded successfully...",'success'=>'1');
		    }else
		    {
		        $set['video-status-image'][]=array('msg' => "something went wrong...",'success'=>'0');

		    }
	 	    $this->response($this->json($set), 200);
	}
	
	public function wallpaper_download_count() {
		include "../includes/connection.php";


        if($_POST['wallpaper_id'] !=""){
            
		$jsonObj= array();	

        $view_qry=mysqli_query($mysqli,"UPDATE tbl_img_list SET download= download + 1 WHERE id = '".$_POST['wallpaper_id']."'");
	
		$set['video-status-image'] = array( 'success' => '1', 'message' => 'wallpaper downloads count updated');;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'success' => 'failed', '0' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}


	}

		public function ringtone_download_count() {
		include "../includes/connection.php";


        if($_POST['ringtone_id'] !=""){
            
		$jsonObj= array();	

        $view_qry=mysqli_query($mysqli,"UPDATE tbl_ringtone SET download= download + 1 WHERE id = '".$_POST['ringtone_id']."'");
	
		$set['video-status-image'] = array( 'success' => '1', 'message' => 'wallpaper downloads count updated');;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'success' => 'failed', '0' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}


	}
	
	
	
	
	public function gettrendinguser() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	
 
		$query="SELECT tbl_users.* , COUNT(tbl_img_list.user_id) as 'total'FROM `tbl_users` LEFT JOIN tbl_img_list ON tbl_users.id = tbl_img_list.user_id where  `tbl_users`.status=1 GROUP BY tbl_users.id  ORDER BY total DESC LIMIT 7";
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
	        $row['id'] = $data['id'];
			$row['login_type'] = $data['login_type'];
			$row['name'] = $data['name'];
			$row['image'] = $data['image'];
			$row['status'] = $data['status'];
			
			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
	
		public function getuserwallpaper() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

        if (isset($_GET['api_key'])) {
    
    		$access_key_received = $_GET['api_key'];
    
    		if ($access_key_received == $api_key) {
    
    		$video_order_by=API_ALL_VIDEO_ORDER_BY;
    
    		$jsonObj= array();	
    		$user_id=$_GET['user_id'];	
    		
    	    $tableName="tbl_img_list";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_img_list.user_id='".$user_id."' and tbl_img_list.status=1 ";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}
    
    		 $query="SELECT tbl_img_list.* , tbl_users.name ,tbl_img_cat.category_name FROM tbl_img_list
    		LEFT JOIN tbl_img_cat ON tbl_img_list.cid= tbl_img_cat.cid 
    	    LEFT JOIN tbl_users ON tbl_img_list.user_id= tbl_users.id 
    		where tbl_img_list.user_id='".$user_id."' and tbl_img_list.status=1 ORDER BY tbl_img_list.id DESC LIMIT $start, $limit";
    
    
    		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
    
    		while($data = mysqli_fetch_assoc($sql))
    		{
    	        $row['id'] = $data['id'];
    			$row['category_name'] = $data['category_name'];
    			$row['image'] = $data['image'];
    			$row['image_name'] = $data['image_name'];
    			$row['user_id'] = $data['user_id'];
    				$row['name'] = $data['name'];
    			$row['description'] = $data['description'];
    			$row['download'] = $data['download'];
    			$row['status'] = $data['status'];
    			
    			array_push($jsonObj,$row);
    		
    		}
                $set['page'] = $_GET['page'];
                $set['totalimage'] = $total_pages;
                $set['limit'] = '10';
            $set['success'] = '1';
    		$set['video-status-image'] = $jsonObj;	
    
     		$this->response($this->json($set), 200);
    
    		} else {
    					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
    					$this->response($this->json($respon), 404);
    				}
    		} else {
    			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
    			$this->response($this->json($respon), 404);
    		}


	}
	
	
		
	public function getuserringtone() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) 
      {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) 
		{

			$video_order_by=API_ALL_VIDEO_ORDER_BY;

			$jsonObj= array();	
			$user_id=$_GET['user_id'];	
			
				$tableName="tbl_ringtone";		
    		$limit = 10; 
    		
    		$query = "SELECT COUNT(*) as num FROM $tableName where tbl_ringtone.user_id='".$user_id."' and tbl_ringtone.status=1 ";
    		$total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
    		$total_pages = $total_pages['num'];
    		
    		$stages = 3;
    		$page=0;
    		if(isset($_GET['page'])){
    		$page = mysqli_real_escape_string($mysqli,$_GET['page']);
    		}
    		if($page){
    			$start = ($page - 1) * $limit; 
    		}else{
    			$start = 0;	
    			}
    	
			 $query="SELECT tbl_ringtone.* , tbl_users.name , tbl_ringtone_cat.ringtone_cat_name FROM tbl_ringtone
			LEFT JOIN tbl_ringtone_cat ON tbl_ringtone.r_cat= tbl_ringtone_cat.rcid 
			 LEFT JOIN tbl_users ON tbl_ringtone.user_id= tbl_users.id 
			where tbl_ringtone.user_id='".$user_id."' and tbl_ringtone.status=1 ORDER BY tbl_ringtone.rid DESC LIMIT $start, $limit";


			$sql = mysqli_query($mysqli,$query)or die(mysqli_error());
			mysqli_query("SET status 'utf8mb4'");

			while($data = mysqli_fetch_assoc($sql))
			{
				$row['rid'] = $data['rid'];
				$row['r_cat'] = $data['r_cat'];
				$row['ringtone_cat_name'] = $data['ringtone_cat_name'];
				$row['rname'] = $data['rname'];
					$row['user_id'] = $data['user_id'];
				$row['name'] = $data['name'];
				$row['ringtone'] = $data['ringtone'];
				$row['status'] = $data['status'];
				
				array_push($jsonObj,$row);
			
			}

            $set['page'] = $_GET['page'];
            $set['totalringtone'] = $total_pages;
            $set['limit'] = '10';
            $set['success'] = '1';
			$set['video-status-image'] = $jsonObj;	
		
			//echo json_encode($this->json($set));die;
	 		$this->response($this->json($set), 200);

		} 
		else
		{
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	
		public function getAllnotification() {
		include "../includes/connection.php";

	    $api_key    = APP_API_KEY;

      if (isset($_GET['api_key'])) {

		$access_key_received = $_GET['api_key'];

		if ($access_key_received == $api_key) {

		$video_order_by=API_ALL_VIDEO_ORDER_BY;

		$jsonObj= array();	

      
     $query="SELECT * FROM tbl_notification ORDER BY tbl_notification.id DESC LIMIT 10";
 

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['date'] = $data['date'];
			$row['msg'] = $data['msg'];
			$row['image'] = $data['image'];
			$row['url'] = $data['url'];

			array_push($jsonObj,$row);
		
		}

		$set['video-status-image'] = $jsonObj;	

 		$this->response($this->json($set), 200);

		} else {
					$respon = array( 'status' => 'failed', 'message' => 'Oops, API Key is Incorrect!');
					$this->response($this->json($respon), 404);
				}
		} else {
			$respon = array( 'status' => 'failed', 'message' => 'Forbidden, API Key is Required!');
			$this->response($this->json($respon), 404);
		}


	}
	

}

?>