<?php include("includes/header.php");

$file_path = 'http://'.$_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']).'/api/';
?>
<div class="row">
      <div class="col-sm-12 col-xs-12">
     	 	<div class="card">
		        <div class="card-header">
		          Example API urls
		        </div>
       			    <div class="card-body no-padding">
         		
         			 <pre><code class="html"><b>Image Category</b><br><?php echo $file_path."get_img_cat?api_key=pXtZkdKQei4hiSgEfLG0pFW2yhAAPDCJCV8x3viuAoSuB"?><br><br><b>image List</b><br><?php echo $file_path."get_img_list?api_key=pXtZkdKQei4hiSgEfLG0pFW2yhAAPDCJCV8x3viuAoSuB"?><br><br><b>Status Category</b><br><?php echo $file_path."get_status_cat?api_key=pXtZkdKQei4hiSgEfLG0pFW2yhAAPDCJCV8x3viuAoSuB"?><br><br><b>Status List</b><br><?php echo $file_path."get_status_list?api_key=pXtZkdKQei4hiSgEfLG0pFW2yhAAPDCJCV8x3viuAoSuB"?><br><br></code></pre>
       		
       				</div>
          	</div>
        </div>
</div>
    <br/>
    <div class="clearfix"></div>
        
<?php include("includes/footer.php");?>       
