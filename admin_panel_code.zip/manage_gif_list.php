<?php
include("includes/header.php");
require("includes/function.php");
require("language/language.php");
?>

<style>
.dropbtn {
background-color: #4e3d69;
    box-shadow: 0 2px 3px rgba(9, 80, 119, 0.3);
    border: 1px solid transparent;
    cursor: pointer;
    display: inline-block;
    font-size: 14px;
    text-align: center;
    vertical-align: middle;
    white-space: nowrap;
    border-radius: 3px;
    border-style: 1px solid;
    margin-bottom: 5px;
    transition: all 0.3s ease 0s;
    padding: 10px 30px;
    color: #ffffff;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 185px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 10;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: center;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {}
</style>

<?php
     //Get all Wallpaper 
	
      $tableName="tbl_gif_list";   
      $targetpage = "manage_gif_list.php"; 
      $limit = 12; 
      
      $query = "SELECT COUNT(*) as num FROM $tableName";
      $total_pages = mysqli_fetch_array(mysqli_query($mysqli,$query));
      $total_pages = $total_pages['num'];
      
      $stages = 3;
      $page=0;
      if(isset($_GET['page'])){
      $page = mysqli_real_escape_string($mysqli,$_GET['page']);
      }
      if($page){
        $start = ($page - 1) * $limit; 
      }else{
        $start = 0; 
        } 
      
    $quotes_qry1 = "SELECT * FROM `tbl_gif_list` ORDER BY `tbl_gif_list`.`id` DESC LIMIT $start, $limit";
 
     $result=mysqli_query($mysqli,$quotes_qry1); 
 
 
 if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}

if (isset($_GET['video_id']) and $_SESSION['TYPE_USERNAME']!=2) {
    $img_res = mysqli_query($mysqli, 'SELECT * FROM tbl_gif_list WHERE id=' . $_GET['video_id'] . '');
    $img_res_row = mysqli_fetch_assoc($img_res);
	
    if($img_res_row['image']!="")
      {
        unlink('GIF/'.$img_res_row['image']);
      }
	
    Delete('tbl_gif_list', 'id=' . $_GET['video_id'] . '');
    
	$_SESSION['msg'] = "12";
    header("Location:manage_gif_list.php");
    exit;
}



?>
    <div class="row">
    <div class="col-xs-12">
        <div class="card mrg_bottom">
            <div class="page_title_block">
                <div class="col-md-5 col-xs-12">
                    <div class="page_title">Manage live walllpaper</div>
                </div>
                <div class="col-md-7 col-xs-12">
                    <div class="search_list">
                        <!--<div class="add_btn_primary"><a href="add_gif.php?add=yes">Add live walllpaper</a></div>-->
                        <div class="dropdown">
                          <button class="dropbtn">Add live walllpaper</button>
                          <div class="dropdown-content">
                            <a href="add_gif.php?add=yes">Upload File(s)</a>
                            <a href="add_gif_link.php?add=yes">GIF Link</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="row mrg-top">
                <div class="col-md-12">
                    <div class="col-md-12 col-sm-12">
                        <?php if (isset($_SESSION['msg'])) { ?>
                            <div class="alert alert-success alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                                            aria-hidden="true">×</span></button>
                                <?php echo $client_lang[$_SESSION['msg']]; ?></a>
                            </div>
                            <?php unset($_SESSION['msg']);
                        } ?>
                    </div>
                </div>
            </div>
            
            
            <?php
            
            if(mysqli_num_rows ($result)==0){
                ?>
            <div class="col-xs-12">
                <div class="col-xs-12" style="height:200px;background: #eeeeeea6;border-radius: 2px;">
                    <div style="position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-family: 'Open Sans', sans-serif;font-size: 1.2em;font-weight: 300;opacity: .8;">
                        Empty Data :(
                        </div>
                        </div>
            </div> 
            <?php }
				$i = 0;
                    while ($row = mysqli_fetch_array($result))
					{					
			?>
				
                <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12" style="margin-bottom: 30px;">
                    <div class="card m-b-30">
                        <div style="height: 300px;width: 100%;position: relative;">
                            <img class="card-img-top img-fluid" src="gif/gif.jpg" alt="Card image cap" style="position: absolute;left: 0;top: 0;z-index: 8;background-size: cover;height: 100%;width: 100%;border-bottom: 1px solid #e8e5e5;float: left;">
                            <div style="position: relative;z-index: 10;">
                            
                            </div>
                        </div>
                        
                        <div class="card-body">
                            <h4 class="card-title font-16 mt-0"><?php echo $row['gif_name'];?> </h4>
                            <?php if (strtolower(substr($row['gif'], 0, 7)) === 'http://' || strtolower(substr($row['gif'], 0, 8)) === 'https://') {?>
                            <a href="<?php echo $row['gif']; ?>" target="_blank" class="btn btn-primary" title="View Live Wallaper" style="padding: 10px 10px;border-radius: 50%;width: 42px;">
                            <?php } else { ?>
                            <a href="<?php echo $file_path.$row['gif']; ?>" target="_blank" class="btn btn-primary" title="View Live Wallaper" style="padding: 10px 10px;border-radius: 50%;width: 42px;">
                            <?php } ?>    
                                <i class="fa fa-external-link text-white"></i></a>
                            <a href="?video_id=<?php echo $row['id']; ?>" class="btn btn-danger" title="Remove" style="padding: 10px 10px;border-radius: 50%;width: 42px;" onclick="return confirm('Are you sure you want to delete this Gif?');">
                                <i class="fa fa-trash-o text-white"></i></a>
                        </div>
                    </div>
                </div>
                <?php
					$i++;}
				?> 
				
            
            <div class="col-md-12 col-xs-12">
                <div class="pagination_item_block">
                    <nav>
                        <?php include("pagination.php"); ?>
                    </nav>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    </div>
<?php
include("includes/footer.php");
?>