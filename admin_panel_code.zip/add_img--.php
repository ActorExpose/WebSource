<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	require_once("thumbnail_images.class.php");

	$cat_qry="SELECT * FROM tbl_img_cat ORDER BY category_name";
	$cat_result=mysqli_query($mysqli,$cat_qry); 
	
	$cat_qry1="SELECT * FROM tbl_color ORDER BY cc_name";
	$cat_result1=mysqli_query($mysqli,$cat_qry1); 
	
	if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}
	
	if(isset($_POST['submit']) and isset($_GET['add']) and $_SESSION['TYPE_USERNAME']!=2)
	{
	
	   //$banner_image=rand(0,99999)."_".$_FILES['banner_image']['name'];
	   $banner_image=rand(0,99999)."_".getName($n);
	   
       //Main Image
       
	   $tpath1='images/'.$banner_image; 			 
       $pic1= compress_image($_FILES["banner_image"]["tmp_name"], $tpath1, 60);
	 
		//Thumb Image 
	   $thumbpath='images/thumbs/'.$banner_image;
	   
	   list($width, $height) = getimagesize($tpath1);
	   
	   $newheight = round($height * (285*100/$width)/100);
	   
       $thumb_pic1=create_thumb_image($tpath1,$thumbpath,'285',$newheight);   
       compress_image($thumbpath, $thumbpath, 20);
          
       $data = array( 
	   			           'cid'  =>  $_POST['cat_id'],
	   			            'cc_id'  =>  $_POST['cc_id'],
			               'image'  =>  $banner_image,
			    	       'image_name'  =>  $_POST['image_name'],
			    	 	   'user_id'  => 1,
			    	 	   'description'  =>  $_POST['description'],
			    	 	   'download'  => 1,
			               'status'  =>  1
			    );		

 		$qry = Insert('tbl_img_list',$data);	

 	   
		$_SESSION['msg']="10"; 
		header( "Location:manage_img_list.php");
		exit;	

		 
		
	}
	
	if(isset($_GET['banner_id']))
	{
			 
			$qry="SELECT * FROM tbl_img_list where id='".$_GET['banner_id']."'";
			$result=mysqli_query($mysqli,$qry);
			$row=mysqli_fetch_assoc($result);

	}
	
	if(isset($_POST['submit']) and isset($_POST['banner_id']) and $_SESSION['TYPE_USERNAME']!=2)
	{
		 
		 if($_FILES['banner_image']['name']!="")
		 {		


				$img_res=mysqli_query($mysqli,'SELECT * FROM tbl_img_list WHERE cid='.$_GET['banner_id'].'');
			    $img_res_row=mysqli_fetch_assoc($img_res);
			

			    if($img_res_row['banner_image']!="")
		        {
					unlink('images/thumbs/'.$img_res_row['banner_image']);
					unlink('images/'.$img_res_row['banner_image']);
			     }

 				   $banner_image=rand(0,99999)."_".getName($n);
		 	 
			       //Main Image
				   $tpath1='images/'.$banner_image; 			 
			       $pic1=compress_image($_FILES["banner_image"]["tmp_name"], $tpath1, 60);
				 
					//Thumb Image 
				   $thumbpath='images/thumbs/'.$banner_image;	
            	   list($width, $height) = getimagesize($tpath1);
            	   
            	   $newheight = round($height * (285*100/$width)/100);
	   
                   $thumb_pic1=create_thumb_image($tpath1,$thumbpath,'285',$newheight); 
                   compress_image($thumbpath, $thumbpath, 20);
      

						
									
									  $data = array( 
	   			 'cid'  =>  $_POST['cat_id'],
	   			 'cc_id'  =>  $_POST['cc_id'],
			    'image'  =>  $banner_image,
			    'image_name'  =>  $_POST['image_name'],
			    'description'  =>  $_POST['description']
			    );	


					$category_edit=Update('tbl_img_list', $data, "WHERE id = '".$_POST['banner_id']."'");

		 }
		 else
		 {

				   	  $data = array( 
	   			 'cid'  =>  $_POST['cat_id'],
	   		     'cc_id'  =>  $_POST['cc_id'],
			     'image_name'  =>  $_POST['image_name'],
			     'description'  =>  $_POST['description']
			    );		

			         $category_edit=Update('tbl_img_list', $data, "WHERE id = '".$_POST['banner_id']."'");

		 }

		     
		$_SESSION['msg']="11"; 
		header( "Location:manage_img_list.php?banner_id=".$_POST['banner_id']);
		exit;
 
	}


?>
<div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title"><?php if(isset($_GET['banner_id'])){?>Edit<?php }else{?>Add<?php }?> Wallpaper</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom"> 
            <form action="" name="addeditcategory" method="post" class="form form-horizontal" enctype="multipart/form-data">
            	<input  type="hidden" name="banner_id" value="<?php echo $_GET['banner_id'];?>" />

              <div class="section">
                <div class="section-body">
				 <div class="form-group">
                    <label class="col-md-3 control-label">image Category :-</label>
                    <div class="col-md-6">
                      <select name="cat_id" id="cat_id" class="select2" required>
                        <option value="">--Select image Category--</option>
          							<?php
          									while($cat_row=mysqli_fetch_array($cat_result))
          									{
          							?>          						 
          							<option value="<?php echo $cat_row['cid'];?>"><?php echo $cat_row['category_name'];?></option>	          							 
          							<?php
          								}
          							?>
                      </select>
                    </div>
                  </div>
            
            
            			 <div class="form-group">
                    <label class="col-md-3 control-label">Color Name :-</label>
                    <div class="col-md-6">
                      <select name="cc_id" id="cc_id" class="select2" required>
                        <option value="">--Select Color Name--</option>
          							<?php
          									while($cat_row1=mysqli_fetch_array($cat_result1))
          									{
          							?>          						 
          							<option value="<?php echo $cat_row1['cc_id'];?>"><?php echo $cat_row1['cc_name'];?></option>	          							 
          							<?php
          								}
          							?>
                      </select>
                    </div>
                  </div>
            
            
            
                <div class="form-group">
                    <label class="col-md-3 control-label"> Image name :-</label>
                    <div class="col-md-6">
                      <input type="text" name="image_name" id="image_name" value="<?php if(isset($_GET['banner_id'])){echo $row['image_name'];}?>" class="form-control" required>
                    </div>
                  </div>   
                                
                  <div class="form-group">
                         <label class="col-md-3 control-label"> Image :-</label>
                
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input type="file" name="banner_image" value="fileupload" id="fileupload"  <?php if(!isset($_GET['banner_id'])) {?>required<?php }?>>
                            <?php if(isset($_GET['banner_id']) and $row['banner_image']!="") {?>
                        	  <div class="fileupload_img"><img type="image" src="images/<?php echo $row['banner_image'];?>" alt="banner image" style="width: 172px;"/></div>
                        	<?php } else {?>
                        	  <div class="fileupload_img"><img type="image" src="assets/images/add-image.png" alt="banner image" /></div>
                        	<?php }?>
                      </div>
                    </div>
                  </div>
            
                      <div class="form-group">
                    <label class="col-md-3 control-label">description (optional) :</label>
                    <div class="col-md-6">
                      <input type="text" name="description" id="description" value="<?php if(isset($_GET['banner_id'])){echo $row['description'];}?>" class="form-control">
                    </div>
                  </div>   
            
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
