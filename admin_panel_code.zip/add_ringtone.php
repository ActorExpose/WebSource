<?php include("includes/header.php");


	require("includes/function.php");
	require("language/language.php");

    if($_SESSION['TYPE_USERNAME']==2){
    	    ?>
    	    <script type="text/javascript">
        
                // Written using ES5 JS for browser support
                window.addEventListener('DOMContentLoaded', function () {
                	// Form elements
                		var title = 'Notification';
                		var message = 'In Mode Preview some process doesnt execute!';
                		var position = 'nfc-bottom-left';
                		var duration = '5000';
                		var theme = 'error';
                		var closeOnClick = false;
                		var displayClose = true;
                
                		if(!message) {
                			message = 'You did not enter a message...';
                		}
                
                		window.createNotification({
                			closeOnClick: closeOnClick,
                			displayCloseButton: displayClose,
                			positionClass: position,
                			showDuration: duration,
                			theme: theme
                		})({
                			title: title,
                			message: message
                		});
                });
    
            </script>
    	    <?php
    	}
	require_once("thumbnail_images.class.php");

	$cat_qry="SELECT * FROM tbl_ringtone_cat ORDER BY rcid";
	$cat_result=mysqli_query($mysqli,$cat_qry); 
	
	
	if(isset($_POST['submit']) and isset($_GET['add']) && $_SESSION['TYPE_USERNAME']!=2)
	{
	
//         $video_url1=rand(0,99999)."_".$_FILES['ringtone']['name'];
// 				$temp=$_FILES['ringtone']['tmp_name'];
// 				$path="ringtone/".$video_url1;
// 				move_uploaded_file($temp,$path);
//         $data = array( 
// 	   			'r_cat'  =>  $_POST['r_cat'],
//                 'rname'  =>  $_POST['rname'],
// 			    'ringtone'  =>  $path,
// 			    'status' =>1
// 		    );		
//  		$qry = Insert('tbl_ringtone',$data);	



 	 
 	   
 	   if(!empty(array_filter($_FILES["ringtone"]["name"]))){
    	    
    	    foreach($_FILES['ringtone']['name'] as $key=>$val){
    	        
    	        $video_url1=rand(0,99999)."_".getName($n).'.mp3';
      
				$temp=$_FILES['ringtone']['tmp_name'][$key];
				$path="ringtone/".$video_url1;
				move_uploaded_file($temp,$path);
				$ext = array(".aif",".aiff",".au.",".flac",".mp3",".m4q",".ogg",".snd",".wav",".w64","_","-");
				if ($_POST['generat']=="yes")
		 	    $rname = ucfirst(str_replace($ext," ",$_FILES['ringtone']['name'][$key]));
		 	    else $rname = $_POST['rname'];
                $data = array( 
        	   			'r_cat'  =>  $_POST['r_cat'],
                        'rname'  =>  $rname,
                        'description' => $_POST['rdesc'],
        			    'ringtone'  =>  $path,
        			    'user_id'  => 1,
        			    'status' =>1
        		    );		
        
         		$qry = Insert('tbl_ringtone',$data);	
    	        
    	        
    	    }
    	    
    	}
 	   
 	   
 	   
 	   
		$_SESSION['msg']="10"; 
		header( "Location:manage_ringtone_list.php");
		exit;	

		 
		
	}
	
	if(isset($_GET['banner_id']))
	{
			 
			$qry="SELECT * FROM tbl_img_list where id='".$_GET['banner_id']."'";
			$result=mysqli_query($mysqli,$qry);
			$row=mysqli_fetch_assoc($result);

	}
	
	

?>

<style>
    .custom-file-input {
  color: transparent;
}
.custom-file-input::-webkit-file-upload-button {
  visibility: hidden;
}
.custom-file-input::before {
  content: 'Select some files';
  color: black;
  display: inline-block;
  background: -webkit-linear-gradient(top, #f9f9f9, #e3e3e3);
  border: 1px solid #999;
  border-radius: 3px;
  padding: 5px 8px;
  outline: none;
  white-space: nowrap;
  -webkit-user-select: none;
  cursor: pointer;
  text-shadow: 1px 1px #fff;
  font-weight: 700;
  font-size: 10pt;
}
.custom-file-input:hover::before {
  border-color: black;
}
.custom-file-input:active {
  outline: 0;
}
.custom-file-input:active::before {
  background: -webkit-linear-gradient(top, #e3e3e3, #f9f9f9); 
}

</style>
<div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title"><?php if(isset($_GET['banner_id'])){?>Edit<?php }else{?>Add<?php }?> Ringtone</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom"> 
            <form action="" name="addeditcategory" method="post" class="form form-horizontal" enctype="multipart/form-data">
            	<input  type="hidden" name="banner_id" value="<?php echo $_GET['banner_id'];?>" />

              <div class="section">
                <div class="section-body">
				 <div class="form-group">
                    <label class="col-md-3 control-label">Ringtone Category : </label>
                    <div class="col-md-6">
                      <select name="r_cat" id="r_cat" class="select2" required>
                        <option value="">--Select Ringtone Category--</option>
          							<?php
          									while($cat_row=mysqli_fetch_array($cat_result))
          									{
          							?>          						 
          							<option value="<?php echo $cat_row['rcid'];?>"><?php echo $cat_row['ringtone_cat_name'];?></option>	          							 
          							<?php
          								}
          							?>
                      </select>
                    </div>
                  </div>
                   
                     <div class="form-group">
                    <label class="col-md-3 control-label">Ringtone Name : </label>
                    <div class="col-md-6">
                        <span style="color: #E91E63;text-transform: capitalize;margin-right: 15px;font-weight: 600;">Generat the name automatically:</span>
                        <input id="r1" type="radio" name="generat"  value="no" style="margin-right: 7px;" checked><span style="font-weight: 600;padding-bottom: 5px;">No</span>
                        <input id="r2" type="radio" name="generat" value="yes" style="margin-left: 10px;margin-right: 7px;"><span style="font-weight: 600;padding-bottom: 5px;">Yes</span>
                        
                        <div id="messgdesc" class="alert alert-info alert-dismissible" role="alert" style="margin-top: 10px;position:absolute;visibility:hidden">
                                The name will be generated like this, for example if the name of file is "love_music_2010.mp3" so the generated name will be "Love music 2010" . (<b>Recommended for multiple files upload</b>)
                        </div>
                        
                        <input type="text" name="rname" id="rname" value="<?php if(isset($_GET['banner_id'])){echo $user_row['rname'];}?>" class="form-control" style="margin-top: 10px;" required>
                    </div>
                  </div>    
                  
                  <div class="form-group">
                    <label class="col-md-3 control-label">Description / tags : </label>
                    <div class="col-md-6">
                      <input type="text" name="rdesc" id="rdesc" value="<?php if(isset($_GET['banner_id'])){echo $user_row['description'];}?>" class="form-control" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-md-3 control-label">Ringtone(s) : </label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                          
                        <input type="file" name="ringtone[]"  value="fileupload" id="fileupload"  <?php if(!isset($_GET['banner_id'])) {?>required<?php }?> style="margin-top:0px" multiple>
                         <!--   <?php if(isset($_GET['banner_id']) and $row['ringtone']!="") {?>-->
                        	<!--  <div class="fileupload_img"><img type="image" src="images/<?php echo $row['ringtone'];?>" alt="banner image" style="width: 172px;"/></div>-->
                        	<!--<?php } else {?>-->
                        	<!--  <div class="fileupload_img"><img type="image" src="assets/images/add-image.png" alt="banner image" /></div>-->
                        	<!--<?php }?>-->
                      </div>
                    </div>
                  </div>
            
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
        
  
<?php include("includes/footer.php");?>  

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script>
     $(document).ready(function () {
         
         $('#r2').click(function(){
             $('#messgdesc').css("visibility","visible"); 
             $('#messgdesc').css("position","relative"); 
             
             $('#rname').css("visibility","hidden");
             $('#rname').css("position","absolute");
             $("#rname").removeAttr("required");
         });
         
         $('#r1').click(function(){
             $('#messgdesc').css("visibility","hidden");
             $('#messgdesc').css("position","absolute");
             $('#rname').css("visibility","visible"); 
             $('#rname').css("position","relative"); 
             $("#rname").attr("required","true");
         });
         
        // $("input[type='button']").click(function(){
        //     var radioValue = $("input[name='generat']:checked").val();
        //     if(radioValue){
        //         alert("yes");
        //         //$('#messgdesc').css("visibility","visible"); 
        //     }else{
        //         alert("no");
        //         //$('#messgdesc').css("visibility","hidden"); 
        //     }
        // });
    });
    
</script>
