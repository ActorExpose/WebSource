<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	
	//Get all Category 
	$qry="SELECT tbl_img_cat.*, COUNT(*) as total  FROM tbl_img_cat , tbl_img_list WHERE tbl_img_cat.cid = tbl_img_list.cid and tbl_img_list.status = 1 GROUP BY tbl_img_cat.cid ORDER BY total DESC";
	$result=mysqli_query($mysqli,$qry);
	
	if(isset($_GET['cat_id']) and $_SESSION['TYPE_USERNAME']!=2 )
	{

		$img_res=mysqli_query($mysqli,'SELECT * FROM tbl_img_cat WHERE cid=\''.$_GET['cat_id'].'\'');
    $img_res_row=mysqli_fetch_assoc($img_res);

    if($img_res_row['image']!="")
      {
        unlink('images/'.$img_res_row['image']);
        unlink('images/thumbs/'.$img_res_row['image']);
      }
 
		Delete('tbl_img_cat','cid='.$_GET['cat_id'].'');
		

		$cat_res=mysqli_query($mysqli,'SELECT * FROM tbl_img_cat WHERE cid=\''.$_GET['cat_id'].'\'');
		$cat_res_row=mysqli_fetch_assoc($cat_res);


		if($cat_res_row['category_image']!="")
	    {
	    	unlink('images/'.$cat_res_row['category_image']);
			  unlink('images/thumbs/'.$cat_res_row['category_image']);

		}
 
		Delete('tbl_category','cid='.$_GET['cat_id'].'');

      
		$_SESSION['msg']="12";
		header( "Location:manage_img_category.php");
		exit;
		
	}	

if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}
  //Active and Deactive status
  if(isset($_GET['status_deactive_id']) and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('status'  =>  '0');
    
    $edit_status=Update('tbl_img_cat', $data, "WHERE cid = '".$_GET['status_deactive_id']."'");
    
     $_SESSION['msg']="14";
     header( "Location:manage_img_category.php");
     exit;
  }
  if(isset($_GET['status_active_id']) and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('status'  =>  '1');
    
    $edit_status=Update('tbl_img_cat', $data, "WHERE cid = '".$_GET['status_active_id']."'");
    
    $_SESSION['msg']="13";
     header( "Location:manage_img_category.php");
     exit;
  }
  
  
  
    //featured categories
  if(isset($_GET['featured_deactive_id']) and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('featured'  =>  '0');
    
    $edit_status=Update('tbl_img_cat', $data, "WHERE cid = '".$_GET['featured_deactive_id']."'");
    
     $_SESSION['msg']="14";
     header( "Location:manage_img_category.php");
     exit;
  }
  if(isset($_GET['featured_active_id']) and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('featured'  =>  '1');
    
    $edit_status=Update('tbl_img_cat', $data, "WHERE cid = '".$_GET['featured_active_id']."'");
    
    $_SESSION['msg']="13";
     header( "Location:manage_img_category.php");
     exit;
  }
	 
?>
                
    <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Wallpaper Categories</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                
                <div class="add_btn_primary"> <a href="add_image_cat.php?add=yes">Add Category</a> </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
            </div>
          
            
            
            <?php
            
            if(mysqli_num_rows ($result)==0){
                ?>
            <div class="col-xs-12">
                <div class="col-xs-12" style="height:200px;background: #eeeeeea6;border-radius: 2px;">
                    <div style="position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-family: 'Open Sans', sans-serif;font-size: 1.2em;font-weight: 300;opacity: .8;">
                        Empty Data :(
                        </div>
                        </div>
            </div> 
            <?php }	
				$i=0;
				while($row=mysqli_fetch_array($result))
				{					
		    ?>
				
                <div class="col-md-4" style="margin-bottom: 30px;">
                    <div class="card mb-3 widget-chart" style="background:url(images/thumbs/<?php echo $row['cat_image'];?>)no-repeat;height: 100%;/* Center and scale the image nicely */background-position: center;background-repeat: no-repeat;background-size: cover;">
                        <div style="background: #000000;position: absolute;left: 0;top: 0;height: 100%;width: 100%;z-index: 1;opacity: .75;filter: grayscale(80%);background-size: cover;"></div>
                        <div class="widget-numbers" style="z-index: 10;color: #fff;position: relative;"><?php echo $row['total'];?></div>
                        <div class="widget-subheading" style="z-index: 10;color: #fff;position: relative;opacity: 1;"><?php echo $row['category_name'];?> Wallpaper</div>
                        <div class="widget-description text-danger" style="z-index: 10;color: #fff;position: relative;opacity: .85;">
                            
                            <a href="add_image_cat.php?banner_id=<?php echo $row['cid'];?>" class="btn btn-transparent" title="Edit" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                <i class="fa fa-edit text-white"></i></a>
                            
                            <?php if($row['status']!="0"){?>
                              <a href="manage_img_category.php?status_deactive_id=<?php echo $row['cid'];?>"  class="btn btn-transparent" title="Disable Visibility" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                  <i class="fa fa-eye text-green" aria-hidden="true"></i></a>
            
                              <?php }else{?>
                              <a href="manage_img_category.php?status_active_id=<?php echo $row['cid'];?>" class="btn btn-transparent" title="Enable Visibility" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                  <i class="fa fa-eye-slash text-red" aria-hidden="true"></i></a>
                            <?php }?>
                            
                            <?php if($row['featured']!="0"){?>
                              <a href="manage_img_category.php?featured_deactive_id=<?php echo $row['cid'];?>" class="btn btn-transparent" title="Disable Featured" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                  <i class="fa fa-rocket text-green" aria-hidden="true"></i></a>
                              <?php }else{?>
                              <a href="manage_img_category.php?featured_active_id=<?php echo $row['cid'];?>" class="btn btn-transparent" title="Enable Featured" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                  <i class="fa fa-rocket text-red" aria-hidden="true"></i></a>
                            <?php }?>
                            
                            <a href="?cat_id=<?php echo $row['cid'];?>" class="btn btn-transparent" title="Remove" onclick="return confirm('Are you sure you want to delete this category and related wallpaper?');" style="padding: 5px 8px;border-radius: 50%;width: 30px;height: 30px;">
                                <i class="fa fa-trash-o text-white"></i></a>
                        </div>
                    </div>
                </div>
          
          
            <?php
						
					$i++;
			     	}
			?> 
          
          
        
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
