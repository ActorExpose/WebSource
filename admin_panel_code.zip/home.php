<?php include("includes/header.php");

$qry_cat="SELECT COUNT(*) as num FROM tbl_img_cat";
$totalimagecat= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat));
$totalimagecat = $totalimagecat['num'];

$qry_colors="SELECT COUNT(*) as num FROM tbl_color";
$totalimagecolors= mysqli_fetch_array(mysqli_query($mysqli,$qry_colors));
$totalimagecolors = $totalimagecolors['num'];


$qry_cat1="SELECT COUNT(*) as num FROM tbl_img_list WHERE status=1";
$totalimglist= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat1));
$totalimglist = $totalimglist['num'];



$qry_gif2="SELECT COUNT(*) as num FROM tbl_gif_list";
$totalvideolist2 = mysqli_fetch_array(mysqli_query($mysqli,$qry_gif2));
$totalgiflist = $totalvideolist2['num'];

$qry_cat2="SELECT COUNT(*) as num FROM tbl_img_list WHERE status=0";
$totalimglist2= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat2));
$totalunimglist2 = $totalimglist2['num'];
 

 $tbl_users="SELECT COUNT(*) as num FROM tbl_users WHERE status=1";
$tbl_users = mysqli_fetch_array(mysqli_query($mysqli,$tbl_users));
$tbl_users = $tbl_users['num'];





$qry_cat_ringtone="SELECT COUNT(*) as num FROM tbl_ringtone_cat";
$totalringtoneecat= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat_ringtone));
$totalringtoneecat = $totalringtoneecat['num'];


$qry_ringtones="SELECT COUNT(*) as num FROM tbl_ringtone WHERE status=1";
$totalringtoneslist= mysqli_fetch_array(mysqli_query($mysqli,$qry_ringtones));
$totalringtoneslist = $totalringtoneslist['num'];

$qry_ringtones_hidden="SELECT COUNT(*) as num FROM tbl_ringtone WHERE status=0";
$totalunapprovedringtoneslist= mysqli_fetch_array(mysqli_query($mysqli,$qry_ringtones_hidden));
$totalunapprovedringtoneslist = $totalunapprovedringtoneslist['num'];


?>       


	
<div class="row">
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 bg-primary widget-chart text-white card-border">
            <a href="manage_img_category.php" style="color:#ffffff">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-sitemap text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalimagecat;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Wallpaper Categories</div>
            </a>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 bg-success widget-chart text-white card-border">
            <a href="manage_img_list.php" style="color:#ffffff">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-image text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalimglist;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Wallpapers Total</div>
            </a>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 bg-warning widget-chart text-white card-border">
            <a href="manage_img_approval.php" style="color:#ffffff">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-check-square-o text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalunimglist2;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Unapprove Wallpapers</div>
            </a>
        </div>
    </div>
      
    

        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 bg-focus widget-chart text-white card-border">
                <a href="manage_color.php" style="color:#ffffff">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-paint-brush text-white"></i></div>
                <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalimagecolors;?>" data-speed="2000" >0</div>
                <div class="widget-subheading">Colors Total</div>
                </a>
                
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 bg-danger widget-chart text-white card-border">
                <a href="manage_gif_list.php" style="color:#ffffff">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-film text-white"></i></div>
                <div class="timer widget-numbers" data-from="0" data-to="<?php echo $totalgiflist;?>" data-speed="2000" >0</div>
                <div class="widget-subheading">Live Wallpaper</div>
                </a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 bg-info widget-chart text-white card-border">
                <a href="manage_users.php" style="color:#ffffff">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-user text-white"></i></div>
                <div id="timer" class="widget-numbers timer" data-from="0" data-to="<?php echo $tbl_users;?>" data-speed="2000" data-refresh-interval="5">0</div>
                <div class="widget-subheading">Number Of Users</div>
                </a>
            </div>
        </div>
        
        
        
        
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 widget-chart text-white card-border" style="background-color:#68af1b">
                <a href="manage_ringtone_category.php" style="color:#ffffff">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-sitemap text-white"></i></div>
                <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalringtoneecat;?>" data-speed="2000" >0</div>
                <div class="widget-subheading">Ringtones Categories</div>
                </a>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 widget-chart text-white card-border" style="background-color:#7e22ad">
            <a href="manage_ringtone_list.php" style="color:#ffffff">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-music text-white"></i></div>
                        <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalringtoneslist;?>" data-speed="2000" >0</div>
                        <div class="widget-subheading">Ringtones Total</div>
                        </a>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 widget-chart text-white card-border" style="background-color:#791c4c">
            <a href="manage_approval_ringtone_list.php" style="color:#ffffff">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-check-square-o text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalunapprovedringtoneslist;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Unapprove Ringtones</div>
            </a>
        </div>
    </div>
        
	<!--   <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"> <a href="manage_gif_list.php" class="card card-banner card-yellow-light">-->
 <!--       <div class="card-body"> <i class="icon fa fa-users fa-4x"></i>-->
 <!--         <div class="content">-->
 <!--           <div class="title">live wallpaper</div>-->
 <!--           <div class="value"><span class="sign"></span>
 <!--<?php echo $totalgiflist;?></div>-->
 <!--         </div>-->
 <!--       </div>-->
 <!--       </a> -->
	<!--</div> -->
	
	<!-- <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"> <a href="manage_users.php" class="card card-banner card-yellow-light">-->
 <!--       <div class="card-body"> <i class="icon fa fa-users fa-4x"></i>-->
 <!--         <div class="content">-->
 <!--           <div class="title">user</div>-->
 <!--           <div class="value"><span class="sign"></span>
 <!--<?php  echo $tbl_users;?></div>-->
 <!--         </div>-->
 <!--       </div>-->
 <!--       </a> -->
	<!--</div> -->
      	</div>   
<?php include("includes/footer.php");?>       

 <script type="text/javascript">
  $('.timer').countTo();
</script>