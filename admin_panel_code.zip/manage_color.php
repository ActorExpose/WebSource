<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	
	//Get all Category 
	$qry="SELECT * FROM tbl_color";
	$result=mysqli_query($mysqli,$qry);
	
	if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}
	if(isset($_GET['cc_id']) and $_SESSION['TYPE_USERNAME']!=2)
	{

		$img_res=mysqli_query($mysqli,'SELECT * FROM tbl_color WHERE cc_id=\''.$_GET['cc_id'].'\'');
    $img_res_row=mysqli_fetch_assoc($img_res);

    if($img_res_row['cc_image']!="")
      {
        unlink('images/'.$img_res_row['cc_image']);
        unlink('images/thumbs/'.$img_res_row['cc_image']);
      }
 
		Delete('tbl_color','cc_id='.$_GET['cc_id'].'');
		

		$cat_res=mysqli_query($mysqli,'SELECT * FROM tbl_color WHERE cc_id=\''.$_GET['cc_id'].'\'');
		$cat_res_row=mysqli_fetch_assoc($cat_res);


      
		$_SESSION['msg']="12";
		header( "Location:manage_color.php");
		exit;
		
	}	


  //Active and Deactive status
  if(isset($_GET['status_deactive_id']) and $_SESSION['TYPE_USERNAME']!=2)
  {
    $data = array('cc_status'  =>  '0');
    
    $edit_status=Update('tbl_color', $data, "WHERE cc_id = '".$_GET['status_deactive_id']."'");
    
     $_SESSION['msg']="14";
     header( "Location:manage_color.php");
     exit;
  }
  if(isset($_GET['status_active_id']) and $_SESSION['TYPE_USERNAME']!=2 )
  {
    $data = array('cc_status'  =>  '1');
    
    $edit_status=Update('tbl_color', $data, "WHERE cc_id = '".$_GET['status_active_id']."'");
    
    $_SESSION['msg']="13";
     header( "Location:manage_color.php");
     exit;
  }
  
  
 
	 
?>
                
    <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Color</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                
                <div class="add_btn_primary"> <a href="add_color.php?add=yes">Add Color</a> </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          
          <div class="row">
              <div class="col-md-12 mrg-top">
    	     <?php
            
            if(mysqli_num_rows ($result)==0){
                ?>
            <div class="col-xs-12">
                <div class="col-xs-12" style="height:200px;background: #eeeeeea6;border-radius: 2px;">
                    <div style="position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-family: 'Open Sans', sans-serif;font-size: 1.2em;font-weight: 300;opacity: .8;">
                        Empty Data :(
                        </div>
                        </div>
            </div> 
            <?php }
					$i=0;
					while($row=mysqli_fetch_array($result))
					{					
			?>
				
                <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12" style="margin-bottom: 30px;">
                    <div class="card m-b-30">
                        <div style="height: 285px;width: 100%;position: relative;">
                            <img class="card-img-top img-fluid" src="images/thumbs/<?php echo $row['cc_image'];?>" alt="Card image cap" style="position: absolute;left: 0;top: 0;z-index: 8;background-size: cover;height: 100%;width: 100%;border-bottom: 1px solid #e8e5e5;float: left;">
                            <!--<a href="manage_color.php?status_deactive_id=<?php echo $row['cc_id'];?>" title="Change Status" style=""><span class="badge badge-success badge-icon" style="width: 100%;">-->
                            <!--    <i class="fa fa-check" aria-hidden="true" style="float: left;"></i><span style="display: block;">Enable</span></span></a>-->
                              <div style="position: relative;z-index: 10;">
                            
                            </div>
                        </div>
                        
                <!--        <div class="icon-wrapper rounded-circle">-->
                <!--<div class="icon-wrapper-bg bg-white opacity-1"></div>-->
                <!--<i class="fa fa-sitemap text-white"></i></div>-->
                        
                        <div class="card-body">
                            <h4 class="card-title font-16 mt-0"><?php echo $row['cc_name'];?></h4>
                            <!--<a href="#" data-id="18" class="btn btn-danger waves-effect waves-light sa-warning" id="sa-warning" style="display: none">Delete</a>-->
                            <!--<span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="" data-custom-class="tooltip-danger" data-original-title="Disabled on demo">-->
                            <!--            <button class="btn btn-danger waves-effect waves-light" type="button" style="pointer-events: none;" disabled="">Delete</button>-->
                            <!--</span>-->
                            <!--<a href="edit_category.php?cid=18" class="btn btn-success waves-effect waves-light">Edit</a>-->
                            <a href="add_color.php?cc_id=<?php echo $row['cc_id'];?>" class="btn btn-primary" title="Edit" style="padding: 10px 10px;border-radius: 50%;width: 42px;">
                                <i class="fa fa-edit text-white"></i></a>
                            <?php if($row['cc_status']!="0"){?>
                            <a href="manage_color.php?status_deactive_id=<?php echo $row['cc_id'];?>" title="Disable Visibility" class="btn btn-success" style="padding: 10px 10px;border-radius: 50%;width: 42px;">
                                <i class="fa fa-eye text-white" style="color: #fff !important;"></i></a>
                              <?php }else{?>
                              <a href="manage_color.php?status_active_id=<?php echo $row['cc_id'];?>" title="Enable Visibility" class="btn btn-default" style="padding: 10px 10px;border-radius: 50%;width: 42px;">
                                  <i class="fa fa-eye-slash text-white" style="color: #f12516 !important;"></i></a>
                            <?php }?>
                            <a href="?cc_id=<?php echo $row['cc_id'];?>" class="btn btn-danger" title="Remove" style="padding: 10px 10px;border-radius: 50%;width: 42px;" onclick="return confirm('Are you sure you want to delete this category and related wallpaper?');"><i class="fa fa-trash-o text-white"></i></a>
 
                            
                        </div>
                    </div>
                </div>
                <?php
						
						$i++;
				     	}
				?> 
				</div>
            </div>
            

           
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
