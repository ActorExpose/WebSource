<?php
/**
 * CoinTable
 *
 * A content management system for cryptocurrency related information.
 *
 * This content is released under the CodeCanyon Standard Licenses.
 *
 * Copyright (c) 2017 - 2018, RunCoders
 *
 *
 * @package   CoinTable
 * @link	  http://cointable.runcoders.com
 * @author    RunCoders
 * @license	  https://codecanyon.net/licenses/standard?ref=RunCoders
 * @copyright Copyright (c) 2017 - 2018, RunCoders (https://runcoders.com)
 * @since	  Version 2.0
 *
 */

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class CT_Controller
 *
 * @package		CoinTable
 * @subpackage	Core
 * @category    Controllers
 * @author		RunCoders
 */

class CT_Controller extends CI_Controller {

    /**
     * If true, timezone will be defined on constructor
     *
     * @var bool
     */
    protected $set_timezone = true;

    /**
     * If true, timezone will be defined on constructor
     *
     * @var bool
     */
    protected $set_default_lang = true;


    /**
     * CT_Controller constructor.
     *
     */
    public function __construct()
    {
        parent::__construct();

        if ($this->set_timezone) $this->coin_table->setTimeZone();
        if ($this->set_default_lang) $this->coin_table->setDefaultLang();
    }

    // --------------------------------------------------------------------

    /**
     * Load Ion Auth shorter
     */

    protected function loadAuth()
    {
        $this->load->library('ion_auth');
    }

    // --------------------------------------------------------------------

    /**
     * Generate CSRF nonce
     *
     * @return array
     */

    public function _get_csrf_nonce()
    {
        $this->load->helper('string');
        $key   = random_string('alnum', 8);
        $value = random_string('alnum', 20);
        $this->session->set_flashdata('csrfkey', $key);
        $this->session->set_flashdata('csrfvalue', $value);

        return array($key => $value);
    }

    // --------------------------------------------------------------------

    /**
     * Validates CSRF nonce
     * @return bool
     */

    public function _valid_csrf_nonce()
    {
        $csrfkey = $this->input->post($this->session->flashdata('csrfkey'));
        if ($csrfkey && $csrfkey == $this->session->flashdata('csrfvalue'))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    // --------------------------------------------------------------------

    /**
     * Render page
     *
     * @param string $view
     * @param array|null $data
     * @param bool $returnhtml
     *
     * @return mixed
     */

    public function _render_page($view, $data=null, $returnhtml=false)//I think this makes more sense
    {

        $this->viewdata = (empty($data)) ? $this->data: $data;

        $view_html = $this->load->view($view, $this->viewdata, $returnhtml);

        if ($returnhtml) return $view_html;//This will return html on 3rd argument being true
    }

    // --------------------------------------------------------------------

    /**
     * Decodes input JSON
     *
     * @return mixed
     */

    protected function getJson()
    {
        $data = $this->input->raw_input_stream;
        return json_decode($data, true);
    }

    // --------------------------------------------------------------------

    /**
     * Ensures all keys in array
     *
     * @param array $array
     * @param array $keys
     *
     * @return bool
     */

    protected function areSet($array, $keys)
    {
        foreach ($keys as $key){
            if(!array_key_exists($key, $array))
                return false;
        }
        return true;
    }

    // --------------------------------------------------------------------

    /**
     * Sets CORS headers
     *
     */

    protected function corsHeaders()
    {
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
        $this->output->set_header('Cache-Control: post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header('Access-Control-Allow-Origin: *');
        $this->output->set_header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method');
        $this->output->set_header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
    }

    // --------------------------------------------------------------------

    /**
     * Encodes data to JSON and outputs it
     * Also sets the response status
     *
     * @param mixed $res
     * @param int|bool $status
     * @param string|array|null $headers
     */

    protected function sendJson($res = null, $status = 200, $headers = null)
    {
        // for easier control
        if($status === true) $status = 200;
        if($status === false) $status = 404;

        // set custom headers if defined
        if(is_array($headers)){
            foreach ($headers as $header){
                $this->output->set_header($header);
            }
        }
        elseif (is_string($headers)){
            $this->output->set_header($headers);
        }

        // Send JSON response
        $this->output
            ->set_content_type('application/json')
            ->set_status_header($status)
            ->set_output(json_encode($res, JSON_NUMERIC_CHECK))
            ->_display();
        exit;
    }
}
