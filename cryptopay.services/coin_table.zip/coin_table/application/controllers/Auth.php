<?php
/**
 * CoinTable
 *
 * A content management system for cryptocurrency related information.
 *
 * This content is released under the CodeCanyon Standard Licenses.
 *
 * Copyright (c) 2017 - 2018, RunCoders
 *
 *
 * @package   CoinTable
 * @link	  http://cointable.runcoders.com
 * @author    RunCoders
 * @license	  https://codecanyon.net/licenses/standard?ref=RunCoders
 * @copyright Copyright (c) 2017 - 2018, RunCoders (https://runcoders.com)
 * @since	  Version 2.0
 *
 */

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Auth
 *
 * @package		CoinTable
 * @subpackage	Controllers
 * @author		RunCoders
 */


class Auth extends CT_Controller {

    /**
     * Auth constructor.
     *
     * Loads Ion Auth, Form Validation, Language
     */

	public function __construct()
	{
		parent::__construct();

        $this->load->library(array('ion_auth','form_validation'));
        $this->load->helper('language');
        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));
		$this->lang->load('auth');
	}

    // --------------------------------------------------------------------

    /**
     * Defines redirection rules based on logged user or visitor
     *
     */
	public function index()
	{
		if ($this->ion_auth->is_admin()) // Administrators have access to Admin Panel
		{
			redirect('admin/', 'refresh');
		}
		elseif ($this->ion_auth->logged_in()) // Non-admin users will get a error message (you can redirect to a different workspace)
		{
			show_error('You must be an administrator to view this page.');
		}
		else // Visitors will be redirect to login
		{
            redirect('admin/', 'refresh');
		}
	}

    // --------------------------------------------------------------------

	/**
     * log the user in
     */

	public function login()
	{
		$this->data['title'] = $this->lang->line('login_heading');

		//validate form input
		$this->form_validation->set_rules('identity', str_replace(':', '', $this->lang->line('login_identity_label')), 'required');
		$this->form_validation->set_rules('password', str_replace(':', '', $this->lang->line('login_password_label')), 'required');

		if ($this->form_validation->run() == true)
		{
			// check to see if the user is logging in
			// check for "remember me"
			$remember = (bool) $this->input->post('remember');

			if ($this->ion_auth->login($this->input->post('identity'), $this->input->post('password'), $remember))
			{
				//if the login is successful
				//redirect them back to the home page
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect('/auth', 'refresh');
			}
			else
			{
				// if the login was un-successful
				// redirect them back to the login page
				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect('auth/login', 'refresh'); // use redirects instead of loading views for compatibility with MY_Controller libraries
			}
		}
		else
		{
			// the user is not logging in so display the login page
			// set the flash data error message if there is one
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

			$this->data['identity'] = array('name' => 'identity',
				'id'    => 'identity',
				'type'  => 'text',
				'value' => $this->form_validation->set_value('identity'),
			);
			$this->data['password'] = array('name' => 'password',
				'id'   => 'password',
				'type' => 'password',
			);

			$this->_render_page('auth/login', $this->data);
		}
	}

    // --------------------------------------------------------------------

	// log the user out
	public function logout()
	{
		$this->data['title'] = "Logout";

		// log the user out
		$logout = $this->ion_auth->logout();

		// redirect them to the login page
		$this->session->set_flashdata('message', $this->ion_auth->messages());
		redirect('auth/login', 'refresh');
	}
}
