<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<?php if($header_top_html) : ?>
    <div class="ui basic segment">
        <?php echo $header_top_html; ?>
    </div>
<?php endif; ?>

<div class="ui basic segment container">
    <h1 class="ui centered header">
        <?php _et($title); ?>
        <div class="sub header"><?php _et($subtitle); ?></div>
    </h1>
</div>

<?php if($header_bottom_html) : ?>
    <div class="ui basic segment">
        <?php echo $header_bottom_html; ?>
    </div>
<?php endif; ?>

<div class="ui container">

    <table id="exchange-table" class="ui attached large selectable very basic table">
        <thead>
        <tr>
            <th colspan="2"><?php et('name'); ?></th>
            <th><?php et('description'); ?></th>
            <th><?php et('volume_24h'); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($pagination->items as $exchange) : ?>

            <tr class="item">
                <td>
                    <a class="ui mini rounded image" target="_blank" href="<?php echo $exchange->url; ?>">
                        <img src="<?php echo $exchange->image; ?>">
                    </a>
                </td>

                <td class="content"><a target="_blank" href="<?php echo $exchange->url; ?>" class="ui header"><?php echo $exchange->name; ?></a></td>

                <td><?php echo str_replace("\n",'<br>', $exchange->description); ?></td>

                <td class="right aligned single line volume"><?php echo $exchange->trade_volume; ?></td>
            </tr>

        <?php endforeach; ?>
        </tbody>
        <?php if($pagination->pages > 1) :?>
        <tfoot>
        <tr>
            <td colspan="4"><?php paginationMenu($pagination, $redirect); ?></td>
        </tr>
        </tfoot>
        <?php endif; ?>
    </table>

</div>

<?php if($after_html) : ?>
    <div class="ui basic segment">
        <?php echo $after_html; ?>
    </div>
<?php endif; ?>



