<?php
/**
 * CoinTable
 *
 * A content management system for cryptocurrency related information.
 *
 * This content is released under the CodeCanyon Standard Licenses.
 *
 * Copyright (c) 2017 - 2018, RunCoders
 *
 *
 * @package   CoinTable
 * @link	  http://cointable.runcoders.com
 * @author    RunCoders
 * @license	  https://codecanyon.net/licenses/standard?ref=RunCoders
 * @copyright Copyright (c) 2017 - 2018, RunCoders (https://runcoders.com)
 * @since	  Version 2.0
 *
 */

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Options_model
 *
 * @package		CoinTable
 * @subpackage	Models
 * @author		RunCoders
 */

class Options_model extends CT_Model
{

    /**
     * Reads an option content by name
     *
     * @param string $name
     * @param mixed $content
     * @param bool $cache
     *
     * @return bool
     */

    public function readOption($name, &$content, $cache = true)
    {
        if(!$this->readCache($name, $content, $cache)) { // if not cached
            $query = $this->db->get_where($this->table_name, array('name' => $name)); // database query
            $result = $query->row(); // result as object

            if(isset($result)) { // if exists
                $content = unserialize($result->content); // unserialize content
                if($cache) $this->cached[$name] = $content; // cache it if enabled
            }
            else return false; // failure
        }

        return true; // success
    }

    // --------------------------------------------------------------------

    /**
     * Saves an option content
     *
     * @param string $name
     * @param mixed $content
     * @param bool $cache
     *
     * @return bool
     */

    public function saveOption($name, $content, $cache = true)
    {
        // prepare data for database query
        $entry = array(
            'name'      => $name,
            'content'   => serialize($content)
        );

        // execute replace query
        if($this->db->replace($this->table_name, $entry)) { // was inserted
            if($cache) $this->cached[$name] = $content; // cache it if enabled
            return true; // success
        }

        return false; // failure
    }

    // --------------------------------------------------------------------

    /**
     * Removes an option by name
     *
     * @param string $name
     *
     * @return bool
     */

    public function dropOption($name)
    {
        return $this->db->delete($this->table_name, array('name' => $name));
    }
}