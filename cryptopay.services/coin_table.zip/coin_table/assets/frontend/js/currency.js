'use strict';

/****************************************************************
 *                                                              *
 *                        Currency Script                       *
 *                                                              *
 ****************************************************************/

(function (CONSTANTS,$,fx,echarts) {


    //----------------------------------------------------------

    var Currency = {

        elements: {
            document: null,
            price: null,
            chart_wrapper: null,
            chart: null,
            chart_menu: null,
            converter: null
        },

        converter_options: {
            slug: null,
            multiple: 1
        },

        chart: null,

        // echarts options
        chart_options: {
            animation: false,
            dataset: {
                source: null
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {type: 'cross'}
            },
            axisPointer: {
                link: {xAxisIndex: 'all'},
                label: {backgroundColor: '#777'}
            },
            toolbox: {
                feature: {
                    restore: {title: ' '},
                    saveAsImage: {title: ' '}
                }
            },
            grid: [
                {
                    left: '3%',
                    right: '4%',
                    bottom: 200
                },
                {
                    left: '3%',
                    right: '4%',
                    height: 80,
                    bottom: 80
                }
            ],
            dataZoom: [
                {
                    type: 'inside',
                    xAxisIndex: [0, 1]
                },
                {
                    show: true,
                    xAxisIndex: [0, 1],
                    type: 'slider',
                    bottom: 10,
                    handleIcon: 'M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%'
                }
            ],
            legend: {
                data:[CONSTANTS.chart.price.label,CONSTANTS.chart.market_cap.label,CONSTANTS.chart.volume.label]
            },
            xAxis: [
                {
                    type: 'category',
                    scale: true,
                    boundaryGap : false,
                    splitLine: {show: false}
                },
                {
                    type: 'category',
                    gridIndex: 1,
                    scale: true,
                    boundaryGap : false,
                    axisTick: {show: false},
                    splitLine: {show: false},
                    axisLabel: {show: false}
                }
            ],
            yAxis: [
                {

                    type: 'value',
                    axisTick: { show: false },
                    axisLine: {show: false},
                    axisLabel: {inside: true},
                    min: 'dataMin'
                },
                {
                    position: 'right',
                    type: 'value',
                    axisTick: { show: false },
                    axisLine: {show: false},
                    splitLine: {show: false},
                    axisLabel: {inside: true},
                    min: 'dataMin'
                },
                {
                    scale: true,
                    gridIndex: 1,
                    axisLabel: {show: false},
                    axisLine: {show: false},
                    axisTick: {show: false},
                    splitLine: {show: false}
                }
            ],
            series: [
                {
                    type:'line',
                    name: CONSTANTS.chart.price.label,
                    symbol: 'none',
                    itemStyle: {color: CONSTANTS.chart.price.color},
                    encode: {x: 0, y: 1}
                },
                {
                    type:'line',
                    name: CONSTANTS.chart.market_cap.label,
                    symbol: 'none',
                    yAxisIndex: 1,
                    itemStyle: {color: CONSTANTS.chart.market_cap.color},
                    encode: {x: 0, y: 2}
                },
                {
                    type: 'bar',
                    name: CONSTANTS.chart.volume.label,
                    xAxisIndex: 1,
                    yAxisIndex: 2,
                    itemStyle: {color: CONSTANTS.chart.volume.color},
                    encode: {x: 0, y: 3}
                }
            ]
        },

        chart_datasets: {},

        init: function () {
            var elements = this.elements;

            if(CONSTANTS.coin.tracking) { // custom asset corrections
                this.converter_options.slug = CONSTANTS.coin.tracking[0];
                this.converter_options.multiple = parseFloat(CONSTANTS.coin.tracking[1]);
            }
            else {
                this.converter_options.slug = CONSTANTS.coin.slug;
            }

            this.initChart();

            elements.document.on('fxready', function () { // fx ready for conversion
                Currency.initConverter();
            });

        },

        dateFormat: function (date) {
            return echarts.format.formatTime('yyyy-MM-dd\nhh:mm',new Date(date));
        },

        initChart: function () {
            var elements = this.elements;

            if(!elements.chart.length) return;

            this.chart = echarts.init(elements.chart[0], {width: 'auto', height: 'auto'});

            var active_dataset = this.elements.chart_menu.find('.item.active').data('dataset');

            this.downloadChartData(active_dataset, function (data) {
                Currency.chart_options.dataset.source = data;
                Currency.chart.setOption(Currency.chart_options);
            });

            this.initChartEvents();
        },

        updateChart: function(dataset) {
            if(this.chart_datasets[dataset]) {
                // replace dataset
                this.chart.setOption({
                    dataset: {
                        source: Currency.chart_datasets[dataset]
                    }
                });

                // force reset on zoom
                this.chart.dispatchAction({
                    type: 'dataZoom',
                    start: 0,
                    end: 100
                });
            }
        },

        downloadChartData: function (dataset, callback) {

            // if already downloaded
            if(this.chart_datasets[dataset]) {
                return callback && callback(this.chart_datasets[dataset]);
            }

            var slug = this.converter_options.slug,
                currency = CONSTANTS.chart.currency,
                multiple = Currency.converter_options.multiple,
                url = CONSTANTS.urls.api + '/chart_data/'+slug+'/'+dataset+'/'+currency+'/?multiple='+multiple;

            var elements = this.elements;

            elements.chart_wrapper.addClass('loading'); // show loading state

            $.getJSON(url, function (data) {
                Currency.chart_datasets[dataset] = data; // save
                callback && callback(data);
            }).always(function() {
                elements.chart_wrapper.removeClass('loading'); // disable loading state
            });
        },

        initChartEvents: function () {
            var items = this.elements.chart_menu.find('.item');

            items.click(function () { // dataset switch
                items.removeClass('active');

                var item = $(this),
                    dataset = item.data('dataset');

                Currency.downloadChartData(dataset, function () {
                    Currency.updateChart(dataset);
                });

                item.addClass('active');
            });

            // adjust chart dimensions on screen resizing
            $(window).on('resize', function () {
                if(Currency.chart)
                    Currency.chart.resize({
                        width: 'auto',
                        height: 'auto'
                    });
            });
        },

        initConverter: function () {
            var elements = this.elements,
                converter = elements.converter,
                currency = CONSTANTS.price_currency,
                slug = this.converter_options.slug,
                multiple = this.converter_options.multiple;

            if(!converter.length) return;

            var left = converter.find('.input-left'),
                right = converter.find('.input-right');

            // initial values
            right.val(fx._priceFormat(fx(parseFloat(left.val())).from(slug).to(currency) * multiple));

            // convert on input events
            left.on('change paste keyup', function() {
                var value = parseFloat(left.val());
                right.val(fx._priceFormat(fx(value).from(slug).to(currency) * multiple));
            });

            right.on('change paste keyup', function() {
                var value = parseFloat(right.val());
                left.val(fx._priceFormat(fx(value).from(currency).to(slug) * multiple));
            });

        }
    };

    $(function () {
        var elements = Currency.elements;

        // collect DOM elements

        elements.document = $(document);
        elements.price = $('#currency-price');
        elements.chart_wrapper = $('#currency-chart-wrapper');
        elements.chart = $('#currency-chart');
        elements.chart_menu = $('#currency-chart-menu');
        elements.converter = $('#currency-converter');

        Currency.init();
    });


})(window.CoinTableConstants,jQuery,fx,echarts);