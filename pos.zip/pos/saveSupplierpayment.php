<?php
include('connect.php');
$date = $_POST['date'];
if($date!=""){
$date = $_POST['date'];	
}else{
$date=date("Y-m-d");	
}		
$suplier_id = $_POST['suplier_id'];
$orderno = $_POST['orderno'];
$amount = $_POST['amount'];
$comments = $_POST['comments'];
$salesman = $_REQUEST['salesman'];
$status="2";

if($comments!=""){
$comments=$comments;
}else{
$comments="Supplier Payment Received";	
}
// Save Customer Payments In Credit

$Query3="INSERT INTO
  suplier_ledger(
  purchase_id,
  `date`,
  GIVE_AMOUNT,
  status,
  comments,
  salesman,
  suplier_id)
		VALUES(
		   '$orderno',
		   '$date',
		   '$amount',
		   '$status',
		   '$comments',
		   '$salesman',	   
		   '$suplier_id')";
	   $result3=mysql_query($Query3);

header("location: addSupplierpayment.php");

?>