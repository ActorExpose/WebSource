<?php
/*require_once('auth.php');*/
include_once('embbed_js_code.php');
include('connect.php');

$lines = isset($_REQUEST['lines'])? $_REQUEST['lines']: 5 ;

if(isset($_REQUEST['task']) && $_REQUEST['task']=='task' && $_REQUEST['Submit']=='Save' && $_REQUEST['customerid']!=""){

$lines = $_REQUEST['lines'];
$id = $_REQUEST['customerid']; // Customer Id
$date = $_REQUEST['date'];

$Delete_Query="DELETE
FROM
  pricelist
WHERE
  pricelist.customer_id = '$id' ";
$result=mysql_query($Delete_Query);

if($date!=""){
$date = $_REQUEST['date'];	
$year=date("Y");
}else{
$date=date("Y-m-d");
$year=date("Y");	
}	


for($i=1;$i<=$lines;$i++){
if($_REQUEST['itemid'.$i]!=""){
$Query="INSERT INTO
pricelist(
Product_Code,
Product_Name,
Selling_Price,
customer_id,
date)
VALUES(
'".$_REQUEST['itemid'.$i]."',
'".$_REQUEST['discription'.$i]."',
'".$_REQUEST['priceach'.$i]."',
'".$_REQUEST['customerid']."',
'".$_REQUEST['date']."')";
$result=mysql_query($Query);
}
}


			//$message="Sale Order Transection Successfully Completed: ".$order." ";
			header("location: CustomerPriceList3.php?invoice=".$order."&customer_id=".$id."&date=".$date."");

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<title>Point of Sale 1.0</title>
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
<link href="assets/css/loader.css" rel="stylesheet" type="text/css" />
<script src="assets/js/loader.js"></script>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&amp;display=swap" rel="stylesheet">
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link href="plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
<link href="assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->

<!-- BEGIN PAGE LEVEL STYLES -->
<link rel="stylesheet" type="text/css" href="plugins/table/datatable/datatables.css">
<link rel="stylesheet" type="text/css" href="plugins/table/datatable/dt-global_style.css">
<!-- END PAGE LEVEL STYLES -->

<!-- BEGIN THEME GLOBAL STYLES -->
<link href="plugins/flatpickr/flatpickr.css" rel="stylesheet" type="text/css">
<link href="plugins/noUiSlider/nouislider.min.css" rel="stylesheet" type="text/css">
<!-- END THEME GLOBAL STYLES -->

<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
<link href="plugins/flatpickr/custom-flatpickr.css" rel="stylesheet" type="text/css">
<link href="plugins/noUiSlider/custom-nouiSlider.css" rel="stylesheet" type="text/css">
<link href="plugins/bootstrap-range-Slider/bootstrap-slider.css" rel="stylesheet" type="text/css">
<!--  END CUSTOM STYLE FILE  -->



<SCRIPT language=javascript>
var rs_debug_mode = false;

function rs_debug(text) {
if (rs_debug_mode)
alert("RSD: " + text);
}
function rs_init_object() {
rs_debug("rs_init_object() called..");

var A;
try {
A=new ActiveXObject("Msxml2.XMLHTTP");
} catch (e) {
try {
A=new ActiveXObject("Microsoft.XMLHTTP");
} catch (oc) {
A=null;
}
}
if(!A && typeof XMLHttpRequest != "undefined")
A = new XMLHttpRequest();
if (!A)
rs_debug("Could not create connection object.");
return A;
}


// wrapper for findparentcustomername		
function x_findcustomername() {
// count args; build URL
var i, x, n;
var url = "autofunctionsdb.php?rs=findcustomername", a = x_findcustomername.arguments;
//for (i = 0; i < a.length-1; i++) 
//	url = url + "&rsargs[]=" + escape(a[i]);
//url = url + "&rsrnd=" + new Date().getTime();

url = url + "&rsargs=" + document.mainform.customername.value ;

x = rs_init_object();
x.open("GET", url, true);
x.onreadystatechange = function() {
if (x.readyState != 4) 
return;
rs_debug("received " + x.responseText);

var status;
var data;
status = x.responseText.charAt(0);
data = x.responseText.substring(2);


if (status == "-") 
alert("Error: " + callback_n);
else  
a[a.length-1](data);
}
x.send(null);
rs_debug("x_findcustomername url = " + url);
rs_debug("x_findcustomername waiting..");
delete x;
}



<?

for($j=1; $j<=$lines; $j++)
{
/**************************************************
*      url=url+\"&Customerid=\"+document.mainform.customerid.value;
*      ADREES ADD CODE FOR CUSTOMER ID 
*/


echo "function x_finditemdesc".$j."() {
var customer_id = document.mainform.customerid.value;

//alert(customer_id);
// count args; build URL
var i, x, n;
var url = \"autofunctionsdb.php?line=".$j."&rs=findProduct_CustomerPriceList\", a = x_finditemdesc".$j.".arguments;
//for (i = 0; i < a.length-1; i++) 
//	url = url + \"&rsargs[]=\" + escape(a[i]);
//url = url + \"&rsrnd=\" + new Date().getTime();

url = url + \"&rsargs=\" + document.mainform.itemdesc".$j.".value ;
url=url+\"&Customerid=\"+document.mainform.customerid.value;
x = rs_init_object();
x.open(\"GET\", url, true);
x.onreadystatechange = function() {
if (x.readyState != 4) 
return;
rs_debug(\"received \" + x.responseText);

var status;
var data;
status = x.responseText.charAt(0);
data = x.responseText.substring(2);


if (status == \"-\") 
alert(\"Error: \" + callback_n);
else  
a[a.length-1](data);
}
x.send(null);
rs_debug(\"x_finditemdesc".$j." url = \" + url);
rs_debug(\"x_finditemdesc".$j." waiting..\");
delete x;
}";
}

?>								


var keystrokedelay=400;					

var displaylistcount=0;					


</SCRIPT>
<script type="text/javascript"> 
function checkForm(){
if(!confirm('Are you sure that you want to submit the form now?\n\nThis does not mean that there is a problem with your form.'))
return false;} 
</script> 

</head>
<body class="alt-menu sidebar-noneoverflow" onLoad="document.mainform.customername.focus();">
<!-- BEGIN LOADER -->
<div id="load_screen"> <div class="loader"> <div class="loader-content"> <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 792 723" style="enable-background:new 0 0 792 723;" xml:space="preserve"> <g> <g> <path class="st0" d="M213.9,584.4c-47.4-25.5-84.7-60.8-111.8-106.1C75,433.1,61.4,382,61.4,324.9c0-57,13.6-108.1,40.7-153.3 S166.5,91,213.9,65.5s100.7-38.2,159.9-38.2c49.9,0,95,8.8,135.3,26.3s74.1,42.8,101.5,75.7l-85.5,78.9 c-38.9-44.9-87.2-67.4-144.7-67.4c-35.6,0-67.4,7.8-95.4,23.4s-49.7,37.4-65.4,65.4c-15.6,28-23.4,59.8-23.4,95.4 s7.8,67.4,23.4,95.4s37.4,49.7,65.4,65.4c28,15.6,59.7,23.4,95.4,23.4c57.6,0,105.8-22.7,144.7-68.2l85.5,78.9 c-27.4,33.4-61.4,58.9-102,76.5c-40.6,17.5-85.8,26.3-135.7,26.3C314.3,622.7,261.3,809.9,213.9,584.4z"/> </g> <circle class="st1" cx="375.4" cy="322.9" r="100"/> </g> <g> <circle class="st2" cx="275.4" cy="910" r="65"></circle> <circle class="st4" cx="475.4" cy="910" r="65"></circle> </g> </svg> </div></div></div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<!-- Navigation-->
<?php include 'Navigationbar.php';?>
<!-- Navigation-->
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

<div class="overlay"></div>
<div class="search-overlay"></div>

<!--  BEGIN TOPBAR  -->

<!--  END TOPBAR  -->

<!--  BEGIN CONTENT PART  -->
<div id="content" class="main-content">
<div class="layout-px-spacing">


<div class="row layout-top-spacing"></div>

<div class="col-xl-12 col-md-12 col-sm-12 col-12">
<h4>Sales Invoice</h4>
</div>              
<div class="table-responsive">

<table cellpadding="5" cellspacing="5"  class="table table-bordered mb-4" style="width:100%">
<form name="mainform" action="CustomerPriceList.php" onSubmit="checkForm();">
<input type="hidden" name="task" id="task" value="task" />
<input type="hidden" name="lines" value="<?=$lines?>" />
<tr>
<td><label class="control-label">Customer Name - ID</label></td>
<td colspan="5"><div align="justify">
<? embbed_js_code("customername", "customerid"); ?>
<table width="100%" class='form' style="PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; BORDER-COLLAPSE: collapse">
<tbody>
<tr>
<td style="BORDER-RIGHT: 0px; PADDING-RIGHT: 0px; BORDER-TOP: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; BORDER-LEFT: 0px; PADDING-TOP: 0px; BORDER-BOTTOM: 0px"><div align="left">
<input class="form-control" id='customername' onblur='normalField(this);' onkeyup='getList_customername(event);' onFocus="fireKeyListener_customername(event); highlightField(this,1);" name='customername' autocomplete="off">

</div></td>
</tr>
<tr>
<td style="BORDER-RIGHT: 0px; PADDING-RIGHT: 0px; BORDER-TOP: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; BORDER-LEFT: 0px; PADDING-TOP: 0px; BORDER-BOTTOM: 0px"><DIV style="POSITION: relative">
<DIV id=resultdisplay_customername style="LEFT: 0px; POSITION: absolute; TOP: 0px"> </DIV>
</DIV></td>
</tr>
</tbody>
</table>
</div><label class="control-label"></label><input type="hidden" class="form-control" id="customerid" name="customerid" onBlur="normalField(this)" onFocus="highlightField(this,1)"  autocomplete="off" /></td>
</tr>

<tr>
<td><label class="control-label">Invoice Date</label></td>
<td><input id="basicFlatpickr" name="date"  class="form-control flatpickr flatpickr-input active" type="text" placeholder="Select Date.."></td>
<td><label class="control-label"></label></td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
</table>

</div>              


<div class="col-xl-12 col-md-12 col-sm-12 col-12">
<h4> </h4>
<div class="texttitle" style="margin:auto">
<div align="right" style="font-family:Calibri; font-size:10px;">Set # of item's rows
<select name="lines" onChange="document.mainform.submit();">
<option value='1' <? if($lines==1) echo "selected" ?>>1</option>
<option value='5' <? if($lines==5) echo "selected" ?>>5</option>
<option value='10' <? if($lines==10) echo "selected" ?>>10</option>
<option value='15' <? if($lines==15) echo "selected" ?>>15</option>
<option value='20' <? if($lines==20) echo "selected" ?>>20</option>
<option value='30' <? if($lines==30) echo "selected" ?> >30</option>
<option value='50' <? if($lines==50) echo "selected" ?>>50</option>
</select>
</div>
</div>
</div>

<p><span class="texttitle" style="margin:auto">
  <font color="#FF0000">
    <?=$message?>
    </font>
  </span></p>
<div class="table-responsive">
<table cellpadding="0" cellspacing="0"  class="table table-bordered mb-4" style="width:100%">
<tr>
<th class="alert-primary">#</th>
<th class="alert-primary">Product Name </th>
<th class="alert-primary">Product Code</TH>
<th class="alert-primary">Discription</TH>
<th class="alert-primary">Price</th>
</tr>
<?	for($i=1; $i<= $lines ; $i++ )
{ 
?>

<tr>
<th><?=$i?></th>
<td style="height:28px"><? embbed_js_code_item("itemdesc".$i, "itemid".$i, $i ); ?>
<table width="100%" class='form' style="PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; BORDER-COLLAPSE: collapse">
<tbody>
<tr>
<td style="BORDER-RIGHT: 0px; PADDING-RIGHT: 0px; BORDER-TOP: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; BORDER-LEFT: 0px; PADDING-TOP: 0px; BORDER-BOTTOM: 0px">
<input class="form-control"  id='itemdesc<?=$i?>' onBlur='checkId("iid<?=$i?>"); normalField(this);' onKeyUp='getList_itemdesc<?=$i?>(event);  chkAvailablity(<?=$i?>); checktotal_2(<?=$lines?>,<?=$i?>);' onChange='chkAvailablity(<?=$i?>); checktotal_2(<?=$lines?>,<?=$i?>);' onFocus="fireKeyListener_itemdesc<?=$i?>(event); highlightField(this,1);" size='30' name='itemdesc<?=$i?>' autocomplete="off" >

<input name="iid<?=$i?>" id="iid<?=$i?>" type="hidden">	  </td>
</tr>
<tr>
<td style="BORDER-RIGHT: 0px; PADDING-RIGHT: 0px; BORDER-TOP: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; BORDER-LEFT: 0px; PADDING-TOP: 0px; BORDER-BOTTOM: 0px">
<DIV style="POSITION: relative">
<DIV id=resultdisplay_itemdesc<?=$i?> style="LEFT: 0px; POSITION: absolute; TOP: 0px"></DIV>
</DIV>		  </td>
</tr>
</tbody>
</table>		</td>

<td><input name='itemid<?=$i?>' class="form-control"  id='itemid<?=$i?>' tabIndex=-'1' onfocus='highlightField(this,1)' onblur='normalField(this)' size='10' ></td>
<td><span style="font-size:12px">
<input name="discription<?=$i?>" type="text" class="form-control"  id="Product_Name<?=$i?>" size="30">
</span></td>
<td>
<span style="height:28px"></span>
<input class="form-control"  type="text" name="priceach<?=$i?>" id="priceach<?=$i?>"  value="" size="10" maxlength="10" onFocus="highlightField(this,1)" onChange=" calculateTotal();" onBlur="normalField(this)"></td>

<? embbed_js_code_glacct("glacctdesc".$i, "glaccountid".$i, $i ); ?>	
</tr>


<tr><td colspan="5" id="txtqty<?=$i?>"></td></tr>


<? } ?>
</table>    
</div>

<table>
<tr>
<td><label>
 <input name="Submit" type="submit" class="submitcomment" value="Save">
</label>
</td>
</tr>
</table>
</form>               
</div>
</div>                                                                                                           

</html>
<script language="javascript">

//Calculates the total amount of the order
function calculateTotal()
{
	var num_line_items = '<?=$lines?>';            
	var price=0;      
	var qty=0;
	var amount=0; 
	var total=0;
	var discount=0;         


	if(num_line_items > 0 )
	{
			for(var i=1; i<=num_line_items; i++)
		{
			price=document.getElementById('priceach'+i).value; 
			qty=document.getElementById('qty'+i).value;
			discount=document.getElementById('discount'+i).value;
			amount=price*qty;
			amount=amount-(amount*discount/100);
			document.getElementById('amount'+i).value=amount; 
			total=total+amount; 
		
			          								
		}
			document.getElementById('pretotal').value=total;
			discountTotal=document.getElementById('discountTotal').value;
			toalamount=total-(total*discountTotal/100); 
			document.getElementById('total').value=toalamount; 
		 
	
	}
}


</script>

<?php
function formatMoney($number, $fractional=false) {
if ($fractional) {
$number = sprintf('%.2f', $number);
}
while (true) {
$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
if ($replaced != $number) {
$number = $replaced;
} else {
break;
}
}
return $number;
}
if($pt=='GIVE_AMOUNT '){
echo $cash;
}
if($pt=='cash'){
echo formatMoney($amount, true);
}
?>


<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<script src="assets/js/libs/jquery-3.1.1.min.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="assets/js/app.js"></script>

<script>
$(document).ready(function() {
App.init();
});
</script>
<script src="assets/js/custom.js"></script>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="plugins/table/datatable/datatables.js"></script>
<script>        
$('#default-ordering').Datatable( {
"oLanguage": {
"oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
"sInfo": "Showing page _PAGE_ of _PAGES_",
"sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
"sSearchPlaceholder": "Search...",
"sLengthMenu": "Results :  _MENU_",
},
"order": [[ 3, "desc" ]],
"stripeClasses": [],
"lengthMenu": [10, 15, 20, 50],
"pageLength": 10,
drawCallback: function () { $('.datatables_paginate > .pagination').addClass(' pagination-style-13 pagination-bordered mb-5'); }
} );
</script>
<!-- END PAGE LEVEL SCRIPTS -->




<!-- BEGIN GLOBAL MANDATORY STYLES -->
<script src="assets/js/libs/jquery-3.1.1.min.js"></script>
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="assets/js/app.js"></script>

<script>
$(document).ready(function() {
App.init();
});
</script>
<script src="plugins/highlight/highlight.pack.js"></script>
<script src="assets/js/custom.js"></script>
<!-- END GLOBAL MANDATORY STYLES -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="assets/js/scrollspyNav.js"></script>
<script src="plugins/flatpickr/flatpickr.js"></script>
<script src="plugins/noUiSlider/nouislider.min.js"></script>

<script src="plugins/flatpickr/custom-flatpickr.js"></script>
<script src="plugins/noUiSlider/custom-nouiSlider.js"></script>
<script src="plugins/bootstrap-range-Slider/bootstrap-rangeSlider.js"></script>
<!-- END PAGE LEVEL SCRIPTS -->