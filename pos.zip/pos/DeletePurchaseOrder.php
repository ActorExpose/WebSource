<?php
include('connect.php');
$id=$_GET['id'];

$Query="DELETE
FROM
  purchaseorder
WHERE
  purchaseorder.id='$id'";
$result=mysql_query($Query);



$Query2="DELETE
FROM
  purchaseorderdetail
WHERE
  purchaseorderdetail.`order`='$id'";
$result2=mysql_query($Query2);


$Query3="DELETE
FROM
  suplier_ledger
WHERE
  suplier_ledger.sale_id='$id'";
$result3=mysql_query($Query3);




// Transection Record Coding Start
date_default_timezone_set("Asia/Karachi");
$transectionno=($_REQUEST['id']); // Transection Number 
$transectiontype="deletecustomer.php";  // Page Where Transection Occur
$comments="Not Happy ! Because you Delete the Data";   //  Happy 
$transectiondate = date("m-d-Y");   // Today Date
$transectiontime = date("h:i:sa"); //  Current Time
$transectionalert="Very High ( 100% )"; // High  //  Low
$Query="INSERT INTO
  transection(
  transectionno,
  transectiontype,
  comments,
  transectiondate,
  transectiontime,
  transectionalert)
VALUES(
  '$transectionno',
  '$transectiontype',
  '$comments',
  '$transectiondate',
  '$transectiontime',
  '$transectionalert')";
$result=mysql_query($Query);
// Transection Record Coding End


header("location: index2.php");
?>