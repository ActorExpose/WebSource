<?php
include('connect.php');
$expense_id = $_POST['expense_id'];
$date = $_POST['date'];
$amount = $_POST['amount'];
$comments = $_POST['comments'];

// Save Expenses Payments

$Query1="TRUNCATE TABLE customer";
	   $result1=mysql_query($Query1);

$Query2="TRUNCATE TABLE customerpricelist";
	   $result2=mysql_query($Query2);	   
	   

$Query3="TRUNCATE TABLE customer_ledger";
	   $result3=mysql_query($Query3);	   
	   
$Query4="TRUNCATE TABLE employee";
	   $result4=mysql_query($Query4);
	   
$Query5="TRUNCATE TABLE expensetype";
	   $result5=mysql_query($Query5);

$Query6="TRUNCATE TABLE expnese";
	$result6=mysql_query($Query6);
	   
$Query7="TRUNCATE TABLE products";
	$result7=mysql_query($Query7);

$Query8="TRUNCATE TABLE purchaseorder";
	$result8=mysql_query($Query8);	 
	
$Query9="TRUNCATE TABLE purchaseorderdetail";
	$result9=mysql_query($Query9);
	
$Query10="TRUNCATE TABLE saleorder";
	$result10=mysql_query($Query10);

$Query11="TRUNCATE TABLE saleorderdetail";
	$result11=mysql_query($Query11);	

$Query12="TRUNCATE TABLE suplier";
	$result12=mysql_query($Query12);
	
$Query13="TRUNCATE TABLE suplier_ledger";
	$result13=mysql_query($Query13);
	
$Query14="TRUNCATE TABLE transection";
	$result14=mysql_query($Query14);
	
$Query15="TRUNCATE TABLE salesman";
$result15=mysql_query($Query15);			   

header("location: index2.php");
?>