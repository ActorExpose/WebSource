<?php
/*require_once('auth.php');*/
?>
<?php
$Today = date("Y-m-d");  // today date
$First_Day_Month = date("Y-m-01");  // First Day  Month
$Last_Day_Month = date("Y-m-31");  //Last Day of Month

$First_Day_Year = date("Y-01-01");  // First  Day of Year
$Last_Day_Year = date("Y-12-31");  // Last Day of Year
?>
<?php
include('connect.php');
/***************************************************
*  Today Queries Start   */
$Query1="SELECT 
SUM(saleorder.total) AS totalsale
FROM
saleorder
WHERE
saleorder.`date`='$Today'";
$result1=mysql_query($Query1);
$row1=mysql_fetch_array($result1);


$Query2="SELECT 
SUM(purchaseorder.total) AS totalpurchase
FROM
purchaseorder
WHERE
purchaseorder.`date`='$Today'";
$result2=mysql_query($Query2);
$row2=mysql_fetch_array($result2);


$Query3="SELECT 
SUM(customer_ledger.GET_AMOUNT) AS totalamountreceived
FROM
customer_ledger
WHERE
customer_ledger.`date`='$Today'";
$result3=mysql_query($Query3);
$row3=mysql_fetch_array($result3);


$Query4="SELECT 
SUM(suplier_ledger.GIVE_AMOUNT) AS totalamountpaid
FROM
suplier_ledger
WHERE
suplier_ledger.`date`='$Today'";
$result4=mysql_query($Query4);
$row4=mysql_fetch_array($result4);


$Query5="SELECT 
SUM(expnese.amount) AS totalexpense
FROM
expnese
WHERE
expnese.`date`='$Today'";
$result5=mysql_query($Query5);
$row5=mysql_fetch_array($result5);
/***************************************************
*  Today Queries End   */






/***************************************************
*  Monthly Queries Start   */

$Query11="SELECT 
SUM(saleorder.total) AS totalmontlysale
FROM
saleorder
WHERE
saleorder.`date` >='$First_Day_Month' AND saleorder.`date` <='$Last_Day_Month'";
$result11=mysql_query($Query11);
$row11=mysql_fetch_array($result11);


$Query12="SELECT 
SUM(purchaseorder.total) AS totalmontlypurchase
FROM
purchaseorder
WHERE
purchaseorder.`date` >= '$First_Day_Month' AND purchaseorder.`date` <= '$Last_Day_Month'";
$result12=mysql_query($Query12);
$row12=mysql_fetch_array($result12);


$Query13="SELECT 
SUM(customer_ledger.GET_AMOUNT) AS totalmontlyamountreceived
FROM
customer_ledger
WHERE
customer_ledger.`date` >= '$First_Day_Month' AND customer_ledger.`date` <= '$Last_Day_Month'";
$result13=mysql_query($Query13);
$row13=mysql_fetch_array($result13);


$Query14="SELECT 
SUM(suplier_ledger.GIVE_AMOUNT) AS totalmontlyamountpaid
FROM
suplier_ledger
WHERE
suplier_ledger.`date` >= '$First_Day_Month' AND suplier_ledger.`date` <= '$Last_Day_Month'";
$result14=mysql_query($Query14);
$row14=mysql_fetch_array($result14);


$Query15="SELECT 
SUM(expnese.amount) AS totalmontlyexpense
FROM
expnese
WHERE
expnese.`date` >= '$First_Day_Month' AND expnese.`date` <= '$Last_Day_Month'";
$result15=mysql_query($Query15);
$row15=mysql_fetch_array($result15);


/***************************************************
*  Monthly Queries End   */





/***************************************************
*  Annual Queries Start   */

$Query21="SELECT 
SUM(saleorder.total) AS totalyearsale
FROM
saleorder
WHERE
saleorder.`date` >='$First_Day_Year' AND saleorder.`date` <='$Last_Day_Year'";
$result21=mysql_query($Query21);
$row21=mysql_fetch_array($result21);


$Query22="SELECT 
SUM(purchaseorder.total) AS totalyearpurchase
FROM
purchaseorder
WHERE
purchaseorder.`date` >= '$First_Day_Year' AND purchaseorder.`date` <= '$Last_Day_Year'";
$result22=mysql_query($Query22);
$row22=mysql_fetch_array($result22);


$Query23="SELECT 
SUM(customer_ledger.GET_AMOUNT) AS totalyearamountreceived
FROM
customer_ledger
WHERE
customer_ledger.`date` >= '$First_Day_Year' AND customer_ledger.`date` <= '$Last_Day_Year'";
$result23=mysql_query($Query23);
$row23=mysql_fetch_array($result23);


$Query24="SELECT 
SUM(suplier_ledger.GIVE_AMOUNT) AS totalyearamountpaid
FROM
suplier_ledger
WHERE
suplier_ledger.`date` >= '$First_Day_Year' AND suplier_ledger.`date` <= '$Last_Day_Year'";
$result24=mysql_query($Query24);
$row24=mysql_fetch_array($result24);


$Query25="SELECT 
SUM(expnese.amount) AS totalyearexpense
FROM
expnese
WHERE
expnese.`date` >= '$First_Day_Year' AND expnese.`date` <= '$Last_Day_Year'";
$result25=mysql_query($Query25);
$row25=mysql_fetch_array($result25);


/***************************************************
*  Annual Queries End   */


$Query31="SELECT 
SUM(saleorder.total) AS totalbusinesssale
FROM
saleorder";
$result31=mysql_query($Query31);
$row31=mysql_fetch_array($result31);

$Query32="SELECT 
SUM(purchaseorder.total) AS totalbusinesspurchase
FROM
purchaseorder";
$result32=mysql_query($Query32);
$row32=mysql_fetch_array($result32);

$Query33="SELECT 
SUM(expnese.amount) AS totalbusinessexpense
FROM
expnese";
$result33=mysql_query($Query33);
$row33=mysql_fetch_array($result33);
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<title>Point of Sale 1.0</title>
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
<link href="assets/css/loader.css" rel="stylesheet" type="text/css" />
<script src="assets/js/loader.js"></script>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&amp;display=swap" rel="stylesheet">
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<link href="plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
<link href="assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->

<!-- BEGIN PAGE LEVEL STYLES -->
<link rel="stylesheet" type="text/css" href="plugins/table/datatable/datatables.css">
<link rel="stylesheet" type="text/css" href="plugins/table/datatable/dt-global_style.css">
<!-- END PAGE LEVEL STYLES -->

<!-- BEGIN THEME GLOBAL STYLES -->
<link href="plugins/flatpickr/flatpickr.css" rel="stylesheet" type="text/css">
<link href="plugins/noUiSlider/nouislider.min.css" rel="stylesheet" type="text/css">
<!-- END THEME GLOBAL STYLES -->

<!--  BEGIN CUSTOM STYLE FILE  -->
<link href="assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
<link href="plugins/flatpickr/custom-flatpickr.css" rel="stylesheet" type="text/css">
<link href="plugins/noUiSlider/custom-nouiSlider.css" rel="stylesheet" type="text/css">
<link href="plugins/bootstrap-range-Slider/bootstrap-slider.css" rel="stylesheet" type="text/css">
<!--  END CUSTOM STYLE FILE  -->

</head>
<body class="alt-menu sidebar-noneoverflow">
<!-- BEGIN LOADER -->
<div id="load_screen"> <div class="loader"> <div class="loader-content"> <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 792 723" style="enable-background:new 0 0 792 723;" xml:space="preserve"> <g> <g> <path class="st0" d="M213.9,584.4c-47.4-25.5-84.7-60.8-111.8-106.1C75,433.1,61.4,382,61.4,324.9c0-57,13.6-108.1,40.7-153.3 S166.5,91,213.9,65.5s100.7-38.2,159.9-38.2c49.9,0,95,8.8,135.3,26.3s74.1,42.8,101.5,75.7l-85.5,78.9 c-38.9-44.9-87.2-67.4-144.7-67.4c-35.6,0-67.4,7.8-95.4,23.4s-49.7,37.4-65.4,65.4c-15.6,28-23.4,59.8-23.4,95.4 s7.8,67.4,23.4,95.4s37.4,49.7,65.4,65.4c28,15.6,59.7,23.4,95.4,23.4c57.6,0,105.8-22.7,144.7-68.2l85.5,78.9 c-27.4,33.4-61.4,58.9-102,76.5c-40.6,17.5-85.8,26.3-135.7,26.3C314.3,622.7,261.3,809.9,213.9,584.4z"/> </g> <circle class="st1" cx="375.4" cy="322.9" r="100"/> </g> <g> <circle class="st2" cx="275.4" cy="910" r="65"></circle> <circle class="st4" cx="475.4" cy="910" r="65"></circle> </g> </svg> </div></div></div>
<!--  END LOADER -->

<!--  BEGIN NAVBAR  -->
<!-- Navigation-->
<?php include 'Navigationbar.php';?>
<!-- Navigation-->
<!--  END NAVBAR  -->

<!--  BEGIN MAIN CONTAINER  -->
<div class="main-container" id="container">

<div class="overlay"></div>
<div class="search-overlay"></div>

<!--  BEGIN TOPBAR  -->

<!--  END TOPBAR  -->

<!--  BEGIN CONTENT PART  -->
<div id="content" class="main-content">
<div class="layout-px-spacing">


<div class="row layout-top-spacing"></div>
<div class="col-xl-12 col-md-12 col-sm-12 col-12">
<h4>Income Statement</h4>
</div>              
<div class="table-responsive"></div>              
<div class="table-responsive">
<table width="100%"   class="table table-bordered mb-4"  style="width:100%">
<tbody>
<tr>
<td><table width="100%" cellpadding="0" cellspacing="0" class="table table-bordered mb-4" style="width:100%">
<thead>
<tr>
<th colspan="3" class="alert-primary"><div align="left">
Daily Business Report</div></th>
</tr>
<tr>
<th width="20%" class="alert-primary">Serial</th>
<th class="alert-primary">Customer Name</th>
<th width="20%"  class="alert-primary"> Mobile</th>
</tr>
</thead>
<tbody>

<tr>
<td>1</td>
<td>Today Sale</td>
<td><div align="left"><? echo $row1['totalsale'];?></div></td>
</tr>
<tr>
<td>2</td>
<td>Today Purchase</td>
<td><div align="left"><? echo $row2['totalpurchase'];?></div></td>
</tr>
<tr>
<td>3</td>
<td>Today Amount Recieved from Customers</td>
<td><div align="left"><? echo $row3['totalamountreceived'];?></div></td>
</tr>
<tr>
<td>4</td>
<td>Today Amount Paid to Suppliers</td>
<td><div align="left"><? echo $row4['totalamountpaid'];?></div></td>
</tr>
<tr>
<td>5</td>
<td>Today Expense</td>
<td><div align="left"><? echo $row5['totalexpense'];?></div></td>
</tr>
<tr>
<th colspan="2">Total Cash in Hand</th>
<th><div align="left"><? echo $row3['totalamountreceived'] - $row4['totalamountpaid'] - $row5['totalexpense'];?></div></th>
</tr>
</tbody>
</table></td>
<td><table width="100%" cellpadding="0" cellspacing="0" class="table table-bordered mb-4" style="width:100%">
<thead>
<tr>
<th colspan="3" class="alert-primary">Monthly Business Report</th>
</tr>
</thead>
<thead>
<tr>
<th width="20%"  class="alert-primary">Serial</th>
<th class="alert-primary">Discription</th>
<th width="20%"  class="alert-primary">Amount</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Monthly Sale</td>
<td><div align="left"><? echo $row11['totalmontlysale'];?></div></td>
</tr>
<tr>
<td>2</td>
<td>Monthly Purchase</td>
<td><div align="left"><? echo $row12['totalmontlypurchase'];?></div></td>
</tr>
<tr>
<td>3</td>
<td>Monthly Amount Recieved from Customers</td>
<td><div align="left"><? echo $row13['totalmontlyamountreceived'];?></div></td>
</tr>
<tr>
<td>4</td>
<td>Monthly Amount Paid to Suppliers</td>
<td><div align="left"><? echo $row14['totalmontlyamountpaid'];?></div></td>
</tr>
<tr>
<td>5</td>
<td>Montly Expense</td>
<td><div align="left"><? echo $row15['totalmontlyexpense'];?></div></td>
</tr>
<tr>
<th height="31" colspan="2">Total Cash in Hand</th>
<th><div align="left"><? echo $row13['totalmontlyamountreceived'] - $row14['totalmontlyamountpaid'] - $row15['totalmontlyexpense'];?></div></th>
</tr>
</tbody>
</table></td>
</tr>
<tr>
<td><table cellpadding="0" cellspacing="0" class="table table-bordered mb-4" style="width:100%">
<thead>
<tr>
<th colspan="3" class="alert-primary">Annual Business Report</th>
</tr>
</thead>
<thead>
<tr>
<th width="20%"  class="alert-primary">Serial</th>
<th class="alert-primary">Discription</th>
<th width="20%"  class="alert-primary">Amount</th>
</tr>
</thead>
<tbody>
<tr>
<td>1</td>
<td>Annual Sale</td>
<td><div align="left"><? echo $row21['totalyearsale'];?></div></td>
</tr>
<tr>
<td>2</td>
<td>Annual Purchase</td>
<td><div align="left"><? echo $row22['totalyearpurchase'];?></div></td>
</tr>
<tr>
<td>3</td>
<td>Annual Amount Recieved from Customers</td>
<td><div align="left"><? echo $row23['totalyearamountreceived'];?></div></td>
</tr>
<tr>
<td>4</td>
<td>Annual Amount Paid to Suppliers</td>
<td><div align="left"><? echo $row24['totalyearamountpaid'];?></div></td>
</tr>
<tr>
<td>5</td>
<td>Annual Expense</td>
<td><div align="left"><? echo $row25['totalyearexpense'];?></div></td>
</tr>
<tr>
<th height="31" colspan="2">Total Cash in Hand</th>
<th><div align="left"><? echo $row23['totalyearamountreceived'] - $row24['totalyearamountpaid'] - $row25['totalyearexpense'];?></div></th>
</tr>
</tbody>
</table></td>
<td><table width="100%" cellpadding="0" cellspacing="0" class="table table-bordered mb-4" style="width:100%">
<thead>
<tr>
<th colspan="3" class="alert-primary">Final Business Report
</tr>
<tr>
<th width="20%"  class="alert-primary">Serial</th>
<th class="alert-primary">Discription</th>
<th width="20%"  class="alert-primary">Amount</th>
</tr>
</thead>
<tbody>

<tr>
<td>1</td>
<td>Total Sale of Business</td>
<td><div align="left"><? echo $row31['totalbusinesssale'];?></div></td>
</tr>
<tr>
<td>2</td>
<td>Total Purchase of Business</td>
<td><div align="left"><? echo $row32['totalbusinesspurchase'];?></div></td>
</tr>
<tr>
<td>3</td>
<td>Total Expense of Business</td>
<td><div align="left"><? echo $row33['totalbusinessexpense'];?></div></td>
</tr>
<tr>
  <th colspan="2">&nbsp;</th>
  <th>&nbsp;</th>
</tr>
<tr>
<th colspan="2">&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr>
  <th colspan="2">Finally Expected Income / Loss</th>
  <th><div align="left"><? echo $row31['totalbusinesssale'] - $row32['totalbusinesspurchase'] - $row33['totalbusinessexpense'];?></div></th>
</tr>
</tbody>
</table
></td>
</tr>
</tbody> 
</table>    
</div>
</div>
</div>
</div>
</body>
</html>
<script language="javascript" type="text/javascript">
function calculateprice()
{
var num_line_items = 50;            
var Selling_Price=0;      
var Quantity=0;
var amount=0; 
var discount=0;
var total=0;
if(num_line_items > 0 )
{
for(var i=1; i<=num_line_items; i++)
{
Selling_Price=document.getElementById('Selling_Price').value; 
Orignal_Price=document.getElementById('Orignal_Price').value;
amount=Selling_Price-Orignal_Price;
document.getElementById('Profit').value=amount; 

}

}
}

</script>

<?php
function formatMoney($number, $fractional=false) {
if ($fractional) {
$number = sprintf('%.2f', $number);
}
while (true) {
$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
if ($replaced != $number) {
$number = $replaced;
} else {
break;
}
}
return $number;
}
if($pt=='GIVE_AMOUNT '){
echo $cash;
}
if($pt=='cash'){
echo formatMoney($amount, true);
}
?>


<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<script src="assets/js/libs/jquery-3.1.1.min.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="assets/js/app.js"></script>

<script>
$(document).ready(function() {
App.init();
});
</script>
<script src="assets/js/custom.js"></script>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="plugins/table/datatable/datatables.js"></script>
<script>        
$('#default-ordering').DataTable( {
"oLanguage": {
"oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
"sInfo": "Showing page _PAGE_ of _PAGES_",
"sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
"sSearchPlaceholder": "Search...",
"sLengthMenu": "Results :  _MENU_",
},
"order": [[ 3, "desc" ]],
"stripeClasses": [],
"lengthMenu": [10, 15, 20, 50],
"pageLength": 10,
drawCallback: function () { $('.dataTables_paginate > .pagination').addClass(' pagination-style-13 pagination-bordered mb-5'); }
} );
</script>
<!-- END PAGE LEVEL SCRIPTS -->




<!-- BEGIN GLOBAL MANDATORY STYLES -->
<script src="assets/js/libs/jquery-3.1.1.min.js"></script>
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="assets/js/app.js"></script>

<script>
$(document).ready(function() {
App.init();
});
</script>
<script src="plugins/highlight/highlight.pack.js"></script>
<script src="assets/js/custom.js"></script>
<!-- END GLOBAL MANDATORY STYLES -->

<!-- BEGIN PAGE LEVEL SCRIPTS -->
<script src="assets/js/scrollspyNav.js"></script>
<script src="plugins/flatpickr/flatpickr.js"></script>
<script src="plugins/noUiSlider/nouislider.min.js"></script>

<script src="plugins/flatpickr/custom-flatpickr.js"></script>
<script src="plugins/noUiSlider/custom-nouiSlider.js"></script>
<script src="plugins/bootstrap-range-Slider/bootstrap-rangeSlider.js"></script>
<!-- END PAGE LEVEL SCRIPTS -->