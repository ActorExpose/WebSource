<?php
session_start();
include('connect.php');
$Query="INSERT INTO
  suplier(
  suplier_name,
  pmobile,
  business,
  bmobile,
  address)
VALUES(
  '".$_REQUEST['name']."',
  '".$_REQUEST['pmobile']."',
  '".$_REQUEST['business']."',
  '".$_REQUEST['bmobile']."',
  '".$_REQUEST['address']."')";
$result=mysql_query($Query);

header("location: addSupplier.php");
?>


