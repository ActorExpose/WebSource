<?php
	include('connect.php');
	
	$lines = $_POST['lines'];
	$id = $_POST['id'];
	
$Query="DELETE
FROM
  customerpricelist
WHERE
  customerpricelist.customer='$id'";
$result=mysql_query($Query);	
	
	
	
for($i=1;$i<=$lines;$i++){
			if($_REQUEST['Selling_Price'.$i]!="" && $_REQUEST['Selling_Price'.$i]!=0){
			   $Query2="INSERT INTO
						  customerpricelist(
						  customer,
						  Product_Code,
						  Product_Name,
						  Selling_Price,
						  Product_Discripion)
					VALUES(
					  '".$_REQUEST['id']."',
					  '".$_REQUEST['Product_Code'.$i]."',
					  '".$_REQUEST['Product_Name'.$i]."',
					  '".$_REQUEST['Selling_Price'.$i]."',
					  '".$_REQUEST['Product_Discripion'.$i]."')";
					  $result2=mysql_query($Query2);	
			 	}	
 }
 
header("location: ViewCustomerPriceList.php?id=".$id."");
?>