<?php
include('connect.php');
$Query="INSERT INTO
  salesman(
  name,
  pmobile,
  cnic,
  hmobile,
  address)
VALUES(
  '".$_REQUEST['name']."',
  '".$_REQUEST['pmobile']."',
  '".$_REQUEST['cnic']."',
  '".$_REQUEST['hmobile']."',
  '".$_REQUEST['address']."')";
$result=mysql_query($Query);
header("location: addSalesman.php");
?>


