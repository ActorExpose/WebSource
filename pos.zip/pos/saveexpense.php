<?php
include('connect.php');
$date = $_POST['date'];
if($date!=""){
$date = $_POST['date'];	
}else{
$date=date("Y-m-d");	
}
$expense_id = $_POST['expense_id'];
$amount = $_POST['amount'];
$comments = $_POST['comments'];

if($comments!=""){
$comments=$comments;
}else{
$comments="Other Bussiness Expanse";	
}
// Save Expenses Payments

$Query3="INSERT INTO
  expnese(
  expense_id,
  `date`,
  amount,
  comments)
		VALUES(
		   '$expense_id',
		   '$date',
		   '$amount',
		   '$comments')";
	   $result3=mysql_query($Query3);
header("location: addexpnses.php");
?>