<?php
session_start();
include('connect.php');
$Query="INSERT INTO
  customer(
  customer_name,
  pmobile,
  business,
  bmobile,
  address,
  remarks)
VALUES(
  '".$_REQUEST['name']."',
  '".$_REQUEST['pmobile']."',
  '".$_REQUEST['business']."',
  '".$_REQUEST['bmobile']."',
  '".$_REQUEST['address']."',
  '".$_REQUEST['remarks']."')";
$result=mysql_query($Query);

header("location: addcustomer.php");
?>


