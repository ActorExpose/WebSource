<?php
session_start();
include('connect.php');
$Query="UPDATE
  products
SET
  Product_Code = '".$_REQUEST['Product_Code']."',
  Product_Name = '".$_REQUEST['Product_Name']."',
  Product_Unit =  '".$_REQUEST['Product_Unit']."',
  Product_Discripion = '".$_REQUEST['Product_Discripion']."',
  Selling_Price = '".$_REQUEST['Selling_Price']."',
  Orignal_Price = '".$_REQUEST['Orignal_Price']."',
  Profit = '".$_REQUEST['Profit']."'
WHERE
  Product_Code='".$_REQUEST['memi']."' ";
$result=mysql_query($Query);


// Transection Record Coding Start
date_default_timezone_set("Asia/Karachi");
$transectionno=($_REQUEST['memi']); // Transection Number 
$transectiontype="editproductrecord.php";  // Page Where Transection Occur
$comments="Not Happy ! Beacause you Update the Data";   //  Happy 
$transectiondate = date("m-d-Y");   // Today Date
$transectiontime = date("h:i:sa"); //  Current Time
$transectionalert="High"; // High  //  Low
$Query="INSERT INTO
  transection(
  transectionno,
  transectiontype,
  comments,
  transectiondate,
  transectiontime,
  transectionalert)
VALUES(
  '$transectionno',
  '$transectiontype',
  '$comments',
  '$transectiondate',
  '$transectiontime',
  '$transectionalert')";
$result=mysql_query($Query);
// Transection Record Coding End

header("location: addproduct.php");

?>

