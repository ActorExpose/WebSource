<?php
session_start();
include('connect.php');
$Query="INSERT INTO
  products(
  Product_Code,
  Product_Name,
  Product_Unit,
  Product_Discripion,
  Selling_Price,
  Orignal_Price,
  Profit)
VALUES(
  '".$_REQUEST['Product_Code']."',
  '".$_REQUEST['Product_Name']."',
  '".$_REQUEST['Product_Unit']."',
  '".$_REQUEST['Product_Discripion']."',
  '".$_REQUEST['Selling_Price']."',
  '".$_REQUEST['Orignal_Price']."',
  '".$_REQUEST['Profit']."')";
$result=mysql_query($Query);

header("location: addproduct.php");
?>


