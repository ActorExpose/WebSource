<?

 include('connect.php');

/************************************************************************************************
(Start)	Hint:Ajax List Method Dont't Delete  ( Ajax Product_Code )  Use in Other Form Like CustomerSearch.php
************************************************************************************************/
 
function highlight($search, $subject)
{

	$lensubject = strlen($subject);
	$lensearch = strlen($search);
	
	$str = "" ;
	$temp = "" ;
	$substr = "" ;
	$c = 0 ;
	

	for( $i = 0 ; $i <= $lensubject ; $i++ )
	{				
		$substr = "";		
		$temp = substr( $subject, $c  , $lensearch );					
		
			if (preg_match( "/".$search."/i", $temp ))
			{
				$substr = "<b>".$temp."</b>";
				$c = $c + $lensearch  ;
			}
			else
			{
				$substr = substr( $temp, 0  , 1 );
						
				$c = $c + 1 ;
			}
		
		$str .= $substr ;	
		
		if( $c  >=  $lensubject  )
		{			
			break;
		}			
	}
		
	return ($str);
	
}


/************************************************************************************************
(Start)	Hint:Find Products Sale  /  FOR SALE ORDER
************************************************************************************************/

if($_REQUEST['rs'] == "finditem_desc_grp" )
{


  /* Search Product from Customer Price List According to the Customer */
  $customerid=$_REQUEST['Customerid'];
 
  if(empty($customerid)){
  $query =  "select * from products where Product_Name like '%" . $_REQUEST['rsargs'] ."%' or Product_Code like '%" . $_REQUEST['rsargs'] ."%'";  
 
 }else{
  
  //$query =  "select * from products where Product_Name like '%" . $_REQUEST['rsargs'] ."%' or Product_Code like '%" . $_REQUEST['rsargs'] ."%'";
  
  $query="SELECT 
  pricelist.Product_Code,
  pricelist.Product_Name,
  pricelist.Selling_Price
FROM
  pricelist
where
 Product_Name like '%" . $_REQUEST['rsargs'] ."%' or Product_Code like '%" . $_REQUEST['rsargs'] ."%' and  pricelist.customer_id='" . $_REQUEST['Customerid'] ."' ";
 
 }
 
 
  /*  Missing Query Part When Required */
 /*  products.Product_Name like '%" . $_REQUEST['rsargs'] ."%' OR  */
 


  
  
	$result = @mysql_query($query);
	$qr = "";
	
	if( @mysql_num_rows($result) > 0 )
	{ 						
		echo "  <table >";
				
		$i = 1;
		$line = $_REQUEST['line'];
		
			
		while( $row = mysql_fetch_array($result) )
		{
						
			
			echo "<tr><td  bgcolor='#003366' id='option_itemdesc".$line."[". $i ."]' onmouseover=\"setCurrent_itemdesc".$line."(". $i .",".$row['Product_Code']."); \" onclick=\"fillbox_itemdesc".$line."('". $row['Product_Name'] ."', '". $row['Product_Code'] ."')\" >". highlight( $_REQUEST['rsargs'] , $row['Product_Name'] . " - " . $row['Product_Code'] ) . "<input type='hidden' value='". $row['Product_Code'] ."' id='resultid_itemdesc".$line."[". $i ."]' /><input type='hidden' value='". $row['name'] ."' id='resultname_itemdesc".$line."[". $i ."]' /><input type='hidden' value='".($row['Selling_Price']) ."' id='perpriceunit".$line."[". $i ."]' /></td></tr>";
			
		
		}
				
			$i++;
		echo "</table>" ;exit();	
	}
		
				

	else
	{
		echo " ";
	}
	
}	




/********************************************************************************
(Start)	Hint:Find Customer --------------------------OK QUERY FOR FIND CUSTOMER  
*********************************************************************************/

if($_REQUEST['rs'] == "findcustomername" )
{

	 $query =  "   select * from customer where ( customer_name like '%" . $_REQUEST['rsargs'] ."%'  ) or ( customer_id like '%" . $_REQUEST['rsargs'] ."%'  ) order by customer_name";					
		
				
	$result = @mysql_query($query);
	
	if( @mysql_num_rows($result) > 0 )
	{ 
		echo "  <table>";
		
		$i = 1 ;
		while( $row = mysql_fetch_array($result) )
		{
		echo "<tr><td bgcolor='#003366' id='option_customername[". $i ."]' onmouseover=\"setCurrent_customername(". $i ."); \" onclick=\"fillbox_customername('". $row['customer_name'] . " , ". $row['customer_id'] .")\" >". highlight( $_REQUEST['rsargs'] , $row['customer_name'] . " - " . $row['customer_id'] ) . "<input type='hidden' value='". $row['customer_id'] ."' id='resultid_customername[". $i ."]' /><input type='hidden' value='". $row['customer_name'] ."' id='resultname_customername[". $i ."]' /></td></tr>";

		$i++;
		
		}
		
		echo "</table>" ;
		exit();
	}
	else
	{
		echo "  ";
	}
	
}	



/********************************************************************************
(Start)	Hint:Find Supplier --------------------------OK QUERY FOR FIND Supplier  
*********************************************************************************/

if($_REQUEST['rs'] == "findsupplierername" )
{

	 $query =  "   select * from suplier where ( suplier_name like '%" . $_REQUEST['rsargs'] ."%'  ) or ( suplier_id like '%" . $_REQUEST['rsargs'] ."%'  ) order by suplier_name";					
		
				
	$result = @mysql_query($query);
	
	if( @mysql_num_rows($result) > 0 )
	{ 
		echo "  <table>";
		
		$i = 1 ;
		while( $row = mysql_fetch_array($result) )
		{
		echo "<tr><td bgcolor='#003366' id='option_customername[". $i ."]' onmouseover=\"setCurrent_customername(". $i ."); \" onclick=\"fillbox_customername('". $row['suplier_name'] . " , ". $row['suplier_id'] .")\" >". highlight( $_REQUEST['rsargs'] , $row['suplier_name'] . " - " . $row['suplier_id'] ) . "<input type='hidden' value='". $row['suplier_id'] ."' id='resultid_customername[". $i ."]' /><input type='hidden' value='". $row['suplier_name'] ."' id='resultname_customername[". $i ."]' /></td></tr>";

		$i++;
		
		}
		
		echo "</table>" ;
		exit();
	}
	else
	{
		echo "  ";
	}
	
}	


/********************************************************************************
(Start)	Hint:findProduct
*********************************************************************************/

if($_REQUEST['rs'] == "findProduct_CustomerPriceList" )
{

	 $query =  "select * from products where ( Product_Name like '%" . $_REQUEST['rsargs'] ."%'  ) or ( Product_Code like '%" . $_REQUEST['rsargs'] ."%'  ) order by Product_Name";					
		
				
	$result = @mysql_query($query);
	$qr = "";
	
	if( @mysql_num_rows($result) > 0 )
	{ 						
		echo "  <table >";
				
		$i = 1;
		$line = $_REQUEST['line'];
		
			
		while( $row = mysql_fetch_array($result) )
		{
						
			
			echo "<tr><td  bgcolor='#003366' id='option_itemdesc".$line."[". $i ."]' onmouseover=\"setCurrent_itemdesc".$line."(". $i .",".$row['Product_Code']."); \" onclick=\"fillbox_itemdesc".$line."('". $row['Product_Name'] ."', '". $row['Product_Code'] ."')\" >". highlight( $_REQUEST['rsargs'] , $row['Product_Name'] . " - " . $row['Product_Code'] ) . "<input type='hidden' value='". $row['Product_Code'] ."' id='resultid_itemdesc".$line."[". $i ."]' /><input type='hidden' value='". $row['name'] ."' id='resultname_itemdesc".$line."[". $i ."]' /><input type='hidden' value='".($row['Selling_Price']) ."' id='perpriceunit".$line."[". $i ."]' /></td></tr>";
			
		
		}
				
			$i++;
		echo "</table>" ;exit();	
	}
		
				

	else
	{
		echo " ";
	}
	
}	


	
?>