<?php
	include('connect.php');
	
	$lines = $_POST['lines'];
	$id = $_POST['id'];
	$Payment = $_POST['Payment'];
	$date = $_POST['date'];
	$total = $_POST['TotalAmount'];
	$status = "1";
	
	if($date!=""){
	$date = $_POST['date'];	
	}else{
	$date=date("Y-m-d");	
	}	
	
$Query="INSERT INTO
				  purchaseorder(
				  suplier_id,
				  payment,
				  date,
				  total,
				  status)
				VALUES(
				   '$id',
				   '$Payment',
				   '$date',
				   '$total',
				   '$status')";
			   $result=mysql_query($Query);
			   $order=mysql_insert_id();
			   
$lines;

for($i=1;$i<=$lines;$i++){
			if($_REQUEST['Quantity'.$i]!=""){
			   $Query2="INSERT INTO
						  purchaseorderdetail(
						  `order`,
						  product,
						  discription,
						  quantity,
						  price,
						  discount,
						  amount)
					VALUES(
					  '$order',
					  '".$_REQUEST['Product_Code'.$i]."',
					  '".$_REQUEST['Product_Discripion'.$i]."',
					  '".$_REQUEST['Quantity'.$i]."',
					  '".$_REQUEST['Selling_Price'.$i]."',
					   '".$_REQUEST['Discount_Price'.$i]."',
					  '".$_REQUEST['Amount'.$i]."')";
					  $result2=mysql_query($Query2);	
			 	}	
			 }
			 
// You_Got & You_Gave Sale Function for Ledger Enteries
// Purchase Order You_Gave Payment Save

$comments="Supplier Purchase";
if($Payment == "1"){

$Query3="INSERT INTO
		  suplier_ledger(
		  purchase_id,
		  `date`,
		  You_Got,
		  comments,
		  status,
		  suplier_id)
				VALUES(
				   '$order',
				   '$date',
				   '$total',
				   '$comments',
				   '$status',
				   '$id')";
			   $result3=mysql_query($Query3);			 

}else{
		$Query3="INSERT INTO
		  suplier_ledger(
		  purchase_id,
		  `date`,
		  You_Gave,
		  You_Got,
		  comments,
		  suplier_id)
				VALUES(
				   '$order',
				   '$date',
				   '$total',
				   '$total',
				   '$comments',
				   '$id')";
			   $result3=mysql_query($Query3);

}
			   
			   			 	   
header("location: preview1.php?invoice=".$order."&suplier_id=".$id."&date=".$date."");
//header("location: preview.php?invoice=".$_POST['order']."");

?>