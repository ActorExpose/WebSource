<?php
session_start();
include('connect.php');
$Query="UPDATE
  company
SET
  name = '".$_REQUEST['name']."',
  phone = '".$_REQUEST['phone']."',
  address =  '".$_REQUEST['address']."',
  ntn = '".$_REQUEST['ntn']."',
  strn = '".$_REQUEST['strn']."',
  date = '".$_REQUEST['date']."'
WHERE
  company.id='".$_REQUEST['memi']."' ";
$result=mysql_query($Query);

header("location: index2.php");
?>


