<?php
session_start();
include('connect.php');
$Query="UPDATE
  salesman
SET
  name = '".$_REQUEST['name']."',
  pmobile = '".$_REQUEST['pmobile']."',
  cnic =  '".$_REQUEST['cnic']."',
  hmobile = '".$_REQUEST['hmobile']."',
  address = '".$_REQUEST['address']."'
WHERE
  id ='".$_REQUEST['memi']."' ";
$result=mysql_query($Query);


// Transection Record Coding Start
date_default_timezone_set("Asia/Karachi");
$transectionno=($_REQUEST['memi']); // Transection Number 
$transectiontype="salesman.php";  // Page Where Transection Occur
$comments="Not Happy ! Beacause you Update the Data";   //  Happy 
$transectiondate = date("m-d-Y");   // Today Date
$transectiontime = date("h:i:sa"); //  Current Time
$transectionalert="High"; // High  //  Low
$Query="INSERT INTO
  transection(
  transectionno,
  transectiontype,
  comments,
  transectiondate,
  transectiontime,
  transectionalert)
VALUES(
  '$transectionno',
  '$transectiontype',
  '$comments',
  '$transectiondate',
  '$transectiontime',
  '$transectionalert')";
$result=mysql_query($Query);
// Transection Record Coding End

header("location: editSalesman.php");

?>

