<?php
session_start();
include('connect.php');
$Query="UPDATE
  suplier
SET
  suplier_name = '".$_REQUEST['name']."',
  pmobile = '".$_REQUEST['pmobile']."',
  business =  '".$_REQUEST['business']."',
  bmobile = '".$_REQUEST['bmobile']."',
  address = '".$_REQUEST['address']."'
WHERE
  suplier_id='".$_REQUEST['memi']."' ";
$result=mysql_query($Query);


// Transection Record Coding Start
date_default_timezone_set("Asia/Karachi");
$transectionno=($_REQUEST['memi']); // Transection Number 
$transectiontype="editSuppliercord.php";  // Page Where Transection Occur
$comments="Not Happy ! Beacause you Update the Data";   //  Happy 
$transectiondate = date("m-d-Y");   // Today Date
$transectiontime = date("h:i:sa"); //  Current Time
$transectionalert="High"; // High  //  Low
$Query="INSERT INTO
  transection(
  transectionno,
  transectiontype,
  comments,
  transectiondate,
  transectiontime,
  transectionalert)
VALUES(
  '$transectionno',
  '$transectiontype',
  '$comments',
  '$transectiondate',
  '$transectiontime',
  '$transectionalert')";
$result=mysql_query($Query);
// Transection Record Coding End

header("location: editSupplier.php");

?>

