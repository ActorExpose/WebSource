<? function embbed_js_code($fnc_names, $id)
	{
	echo "  <script language=\"JavaScript\" type=\"text/javascript\">
	var currentoption_".$fnc_names."=1;		//The currently selected auto-complete option
	var thislistopen_".$fnc_names."=false;	//Whether this list is opened up
	
	//Get a list of matching entries
	function getList_".$fnc_names."(e)
	{
		if(!e){
		  //for IE
		  e = window.event;
		}
		if(e.keyCode!=38&&e.keyCode!=40&&e.keyCode!=37&&e.keyCode!=39&&e.keyCode!=13&&e.keyCode!=9)
		{
			//Add in a delay to reduce remote calls if person types fast
			setTimeout('finditem_".$fnc_names."(\"'+document.getElementById(\"".$fnc_names."\").value+'\")',keystrokedelay);
		}
		else if(document.getElementById(\"".$fnc_names."\").setSelectionRange&&e.keyCode==38) //For moz. up arrow behavior
		{
			document.getElementById(\"".$fnc_names."\").setSelectionRange(document.getElementById(\"".$fnc_names."\").value.length,document.getElementById(\"".$fnc_names."\").value.length);
			document.getElementById(\"".$fnc_names."\").focus();
		}
	}
	
	function fireKeyListener_".$fnc_names."(e)
	{
		if(navigator.appName==\"Microsoft Internet Explorer\" )//IE
		{
			if(document.onkeydown!=keyListener_".$fnc_names.")
			{
				document.onkeydown=keyListener_".$fnc_names.";
			}
		}
		else
		{
			if(document.onkeypress!=keyListener_".$fnc_names.")
			{
				document.onkeypress=keyListener_".$fnc_names.";
			}
		}
		
	}
	
	//Listens for arrow keys
	function keyListener_".$fnc_names."(e)
	{		
		
		if(!e){
		  //for IE
		  e = window.event;
		}
		
		if(document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML!=\"\")
		{
				
			if(e.keyCode==38){
				//keyCode 38 is up arrow
			  	//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")-1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."-1;
				}								
				
				e.cancelBubble=true;
		    	e.returnValue=false;
		    	return false;
			}
			if(e.keyCode==40){
				//keyCode 40 is down arrow
				//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")+1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."+1;
				}
				e.cancelBubble=true;
		    	e.returnValue=false;
				return false;
			}
			if(e.keyCode==13||e.keyCode==9 || e.keyCode==90){
				//keyCode 13 is Enter
				fillbox_".$fnc_names."(document.getElementById(\"resultname_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value, document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value);
				if(e.keyCode==13 || e.keyCode==90)document.getElementById(\"".$fnc_names."\").focus();
				if(document.getElementById(\"".$id."\").onchange)document.getElementById(\"".$id."\").onchange();
				
				return false;
			}
		}
		
		
		return true;
	}
	
	//Display list of current string matches
	function displayresult_".$fnc_names."(names)
	{		
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=names;
		
		if(names!=\"\")
		{
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlight\";
			
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"hidden\";
			}
			if(thislistopen_".$fnc_names."==false)
			{
				displaylistcount++; //Record that an additional list is open
				thislistopen_".$fnc_names."=true;
			}
		}
		else //Show our hidden selects (for IE)
		{
			document.getElementById(\"".$id."\").value=\"\";									
			hideresult_".$fnc_names."();
		}
	}
	
	function finditem_".$fnc_names."(namepart)
	{
		if(namepart!=\"\")
		{
			if(document.getElementById('".$fnc_names."').value==namepart)
			{
				//document.getElementById('sent').innerHTML+=\"SENT request for: <b>\"+namepart+\"</b><br>\";
				x_find".$fnc_names."(namepart, '".$fnc_names."', displayresult_".$fnc_names.");
			}
			else
			{
				//document.getElementById('canceled').innerHTML+=\"CANCELED request for: <b>\"+namepart+\"</b><br>\";
			}
		}
		else
		{
			document.getElementById(\"".$id."\").value=\"\";
			hideresult_".$fnc_names."();
		}
	}
	
	//Record the user's selection
	function fillbox_".$fnc_names."(name, id)
	{
		document.getElementById(\"".$id."\").value=id;		
		document.getElementById(\"".$fnc_names."\").value=name;		
		hideresult_".$fnc_names."();
	}
	
	//Highlight the current selection
	function setCurrent_".$fnc_names."(currentNum)
	{		
	
		if(currentNum!=currentoption_".$fnc_names.")
		{		
			//blank out all previous
			document.getElementById(\"option_".$fnc_names."[\"+(currentNum)+\"]\").className=\"autohighlight\";
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentNum)+\"]\").value;
			currentoption_".$fnc_names."=currentNum*1;
		
		}
		
	}
	
	//Hide result set and show select boxes again (for IE)
	function hideresult_".$fnc_names."()
	{
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		if(thislistopen_".$fnc_names."==true)
		{
			thislistopen_".$fnc_names."=false;
			displaylistcount--; //Reduce the number of lists open
		}
		if(displaylistcount==0)
		{
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"visible\";
			}
		}
	}
	</script>";

}



function embbed_js_code_item($fnc_names, $id, $line )
	{
	echo "  <script language=\"JavaScript\" type=\"text/javascript\">
	var currentoption_".$fnc_names."=1;		//The currently selected auto-complete option
	var thislistopen_".$fnc_names."=false;	//Whether this list is opened up
	
	//Get a list of matching entries
	function getList_".$fnc_names."(e)
	{
		if(!e){
		  //for IE
		  e = window.event;
		}
		if(e.keyCode!=38&&e.keyCode!=40&&e.keyCode!=37&&e.keyCode!=39&&e.keyCode!=13&&e.keyCode!=9)
		{
			//Add in a delay to reduce remote calls if person types fast
			setTimeout('finditem_".$fnc_names."(\"'+document.getElementById(\"".$fnc_names."\").value+'\")',keystrokedelay);
		}
		else if(document.getElementById(\"".$fnc_names."\").setSelectionRange&&e.keyCode==38) //For moz. up arrow behavior
		{
			document.getElementById(\"".$fnc_names."\").setSelectionRange(document.getElementById(\"".$fnc_names."\").value.length,document.getElementById(\"".$fnc_names."\").value.length);
			document.getElementById(\"iid".$line."\").value=document.getElementById(\"itid".$line."\").value;
			document.getElementById(\"".$fnc_names."\").focus();
		}
	}
	
	function fireKeyListener_".$fnc_names."(e)
	{
		if(navigator.appName==\"Microsoft Internet Explorer\" )//IE
		{
			if(document.onkeydown!=keyListener_".$fnc_names.")
			{
				document.onkeydown=keyListener_".$fnc_names.";
			}
		}
		else
		{
			if(document.onkeypress!=keyListener_".$fnc_names.")
			{
				document.onkeypress=keyListener_".$fnc_names.";
			}
		}
		
	}
	
	//Listens for arrow keys
	function keyListener_".$fnc_names."(e)
	{		
		
		if(!e){
		  //for IE
		  e = window.event;
		}
		
		if(document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML!=\"\")
		{
				
			if(e.keyCode==38){
				//keyCode 38 is up arrow
			  	//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")-1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					
					document.getElementById(\"priceach".$line."\").value=document.getElementById(\"perpriceunit".$line."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					document.getElementById(\"iid".$line."\").value=document.getElementById(\"itid".$line."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					
					document.getElementById(\"qtyunitperpriceunit".$line."\").value=document.getElementById(\"priceunitsperstockunit".$line."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					document.getElementById(\"glacctdesc".$line."\").value=document.getElementById(\"glacctdesc".$line."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					document.getElementById(\"glaccountid".$line."\").value=document.getElementById(\"glaccountid".$line."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."-1;
				}								
				
				e.cancelBubble=true;
		    	e.returnValue=false;
		    	return false;
			}
			if(e.keyCode==40){
				//keyCode 40 is down arrow
				//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")+1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					
					document.getElementById(\"priceach".$line."\").value=document.getElementById(\"perpriceunit".$line."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					
					document.getElementById(\"iid".$line."\").value=document.getElementById(\"itid".$line."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					
					document.getElementById(\"qtyunitperpriceunit".$line."\").value=document.getElementById(\"priceunitsperstockunit".$line."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					
					document.getElementById(\"glacctdesc".$line."\").value=document.getElementById(\"glacctdesc".$line."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
			
			document.getElementById(\"glaccountid".$line."\").value=document.getElementById(\"glaccountid".$line."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."+1;
				}
				e.cancelBubble=true;
		    	e.returnValue=false;
				return false;
			}
			if(e.keyCode==13||e.keyCode==9){
				//keyCode 13 is Enter
				document.getElementById(\"iid".$line."\").value=document.getElementById(\"itid".$line."[\"+(currentoption_".$fnc_names.")+\"]\").value;
				fillbox_".$fnc_names."(document.getElementById(\"resultname_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value, document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value);
				if(e.keyCode==13)document.getElementById(\"".$fnc_names."\").focus();
				if(document.getElementById(\"".$id."\").onchange)document.getElementById(\"".$id."\").onchange();
				
				return false;
			}
		}
		
		
		return true;
	}
	
	//Display list of current string matches
	function displayresult_".$fnc_names."(names)
	{		
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=names;
		
		if(names!=\"\")
		{
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			document.getElementById(\"priceach".$line."\").value=document.getElementById(\"perpriceunit".$line."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			document.getElementById(\"qtyunitperpriceunit".$line."\").value=document.getElementById(\"priceunitsperstockunit".$line."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			document.getElementById(\"glacctdesc".$line."\").value=document.getElementById(\"glacctdesc".$line."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			document.getElementById(\"glaccountid".$line."\").value=document.getElementById(\"glaccountid".$line."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlight\";
			
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"hidden\";
			}
			if(thislistopen_".$fnc_names."==false)
			{
				displaylistcount++; //Record that an additional list is open
				thislistopen_".$fnc_names."=true;
			}
		}
		else //Show our hidden selects (for IE)
		{
			document.getElementById(\"".$id."\").value=\"\";
			
			document.getElementById(\"priceach".$line."\").value=\"\";
			document.getElementById(\"qtyunitperpriceunit".$line."\").value=\"\";
			document.getElementById(\"glacctdesc".$line."\").value=\"\";
			document.getElementById(\"glaccountid".$line."\").value=\"\";
			document.getElementById(\"qty".$line."\").value=\"\";
			
			hideresult_".$fnc_names."();
		}
	}
	
	function finditem_".$fnc_names."(namepart)
	{
		if(namepart!=\"\")
		{
			if(document.getElementById('".$fnc_names."').value==namepart)
			{
				//document.getElementById('sent').innerHTML+=\"SENT request for: <b>\"+namepart+\"</b><br>\";
				x_find".$fnc_names."(namepart, '".$fnc_names."', displayresult_".$fnc_names.");
			}
			else
			{
				//document.getElementById('canceled').innerHTML+=\"CANCELED request for: <b>\"+namepart+\"</b><br>\";
			}
		}
		else
		{
			document.getElementById(\"".$id."\").value=\"\";
			
			document.getElementById(\"priceach".$line."\").value=\"\";
			document.getElementById(\"qtyunitperpriceunit".$line."\").value=\"\";
			document.getElementById(\"glacctdesc".$line."\").value=\"\";
			document.getElementById(\"glaccountid".$line."\").value=\"\";
			document.getElementById(\"qty".$line."\").value=\"\";
			hideresult_".$fnc_names."();
		}
	}
	
	//Record the user's selection
	function fillbox_".$fnc_names."(name, id)
	{
		document.getElementById(\"".$id."\").value=id;		
		document.getElementById(\"".$fnc_names."\").value=name;		
		hideresult_".$fnc_names."();
	}
	
	//Highlight the current selection
	function setCurrent_".$fnc_names."(currentNum, iid)
	{		
	//alert(currentNum+'--'+ iid);
	//alert(".$fnc_names.");
		if(currentNum!=currentoption_".$fnc_names.")
		{		
			//blank out all previous
			document.getElementById(\"option_".$fnc_names."[\"+(currentNum)+\"]\").className=\"autohighlight\";
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentNum)+\"]\").value;
						
			document.getElementById(\"priceach".$line."\").value=document.getElementById(\"perpriceunit".$line."[\"+(currentNum)+\"]\").value;

			document.getElementById(\"qtyunitperpriceunit".$line."\").value=document.getElementById(\"priceunitsperstockunit".$line."[\"+(currentNum)+\"]\").value;

			document.getElementById(\"glacctdesc".$line."\").value=document.getElementById(\"glacctdesc".$line."[\"+(currentNum)+\"]\").value;
			
			document.getElementById(\"glaccountid".$line."\").value=document.getElementById(\"glaccountid".$line."[\"+(currentNum)+\"]\").value;

			document.getElementById(\"iid".$line."\").value=iid;

			//alert(document.getElementById(\"perpriceunit".$line."[\"+(currentNum)+\"]\").value);
			
			currentoption_".$fnc_names."=currentNum*1;
		
		}
		else
		{		
			//blank out all previous
			document.getElementById(\"option_".$fnc_names."[\"+(currentNum)+\"]\").className=\"autohighlight\";
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentNum)+\"]\").value;
						
			document.getElementById(\"priceach".$line."\").value=document.getElementById(\"perpriceunit".$line."[\"+(currentNum)+\"]\").value;

			document.getElementById(\"qtyunitperpriceunit".$line."\").value=document.getElementById(\"priceunitsperstockunit".$line."[\"+(currentNum)+\"]\").value;

			document.getElementById(\"glacctdesc".$line."\").value=document.getElementById(\"glacctdesc".$line."[\"+(currentNum)+\"]\").value;
			
			document.getElementById(\"glaccountid".$line."\").value=document.getElementById(\"glaccountid".$line."[\"+(currentNum)+\"]\").value;

			document.getElementById(\"iid".$line."\").value=iid;

			//alert(document.getElementById(\"perpriceunit".$line."[\"+(currentNum)+\"]\").value);
			
			currentoption_".$fnc_names."=currentNum*1;
		
		}
	}
	
	//Hide result set and show select boxes again (for IE)
	function hideresult_".$fnc_names."()
	{
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		if(thislistopen_".$fnc_names."==true)
		{
			thislistopen_".$fnc_names."=false;
			displaylistcount--; //Reduce the number of lists open
		}
		if(displaylistcount==0)
		{
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"visible\";
			}
		}
	}
	</script>";

}



function embbed_js_code_item_mfg($fnc_names, $id, $line )
	{
	echo "  <script language=\"JavaScript\" type=\"text/javascript\">
	var currentoption_".$fnc_names."=1;		//The currently selected auto-complete option
	var thislistopen_".$fnc_names."=false;	//Whether this list is opened up
	
	//Get a list of matching entries
	function getList_".$fnc_names."(e)
	{
		if(!e){
		  //for IE
		  e = window.event;
		}
		if(e.keyCode!=38&&e.keyCode!=40&&e.keyCode!=37&&e.keyCode!=39&&e.keyCode!=13&&e.keyCode!=9)
		{
			//Add in a delay to reduce remote calls if person types fast
			setTimeout('finditem_".$fnc_names."(\"'+document.getElementById(\"".$fnc_names."\").value+'\")',keystrokedelay);
		}
		else if(document.getElementById(\"".$fnc_names."\").setSelectionRange&&e.keyCode==38) //For moz. up arrow behavior
		{
			document.getElementById(\"".$fnc_names."\").setSelectionRange(document.getElementById(\"".$fnc_names."\").value.length,document.getElementById(\"".$fnc_names."\").value.length);
			document.getElementById(\"".$fnc_names."\").focus();
		}
	}
	
	function fireKeyListener_".$fnc_names."(e)
	{
		if(navigator.appName==\"Microsoft Internet Explorer\" )//IE
		{
			if(document.onkeydown!=keyListener_".$fnc_names.")
			{
				document.onkeydown=keyListener_".$fnc_names.";
			}
		}
		else
		{
			if(document.onkeypress!=keyListener_".$fnc_names.")
			{
				document.onkeypress=keyListener_".$fnc_names.";
			}
		}
		
	}
	
	//Listens for arrow keys
	function keyListener_".$fnc_names."(e)
	{		
		
		if(!e){
		  //for IE
		  e = window.event;
		}
		
		if(document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML!=\"\")
		{
				
			if(e.keyCode==38){
				//keyCode 38 is up arrow
			  	//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")-1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
					
					
					
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."-1;
				}								
				
				e.cancelBubble=true;
		    	e.returnValue=false;
		    	return false;
			}
			if(e.keyCode==40){
				//keyCode 40 is down arrow
				//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")+1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;
					
										
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."+1;
				}
				e.cancelBubble=true;
		    	e.returnValue=false;
				return false;
			}
			if(e.keyCode==13||e.keyCode==9){
				//keyCode 13 is Enter
				fillbox_".$fnc_names."(document.getElementById(\"resultname_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value, document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value);
				if(e.keyCode==13)document.getElementById(\"".$fnc_names."\").focus();
				if(document.getElementById(\"".$id."\").onchange)document.getElementById(\"".$id."\").onchange();
				
				return false;
			}
		}
		
		
		return true;
	}
	
	//Display list of current string matches
	function displayresult_".$fnc_names."(names)
	{		
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=names;
		
		if(names!=\"\")
		{
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value;
			
			
			
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlight\";
			
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"hidden\";
			}
			if(thislistopen_".$fnc_names."==false)
			{
				displaylistcount++; //Record that an additional list is open
				thislistopen_".$fnc_names."=true;
			}
		}
		else //Show our hidden selects (for IE)
		{
			document.getElementById(\"".$id."\").value=\"\";
			
			
			
			hideresult_".$fnc_names."();
		}
	}
	
	function finditem_".$fnc_names."(namepart)
	{
		if(namepart!=\"\")
		{
			if(document.getElementById('".$fnc_names."').value==namepart)
			{
				//document.getElementById('sent').innerHTML+=\"SENT request for: <b>\"+namepart+\"</b><br>\";
				x_find".$fnc_names."(namepart, '".$fnc_names."', displayresult_".$fnc_names.");
			}
			else
			{
				//document.getElementById('canceled').innerHTML+=\"CANCELED request for: <b>\"+namepart+\"</b><br>\";
			}
		}
		else
		{
			document.getElementById(\"".$id."\").value=\"\";
			
			
			hideresult_".$fnc_names."();
		}
	}
	
	//Record the user's selection
	function fillbox_".$fnc_names."(name, id)
	{
		document.getElementById(\"".$id."\").value=id;		
		document.getElementById(\"".$fnc_names."\").value=name;		
		hideresult_".$fnc_names."();
	}
	
	//Highlight the current selection
	function setCurrent_".$fnc_names."(currentNum)
	{		
	
		if(currentNum!=currentoption_".$fnc_names.")
		{		
			//blank out all previous
			document.getElementById(\"option_".$fnc_names."[\"+(currentNum)+\"]\").className=\"autohighlight\";
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentNum)+\"]\").value;
						
			
			
			currentoption_".$fnc_names."=currentNum*1;
		
		}
		
	}
	
	//Hide result set and show select boxes again (for IE)
	function hideresult_".$fnc_names."()
	{
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		if(thislistopen_".$fnc_names."==true)
		{
			thislistopen_".$fnc_names."=false;
			displaylistcount--; //Reduce the number of lists open
		}
		if(displaylistcount==0)
		{
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"visible\";
			}
		}
	}
	</script>";

}


function embbed_js_code_glacct($fnc_names, $id, $line )
	{
	echo "  <script language=\"JavaScript\" type=\"text/javascript\">
	var currentoption_".$fnc_names."=1;		//The currently selected auto-complete option
	var thislistopen_".$fnc_names."=false;	//Whether this list is opened up
	
	//Get a list of matching entries
	function getList_".$fnc_names."(e)
	{
		if(!e){
		  //for IE
		  e = window.event;
		}
		if(e.keyCode!=38&&e.keyCode!=40&&e.keyCode!=37&&e.keyCode!=39&&e.keyCode!=13&&e.keyCode!=9)
		{
			//Add in a delay to reduce remote calls if person types fast
			setTimeout('finditem_".$fnc_names."(\"'+document.getElementById(\"".$fnc_names."\").value+'\")',keystrokedelay);
		}
		else if(document.getElementById(\"".$fnc_names."\").setSelectionRange&&e.keyCode==38) //For moz. up arrow behavior
		{
			document.getElementById(\"".$fnc_names."\").setSelectionRange(document.getElementById(\"".$fnc_names."\").value.length,document.getElementById(\"".$fnc_names."\").value.length);
			document.getElementById(\"".$fnc_names."\").focus();
		}
	}
	
	function fireKeyListener_".$fnc_names."(e)
	{
		if(navigator.appName==\"Microsoft Internet Explorer\" )//IE
		{
			if(document.onkeydown!=keyListener_".$fnc_names.")
			{
				document.onkeydown=keyListener_".$fnc_names.";
			}
		}
		else
		{
			if(document.onkeypress!=keyListener_".$fnc_names.")
			{
				document.onkeypress=keyListener_".$fnc_names.";
			}
		}
		
	}
	
	//Listens for arrow keys
	function keyListener_".$fnc_names."(e)
	{		
		
		if(!e){
		  //for IE
		  e = window.event;
		}
		
		if(document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML!=\"\")
		{
				
			if(e.keyCode==38){
				//keyCode 38 is up arrow
			  	//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")-1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."-1)+\"]\").value;
				
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."-1;
				}								
				
				e.cancelBubble=true;
		    	e.returnValue=false;
		    	return false;
			}
			if(e.keyCode==40){
				//keyCode 40 is down arrow
				//document.getElementById(\"".$fnc_names."\").blur();
				setTimeout('document.getElementById(\"".$fnc_names."\").focus();',10);
				if(document.getElementById(\"option_".$fnc_names."[\"+((currentoption_".$fnc_names.")+1)+\"]\"))
				{
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").className=\"autohighlight\";
					document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names."+1)+\"]\").value;										
					
					document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
					currentoption_".$fnc_names."=currentoption_".$fnc_names."+1;
				}
				e.cancelBubble=true;
		    	e.returnValue=false;
				return false;
			}
			if(e.keyCode==13||e.keyCode==9){
				//keyCode 13 is Enter
				
				fillbox_".$fnc_names."(document.getElementById(\"resultname_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value, document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value);
				
				if(e.keyCode==13)document.getElementById(\"".$fnc_names."\").focus();
				if(document.getElementById(\"".$id."\").onchange)document.getElementById(\"".$id."\").onchange();
				
				return false;
			}
		}
		
		
		return true;
	}
	
	//Display list of current string matches
	function displayresult_".$fnc_names."(names)
	{		
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=names;
		
		if(names!=\"\")
		{
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").value;						
			
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlight\";
			
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"hidden\";
			}
			if(thislistopen_".$fnc_names."==false)
			{
				displaylistcount++; //Record that an additional list is open
				thislistopen_".$fnc_names."=true;
			}
		}
		else //Show our hidden selects (for IE)
		{
			document.getElementById(\"".$id."\").value=\"\";						
			hideresult_".$fnc_names."();
		}
	}
	
	function finditem_".$fnc_names."(namepart)
	{
		if(namepart!=\"\")
		{
			if(document.getElementById('".$fnc_names."').value==namepart)
			{
				//document.getElementById('sent').innerHTML+=\"SENT request for: <b>\"+namepart+\"</b><br>\";
				x_find".$fnc_names."(namepart, '".$fnc_names."', displayresult_".$fnc_names.");
			}
			else
			{
				//document.getElementById('canceled').innerHTML+=\"CANCELED request for: <b>\"+namepart+\"</b><br>\";
			}
		}
		else
		{
			document.getElementById(\"".$id."\").value=\"\";			
			hideresult_".$fnc_names."();
		}
	}
	
	//Record the user's selection
	function fillbox_".$fnc_names."(name, id)
	{
		document.getElementById(\"".$id."\").value=id;		
		document.getElementById(\"".$fnc_names."\").value=name;		
		hideresult_".$fnc_names."();
	}
	
	//Highlight the current selection
	function setCurrent_".$fnc_names."(currentNum)
	{		
	
		if(currentNum!=currentoption_".$fnc_names.")
		{		
			//blank out all previous
			document.getElementById(\"option_".$fnc_names."[\"+(currentNum)+\"]\").className=\"autohighlight\";
			document.getElementById(\"option_".$fnc_names."[\"+(currentoption_".$fnc_names.")+\"]\").className=\"autohighlightoff\";
			document.getElementById(\"".$id."\").value=document.getElementById(\"resultid_".$fnc_names."[\"+(currentNum)+\"]\").value;						
			
			currentoption_".$fnc_names."=currentNum*1;
		
		}
		
	}
	
	//Hide result set and show select boxes again (for IE)
	function hideresult_".$fnc_names."()
	{
		document.getElementById(\"resultdisplay_".$fnc_names."\").innerHTML=\"\";
		if(thislistopen_".$fnc_names."==true)
		{
			thislistopen_".$fnc_names."=false;
			displaylistcount--; //Reduce the number of lists open
		}
		if(displaylistcount==0)
		{
			var nodeList = document.getElementsByTagName(\"SELECT\");
			for (var i = 0; i < nodeList.length; i++)
			{
				nodeList[i].style.visibility = \"visible\";
			}
		}
	}
	</script>";

}



?>