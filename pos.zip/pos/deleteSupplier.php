<?php
include('connect.php');
$id=$_GET['id'];
$Query="DELETE FROM suplier WHERE suplier_id='$id'";
$result=mysql_query($Query);

// Transection Record Coding Start
date_default_timezone_set("Asia/Karachi");
$transectionno=($_REQUEST['id']); // Transection Number 
$transectiontype="deleteSupplier.php";  // Page Where Transection Occur
$comments="Not Happy ! Because you Delete the Data";   //  Happy 
$transectiondate = date("m-d-Y");   // Today Date
$transectiontime = date("h:i:sa"); //  Current Time
$transectionalert="Very High ( 100% )"; // High  //  Low
$Query="INSERT INTO
  transection(
  transectionno,
  transectiontype,
  comments,
  transectiondate,
  transectiontime,
  transectionalert)
VALUES(
  '$transectionno',
  '$transectiontype',
  '$comments',
  '$transectiondate',
  '$transectiontime',
  '$transectionalert')";
$result=mysql_query($Query);
// Transection Record Coding End


header("location: index.php");
?>