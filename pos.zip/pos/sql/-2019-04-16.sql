DROP TABLE company;

CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company VALUES("1","Five Star Plastic Industry","03004251610","Samanabad  Chungi Pindi Bypass Gujranwala");



DROP TABLE customer;

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) DEFAULT NULL,
  `pmobile` varchar(100) DEFAULT NULL,
  `business` varchar(100) DEFAULT NULL,
  `bmobile` varchar(100) DEFAULT NULL,
  `address` varchar(550) DEFAULT NULL,
  `date` varchar(500) DEFAULT NULL,
  `Opening_Balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO customer VALUES("1","Gujrat -  Abdul Rehman Akram ","03006263015","Akram Sanitary Store , Gujrat","","Near Shah Dola Chowk , Gujrat","2018-12-25","399398");
INSERT INTO customer VALUES("2","Mandi Baho Din - Gulzar Sab.","03338018385","Al-Mobini Sanitary Store , Mandi Baho Din","","Near Markazi Masjid - Mandi Baho Din","2018-12-25","238325");
INSERT INTO customer VALUES("3","Phalia - Iqbal Brothers","03016879560","Iqbal Brothers Trader - Phalia","","Near Ganda Nala CNG - Phalia","2018-12-25","265495");
INSERT INTO customer VALUES("4","Lala Musa - Abid Hussain","03016325369","Ali Husnain Sanitary Store , Lala Musa","","Main Sanitary Bazar - Lala Musa","2018-12-25","242050");
INSERT INTO customer VALUES("5","Sailkot - Ahmed Butt","03009615594","Ahmed Butt Sanitary Store , Gujrat","","Near 1122 Office - Sailkot","2018-12-25","48725");
INSERT INTO customer VALUES("6","Sailkot - Shahbaz Jutt","03006144321","Khari Sharif Sanitary Store","","Near maryam abad Sailkot - Ugoki Road","2018-12-25","291635");
INSERT INTO customer VALUES("7","Sailkot - Sultan Khan ","03216109313","Khan Sanitary Store, Sailkot","","Main Sahaba Phatak , Sailkot","2018-12-25","181765");
INSERT INTO customer VALUES("8","Sailkot - Waseem / Azhar","03008614192","Azhar Pipe Store , Sailkot","03009614192"," Near Goad Pur Chowk , Sailkot","2018-12-25","1235560");
INSERT INTO customer VALUES("9","Zafarwal - Amir Shahfiq","03466927935","Shahfiq Sanitary Store , Zafarwal","","Chawind Chowk , Zafarwal","2018-12-25","104112");
INSERT INTO customer VALUES("10","Damthal - Abdul Razaq","03466791214","Abdul Razaq Sanitary Store , Damthal","03419803436","Main Bazar Damthal - Zafawal Road","2018-12-25","234000");
INSERT INTO customer VALUES("11","Damthal - Rana Sajid , Rana Danish","03009617972","Danish Sanitary Store , Damthal","","Main Bazar Damthal - Zafawal Road","2018-12-25","782700");
INSERT INTO customer VALUES("12","Sailkot - Abdul Raheem / Munna Bahi","03007174853","Al Sadiq Pipes Store , Sailkot","03000412470","1-Nika Pura ,2- Sailkot Mandi , Sailkot ","2018-12-25","458960");
INSERT INTO customer VALUES("13","Samundri - Ajmal / Akmal","03457813749","Jameel Sanitary Store , Samundri ,Faisalabad","03467745150","Samundri Road ","2018-12-25","214990");
INSERT INTO customer VALUES("14","Deena - Habib ","03005459967","Noman Sanitary Store , Deena","03205459967","Pakhi wali Sarkar - Deena","2018-12-25","45225");
INSERT INTO customer VALUES("15","Nonar - Rana Asad","03006185561","Rana Azam Sanitary Store , Nonar","03006267046","Main Bazar - Nonar","2018-12-25","39400");
INSERT INTO customer VALUES("16","Saraay Alam Gir - Gulam Ghous","03009519642","Abudl Majeed Sanitary Store , Saraay Alam Gir","03009519642","Main Bazar , Saraay Alam Gir","2018-12-25","40000");
INSERT INTO customer VALUES("17","Lala Musa - Umair","03088069122","Rehmat Sanitary Store , Lala Musa","","Main Bazar Lala Musa","2018-12-25","341820");
INSERT INTO customer VALUES("18","Jehlam - Ahmed","03005440904","Naqasbandiya Sanitary Store , Jehlam","","Jehlam","2018-12-25","1900");
INSERT INTO customer VALUES("19","Lala Musa - Liaqat","03338461997","Liaqat Sanitary Store , Lala Musa","","Main Baza Lala Musa","2018-12-26","140250");
INSERT INTO customer VALUES("20","Khatyala Sheikhan - Adnan Zafar","03226623060","Zafar Paint Store - Khatyala Sheikhan","03007743040","Phalia Road Main Bazar Khatyala Sheikhan","2018-12-26","61130");
INSERT INTO customer VALUES("21","Deena - Kousar Nadeem Shah","03015833875","Bukhari Sanitary Store , Deena","03335792064","Mangla Road , Main Bazar Deena","2018-12-26","756900");
INSERT INTO customer VALUES("22","Khatyala Syedian - Khawar Ejaz","03077566673","Seven Sanitary Store , Khatyala Sheikhan","03077566671","Malikwal Road Khatyala Sheikhan , Mandi Baho Din","2018-12-26","170875");
INSERT INTO customer VALUES("23","Sailkot - Fahid Sab","03456666677","Groei Sanitary Store , Sailkot","03003666677","Near Godh Pur Chowk , Sailkot","2018-12-26","503590");
INSERT INTO customer VALUES("24","Nonar - Sohaib Umer","03457197483","Manj Sanitary Store , Nonar","03457197483","Main Bazar Nonar","2018-12-26","15440");
INSERT INTO customer VALUES("25","Badyana - Hamza Yousaf","03217182136","Hamza Sanitary Store , Badyana","03436442314","Main Bazar Badyana - Sailkot Road","2018-12-26","261140");
INSERT INTO customer VALUES("26","Ranja Maira - Gillani Sab","03135546664","Gillani Sanitary Store , Ranja Maira","03135546664","Main Bazar Ranja Maira","2018-12-26","65950");
INSERT INTO customer VALUES("27","Motra - Sokhat Sab","03006102447","Umair Sanitary Store , Motra","03006102447","Main Bazar Motra","2018-12-26","170175");
INSERT INTO customer VALUES("28","Ajk - Subhani ","03455736182","Subhani Sanitary Store , Khoi Ratta Ajk","03455739047","Subhani Sanitary Store , Khoi Ratta Ajk","2018-12-26","87150");
INSERT INTO customer VALUES("29","Gujranwala - Sajjad Gujjar","03400001301","Sajjad Trader , Gujranwala","","","2018-12-26","122000");
INSERT INTO customer VALUES("30","Gujranwala - Guffar Gujjar","034666261254","Guffar Traders , Gujranwala","","","2018-12-26","79980");
INSERT INTO customer VALUES("31","Gujranwala - Ramzan Gujjar","03026634529","Ramzan Traders , Gujranwala","03456634059","","2018-12-26","82320");
INSERT INTO customer VALUES("32","Gujranwala - Naseem","","","","","2018-12-26","29760");
INSERT INTO customer VALUES("33","Gujranwala - Nazim","03466200412","","","","2018-12-26","18000");
INSERT INTO customer VALUES("34","Chobara - Abdul Razaq","03018710755","Mugal Sanitary & Paint Store , Chobara","","","2018-12-26","136705");
INSERT INTO customer VALUES("35","Sailkot - Usman / Abdullah","03216153076","New Usman Sanitary Store , Sailkot","03227463655","Near Shahba Pathak , Sailkot","2018-12-26","58610");
INSERT INTO customer VALUES("36","Chak Jamal - Shah Jee","03005440403","Shah Jee Sanitary Store , Chak Jamal Jehlam","03335836901","Main Bazar Chak Jamal Jehlam","2018-12-26","46175");
INSERT INTO customer VALUES("37","Zafarwal - Mian Tariq","03456678265","Mian Tariq Hardware Store , Zafarwal","03336678266","Darman Road , Zafarwal","2018-12-26","70100");
INSERT INTO customer VALUES("38","Wadala Sindhwan - M.Rafique","03456743876","Mew Sanitary Store , Wadala Sindhwan","03456743876","Main Bazar Wadala Sindhwan","2018-12-26","26585");
INSERT INTO customer VALUES("39","Pasroor - Mirza Dilawar Fakhir","032118442417","Mirza Bashir Sanitary Store , Pasroor","03222222581"," Mian Bazar Near Police Station Pasroor","2018-12-26","611815");
INSERT INTO customer VALUES("40","Narowal - Irfan Farooq","03076889884","Farooq Sanitary Store , Narowal","03216061655","Main Bazar Pasroor Near Pathak","2018-12-26","256320");
INSERT INTO customer VALUES("41","Ugoki - Zulifqar Sab","03007128745","Al Madina Sanitary Store , Ugoki","","Main Bazar Ugoki","2018-12-26","43925");
INSERT INTO customer VALUES("42","Pasroor - Nadeem Mughal","03217165600","Mughal Sanitary Store , Pasroor","","Near Chawinda Phatak , Pasroor","2018-12-26","19235");
INSERT INTO customer VALUES("43","Nokhar - Nadeem Sab","030007442838","Nadeem Traders","03477801947","Nokhar ,Gujranwala Road","2018-12-26","47955");
INSERT INTO customer VALUES("44","Gujranwala - Khalid Dawn","","","","Dawn Traders","2018-12-26","212045");



DROP TABLE customer_ledger;

CREATE TABLE `customer_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `debit` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE customerpricelist;

CREATE TABLE `customerpricelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Product_Code` int(11) DEFAULT NULL,
  `Product_Name` varchar(200) DEFAULT NULL,
  `Selling_Price` int(11) DEFAULT NULL,
  `Discription` varchar(200) DEFAULT NULL,
  `customer` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE daybook;

CREATE TABLE `daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Particulars` varchar(100) DEFAULT NULL,
  `Transaction_Date` varchar(20) DEFAULT NULL,
  `Transaction_Detail` varchar(20) DEFAULT NULL,
  `Transaction_ID` int(11) DEFAULT NULL,
  `Debit` int(11) DEFAULT NULL,
  `Credit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE employee;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `pmobile` varchar(20) DEFAULT NULL,
  `cnic` varchar(20) DEFAULT NULL,
  `hmobile` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `startjob` varchar(20) DEFAULT NULL,
  `endjob` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE expensetype;

CREATE TABLE `expensetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `discription` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO expensetype VALUES("1","Utility Bills ( Electricity + Sui Gass  ) Monthly","( Electricity + Sui Gass + Others ) All Kinds of Bills");
INSERT INTO expensetype VALUES("2","Employees Monthly Salary","All Employees Monthly Salary");
INSERT INTO expensetype VALUES("3","Others Charges ( Any Kinds )","Any Kinds of Charges");



DROP TABLE expnese;

CREATE TABLE `expnese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE products;

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `Product_Code` int(11) DEFAULT NULL,
  `Product_Name` varchar(200) DEFAULT NULL,
  `Product_Unit` varchar(20) DEFAULT NULL,
  `Product_Discripion` varchar(200) DEFAULT NULL,
  `Selling_Price` int(11) DEFAULT NULL,
  `Orignal_Price` int(11) DEFAULT NULL,
  `Profit` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE purchaseorder;

CREATE TABLE `purchaseorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_id` int(11) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE purchaseorderdetail;

CREATE TABLE `purchaseorderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `discription` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE saleorder;

CREATE TABLE `saleorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE saleorderdetail;

CREATE TABLE `saleorderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `discription` varchar(200) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE suplier;

CREATE TABLE `suplier` (
  `suplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_name` varchar(100) NOT NULL,
  `pmobile` varchar(100) NOT NULL,
  `business` varchar(100) NOT NULL,
  `bmobile` varchar(100) NOT NULL,
  `address` varchar(550) NOT NULL,
  `date` varchar(500) NOT NULL,
  `Opening_Balance` int(11) DEFAULT NULL,
  PRIMARY KEY (`suplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE suplier_ledger;

CREATE TABLE `suplier_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `debit` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `suplier_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE transection;

CREATE TABLE `transection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transectionno` varchar(20) NOT NULL,
  `transectiontype` varchar(20) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `transectiondate` varchar(20) NOT NULL,
  `transectiontime` varchar(20) NOT NULL,
  `transectionalert` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO transection VALUES("1","1","editcustomerecord.ph","Not Happy ! Beacause you Update the Data","03-21-2019","06:54:56pm","High");
INSERT INTO transection VALUES("2","1","editcustomerecord.ph","Not Happy ! Beacause you Update the Data","04-11-2019","10:24:18pm","High");



DROP TABLE user;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","admin","admin","Admin","admin");
INSERT INTO user VALUES("2","ranaadrees","ranaadrees","ranaadrees","owner");



