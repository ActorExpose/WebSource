DROP TABLE company;

CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `ntn` varchar(20) DEFAULT NULL,
  `strn` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company VALUES("1","Five Star Plastic Industry","03004251610","Samanabad  Chungi Pindi Bypass Gujranwala","12344554454","1234564","2020-03-04");



DROP TABLE customer;

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) DEFAULT NULL,
  `pmobile` varchar(100) DEFAULT NULL,
  `business` varchar(100) DEFAULT NULL,
  `bmobile` varchar(100) DEFAULT NULL,
  `address` varchar(550) DEFAULT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO customer VALUES("1","Waseem Sab , Azhar Sab","03008614192","Azhar Pipes Store , Sailkot","03009614192","Airport Road KourPur Saikot","Wholesale Dealers / Top Level");



DROP TABLE customer_ledger;

CREATE TABLE `customer_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `GET_AMOUNT` int(11) NOT NULL,
  `GIVE_AMOUNT` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE daybook;

CREATE TABLE `daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transection_id` int(11) DEFAULT NULL,
  `transection_name` varchar(20) DEFAULT NULL,
  `transection_discription` varchar(50) DEFAULT NULL,
  `transection_date` varchar(20) DEFAULT NULL,
  `transection_year` varchar(20) DEFAULT NULL,
  `GET_AMOUNT` int(11) DEFAULT NULL,
  `GIVE_AMOUNT` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE employee;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `pmobile` varchar(20) DEFAULT NULL,
  `cnic` varchar(20) DEFAULT NULL,
  `hmobile` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `startjob` varchar(20) DEFAULT NULL,
  `endjob` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE expensetype;

CREATE TABLE `expensetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `discription` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE expnese;

CREATE TABLE `expnese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE products;

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `Product_Code` int(11) DEFAULT NULL,
  `Product_Name` varchar(200) DEFAULT NULL,
  `Product_Unit` varchar(20) DEFAULT NULL,
  `Product_Discripion` varchar(200) DEFAULT NULL,
  `Selling_Price` int(11) DEFAULT NULL,
  `Orignal_Price` int(11) DEFAULT NULL,
  `Profit` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO products VALUES("1","9999","Opening Balance","Opening Balance","Opening Balance ","0","0","0");



DROP TABLE purchaseorder;

CREATE TABLE `purchaseorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_id` int(11) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `Pre_Total` int(11) DEFAULT NULL,
  `Discount_Total` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE purchaseorderdetail;

CREATE TABLE `purchaseorderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `discription` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE saleorder;

CREATE TABLE `saleorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `Pre_Total` int(11) DEFAULT NULL,
  `Discount_Total` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE saleorderdetail;

CREATE TABLE `saleorderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `discription` varchar(200) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE salesman;

CREATE TABLE `salesman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `pmobile` varchar(20) DEFAULT NULL,
  `cnic` varchar(20) DEFAULT NULL,
  `hmobile` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `startjob` varchar(20) DEFAULT NULL,
  `endjob` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE suplier;

CREATE TABLE `suplier` (
  `suplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_name` varchar(100) NOT NULL,
  `pmobile` varchar(100) NOT NULL,
  `business` varchar(100) NOT NULL,
  `bmobile` varchar(100) NOT NULL,
  `address` varchar(550) NOT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`suplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE suplier_ledger;

CREATE TABLE `suplier_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `GET_AMOUNT` int(11) DEFAULT NULL,
  `GIVE_AMOUNT` int(11) DEFAULT NULL,
  `suplier_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE transection;

CREATE TABLE `transection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transectionno` varchar(20) NOT NULL,
  `transectiontype` varchar(50) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `transectiondate` varchar(20) NOT NULL,
  `transectiontime` varchar(20) NOT NULL,
  `transectionalert` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE user;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","admin","admin","Admin","admin");



