DROP TABLE company;

CREATE TABLE `company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `ntn` varchar(20) DEFAULT NULL,
  `strn` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company VALUES("1","Rajput Plastic Industry","03004251610","Samanabad  Chungi Pindi Bypass Gujranwala","12344554454","1234564","2020-03-04");



DROP TABLE customer;

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) DEFAULT NULL,
  `pmobile` varchar(100) DEFAULT NULL,
  `business` varchar(100) DEFAULT NULL,
  `bmobile` varchar(100) DEFAULT NULL,
  `address` varchar(550) DEFAULT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO customer VALUES("1","Waseem Sab , Azhar Sab","03008614192","Azhar Pipes Store , Sailkot","03009614192","Airport Road KourPur Saikot","Wholesale Dealers / Top Level");
INSERT INTO customer VALUES("2","Abid Sab - Lala Musa","","","","","");



DROP TABLE customer_ledger;

CREATE TABLE `customer_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `GET_AMOUNT` int(11) NOT NULL,
  `GIVE_AMOUNT` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO customer_ledger VALUES("1","1","2020-10-17","0","1837425","1","1","Customer Sale","1");



DROP TABLE daybook;

CREATE TABLE `daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transection_id` int(11) DEFAULT NULL,
  `transection_name` varchar(20) DEFAULT NULL,
  `transection_discription` varchar(50) DEFAULT NULL,
  `transection_date` varchar(20) DEFAULT NULL,
  `transection_year` varchar(20) DEFAULT NULL,
  `GET_AMOUNT` int(11) DEFAULT NULL,
  `GIVE_AMOUNT` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO daybook VALUES("1","1","Customer Sale","Credit sales","2020-10-22","2020","","0");
INSERT INTO daybook VALUES("2","2","Customer Sale","Credit sales","2020-10-22","2020","","0");
INSERT INTO daybook VALUES("3","3","Customer Sale","Credit sales","2020-10-17","2020","","1837425");
INSERT INTO daybook VALUES("4","1","Customer Sale","Credit sales","2020-10-17","2020","","1837425");
INSERT INTO daybook VALUES("5","2","Customer Sale","Credit sales","2020-10-23","2020","","190250");
INSERT INTO daybook VALUES("6","1","Customer Sale","Credit sales","2020-10-17","2020","","1837425");



DROP TABLE employee;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `pmobile` varchar(20) DEFAULT NULL,
  `cnic` varchar(20) DEFAULT NULL,
  `hmobile` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `startjob` varchar(20) DEFAULT NULL,
  `endjob` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE expensetype;

CREATE TABLE `expensetype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `discription` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE expnese;

CREATE TABLE `expnese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE pricelist;

CREATE TABLE `pricelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Product_Code` int(11) DEFAULT NULL,
  `Product_Name` varchar(200) DEFAULT NULL,
  `Selling_Price` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `suplier_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

INSERT INTO pricelist VALUES("27","101","150 - US - UNITED","1500","1","","2020-10-23");
INSERT INTO pricelist VALUES("28","102","200 - US  - UNITED","2125","1","","2020-10-23");
INSERT INTO pricelist VALUES("29","103","300 - US - UNITED","2250","1","","2020-10-23");
INSERT INTO pricelist VALUES("30","501","400 - FS - DORA PLAST","2800","1","","2020-10-23");
INSERT INTO pricelist VALUES("31","502","500 - FS - DORA PLAST","3150","1","","2020-10-23");
INSERT INTO pricelist VALUES("32","503","600 - FS - DORA PLAST","4375","1","","2020-10-23");
INSERT INTO pricelist VALUES("33","504","800 - FS - DORA PLAST","5250","1","","2020-10-23");
INSERT INTO pricelist VALUES("34","505","1200 - FS - DORA PLAST","7700","1","","2020-10-23");
INSERT INTO pricelist VALUES("35","506","2000 - FS - DORA PLAST","10500","1","","2020-10-23");
INSERT INTO pricelist VALUES("36","9999","DAKAN","100","1","","2020-10-23");
INSERT INTO pricelist VALUES("37","101","150 - US - UNITED","1560","2","","2020-10-23");
INSERT INTO pricelist VALUES("38","102","200 - US  - UNITED","5100","2","","2020-10-23");
INSERT INTO pricelist VALUES("39","103","300 - US - UNITED","6300","2","","2020-10-23");



DROP TABLE products;

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `Product_Code` int(11) DEFAULT NULL,
  `Product_Name` varchar(200) DEFAULT NULL,
  `Product_Unit` varchar(20) DEFAULT NULL,
  `Product_Discripion` varchar(200) DEFAULT NULL,
  `Selling_Price` int(11) DEFAULT NULL,
  `Orignal_Price` int(11) DEFAULT NULL,
  `Profit` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO products VALUES("1","99999","Opening Balance","Balance","Opening Balance","0","0","0");
INSERT INTO products VALUES("2","101","150 - US - UNITED","Pcs","UNITED","3600","1800","1800");
INSERT INTO products VALUES("3","102","200 - US  - UNITED","Pcs","UNITED","5100","2550","2550");
INSERT INTO products VALUES("4","103","300 - US - UNITED","Pcs","UNITED","6300","3150","3150");
INSERT INTO products VALUES("5","201","150 - US - FIVE STAR","Pcs","FIVE STAR","3600","1800","1800");
INSERT INTO products VALUES("6","202","200 - US - FIVE STAR","Pcs","FIVE STAR","5100","2550","2550");
INSERT INTO products VALUES("7","203","300 - US - FIVE STAR","Pcs","FIVE STAR","6300","3150","3150");
INSERT INTO products VALUES("8","301","150 - US - DORA PLAST","Pcs","DORA PLAST","4800","2400","2400");
INSERT INTO products VALUES("9","302","200 - US - DORA PLAST","Pcs","DORA PLAST","7800","3400","4400");
INSERT INTO products VALUES("10","303","300 - US - DORA PLAST","pcs","DORA PLAST","8400","4200","4200");
INSERT INTO products VALUES("11","401","400 - FS - FIVE STAR","pcs","FIVE STAR","4800","2400","2400");
INSERT INTO products VALUES("12","402","500 - FS - FIVE STAR","Pcs","FIVE STAR","5400","2700","2700");
INSERT INTO products VALUES("13","403","600 - FS - FIVE STAR","Pcs","FIVE STAR","7800","3900","3900");
INSERT INTO products VALUES("14","404","800 - FS - FIVE STAR","Pcs","Five Star","9000","4500","4500");
INSERT INTO products VALUES("15","405","1200 - FS - FIVE STAR","Pcs","FIVE STAR","13200","6600","6600");
INSERT INTO products VALUES("16","406","2000 - FS - FIVE STAR","Pcs","FIVE STAR","18000","9000","9000");
INSERT INTO products VALUES("17","501","400 - FS - DORA PLAST","Pcs","DORA PLAST","5600","2800","2800");
INSERT INTO products VALUES("18","502","500 - FS - DORA PLAST","Pcs","DORA PLAST","6300","3150","3150");
INSERT INTO products VALUES("19","503","600 - FS - DORA PLAST","Pcs","DORA PLAST","8750","4375","4375");
INSERT INTO products VALUES("20","504","800 - FS - DORA PLAST","Pcs","DORA PLAST","10500","5250","5250");
INSERT INTO products VALUES("21","505","1200 - FS - DORA PLAST","Pcs","DORA PLAST","15400","7700","7700");
INSERT INTO products VALUES("22","506","2000 - FS - DORA PLAST","Pcs","DORA PLAST","21000","10500","10500");
INSERT INTO products VALUES("23","9999","DAKAN","PCS","DAKAN","100","90","10");



DROP TABLE purchaseorder;

CREATE TABLE `purchaseorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_id` int(11) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `Pre_Total` int(11) DEFAULT NULL,
  `Discount_Total` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE purchaseorderdetail;

CREATE TABLE `purchaseorderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `discription` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE saleorder;

CREATE TABLE `saleorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `payment` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `Pre_Total` int(11) DEFAULT NULL,
  `Discount_Total` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO saleorder VALUES("1","1","1","2020-10-17","1837425","0","1837425","1","1");



DROP TABLE saleorderdetail;

CREATE TABLE `saleorderdetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` int(11) DEFAULT NULL,
  `product` int(11) DEFAULT NULL,
  `discription` varchar(200) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO saleorderdetail VALUES("1","1","99999","Account Receivable","1","1837425","0","1837425");



DROP TABLE salesman;

CREATE TABLE `salesman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `pmobile` varchar(20) DEFAULT NULL,
  `cnic` varchar(20) DEFAULT NULL,
  `hmobile` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `startjob` varchar(20) DEFAULT NULL,
  `endjob` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO salesman VALUES("1","Rana Adrees","03004251610","","","","","");



DROP TABLE suplier;

CREATE TABLE `suplier` (
  `suplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_name` varchar(100) NOT NULL,
  `pmobile` varchar(100) NOT NULL,
  `business` varchar(100) NOT NULL,
  `bmobile` varchar(100) NOT NULL,
  `address` varchar(550) NOT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`suplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE suplier_ledger;

CREATE TABLE `suplier_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `GET_AMOUNT` int(11) DEFAULT NULL,
  `GIVE_AMOUNT` int(11) DEFAULT NULL,
  `suplier_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `salesman` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE transection;

CREATE TABLE `transection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transectionno` varchar(20) NOT NULL,
  `transectiontype` varchar(50) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `transectiondate` varchar(20) NOT NULL,
  `transectiontime` varchar(20) NOT NULL,
  `transectionalert` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

INSERT INTO transection VALUES("1","102","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:24:34pm","High");
INSERT INTO transection VALUES("2","301","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:29:17pm","High");
INSERT INTO transection VALUES("3","302","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:30:05pm","High");
INSERT INTO transection VALUES("4","99999","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:30:30pm","High");
INSERT INTO transection VALUES("5","301","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:31:43pm","High");
INSERT INTO transection VALUES("6","101","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:36:50pm","High");
INSERT INTO transection VALUES("7","102","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:37:05pm","High");
INSERT INTO transection VALUES("8","103","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:37:18pm","High");
INSERT INTO transection VALUES("9","201","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:37:36pm","High");
INSERT INTO transection VALUES("10","202","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:37:55pm","High");
INSERT INTO transection VALUES("11","203","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:38:17pm","High");
INSERT INTO transection VALUES("12","301","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:38:32pm","High");
INSERT INTO transection VALUES("13","302","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:38:49pm","High");
INSERT INTO transection VALUES("14","303","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-20-2020","05:39:07pm","High");
INSERT INTO transection VALUES("15","101","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","03:59:12pm","High");
INSERT INTO transection VALUES("16","102","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","03:59:19pm","High");
INSERT INTO transection VALUES("17","103","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","03:59:28pm","High");
INSERT INTO transection VALUES("18","201","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","03:59:50pm","High");
INSERT INTO transection VALUES("19","202","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:00:06pm","High");
INSERT INTO transection VALUES("20","203","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:00:18pm","High");
INSERT INTO transection VALUES("21","406","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:00:53pm","High");
INSERT INTO transection VALUES("22","405","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:01:08pm","High");
INSERT INTO transection VALUES("23","404","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:01:19pm","High");
INSERT INTO transection VALUES("24","403","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:01:33pm","High");
INSERT INTO transection VALUES("25","402","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:01:51pm","High");
INSERT INTO transection VALUES("26","401","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:02:10pm","High");
INSERT INTO transection VALUES("27","301","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:02:54pm","High");
INSERT INTO transection VALUES("28","302","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:03:07pm","High");
INSERT INTO transection VALUES("29","303","editproductrecord.php","Not Happy ! Beacause you Update the Data","10-23-2020","04:03:22pm","High");



DROP TABLE user;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","admin","admin","Admin","admin");



