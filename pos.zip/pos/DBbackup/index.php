<head>
<link  rel="stylesheet" type="text/css" href="../css/layout.css"  />
<link media="print" rel="stylesheet" type="text/css" href="../css/layoutprint.css"  />
<link  rel="stylesheet" type="text/css" href="../css/colors_default.css"  />
</head>
<form action="backup.php" method="post">
<div align="center">
<h4>Database backup:</h4>

<label for="name">File name:&nbsp;</label>
<input name="name" type="text" /><br /><br />
<input type="image" src="../images/Download Icon.jpg" alt="Download" value="Submit" />
</div>

</form>