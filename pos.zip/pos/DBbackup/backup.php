<?php
	//require_once('../auth.php');
?>
<?php
include('../connect.php');
//========================================
class Variables{ // database variables defined in the class
	
	var $dbServer;
	var $dbUser ;
	var $dbPass ;
	var $dbName ;

function Variables()
{	
	$this->dbServer = "localhost";
	$this->dbUser = "root";
	$this->dbPass = "";
	$this->dbName = "pos";
	}
}			
//+----------------------------------------+
class DB  { // database class contains the function
	
	var $dbase;
	var $connection;
	function ConnectToDb()
	{
		// Connect to the database and return
		// true/false depending on whether or
		// not a connection could be made.
		
		$vari=new Variables();
		
		$this->connection = mysql_connect($vari->dbServer, $vari->dbUser, $vari->dbPass)
	    or die("Could not connect :" . @mysql_error());	    	    
	    
		$this->dbase = mysql_select_db($vari->dbName, $this->connection);
				
		
		if(!$this->connection || !$this->dbase){			
			
			return false;
}
		else{					
				
			return true;
			}
	}
}
	
//==============================

	
//==============================
$vari=new Variables();
$dir = 'sql/'; 			// folder path to empty 
foreach(glob($dir.'*.*') as $v)
{
unlink($v);

}
#############################




	  
backup_tables($vari->dbServer, $vari->dbUser, $vari->dbPass,$vari->dbName);
 

// backup the db OR just a table 
function backup_tables($host,$user,$pass,$name,$tables = '*')
{
	
	$link = mysql_connect($host,$user,$pass);
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	
	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return.= 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return.= "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";
	}
	
	//save file

	//$bufname = $_POST['name'].'-'.time().'.sql';//prev
	$bufname = $_POST['name'].'-'.date("Y-m-d").'.sql'; // ADREES,13-4-10
	$handle = fopen("../sql/".$bufname,'w+') or die("can't open file");
	fwrite($handle,$return);
	fclose($handle);
	//echo '<div align="center"><h4>Backup file "'.$bufname.'" Save successfully to "DBbackup" folder.</h4></div>';prev
	/*ADREES,13-4-10*/
	  
     
	//echo '<a href="download.php?file='.$bufname.'">Download </a></div>';
	header('Location:download.php?file='.$bufname);
	echo '<div align="center"><h4>Backup file "'.$bufname.'" Save successfully to "DBbackup" folder.</h4>';
	//$myFile = "test2-1271140447.sql"; //ADREES,13-4-10
	//unlink($myFile);
	/***************************************************/
}
?>