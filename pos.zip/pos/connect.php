<?php
$db_host		= 'localhost';
$db_user		= 'root';
$db_pass		= '';
$db_database	= 'pos'; 

/*$db_host		= 'localhost';
$db_user		= 'lawyers2_root';
$db_pass		= 'lawyers2_pos';
$db_database	= 'lawyers2_pos'; */

// Create connection
$con=mysql_connect($db_host,$db_user,$db_pass);
$db=mysql_select_db($db_database,$con);
//mysql_select_db($database);
?>
