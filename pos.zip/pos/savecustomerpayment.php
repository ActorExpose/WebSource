<?php
include('connect.php');
$date = $_POST['date'];
if($date!=""){
$date = $_POST['date'];	
}else{
$date=date("Y-m-d");	
}	
$customer_id = $_POST['customer_id'];
$orderno = $_POST['orderno'];
$amount = $_POST['amount'];
$salesman = $_REQUEST['salesman'];
$comments = $_POST['comments'];
$status="2";

if($comments!=""){
$comments=$comments;
}else{
$comments="Customer Payment Received";	
}
// Save Customer Payments

$Query3="INSERT INTO
  customer_ledger(
  sale_id,
  `date`,
  GET_AMOUNT,
  status,
  comments,
  salesman,
  customer_id)
		VALUES(
		   '$orderno',
		   '$date',
		   '$amount',
		   '$status',
		   '$comments',	
		   '$salesman',   
		   '$customer_id')";
	   $result3=mysql_query($Query3);

header("location: addcustomerpayment.php");

?>