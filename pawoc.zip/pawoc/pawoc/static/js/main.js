// Contact Us Form - AJAX Submission
$(function() {
    // This function gets cookie with a given name
    function getCookie(name) {
        var cookieValue = null;
        if (document.cookie && document.cookie != "") {
            var cookies = document.cookie.split(";");
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == name + "=") {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    var csrftoken = getCookie("csrftoken");

    /*
                The functions below will create a header with csrftoken
                */

    function csrfSafeMethod(method) {
        // these HTTP methods do not require CSRF protection
        return /^(GET|HEAD|OPTIONS|TRACE)$/.test(method);
    }

    function sameOrigin(url) {
        // test that a given url is a same-origin URL
        // url could be relative or scheme relative or absolute
        var host = document.location.host; // host + port
        var protocol = document.location.protocol;
        var sr_origin = "//" + host;
        var origin = protocol + sr_origin;
        // Allow absolute or scheme relative URLs to same origin
        return (
            url == origin ||
            url.slice(0, origin.length + 1) == origin + "/" ||
            url == sr_origin ||
            url.slice(0, sr_origin.length + 1) == sr_origin + "/" ||
            // or any other URL that isn't scheme relative or absolute i.e relative.
            !/^(\/\/|http:|https:).*/.test(url)
        );
    }

    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!csrfSafeMethod(settings.type) && sameOrigin(settings.url)) {
                // Send the token to same-origin, relative URLs only.
                // Send the token only if the method warrants CSRF protection
                // Using the CSRFToken value acquired earlier
                xhr.setRequestHeader("X-CSRFToken", csrftoken);
            }
        },
    });
});

// Sending the Message from Contact Us Form
$("#contact-us-form").on("submit", function(event) {
    event.preventDefault();
    send_message();
});

function send_message() {
    $.ajax({
        url: "contact-us/",
        type: "POST",
        data: {
            name: $("#id_name").val(),
            email: $("#id_email").val(),
            message: $("#id_message").val(),
        },

        // Handling the success message
        success: function(json) {
            $("#results").html(
                "<div class='alert alert-info alert-dismissible fade show mt-3' role='alert' style='margin-left: 10%; margin-right: 10%;'>" +
                json["result"] +
                " <button type='button' class='close' data-dismiss='alert'> <span>&times;</span></button><div>"
            );
            $("#id_name").val("");
            $("#id_email").val("");
            $("#id_message").val("");

            console.log(json);
            console.log("success");
        },

        // Handling non-success response
        error: function(xhr, errmsg, err) {
            $("#results").html(
                "<div class='alert alert-danger alert-dismissible fade show mt-3' role='alert' style='margin-left: 10%; margin-right: 10%;'>Oops! " +
                errmsg +
                ": " +
                err +
                " <button type='button' class='close' data-dismiss='alert'> <span>&times;</span></button><div>"
            );
            console.log(xhr.status + ": " + xhr.responseText);
        },
    });
}

// Scroll When you are on different page
let target = window.location.hash;
target = target.replace("#", "");
window.location.hash = "";
// (in this case I use jQuery to scroll to the tag after the page has loaded)
$(window).on("load", function() {
    if (target) {
        console.log(target);
        $("html, body").animate({
                scrollTop: $("#" + target).offset().top - 90,
            },
            1000,
            "swing",
            function() {}
        );
    }
});

// Scroll when you are on the same page as the links.
$(".nav-item a").on("click", function(e) {
    // console.log(this.hash);
    if (this.hash !== "") {
        // e.preventDefault();
        const hash = this.hash;

        $("html, body").animate({
                scrollTop: $(hash).offset().top - 90,
            },
            1000
        );
    }
});

// Mobile Smooth Scroll
$(".mobile-nav-item a").on("click", function(e) {
    // console.log(this.hash);
    if (this.hash !== "") {
        // e.preventDefault();
        const hash = this.hash;

        $("html, body").animate({
                scrollTop: $(hash).offset().top - 100,
            },
            5000
        );
    }
});

const menuBtnOne = document.querySelector(".one");
const menuBtnTwo = document.querySelector(".two");
const menu = document.querySelector(".menu");
const menuList = document.querySelectorAll(".menu ul li");

gsap.registerPlugin(ScrollToPlugin);

const navigationTL = gsap.timeline({ paused: true });
navigationTL
    .to(menuBtnOne, {
        duration: 0.8,
        y: 6,
        rotation: 45,
        ease: Expo.easeInOut,
    })
    .to(menuBtnTwo, {
        duration: 0.8,
        y: -6,
        rotation: -45,
        ease: Expo.easeInOut,
        delay: -0.8,
    })
    .to(menu, {
        duration: 2,
        left: "0vw",
        ease: Expo.easeInOut,
    })
    .from(menuList, {
        duration: 1,
        x: -200,
        opacity: 0,
        ease: Expo.easeOut,
        delay: 0.3,
        stagger: {
            amount: 0.4,
        },
    });

navigationTL.reverse();
$(document).on("click", ".toggle-btn", () => {
    navigationTL.reversed(!navigationTL.reversed());
});

$(document).on("click", ".pawoc-mobile-tablet-link", () => {
    navigationTL.reversed(!navigationTL.reversed());
});

//Scroll Down Button
$(".scroll-down").on("click", () => {
    gsap.to(window, {
        duration: 2,
        scrollTo: { y: "#annual-events", offsetY: 80 },
    });
});

$(window).scroll(() => {
    if ($(this).scrollTop() > 80) {
        $("#header").addClass("main-nav");
    } else {
        $("#header").removeClass("main-nav");
    }
});

$(document).ready(function() {
    // HOME MOBILE TIMELINE
    const homeMobileTL = gsap.timeline();

    homeMobileTL.from(
        [
            ".welcome-pawoc .home-mobile",
            ".welcome-pawoc .pawoc-tablet-above",
            ".welcome-pawoc .home-behind",
            ".scroll-down",
        ], {
            duration: 2,
            opacity: 0,
            y: -40,
            ease: "power3.inOut",
            stagger: {
                amount: 0.8,
            },
        }
    );

    // HEALTH MOBILE ANIMATIONS
    const healthMobileTL = gsap.timeline();

    let areaHeaderRule = CSSRulePlugin.getRule("h3::before");
    const areaHeader = document.querySelector(".area-header h3");

    healthMobileTL
        .from([".mobile", ".pawoc-tablet-above", ".theme-header h3"], {
            duration: 1.2,
            opacity: 0,
            y: -40,
            ease: "power3.inOut",
            stagger: {
                amount: 0.2,
            },
        })
        .from(
            ".circle-bg", {
                duration: 1.2,
                opacity: 0,
                x: -40,
            },
            "-=.5"
        )
        .from(areaHeader, {
            duration: 1.2,
            opacity: 0,
            x: -20,
            ease: "power3.inOut",
        })
        .from([".focus", ".focus-one"], {
            duration: 1.2,
            backgroundPosition: "center center",
            opacity: 0,
            ease: "power3.inOut",
        })
        .from(
            [
                ".circle-proto",
                ".rounded-rect-proto",
                ".circle-proto-one",
                ".rounded-rect-proto-one",
            ], {
                duration: 1.2,
                opacity: 0,
                x: 40,
                ease: "power3.inOut",
            },
            "-=.5"
        )
        .from(
            [".focus-one p", ".focus-one ul li"], {
                duration: 1.2,
                opacity: 0,
                x: -20,
                ease: "power3.inOut",
                stagger: {
                    amount: 0.6,
                },
            },
            "-=.6"
        );
});