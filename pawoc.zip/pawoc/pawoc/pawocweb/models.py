from django.db import models

# About Pawoc Model
class About(models.Model):
    title = models.CharField(max_length=256, default='')
    details = models.TextField(max_length=2000, default='')
    image = models.ImageField(
        blank=True, default='pawoc_image_placeholder.png'
        )
    image_caption = models.CharField(max_length=100, default='', blank=True)

    def __str__(self):
        return self.title


# Annual Event Model
class AnnualEvent(models.Model):

    # RESOURCES CHOICES
    AVAILABLE = 'Available'
    PARTIALLY_AVAILABLE = 'Partially Available'
    NOT_AVAILABLE = 'Not Available'

    RESOURCES = [
        (AVAILABLE, ('Available')),
        (PARTIALLY_AVAILABLE, ('Partially Available')),
        (NOT_AVAILABLE, ('Not Available')),
    ]

    #   REMARKS CHOICES
    DONE = 'Done'
    BEING_IMPLEMENTED = 'Being Implemented'
    NOT_DONE = 'Not Done'

    REMARKS = [
        (DONE, ('Done')),
        (BEING_IMPLEMENTED, ('Being Implemented')),
        (NOT_DONE, ('Not Done')),
    ]

    activity = models.CharField(max_length=256, default='', )
    resources = models.CharField(max_length=256, choices=RESOURCES, default=NOT_AVAILABLE, )
    remarks = models.CharField(max_length=256, choices=REMARKS, default=NOT_DONE, )

    def __str__(self):
        return self.activity
 
# HEALTH MODELS
class Health(models.Model):
    area = models.CharField(max_length=256, default='')

    def __str__(self):
        return self.area



class HealthAreaFocus(models.Model):
    area = models.ForeignKey(Health, on_delete=models.CASCADE, blank=True, related_name='focus')
    focus = models.TextField(default='')

    def __str__(self):
        return self.focus


class HealthAreaFocusActivity(models.Model):
    focus = models.ForeignKey(HealthAreaFocus, on_delete=models.CASCADE, blank=True, related_name='activity')
    activity = models.TextField(default='')

    def __str__(self):
        return self.activity


# EDUCATION THEMATIC MODELS
class Education(models.Model):
    area = models.CharField(max_length=256, default='')

    def __str__(self):
        return self.area


class EducationAreaFocus(models.Model):
    area = models.ForeignKey(Education, on_delete=models.CASCADE, blank=True, related_name='focus')
    focus = models.TextField(default='')

    def __str__(self):
        return self.focus


class EducationAreaFocusActivity(models.Model):
    focus = models.ForeignKey(EducationAreaFocus, on_delete=models.CASCADE, blank=True, related_name='activity')
    activity = models.TextField(default='')

    def __str__(self):
        return self.activity



# HUMAN RIGHTS THEMATIC MODELS
class HumanRight(models.Model):
    area = models.CharField(max_length=256, default='')

    def __str__(self):
        return self.area


class HumanRightAreaFocus(models.Model):
    area = models.ForeignKey(
        HumanRight, on_delete=models.CASCADE, blank=True, related_name='focus')
    focus = models.TextField(default='')

    def __str__(self):
        return self.focus


class HumanRightAreaFocusActivity(models.Model):
    focus = models.ForeignKey(
        HumanRightAreaFocus, on_delete=models.CASCADE, blank=True, related_name='activity')
    activity = models.TextField(default='')

    def __str__(self):
        return self.activity
