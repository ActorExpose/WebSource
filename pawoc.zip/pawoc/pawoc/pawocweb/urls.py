from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('contact-us/', views.contact_us, name='contact-us'),
    path('annual-activities/', views.annual_events, name='annual_events'),
    path('thematic-areas/health/', views.health, name='health'),
    path('thematic-areas/education/', views.education, name='education'),
    path('thematic-areas/human-rights/', views.human_rights, name='human_rights'),
]
