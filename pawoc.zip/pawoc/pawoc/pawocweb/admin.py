from django.contrib import admin
import nested_admin

from .models import About, AnnualEvent, Health, HealthAreaFocus, HealthAreaFocusActivity, Education, EducationAreaFocus, EducationAreaFocusActivity, HumanRight, HumanRightAreaFocus, HumanRightAreaFocusActivity

admin.site.site_header = 'Passion for Women and Children Admin'
admin.site.site_title = 'Passion for Women and CHildren Admin Site'
admin.site.index_title = 'Welcome to the Passion for Women and Children Admin Site'

admin.site.register(About)
admin.site.register(AnnualEvent)

# HEALTH
class HealthAreaFocusActivityInline(nested_admin.NestedStackedInline):
    model = HealthAreaFocusActivity
    extra = 1

class HealthAreaFocusInline(nested_admin.NestedStackedInline):
    model = HealthAreaFocus
    extra = 1
    inlines = [HealthAreaFocusActivityInline]


class HealthAdmin(nested_admin.NestedModelAdmin):
    inlines = [HealthAreaFocusInline]


# EDUCATION
class EducationAreaFocusActivityInline(nested_admin.NestedStackedInline):
    model = EducationAreaFocusActivity
    extra = 1


class EducationAreaFocusInline(nested_admin.NestedStackedInline):
    model = EducationAreaFocus
    extra = 1
    inlines = [EducationAreaFocusActivityInline]


class EducationAdmin(nested_admin.NestedModelAdmin):
    inlines = [EducationAreaFocusInline]

# HUMAN RIGHTS
class HumanRightAreaFocusActivityInline(nested_admin.NestedStackedInline):
    model = HumanRightAreaFocusActivity
    extra = 1


class HumanRightAreaFocusInline(nested_admin.NestedStackedInline):
    model = HumanRightAreaFocus
    extra = 1
    inlines = [HumanRightAreaFocusActivityInline]


class HumanRightAdmin(nested_admin.NestedModelAdmin):
    inlines = [HumanRightAreaFocusInline]



admin.site.register(Health, HealthAdmin)
admin.site.register(Education, EducationAdmin)
admin.site.register(HumanRight, HumanRightAdmin)
