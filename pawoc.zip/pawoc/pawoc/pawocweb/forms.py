from django import forms

'''
    CONTACT FORM
'''
class ContactUsForm(forms.Form):
    name = forms.CharField(label="Your name", max_length=100, required=True)
    email = forms.EmailField(label="Your email", max_length=100, required=True)
    message = forms.CharField(widget = forms.Textarea(attrs={
        'cols' : '30',
        'rows' : '3',
    }), required=True)
