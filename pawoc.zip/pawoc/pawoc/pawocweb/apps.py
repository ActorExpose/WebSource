from django.apps import AppConfig


class PawocwebConfig(AppConfig):
    name = 'pawocweb'
