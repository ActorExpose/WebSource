from django.shortcuts import render
from django.http import HttpResponse
from django.core.mail import EmailMessage

import json

from .models import About, AnnualEvent, Health, Education, HumanRight
from .forms import ContactUsForm
from django.views.generic import FormView

# class Index(FormView):
#     contact_form = ContactUsForm
#     template_name = 'pawoc/index.html'

def index(request):
    if request.method == 'GET':
        contact_form = ContactUsForm()
        return render(request, 'pawoc/index.html', {'contact_form': contact_form, 'title': 'Home'})
    



# About Page View
def about(request):
    about_list = About.objects.all()
    return render(request, 'pawoc/about.html', {'about_list': about_list, 'title': 'About'})


# Annual Event Page View
def annual_events(request):
    events = AnnualEvent.objects.all()
    return render(request, 'pawoc/annual-events.html', {'events': events, 'title': 'Annual Events'})


# Health Thematic Area Page View
def health(request):
    health = Health.objects.all()
    return render(request, 'pawoc/thematic-areas/health.html', {'health': health, 'title': 'Health'})

# Education Thematic Area Page View


def education(request):
    education = Education.objects.all()
    return render(request, 'pawoc/thematic-areas/education.html', {'education': education, 'title': 'Education'})

# Human Rights Thematic Area Page View


def human_rights(request):
    human_rights = HumanRight.objects.all()
    return render(request, 'pawoc/thematic-areas/human-rights.html', {'human_rights': human_rights, 'title' : 'Human Rights'})


def contact_us(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        subject = "Hello, it's " + name + "."
        frommail = email
        
        email = EmailMessage(
            subject, 
            message, 
            email, 
            ['majawah.jfrancis824@gmail.com',],
            bcc=None,
            reply_to=[email,],
            headers=None,
            )
        email.send()
        
        print({ 'name' : name, 'email' : email, 'message' : message })

        response_data = {}

        response_data['result'] = 'Message was sent successfully!'
        response_data['name'] = name

        return HttpResponse(
            json.dumps(response_data),
            content_type = "application/json"
        )
