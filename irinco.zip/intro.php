<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>:: Irinco Official Website ::</title>
<style type="text/css">
body {
	background-color: #4d4d4d;
}
a:link {
	color: #FFF;
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	color: #FFF;
}
a:hover {
	text-decoration: none;
	color: #FC0;
}
a:active {
	text-decoration: none;
	color: #FFF;
}
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
</style>
</head>

<body>
<div style="width:607px;height:378px;margin:0 auto;margin-top:50px;background:url(images/intro.jpg)">
<div style="width:90px;height:24px;float:right;margin:280px 130px 0 0;padding-top:5px">
<a href="?lang=fa" title="زبان فارسی"><img src="images/ir_flag.jpg" width="36" height="21" align="absmiddle" border="0" /> &nbsp; فارسی</a>
</div>
<div style="width:90px;height:24px;float:left;margin:280px 0 0 130px;padding-top:5px">
<a href="?lang=en" title="English Language"><img src="images/en_flag.jpg" width="36" height="21" align="absmiddle" border="0" /> &nbsp; English</a>
</div>
</div>
</body>
</html>