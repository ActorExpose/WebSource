<?	
session_start();
include ("config.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta charset="UTF-8">
<meta content="" name="keywords">
<meta content="" name="description">
<title>Irinco Official Website</title>
<link rel="shortcut icon" href="./images/icon.png"/>
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
<link href="./stylesheets/tmpview.css" rel="stylesheet">
<!--[if lt IE 7]>
<script src="Scripts/ie6.js"></script>
<![endif]--><!--[if IE]>
<link href="Css/ie.css" rel="stylesheet" />
<![endif]-->
<script src="./scripts/jquery.js"></script>
<script src="./scripts/modernizr-2.js"></script>
<script src="./scripts/jquery.easing.1.3.js"></script>
<script src="./scripts/jcarousellite.js"></script>
<script src="./scripts/scripts.js"></script>
<link rel="stylesheet" href="./stylesheets/weather.css" type="text/css"/>
<script src="./scripts/jquery.zweatherfeed.min.js" language="javascript" type="text/javascript"></script>
<script language="javascript" type="text/javascript" src="./scripts/jquery.nicescroll.min.js"></script>
<script language="javascript" type="text/javascript">
var Cpage='home';
<?
        $rescat=mysql_query("SELECT Cid FROM tbcat WHERE Cstatus='1' Order By Corder ASC");
		
  		$reccat =mysql_fetch_object($rescat);
	   
	    $ressli=mysql_query("SELECT Sename,Scat,Saddpic FROM products WHERE Scat='".$reccat->Cid."' and Sstatus='1' Order By Sorder ASC");
		 $recsli =mysql_fetch_object($ressli);
			 ?>
var Ccat='<?=$reccat->Cid?>';
var Pcat='<?=$reccat->Cid?>';
var Cproduct='<?=$recsli->Sename?>';
var Pproduct='<?=$recsli->Sename?>';
var Ppage='home';
var toph=document.documentElement.clientHeight-88;
var scrolh=762-document.documentElement.clientHeight+88;
var gLm=651;

function show_cat(x){
	
		/*	if($("#cat_"+x).css('display')=='block'){
		$('.pro-cat a[cat="'+x+'"]').css('color','#ca2704');
		$("#cat_"+x).slideUp("hide");
		}else{
		$("#cat_"+x).slideDown("show");
		$(".pro-cat a").css('color','#900');
		$('.pro-cat a[cat="'+x+'"]').css('color','#ca2704');
		}*/
		
	if(Ccat!=x){
	$(".pro-cat a").css('color','#ca2704');
	$('.pro-cat a[cat="'+x+'"]').css('color','#900');
	$("#cat_"+Pcat).slideUp("hide",function(){
	$("#cat_"+x).slideDown("show");	
	});
		Pcat=x;
	}

}
				
			
function closef(){
$("#page-content").animate({width : '0px',marginLeft:'0px'},600,'easeOutCirc',function(){
$("#product_slider").css('marginLeft','-5000px');
          $("#page-content").css('visibility','hidden');
		$("#page-"+Cpage).css('visibility','hidden');    
		Cpage='home';
		Ppage='home';
		$(".top_menu a span").css('opacity','0');
		$(".top_menu a span").css('borderTop','none');
		$(".top_menu a span").css('height','88px');
		$('.top_menu a[rel="home"]').find('span').animate({opacity:'.8'},600,'easeOutCirc',function(){
		$('.top_menu a[rel="home"]').find('span').css('borderTop','4px solid #0C0');
	   $('.top_menu a[rel="home"]').find('span').css('height','84px');
});

            });	
}

function show_page(){
	if(Ppage=='home'){
$("#page-content").css('visibility','visible');
$("#page-"+Cpage).css('visibility','visible');
if(Cpage!='products')
$("#product_slider").css('marginLeft','-5000px');
else
$("#product_slider").css('marginLeft','80px');
$("#page-content").animate({width : '900px',marginLeft:'-450px'},600,'easeOutCirc');
}else{
$("#page-content").animate({width : '0px',marginLeft:'0px'},600,'easeOutCirc',function(){
		$("#page-content").css('visibility','hidden');
		$("#page-"+Ppage).css('visibility','hidden'); 
		$("#product_slider").css('marginLeft','-5000px');
		 if(Cpage!='home'){
		$("#page-content").css('visibility','visible'); 
		$("#page-"+Cpage).css('visibility','visible');
		if(Cpage!='products')
$("#product_slider").css('marginLeft','-5000px');
else
$("#product_slider").css('marginLeft','80px');
		$("#page-content").animate({width : '900px',marginLeft:'-450px'},600,'easeOutCirc');
		 }
		            });
}

}




$(document).ready(function(){
		
		 		$(".pro-cat a").click(function(){
			show_cat($(this).attr("cat"));
			Ccat=$(this).attr("cat");
		});
		
		$('.pro-cat a').hover(function(){
		if(Ccat!=$(this).attr("cat")){
		$(this).css('color','#900');
		}
		}, function(){
			if(Ccat!=$(this).attr("cat")){
			$(this).css('color','#ca2704');
			}
			});	
			
	$(".top_menu a").click(function(){
		
		$(".top_menu a span").css('opacity','0');
		$(".top_menu a span").css('borderTop','none');
		$(".top_menu a span").css('height','88px');
		$(this).find('span').css('opacity','.8');
		$(this).find('span').css('borderTop','4px solid #0C0');
	    $(this).find('span').css('height','84px');
		 
		 if( Cpage!=$(this).attr("rel")){
		 Ppage=Cpage;	 
		 Cpage=$(this).attr("rel");
		 show_page();
		 }
		 
		});
		
	$("#closef a").click(function(){
	closef();
	});
	
	$(".bt_submit a").click(function(){
	submit_me();
	});
	
	  $(".top_menu a").hover(function(){
	 	 $(this).find('span').animate({opacity : .8});
 		 },function(){
			 if(Cpage!=$(this).attr("rel"))
	 	 $(this).find('span').animate({opacity : 0});
		});
		
		
		$("#product_slider li a").click(function(){
			if(Cproduct!=$(this).attr("title")){
			$("#product_slider li").find('strong').css('display','none');	
	 		 $(this).find('strong').css('display','block');
			 Cproduct!=$(this).attr("title");
			}
 		 });
		
		$("#product_slider li a").hover(function(){
			if(Cproduct!=$(this).attr("title"))
	 	 $(this).find('strong').fadeIn(500);
 		 },function(){
			if(Cproduct!=$(this).attr("title"))	 
	 	 $(this).find('strong').fadeOut(500);
		});
		
		
		$("#product_slider a").click(function(){
			//alert($('#product_slider ul').css('left'));
			if(Ccat!=$(this).attr("cat")){
				show_cat($(this).attr("cat"));
				Ccat=$(this).attr("cat");
			}
			
		if(Cproduct!=$(this).attr("title")){
			var pro=$(this).attr("title");
			$(".list1 li a").css('color','#fff');
			$(".list1 li a").css('background-position','0px 6px');
			$(".list1 li a").css('paddingLeft','12px');
			$(".list1 li a").css('cursor','pointer');
			$('.list1 li a[title="'+pro+'"]').css('color','#ca2704');
			$('.list1 li a[title="'+pro+'"]').css('background-position','0px -14px');
			$('.list1 li a[title="'+pro+'"]').css('paddingLeft','20px');
			$('.list1 li a[title="'+pro+'"]').css('cursor','text');
			
 			$.post("modules/ch-product.php", {pro:pro}, function(response) {
			//timeout();				
			var response = eval('(' + response + ')');	
			$('#product-content').fadeTo(500,0.1,function(){
			document.getElementById('product-content').innerHTML=response.reply;	
			$("#product-content").fadeTo(500,1);
			});
			});
			Cproduct=$(this).attr("title");
		}
		});
		
			$("#clear").click(function(){
			document.getElementById('name').value="Name:";
			document.getElementById('phone').value="Phone:";
			document.getElementById('email2').value="E-mail:";
			document.getElementById('message').value="Message:";	
			});
			
			$("#submit").click(function(){
			SubmitForm();
			});
			
			$(".list1 li a").click(function(){
		if(Cproduct!=$(this).attr("title")){
			var pro=$(this).attr("title");
			$("#product_slider li").find('strong').css('display','none');	
			$("#product_slider li a[title='"+pro+"']").find('strong').fadeIn(500);
			var index = $("#product_slider ul li a").index($("a[title='"+pro+"']"));
			var len= $('#countli').val()-3;
			if(index<3)
			index=index+len;
			else
			index=index-3;
		
			var Lm=index*217;
		//	if(-gLm>=3038)
			//gLm=651;
			//$("#product_slider ul").css('marginLeft','0px');
			$("#product_slider ul").animate({left:'-'+(gLm+Lm)+'px'},600);
			//alert($("#product_slider ul").css('left'));
			$(".list1 li a").css('color','#fff');
			$(".list1 li a").css('background-position','0px 6px');
			$(".list1 li a").css('paddingLeft','12px');
			$(".list1 li a").css('cursor','pointer');
			$(this).css('color','#ca2704');
			$(this).css('background-position','0px -14px');
			$(this).css('paddingLeft','20px');
			$(this).css('cursor','text');
			
 			$.post("modules/ch-product.php", {pro:pro}, function(response) {
			//timeout();				
			var response = eval('(' + response + ')');	
			$('#product-content').fadeTo(500,0.1,function(){
			document.getElementById('product-content').innerHTML=response.reply;	
			$("#product-content").fadeTo(500,1);
			});
			});
			Cproduct=$(this).attr("title");
		}
		});
		
	$('.list1 li a').hover(function(){
		if(Cproduct!=$(this).attr("title")){
		$(this).stop().animate({paddingLeft:'20'},600, 'easeOutElastic');
		$(this).css('background-position','0px -14px');
		$(this).css('color','#ca2704');
		}
		}, function(){
			if(Cproduct!=$(this).attr("title")){
			$(this).stop().animate({paddingLeft:'12'},600, 'easeOutElastic');
			$(this).css('background-position','0px 6px');
			$(this).css('color','#fff');
			}
			});	
			
	$('.link1').hover(function(){
		$(this).stop().animate({paddingRight:'16'},600, 'easeOutElastic')
		}, function(){
			$(this).stop().animate({paddingRight:'8'},600, 'easeOutElastic')
		});
	
		$('#Skype').hover(function(){
		$('#Skypetxt').fadeIn();
		
		}, function(){
		$('#Skypetxt').fadeOut();
			
			});
			
				$('#Skype2').hover(function(){
		$('#Skypetxt2').fadeIn();
		
		}, function(){
		$('#Skypetxt2').fadeOut();
			
			});
			
		});
		
  </script>      
</head>

<body>
<!-- header -->

<!-- header:END -->
<!-- goTop -->

<!-- wrapper -->
	<section id="homeDestqs" class="msv-carousel">
	  <div style="left: -534px; width: 6930px; display: block;" class="slider">
		
			
			
			
			
			
		<article>
				<figure>
					<img src="./images/slider_bg1.jpg">
				</figure>
		  </article><article>
				
				<figure>
					<img src="./images/slider_bg2.jpg">
				</figure>
			</article><article>
				<figure>
					<img src="./images/slider_bg3.jpg">
				</figure>
			</article><article>
			
				
				<figure>
					<img src="./images/slider_bg4.jpg">
				</figure>
			</article>
            <article>
				<figure>
					<img src="./images/slider_bg5.jpg">
				</figure>
			</article>
            
			  <article>	<figure>
					<img src="./images/slider_bg6.jpg">
				</figure>
			</article>
              <article>
				<figure>
					<img src="./images/slider_bg7.jpg">
				</figure>
			</article> 
            
            </div>
		<div style="display: block;" class="in">
			<div id="goPrev">
				<div class="normal">
&nbsp;</div>
				<div class="hover">
&nbsp;</div>
			</div>
			<div id="goNext">
				<div class="normal">
&nbsp;</div>
				<div class="hover">
&nbsp;</div>
			</div>
		</div>
		<div style="display: block;" class="hCenter bulletNav">
			<ul>
				<li class="">1</li>
				<li class="">2</li>
				<li class="">3</li>
				<li class="">4</li>
				<li class="current">5</li>
			</ul>
		</div>
		<!-- why -->
		<div style="width: 457px;" class="ocult left">
		</div>
		<div style="width: 457px;" class="ocult right">
		</div>
		<div style="display: none;" id="carouselloader">
		</div>
	</section>
	<!-- searchBlock -->
	<!-- sliderBlock1 -->
	
	<!-- sliderBlock1: END -->
	<!-- sliderBlock2 -->
	
	<!-- sliderBlock2: END -->
	
	<!-- quote -->
	
	<!-- quote:END -->
	<!-- footer -->
	
<!-- modal callback -->
<!-- modal newsletter -->
<div class="top_menu">
          <ul>
           
            <li style="width:139px;"><a rel="home"><strong>Home Page</strong><span <? if ($_GET['p']=="main" || !$_GET['p']) echo 'class="active"'?>></span></a></li>
            <li style="width:131px;"><a rel="about"><strong>ABOUT US</strong><span <? if ($_GET['p']=="about") echo 'class="active"'?>></span></a></li>
            <li style="width:136px;"><a rel="products"><strong>PRODUCTS</strong><span <? if ($_GET['p']=="products") echo 'class="active"'?>></span></a></li>
            <li style="width:154px;"><a rel="contact"><strong>CONTACT US</strong><span <? if ($_GET['p']=="contact") echo 'class="active"'?>></span></a></li>
	<li style="width:235px;background:url(./images/logo.png) center no-repeat;height:88px;margin-right:20px;"></li>
          </ul>
        </div>
<div class="top_menu_bg">
        </div>
<div class="footer" style="width:100%;height:250px;background:url(images/footer.jpg) center repeat-x;display:block;">
<div style="width:970px;margin:0 auto;">

<div style="float:left;height:198px;width:324px;">
<div style="height:30px;padding:20px 0px 0px 30px;text-align:left"><strong>Newsletter</strong>
</div>
<div style="padding:10px 0 10px 20px;">
Enter your E-mail :
</div><div style="padding:0 0 0 20px;"><input  class="input2" name="email" id="email" type="text" value="" onKeyPress="ch_enter(event)">&nbsp;&nbsp;<div class="bt_submit" style="float:right;padding-right:55px;"><a id="bt_submit">submit</a></div></div>
<div>
<div id="waitMessage" class="waitMessage" style="height:20px;">
Please Wait ...
</div>
    <div id="sendMessage" class="sendMessage" style="height:20px;">
    &nbsp;Your E-mail sent successfully !</div>
    <div class="errorMessage" id="error1" style="height:20px;">
&nbsp;Your E-mail alredy existed !</div>
    <div class="errorMessage" id="error2" style="height:20px;">
&nbsp;Please enter an valid E-mail !</div>
</div>
</div>
<div style="float:left;height:198px;width:300px;background:url(images/footer_sp.jpg) left no-repeat;">
<div style="height:30px;padding:20px 0px 0px 30px;text-align:left"><strong>Follow Us</strong></div>
<div style="position:relative;padding:10px 0 0 30px;"><a href="#" target="_blank" id="Skype"><img src="images/sckpe_icon.png" width="52" height="52"></a>&nbsp;&nbsp;&nbsp;<a href="#" target="_blank" title="Facebook"><img src="images/fb_icon.png" width="52" height="52"></a>&nbsp;&nbsp;&nbsp;<a href="#" target="_blank" title="Google Plus"><img src="images/gplus_icon.png" width="52" height="52"></a><div id="Skypetxt" style="display:none;padding:10px 0 0 5px;">Skype : Irintrade</div></div>
</div>
<div style="float:left;height:198px;width:344px;background:url(images/footer_sp.jpg) left no-repeat;">
<? include('./modules/weather.php') ?>
</div>
<div align="center" style="color:#999;padding-top:215px;">© Copyright 2014-2015 By irinco. All rights reserved. Design by <a href="/design/" target="_blank">Mohamad Saffari</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="?lang=en" title="English Language"><img src="images/en_flag.jpg" width="36" height="21" align="absmiddle" border="0" />&nbsp; English</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="?lang=fa" title="زبان فارسی"><img src="images/ir_flag.jpg" width="36" height="21" align="absmiddle" border="0" />&nbsp; فارسی</a>
</div>
</div>
</div>

<div style="width:100%;"><div style="position:absolute;top:125px;z-index:9995;margin:0 auto;left:50%;margin-left:0px;visibility:hidden;width:0" id="page-content">
<div style="width:900px;height:600px;overflow:hidden;">
<div id="closef" style="padding:20px 0 0 855px;position:absolute;z-index:3;"><a></a></div>
<div id="page-about" style="width:860px;height:560px;padding:20px;visibility:hidden;position:absolute;z-index:2;margin-top:20px;">
<div><div style="background:url(images/about.jpg) 20px 0px no-repeat;padding:0px 20px 0 320px;text-align:justify;height:200px;"><h2>About Us</h2><br/>
							<div class="content1">
<?
	$resa = mysql_query("SELECT etext FROM about"); 
	$reca = mysql_fetch_object($resa);
	echo $reca->etext ?>
</div></div>
<div>
<div style="width:395px;float:left;padding:0 10px 0 30px;"><h2>Mission</h2><br/><div class="content1">
<?
	$resa = mysql_query("SELECT emission FROM about"); 
	$reca = mysql_fetch_object($resa);
	echo $reca->emission ?>
</div></div>
<div style="width:395px;float:left;padding:0 10px 0 20px;"><h2>Goal</h2><br/><div class="content1">
<?
	$resa = mysql_query("SELECT egoal FROM about"); 
	$reca = mysql_fetch_object($resa);
	echo $reca->egoal?>
</div></div>
</div>
</div>
</div>

<div id="page-products" style="width:860px;height:560px;padding:20px;visibility:hidden;position:absolute;z-index:2;margin-top:20px;">
<div style="position:absolute"></div>
<div dir="ltr" id="product_slider" >
       <ul>
       <?	
        $rescat=mysql_query("SELECT Cid FROM tbcat WHERE Cstatus='1' Order By Corder ASC");
		
   while ($reccat =mysql_fetch_object($rescat)) {
	   
	    $ressli=mysql_query("SELECT Sename,Scat,Saddpic FROM products WHERE Scat='".$reccat->Cid."' and Sstatus='1' Order By Sorder ASC");
		 while ($recsli =mysql_fetch_object($ressli)) {
          ?>
  				<li><a cat="<?=$recsli->Scat?>" title="<?=$recsli->Sename?>"><strong><?=$recsli->Sename?></strong><img src="./images/products/<?=$recsli->Scat?>/<?=$recsli->Saddpic?>" width="197" height="160" border="0"/></a></li>
        <? }  
		
		}?>        
      </ul>
</div>
	<div id="scrollbar">
		<a id="left_scroll" class="mouseover_left"></a>
		<a id="right_scroll" class="mouseover_right"></a>        </div>  
       <div class="list1" style="float:left;width:250px;height:250px;display:block;margin:20px;">
       <h2>Main Products</h2>
              <div id="product-scroll" style="width:250px;height:230px;display:block;overflow: auto;padding-left:20px;">
              <?	
        $rescat=mysql_query("SELECT Cid,Cename FROM tbcat WHERE Cstatus='1' Order By Corder ASC");
		 $counli=0;
   while ($reccat =mysql_fetch_object($rescat)) {
	   ?>
       <div class="pro-cat"><a cat='<?=$reccat->Cid?>' <? if(!$avisit) { echo 'style="color:#900;"'; $avisit=true; } ?>><?=$reccat->Cename?></a></div>
       <div id="cat_<?=$reccat->Cid?>" <? if(!$cvisit) { echo 'style="display:block"'; $cvisit=true; }else { echo 'style="display:none"';} ?>><ul>
       <?
	    $ressli=mysql_query("SELECT Sename,Scat,Saddpic FROM products WHERE Scat='".$reccat->Cid."' and Sstatus='1' Order By Sorder ASC");
		 while ($recsli =mysql_fetch_object($ressli)) {
			 $counli=$counli+1;	
          ?>
          						
  			<li><a title="<?=$recsli->Sename?>" <? if(!$fvisit) { echo 'class="active"'; $fvisit=true; } ?> ><?=$recsli->Sename?></a><br/></li>
          
          <?
		  
		     } 
			 ?>
             </ul>
             </div>
             <?
  		 }
		  ?>
       </div>  
       <input name="countli" id="countli" type="hidden" value="<?=$counli?>" />
       <script type="text/javascript">
	   $(document).ready(function() {
        					$("#product-scroll").niceScroll({
			cursorborder: '1px solid #cbcbcb',
			cursorcolor: '#d8d8d8',
			cursorborderradius: 10,
			autohidemode: 'cursor',
			cursoropacitymin: 0.1
		});
	   });
       </script>                    
       </div>
    	<div id="product-content">
        <?
		        $rescat=mysql_query("SELECT Cid FROM tbcat WHERE Cstatus='1' Order By Corder ASC");
		
  		$reccat =mysql_fetch_object($rescat);
	   
	    $ressli=mysql_query("SELECT Sename,Secomment FROM products WHERE Scat='".$reccat->Cid."' and Sstatus='1' Order By Sorder ASC");
		 $recsli =mysql_fetch_object($ressli);
		?>
       <h2><?=$recsli->Sename?></h2> 
        <div class="content1"><?=$recsli->Secomment?></div>
        </div>
</div>
<div id="page-contact" style="width:860px;height:560px;padding:20px;visibility:hidden;position:absolute;z-index:2;margin-top:20px;">
<div style="width:400px;height:560px;float:left;padding:0 10px 0 20px;line-height:22px;">
<div><h2>How to find us</h2><br/><iframe style="background:#FFF;border:1px #999999 solid;" width="339" height="250" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps/ms?msa=0&amp;msid=212492976841609101406.0004ea714af273152d3d8&amp;ie=UTF8&amp;ll=36.292835,59.574662&amp;spn=0,0&amp;t=m&amp;output=embed"></iframe><br /><small>View <a href="https://maps.google.com/maps/ms?msa=0&amp;msid=212492976841609101406.0004ea714af273152d3d8&amp;ie=UTF8&amp;ll=36.292835,59.574662&amp;spn=0,0&amp;t=m&amp;source=embed" style="color:#0000FF;text-align:left" target="_blank">irinco Compony</a> in a larger map</small>
<br/><br/>
<div style="font-size:11pt;">
<?
	$resc = mysql_query("SELECT * FROM information");
	$recc = mysql_fetch_object($resc);
	?>
<strong>Address :</strong> <?=$recc->address2?> <br/>
<strong>Tel :</strong> <?=$recc->tel2?><br/>
<strong>Fax :</strong> <?=$recc->fax2?><br/>
<strong>Mobile :</strong> <?=$recc->mobile2?><br/>
<strong>Email :</strong> <?=$recc->mail?>
</div>
</div>
</div>
<div style="width:430px;height:560px;float:left">
<h2>Follow us in :</h2><br/><br/>
<div style="position:relative;padding:10px 0 0 30px;"><a href="#" target="_blank" title="Skype" id="Skype2"><img src="images/sckpe_icon.png" width="52" height="52"></a>&nbsp;&nbsp;&nbsp;<a href="#" target="_blank" title="Facebook"><img src="images/fb_icon.png" width="52" height="52"></a>&nbsp;&nbsp;&nbsp;<a href="#" target="_blank" title="Google Plus"><img src="images/gplus_icon.png" width="52" height="52"></a><div style="height:25px;font:11px Verdana, Tahoma, Geneva, sans-serif;color:#FFF;"><div id="Skypetxt2" style="display:none;padding:10px 0 0 5px;">Skype : Irintrade</div></div></div>
<div><br/><br/><br/>
<h2>Contact form</h2><br/>
<div>
<div><input class="input3" name="name" size="38" id="name" value="Name:" onblur="if(this.value=='') this.value='Name:'" onfocus="if(this.value =='Name:' ) this.value=''" type="text"></div>
<div style="padding:10px 0 5px 0;"><input  class="input3" name="email2" size="38" id="email2" value="E-mail:" onblur="if(this.value=='') this.value='E-mail:'" onfocus="if(this.value =='E-mail:' ) this.value=''" type="text"></div>
<div style="padding:5px 0 5px 0;"><input class="input3" name="phone" size="38" id="phone" value="Phone:" onblur="if(this.value=='') this.value='Phone:'" onfocus="if(this.value =='Phone:' ) this.value=''" type="text"></div>
<div style="padding:5px 0 5px 0;"><textarea class="textarea3" cols="58" rows="4" name="message" id="message" onblur="if(this.value=='') this.value='Message:'" onfocus="if(this.value =='Message:' ) this.value=''">Message:</textarea></div>
<div style="float:left;" id="contact_error"></div>
<div class="relative">

	<a id="clear" class="link1">clear</a>
    	<a id="submit" class="link1" style="margin-left:60px;">submit</a>
</div>
</div>
</div>
</div>
</div>


<div id="bg-content" style="position:absolute;z-index:1;"></div>
</div>
</div></div>

<script language="javascript" type="text/javascript">
    var arrMonths = ['January','February','March','April','May','June','July','August','September','October','November','December']
    var arrWeeks= ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
		
//alert(document.getElementById('endp').offsetTop);
    </script>
<script src="./scripts/plugins3rd.js"></script>
<script src="./scripts/plugins.js"></script>
<script src="./scripts/homepage.js"></script>
<script src="./scripts/SFind.js"></script>
<script src="./scripts/tmpview.js"></script>
<script>
 $("#product_slider").jCarouselLite({
     btnNext: ".mouseover_right",
     btnPrev: ".mouseover_left",
	  visible :3 ,
	  circular: true,
    speed: 1000
 });
  $('#product_slider li a[title="'+Cproduct+'"]').find('strong').css('display','block');
 // var ult= $('#product_slider ul').children('li').length;
  //$('#product_slider ul').css('width',(ult*217)+'px');
/*	$("#gallery").jCarouselLite({
			btnNext: ".next",
		 	btnPrev: ".prev",
			visible: 3,
			speed: 600,
			easing: 'easeOutCirc'
		});	*/
		
//alert(document.getElementById('endp').offsetTop);
</script>
<?
//$bnum=rand(1, 8);
//echo '<div style="position:fixed;top:0px;right:0;width:170px;height:170px;background:url(./images/banner/muharam'.$bnum.'.gif") center no-repeat;z-index:99999"></div>';

$diff=time()-18000;
if(mysql_num_rows(mysql_query("SELECT * FROM counter WHERE ip='$user_ip' and date> '$diff' "))==0){
mysql_query("INSERT INTO counter (`ip`,`date`,`refer`) VALUES('$user_ip','".time()."','$refer') ");
}
?>
</body></html>