<?
if($_GET['lang'] != 'fa' && $_GET['lang'] != 'en'){
	include_once('intro.php');
}elseif($_GET['lang'] == 'fa'){
	include_once('indexFa.php');
}elseif($_GET['lang'] == 'en'){
	include_once('indexEn.php');
}
	
	 ?>