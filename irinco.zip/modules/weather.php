
<script type="text/javascript">

$(document).ready(function () {

	$('#mash').weatherfeed(['IRXX0008']).ajaxStop(function() {

	});
});
</script>
<div align="center" style="width:100%;padding:10px 10px 0 10px">
	<div id="mash" class="items"></div>
</div>