<?php 
include('../config.php');
	// this function escapes strings that are inserted to db
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$message=$_POST['message'];
	
	if(strlen($jday)<2)
	$jday=0 .$jday;
	if(strlen($jmonth)<2)
	$jmonth=0 .$jmonth;
	
$post_date	= 	$jyear.$jmonth.$jday;
	if(mysql_query("INSERT INTO contacts (time,post,name,phone,email,message,visited) VALUES (".time().",'$post_date','$name','$phone','$email','$message',0)"))
		echo "{success:true}";
	else 
		echo "{success:false}";	
?>