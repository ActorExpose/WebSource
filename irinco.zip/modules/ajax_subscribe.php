<?php 
include('../config.php');
	// this function escapes strings that are inserted to db
$email=$_POST['email'];
	if(strlen($jday)<2)
	$jday=0 .$jday;
	if(strlen($jmonth)<2)
	$jmonth=0 .$jmonth;
	
$post_date	= 	$jyear.$jmonth.$jday;
	if($num=mysql_num_rows(mysql_query("SELECT Eid FROM emails WHERE Eemail='".$email."' ")))
	echo "{success:".$num."}";
	else if(mysql_query("INSERT INTO emails (Etime,Epost,Eemail) VALUES (".time().",'$post_date','$email')"))
		echo "{success:2}";
	else 
		echo "{success:false}";	
?>