<?php 
include('../dbconnect.php');		  
		  $ressli=mysql_query("SELECT Sname,Scomment FROM products WHERE Sname='".$_POST['pro']."'");
		 $recsli =mysql_fetch_object($ressli);
		 
	$reply="<h2 style='font-family:Tahoma,Arial, Geneva, sans-serif;'>".$recsli->Sname."</h2><div class='content1' style='font-family:Tahoma,Arial, Geneva, sans-serif;font-size:12px;direction:rtl'>".str_replace("\r\n", "<br>", $recsli->Scomment)."</div>";
	
	echo '{reply:"'.$reply.'"}';	
?>