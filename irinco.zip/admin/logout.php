<?
	session_start();
	session_unset();
	session_destroy();
	echo "<meta http-equiv='Content-type' content='text/html; charset=utf-8' />"; 
	echo "<p>&nbsp;</p><p>&nbsp;</p>";
	echo "<center style='font:bold 12px tahoma; color:red;'>... در حال خروج از سيستم مديريت </center>";
	echo "<META HTTP-EQUIV=Refresh CONTENT=\"3;URL=./index.php\">";
			
?>