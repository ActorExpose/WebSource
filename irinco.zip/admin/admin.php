<? 
include ("../config.php");
function create_feed(){
include_once("../modules/feed.php");
}
if(isset($_SESSION['user']) && $_SESSION['login'] == true){
	$tipg="صفحه اصلی";
	$title="صفحه اصلی";
	$title="::::&nbsp;&nbsp;".$title."&nbsp;&nbsp;";
if($_GET['q'] && $_SESSION['user']=='admin'){
	switch($_GET['q']){
	case "pro-cat-mg":
    $title="ایجاد دسته جدید";
    break;
	case "pro-cat-edit":
    $title="ویرایش دسته";
    break;
	case "product-mg":
    $title="مدیریت محصولات";
    break;
	case "product-edit":
    $title="ویرایش محصول";
    break;
	case "about":
    $title="درباره ما";
    break;
	case "organic":
    $title="ارگانیک";
    break;
	case "mission":
    $title="ماموریت";
    break;
	case "standard":
    $title="استاندارد";
    break;
	case "goal":
    $title="اهداف";
    break;
	case "information":
    $title="اطلاعات تماس";
    break;
	
	case "pro-cat-mg-e":
    $title="Create New Category";
    break;
	case "pro-cat-edit-e":
    $title="Edit Category";
    break;
	case "product-mg-e":
    $title="Product Management";
    break;
	case "product-edit-e":
    $title="Edit Product";
    break;
	case "about-e":
    $title="َAbout Us";
    break;
	case "organic-e":
    $title="Organic";
    break;
	case "mission-e":
    $title="Mission";
    break;
	case "standard-e":
    $title="Standard";
    break;
	case "goal-e":
    $title="Goal";
    break;
	case "information-e":
    $title="Contact Detail";
    break;
	
	case "inbox":
    $title="صندوق دریافتی";
    break;
	case "show-contact":
    $title="مشاهده پیغام";
    break;
	case "email-mg":
    $title="مدیریت خبرنامه";
    break;
	case "user-manage":
    $title="مدیریت کاربران";
    break;	
	case "user-add":
    $title="ثبت کاربر جدید";
    break;	
	case "user-show":
    $title="ویرایش اطلاعات کاربری";
    break;	
	default:
    $q="";
	header("Location:admin.php");
	}
	
	$tipg=$title;
	$title="::::&nbsp;&nbsp;".$title."&nbsp;&nbsp;";
	
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script language="javascript" type="text/javascript" src="scripts/jquery.js"></script>
<script language="javascript" type="text/javascript" src="scripts/script.js" ></script>
<script language="javascript" type="text/javascript" src="menu/c_config.js"></script>
<script language="javascript" type="text/javascript" src="menu/c_smartmenus.js"></script>
<script language="javascript" type="text/javascript" src="menu/c_addon_fx_slide.js"></script>
<script language="javascript" type="text/javascript" src="../scripts/jquery.scrollTo-min.js" ></script>
<script language="javascript" type="text/javascript" src="../scripts/jquery.flipCounter.1.2.pack.js" ></script>
<link rel="stylesheet" type="text/css" href="admin.css" />
<title>
<?=$title?>::::&nbsp;&nbsp;سیستم مدیریت سایت&nbsp;&nbsp;::::</title>
</head>
<body>
<table width="900" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="142" style="background:url(layout/header.jpg) center no-repeat;">&nbsp;</td>
  </tr>
  <tr>
    <td height="28" valign="top"><table class="topmenu" width="900" height="28" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="30"></td>
          <td width="10" style="background:url(layout/menu_l.jpg) left no-repeat;"></td>
          <td width="778" align="center" valign="top" style="background:url(layout/menu_bg.jpg) left repeat-x;padding-top:15px;padding-right:20px;"><? include("menu/menu.php"); ?></td>
          <td width="10" style="background:url(layout/menu_r.jpg) right no-repeat;"></td>
          <td width="32"></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td height="40"></td>
  </tr>
  <tr>
    <td height="328" valign="top"><table width="900" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="11" height="34" style="background:url(layout/pln_ctl.jpg) left no-repeat;"></td>
          <td colspan="3" valign="top"><table width="878" height="34" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="114" style="background:url(layout/pln_t.jpg) right repeat-x;"></td>
                <td width="9" style="background:url(layout/pln_end.jpg) right no-repeat;"></td>
                <td align="right" valign="top"><table border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="18" height="34" style="background:url(layout/ti_l.jpg) right  no-repeat;"></td>
                <td  class="tipg" align="center" style="background:url(layout/ti_bg.jpg) right repeat-x;padding:0 10px 0 10px;"><?=$tipg?></td>
                <td width="18" style="background:url(layout/ti_r.jpg) right no-repeat;"></td>
                  </tr>
                </table></td>
                <td width="147" style="background:url(layout/pln_t.jpg) right repeat-x;"></td>
              </tr>
          </table></td>
          <td width="11" style="background:url(layout/pln_ctr.jpg) right no-repeat;"></td>
        </tr>
        <tr>
          <td rowspan="3" style="background:url(layout/pln_l.jpg) left repeat-y;"></td>
          <td width="20" height="20"></td>
          <td width="838"></td>
          <td width="20"></td>
          <td rowspan="3" style="background:url(layout/pln_r.jpg) right repeat-y;"></td>
        </tr>
        <tr>
          <td height="291"></td>
          <td align="right" valign="top"><div dir="rtl" id="content">
              <?

	$content="pages/$q.php";

	if (strlen($q)==0)

	{
        include("pages/home.php");
        }
	else
	{
		if (file_exists($content)) {
        	include("pages/$q.php");
        	}
        	else
        	{
			echo "<p>&nbsp;</p>";
			echo "<p>&nbsp;</p>";
        	echo "<div align=\"center\" style=\"font: bold 13px tahoma; color:#990033; \">صفحه مورد نظر شما وجود ندارد !</div>";
        	}

	}

?>
              <p></p>
            </div></td>
          <td></td>
        </tr>
        <tr>
          <td height="24"></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td height="11" style="background:url(layout/pln_cbl.jpg) left no-repeat;"></td>
          <td colspan="3" style="background:url(layout/pln_b.jpg) center repeat-x;"></td>
          <td style="background:url(layout/pln_cbr.jpg) right no-repeat;"></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td height="56"></td>
  </tr>
  <tr>
    <td><table width="900" height="81" border="0" cellspacing="0" cellpadding="0" style="background-color:#dde8eb">
        <tr>
          <td width="12" height="12" style="background:url(layout/ftcl.jpg) right no-repeat;"></td>
          <td width="876" height="12" style="background:url(layout/ftt.jpg) right repeat-x;"></td>
          <td width="12" height="12" style="background:url(layout/ftct.jpg) right no-repeat;"></td>
        </tr>
        <tr>
          <td height="30" style="background:url(layout/ftl.jpg) right repeat-y;"></td>
          <td height="70" class="footer" align="center" ><a href="http://www.irinco.com" target="_blank">ورود به سایت اصلی</a><br />
            &copy; کلیه حقوق این سایت متعلق به <a href="mailto:info@irinco.com">شرکت آیرین تجارت پاسارگاد</a> می باشد  . </td>
          <td height="30" style="background:url(layout/ftr.jpg) right repeat-y;"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
<?
mysql_close();
?>
<? }
else{
include('index.php');
}
?>
