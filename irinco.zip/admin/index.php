<?
$pieces = explode("/",$_SERVER['PHP_SELF']);
if(($pieces[count($pieces)-1]) != "index.php"){
if($_SERVER['QUERY_STRING'])
$path=$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
else
$path=$_SERVER['PHP_SELF'];
}else{
$path="admin.php";
}
?>
<html><head><title>:: ورود به سيستم مديريت ::</title>
<script language="javascript" type="text/javascript" src="scripts/jquery.js" ></script>
<script language="javascript" type="text/javascript" src="scripts/script.js" ></script>
<style>
*{ FONT-SIZE: 8pt; FONT-FAMILY: tahoma; } b { FONT-WEIGHT: bold; } .listtitle { BACKGROUND: #425984; COLOR: #EEEEEE; white-space: nowrap; } td.list { BACKGROUND: #EEEEEE; white-space: nowrap; } 
#login{
/*display:none;*/

}
#waitmessage{
font:bold 12px tahoma; 
color:green;
display:none;
}
#errormessage{
font:bold 12px tahoma; 
color:red;
display:none;
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head><body onLoad="document.user.user.focus();">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="login" align="center">
<h1>ورود به سيستم مديريت</h1>
<table width="250" dir="rtl" cellpadding="5" cellspacing="1">
<tr>
<td height="28" colspan="2" class="listtitle">لطفا نام كابري و كلمه عبور خود را وارد نماييد </td>
</tr>
<form action="./pages/login.php" method="post" name="user" onSubmit="return false;">
<tr><td class="list" align="right">نام كاربري :</td><td class="list"><input name="user" id="user" type="text"></td></tr>
<tr><td class="list" align="right">كلمه عبور :</td><td class="list"><input name="pass" id="pass" type="password"></td></tr>
<tr><td height="28" colspan="2" align="center" class="listtitle">
<input name="path" id="path" type="hidden" value="<?=$path?>">
<input style="width:50px" value="ورود" type="submit" onClick="return ch_login();"></td>
</tr>
</form>
</table>
</div>
<div align="center" id="waitmessage">
... در حال ورود به سيستم مديريت
</div>
<div align="center" id="errormessage">
! نام كاربري شما جهت ورود به سيستم مديريت معتبر نمي باشد
<br><br><br><a style="font:bold 12px tahoma; color:#990000; text-decoration: none;" href="javascript:ret()" > بازكشت </a>
</div>
</body></html>