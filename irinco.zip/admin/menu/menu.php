﻿<div style="margin-top:-9px;">
  <ul id="Menu1" class="MM">
    <li style="border:none;"><a href="?q=home" >صفحه اصلی</a></li>
        <li><a href="#">محصولات</a>
      <ul>
      <li><a href="?q=pro-cat-mg">مدیریت دسته ها</a></li>
       <li><a href="?q=product-mg">مدیریت محصولات</a></li>
      </ul>
    </li>
    <li><a href="#">ارتباط با مدیریت</a>
      <ul>
        <li><a href="?q=information">اطلاعات تماس</a></li>
        <li><a href="?q=inbox">صندوق دریافتی</a></li>
      </ul>
    </li>
      <li><a href="?q=email-mg">خبرنامه</a></li>  
          <li><a href="#">درباره ما مدیریت</a>
      <ul>
     <li><a href="?q=about">درباره ما</a></li>  
     <li><a href="?q=mission">ماموریت</a></li>  
        <li><a href="?q=goal">اهداف</a></li>  
     </ul>
     </li>
     <li><a href="logout.php" >خروج</a></li>
    </ul>
</div>
