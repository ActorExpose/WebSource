﻿// JavaScript Document
 function add_comma(textbox)
	{
		var comma = ',';
		textbox=textbox.toString();
		while (textbox.indexOf(comma) > 0)
		{
			textbox = textbox.replace(comma,'');
		}
		var num = textbox;
		if (num.length != 0 && parseInt(num))
		{
			var regex  = new RegExp('(-?[0-9]+)([0-9]{3})');
			while(regex.test(num))
			{
				num = num.replace(regex, '$1' + comma + '$2');
			}
		}
			 return num;
	};

function disable_browse(ch){
	if(ch==2){
	var form=document.album;
	var src=document.getElementById("album_preview").value;
	var add="albums";
	}else if(ch==3){
	var form=document.managers;
	var src=document.getElementById("manager_preview").value;
	var add="managers";
	}else if(ch==4){
	var form=document.hots;
	var src=document.getElementById("hots_preview").value;
	var add="hots";
	}else{
	var form=document.pro;
	var src=document.getElementById("news_preview").value;
	var add="news";
	}
	
 if (form.default_image.checked){
	document.getElementById("new_image").disabled = true;
	form.default_image.value=1;
	document.getElementById("img_place").innerHTML="<img alt='بدون تصویر' src='../images/"+add+"/blank.jpg' name='new_image2' width='100' height='100' id='new_image2' title='بدون تصویر'/>";
 }else{
	form.default_image.value=0;
	document.getElementById("new_image").disabled = false;
	if(src){
	document.getElementById("img_place").innerHTML="<a href='../images/"+add+"/"+src+"' target='_blank'><img alt='بزرگنمایی تصویر' src='../images/"+add+"/"+src+"' name='new_image2' width='100' height='100' border='0' id='new_image2' title='بزرگنمایی تصویر'/></a>";
	}else{
	document.getElementById("img_place").innerHTML="";	
	}
 }	
}

function checkForm_products()
{

if (document.products.cat.value=="")
 {
    alert("! یک دسته را انتخاب نمایید");
    document.products.cat.focus();
 return false;
 }
 
if (document.products.name.value=="")
 {
    alert("! نام محصول را وارد نماييد");
    document.products.name.focus();
 return false;
 } 
 
 	if(document.products.new_image.value == "")
	{
	if(document.products.products_preview.value == ""){	
 	alert("! تصوير محصول را وارد نماييد");
    document.products.new_image.focus();
	return false;
	}
}

if(document.products.edit_products.value == 1)
return confirm("آيا محصول جاري ويرايش گردد ؟");
}

function checkForm_note()
{
 if (document.pro.default_image.checked)
	document.pro.default_image.value=1;

if (document.pro.caption.value=="")
 {
    alert("! تیتر یادداشت را وارد نماييد");
    document.pro.caption.focus();
 return false;
 } 
 
 if(document.pro.short_comment.value == "")
 {
 	alert("! خلاصه یادداشت را وارد نماييد");
    document.pro.short_comment.focus();
	return false;
 }
  if(document.pro.short_comment.value.length > 150 )
 {
 	alert("! خلاصه یادداشت طولانی می باشد");
    document.pro.short_comment.focus();
	return false;
 }
	if(document.pro.new_image.value == "" && document.pro.default_image.value != 1)
	{
	if(document.pro.note_preview.value == ""){	
 	alert("! تصوير یادداشت را وارد نماييد");
    document.pro.note_preview.focus();
	return false;
	}
}
if(document.pro.edit_note.value == 1)
return confirm("آيا یادداشت جاري ويرايش گردد ؟");
}

function checkForm_interview()
{
 if (document.pro.default_image.checked)
	document.pro.default_image.value=1;

if (document.pro.caption.value=="")
 {
    alert("! تیتر مصاحبه را وارد نماييد");
    document.pro.caption.focus();
 return false;
 } 
 
 if(document.pro.short_comment.value == "")
 {
 	alert("! خلاصه مصاحبه را وارد نماييد");
    document.pro.short_comment.focus();
	return false;
 }
  if(document.pro.short_comment.value.length > 150 )
 {
 	alert("! خلاصه مصاحبه طولانی می باشد");
    document.pro.short_comment.focus();
	return false;
 }
	if(document.pro.new_image.value == "" && document.pro.default_image.value != 1)
	{
	if(document.pro.interview_preview.value == ""){	
 	alert("! تصوير مصاحبه را وارد نماييد");
    document.pro.new_image.focus();
	return false;
	}
}
if(document.pro.edit_interview.value == 1)
return confirm("آيا مصاحبه جاري ويرايش گردد ؟");
}

function checkForm_hots()
{
 if (document.hots.default_image.checked)
	document.hots.default_image.value=1;

if (document.hots.caption.value=="")
 {
    alert("! عنوان مطلب را وارد نماييد");
    document.hots.caption.focus();
 return false;
 } 
 
 if(document.hots.short_comment.value == "")
 {
 	alert("! خلاصه مطلب را وارد نماييد");
    document.hots.short_comment.focus();
	return false;
 }
  if(document.hots.short_comment.value.length > 150 )
 {
 	alert("! خلاصه مطلب طولانی می باشد");
    document.hots.short_comment.focus();
	return false;
 }
	if(document.hots.new_image.value == "" && document.hots.default_image.value != 1)
	{
	if(document.hots.hots_preview.value == ""){	
 	alert("! تصوير مطلب را وارد نماييد");
    document.hots.new_image.focus();
	return false;
	}
}
if(document.hots.edit_news.value == 1)
return confirm("آيا مطلب جاري ويرايش گردد ؟");
}

function checkForm_album()
{
	
 if (document.album.default_image.checked)
	document.album.default_image.value=1;
	
if (document.album.name.value=="")
 {
    alert("! عنوان آلبوم را وارد نماييد");
    document.album.name.focus();
 return false;
 } 
 
if(document.album.new_image.value == "" && document.album.default_image.value != 1)
	{
	if(document.album.album_preview.value == ""){	
 	alert("! تصوير آلبوم را وارد نماييد");
    document.album.new_image.focus();
	return false;
	}
}
 
 if(document.album.comment.value.length >150)
 {
 	alert("! متن توضیحات طولانی است");
    document.album.comment.focus();
	return false;
 } 
 
if(document.album.add_album.value==1){
	
		var notice=document.getElementById('notice');
		var name_value = $('#name').val();
		$.post("pages/check_album.php", {name:name_value}, function(response) {
																						 
			var response = eval('(' + response + ')');			
			if (response.success){

			notice.innerHTML = "<br/><p class=\"notice\">آلبوم ای با نام <span style=\"color:#690124\">"+name_value+"</span> قبلا در سیستم ثبت شده است !</p>";	
			location.href="#";
			document.album.name.focus();
			return false;
			}else{
			document.album.submit();
			}
		});
		return false;
	}else
	{
		var notice=document.getElementById('notice');
		var oldname_value = $('#old_name').val();
		var name_value = $('#name').val();
		
		$.post("pages/check_album.php", {name:name_value}, function(response) {
																						 
			var response = eval('(' + response + ')');			

			if (response.success && oldname_value != name_value){
				
			notice.innerHTML = "<br/><p class=\"notice\">آلبوم ای با نام <span style=\"color:#690124\">"+name_value+"</span> قبلا در سیستم ثبت شده است !</p>";	
			location.href="#";
			document.album.name.focus();
			return false;
			}else{
			if(confirm("آيا آلبوم جاري ويرايش گردد ؟"))
			document.album.submit();
			}
		});
		return false;	
	}
 
}

function checkForm_pro_gallery()
{
if (document.gallery.project.value=="")
 {
    alert("! یک پروژه را انتخاب نمایید");
    document.gallery.project.focus();
 return false;
 } 
 if (document.gallery.name.value=="")
 {
    alert("! عنوان تصویر را وارد نماييد");
    document.gallery.name.focus();
 return false;
 } 
 
if(document.gallery.new_image.value=="")
	{
	if(document.gallery.gallery_preview.value == ""){	
 	alert("! آدرس تصوير را وارد نماييد");
    document.gallery.new_image.focus();
	return false;
	}
}
 
 if(document.gallery.comment.value.length >150)
 {
 	alert("! متن توضیحات طولانی است");
    document.gallery.comment.focus();
	return false;
 } 
if(document.gallery.edit_gallery.value == 1)
return confirm("آيا تصویر جاري ويرايش گردد ؟");
}

function checkForm_cert()
{
 if (document.cert.name.value=="")
 {
    alert("! عنوان تصویر را وارد نماييد");
    document.cert.name.focus();
 return false;
 } 
 
if(document.cert.new_image.value=="")
	{
	if(document.cert.cert_preview.value == ""){	
 	alert("! تصوير را وارد نماييد");
    document.cert.new_image.focus();
	return false;
	}
}
 
if(document.cert.edit_cert.value == 1)
return confirm("آيا تصویر جاري ويرايش گردد ؟");
}

function checkForm_plan()
{

 if (document.plan.cat.value=="")
 {
    alert("! نام دسته را وارد نماييد");
    document.plan.cat.focus();
 return false;
 } 
 
 if (document.plan.name.value=="")
 {
    alert("! عنوان  پلان را وارد نماييد");
    document.plan.name.focus();
 return false;
 } 
 
if(document.plan.new_image.value=="")
	{
	if(document.plan.plan_preview.value == ""){	
 	alert("! آدرس تصوير پلان را وارد نماييد");
    document.plan.new_image.focus();
	return false;
	}
}
 
if(document.plan.edit_plan.value == 1)
return confirm("آيا پلان جاري ويرايش گردد ؟");
}

function checkForm_link()
{
if (document.links.caption.value=="")
 {
    alert("! عنوان پیوند را وارد نماييد");
    document.links.caption.focus();
 return false;
 } 
 if (document.links.url.value=="http://" || document.links.url.value=="")
 {
    alert("! آدرس پیوند را وارد نماييد");
    document.links.url.focus();
 return false;
 } 

if(document.links.edit_links.value == 1)
return confirm("آيا پیوند جاري ويرايش گردد ؟");
}

function checkForm_price()
{
if (document.price.uset.value=="")
 {
    alert("! کاربری را وارد نماييد");
    document.price.uset.focus();
 return false;
 } 
 
if (document.price.minp.value=="")
 {
    alert("! حداقل قیمت را وارد نماييد");
    document.price.minp.focus();
 return false;
 } 
 
if (document.price.maxp.value=="")
 {
    alert("! حداکثر قیمت را وارد نماييد");
    document.price.maxp.focus();
 return false;
 }
 
 if(document.price.edit_price.value == 1)
return confirm("آيا قیمت جاري ويرايش گردد ؟");

}

function checkForm_header()
{
 
 if(document.header.new_image.value == "")
 {
	if(document.header.file_preview.value == "")
	{
 	alert("! آدرس تصویر وارد نشده است");
    document.header.new_image.focus();
	return false;
	}
 }
}

function checkForm_pos()
{
 
 if(document.pos.address.value == "")
 {
 	alert("! آدرس پروژه را وارد نمایید");
    document.pos.address.focus();
	return false;
 }
  if(document.pos.position.value == "")
 {
 	alert("! مختصات پروژه را وارد نمایید");
    document.pos.position.focus();
	return false;
 }
} 

function check_ch()
{
	if(document.pro.short_comment.value.length < 150){
		document.getElementById('character').innerHTML = 150-document.pro.short_comment.value.length;
	}else{
		document.getElementById('character').innerHTML = 0;
	}
}


function check_ch_album()
{
	if(document.album.comment.value.length < 150){
		document.getElementById('character').innerHTML = 150-document.album.comment.value.length;
	}else{
		document.getElementById('character').innerHTML = 0;
	}
}

function check_ch_gallery()
{
	if(document.gallery.comment.value.length < 150){
		document.getElementById('character').innerHTML = 150-document.gallery.comment.value.length;
	}else{
		document.getElementById('character').innerHTML = 0;
	}
}

function check_ch_cert()
{
	if(document.cert.comment.value.length < 120){
		document.getElementById('character').innerHTML = 120-document.cert.comment.value.length;
	}else{
		document.getElementById('character').innerHTML = 0;
	}
}

function chkKeyDigit(event) {
	if(navigator.appName=='Netscape')
      var k = event.which;
	  else
	  var k = event.keyCode;
	  if(k==0 || k==8){
		return true;  
	  }
      else if (k < 48 || k > 57) {
            return false;
      }
      return true;
}

function chkKeyLetterSpace(e) {
      var k = (e.which)? e.which : e.keyCode;
      var kName = String.fromCharCode(k);
      if (!kName.match(/^[A-Z ]+$/i)) {
            return false;
      }
      return true;
}

function edit_en(){
for (var i = 0; i < document.forms[1].length; i++){
    document.forms[1].elements[i].disabled=false;
	 document.forms[1].elements[i].style.border = "1px solid #ADAEAF";
	 document.forms[1].elements[i].style.backgroundColor = "#FFFFFF";
}
}
function reset_form(){
for (var i = 0; i < document.forms[1].length; i++){
    document.forms[1].elements[i].disabled=true;
	document.forms[1].elements[i].style.border = "none";
	document.forms[1]. reset();
}
}

function GETIp(Postid){
	
	strUrl="pages/bvisit.php?id="+Postid;
window.open( strUrl ,"blogfa_comments","status=yes,scrollbars=yes,toolbar=no,menubar=no,location=no ,width=500px,height=500px");
	
}

function makedate2(jday1,jmonth1,jyear1){
	if(jday1==null){
	var jday1=document.getElementById("jday").value;
	var jmonth1=document.getElementById("jmonth").value;
	var jyear1=document.getElementById("jyear").value;
	}
	var sdate;
	sdate =  "&nbsp;&nbsp;انتخاب تاریخ&nbsp;&nbsp;<select name='p_day1' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	for(var i=1; i<=31; i++)
{
	if(jday1 == i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
}	
	sdate +=  "</select>&nbsp;/&nbsp;";
	sdate +=  "<select name='p_month1' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	
	for(var i=1; i<=12; i++)
		{
	if( jmonth1 ==  i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
		}
		
	sdate +=  "</select>&nbsp;/&nbsp;";
	sdate +=  "<select name='p_year1' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	
for(var i=1380; i<=1400; i++)
{
	if( jyear1 ==  i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
}
	sdate +=  "</select>&nbsp;";
return sdate;

}

function makedate(jday1,jmonth1,jyear1,jday2,jmonth2,jyear2){
	if(document.forms[0].name=="nshow"){
	var to="تا تاریخ";
	var from="از تاریخ";
	}else if(document.forms[0].name=="ashow"){
	var to="تاریخ پایان";
	var from="تاریخ شروع";
	}else if(document.forms[0].name=="fshow" || document.forms[1].name=="fshow"){
	var to="تا تاریخ";
	var from="از تاریخ";
	}
	
	if(jday1==null){
	var jday1=document.getElementById("jday").value;
	var jmonth1=document.getElementById("jmonth").value;
	var jyear1=document.getElementById("jyear").value;
	var jday2=document.getElementById("jday").value;
	var jmonth2=document.getElementById("jmonth").value;
	var jyear2=document.getElementById("jyear").value;
	}
	var sdate;
	sdate =  "&nbsp;&nbsp;"+from+"&nbsp;&nbsp;<select name='p_day1' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	for(var i=1; i<=31; i++)
{
	if(jday1 == i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
}	
	sdate +=  "</select>&nbsp;/&nbsp;";
	sdate +=  "<select name='p_month1' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	
	for(var i=1; i<=12; i++)
		{
	if( jmonth1 ==  i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
		}
		
	sdate +=  "</select>&nbsp;/&nbsp;";
	sdate +=  "<select name='p_year1' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	
for(var i=1380; i<=1400; i++)
{
	if( jyear1 ==  i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
}
	sdate +=  "</select>&nbsp;";
	sdate +=  "&nbsp;"+to+"&nbsp;&nbsp;<select name='p_day2' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	for(var i=1; i<=31; i++)
{
	if(jday2 == i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
}	
	sdate +=  "</select>&nbsp;/&nbsp;";
	sdate +=  "<select name='p_month2' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	
	for(var i=1; i<=12; i++)
		{
	if( jmonth2 ==  i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
		}
		
	sdate +=  "</select>&nbsp;/&nbsp;";
	sdate +=  "<select name='p_year2' dir='rtl' style='font-family:Tahoma,Arial; font-size:8pt'>";
	
for(var i=1380; i<=1400; i++)
{
	if( jyear2 ==  i)
	{
		sdate += "<option selected='selected' value='"+ i +"'>"+ i +"</option>";
	}
	else
	{
		sdate += "<option value='"+ i +"'>"+ i +"</option>";
	}
}
	sdate +=  "</select>";
return sdate;
}

function ch_fields(){
   var field = document.getElementById("field");
	if(document.getElementById("scope").value == 1 || document.getElementById("scope").value == 2){
	field.innerHTML='<input type="text" name="eshow" class="input" id="eshow" value="" />';	
	}else if(document.getElementById("scope").value == 3 || document.getElementById("scope").value == 5){
	field.innerHTML=makedate();	
	}else if(document.getElementById("scope").value == 4){
	field.innerHTML=makedate2();
	}else if(document.getElementById("scope").value == 6){
	field.innerHTML='<select class="select" name="level" id="level" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl"><option value="0" >کاربر عادی</option><option value="1" >مدیریت</option></select>';	
	}else{
	field.innerHTML='';	
	}
}

function ch_fields2(){
   var field = document.getElementById("field");
	if(document.getElementById("scope2").value == 1){
	field.innerHTML='<select name="order" id="order"><option value="1">صعودی</option><option value="2">نزولی</option></select>';
	}else if(document.getElementById("scope2").value == 2){
	field.innerHTML='<select name="order" id="order"><option value="1">بیشترین</option><option value="2">کمترین</option></select>';
	}else{
	field.innerHTML='';	
	}
}

function ch_fields_employ(){
   var field = document.getElementById("field");
	if(document.getElementById("scope").value == 1){
	field.innerHTML='<input type="text" name="eshow" class="input" id="eshow" value="" />';	
	}else if(document.getElementById("scope").value == 2){
	field.innerHTML='<select name="fields"><option value="a">ساختمانی و ابنیه</option><option value="b">فنی و مهندسی</option><option value="c">فروش</option><option value="d">روابط عمومي</option><option value="e">ترابری و ماشین آلات</option><option value="f">امور مالی</option><option value="g">حراست و نگهبانی</option><option value="h">امور میهمان و لیدرها</option><option value="i">واحد انفورماتیک</option><option value="j">رزرواسیون</option><option value="k">امور اداري</option><option value="l">خدمات</option></select>';
	}else{
	field.innerHTML=makedate();	
	}
}

function ch_fields_comment(){
   var field = document.getElementById("field");
	if(document.getElementById("scope").value == 1 || document.getElementById("scope").value == 2){
	field.innerHTML='&nbsp;<input type="text" name="eshow" class="input" id="eshow" value="" />';	
	}else if(document.getElementById("scope").value == 4){
	field.innerHTML=makedate();	
	}else{
	field.innerHTML='';	
	}
}

function showimage(){
/*	var BrowserName= navigator.appName;
	var BrowserVersion = navigator.appVersion;
	var BrowserAgent= navigator.userAgent;
	var str=BrowserAgent.substr(30,3);
	var preview = document.getElementById("preview");
	var img_prew = document.getElementById("new_image").src;
		alert(img_prew);
	preview.innerHTML="<img src='"+img_prew+"' width='122' height='168'/>";*/
}

function timeout(path_value)
{
location.href=path_value;
}

function ret(){	
document.getElementById('errormessage').style.display='none';
document.getElementById('user').value='';
document.getElementById('pass').value='';
document.getElementById('login').style.display='block';
document.getElementById('user').focus();
}

function waiting(path_value)
{
document.getElementById('login').style.display='none';	
document.getElementById('waitmessage').style.display='block';
setTimeout("timeout('"+path_value+"')", 3000);
}

function error()
{
document.getElementById('login').style.display='none';	
document.getElementById('errormessage').style.display='block';
}

function ch_login()
{
		var user_value = $('#user').val();
		var pass_value = $('#pass').val();
		var path_value = $('#path').val();
		$.post("pages/login.php", { user:user_value , pass:pass_value }, function(response) {
																				  
			var response = eval('(' + response + ')');			
			//alert(response.success);
			if (response.success){
				waiting(path_value);
			}
			else{
				error();
			}
		  });
}

function ch_enter(e) {
      var k = (e.which)? e.which : e.keyCode;
      if (k == 13) {
           ch_login();
      }
}

function delfunc(){
var Url=arguments[0];
var title=arguments[1];
var mgs ='آيا مطمئن به حذف '+title+' جاری مي باشيد ؟';
if(arguments.length>2){
mgs=arguments[2];
}
if(confirm(mgs))
location.href=Url;
}

function checkForm_cat()
{
if (document.cat.name.value=="")
 {
    alert("! عنوان دسته را وارد نماييد");
    document.cat.name.focus();
 return false;
 } 

if(document.cat.add_cat.value==1){
		var notice=document.getElementById('notice');
		var name_value = $('#name').val();
		$.post("pages/check_exist.php", {action:"cat",name:name_value}, function(response) {
																						 
			var response = eval('(' + response + ')');			
			if (response.success){

			notice.innerHTML = "<br/><p class=\"notice\">دسته ای با نام <span style=\"color:#690124\">"+name_value+"</span> قبلا در سیستم ثبت شده است !</p>";	
			location.href="#";
			document.cat.name.focus();
			return false;
			}else{
			document.cat.submit();
			}
		});
		return false;
	}else
	{
		var notice=document.getElementById('notice');
		var oldname_value = $('#old_name').val();
		var name_value = $('#name').val();
		
		$.post("pages/check_exist.php", {action:"cat",name:name_value}, function(response) {
																						 
			var response = eval('(' + response + ')');			

			if (response.success && oldname_value != name_value){
				
			notice.innerHTML = "<br/><p class=\"notice\">دسته ای با نام <span style=\"color:#690124\">"+name_value+"</span> قبلا در سیستم ثبت شده است !</p>";	
			location.href="#";
			document.cat.name.focus();
			return false;
			}else{
			if(confirm("آيا دسته جاري ويرايش گردد ؟"))
			document.cat.submit();
			}
		});
		return false;	
	}
 
}

function checkForm_user(){

if (document.users.user.value=="")
 {
    alert("! نام کاربری را وارد نماييد");
    document.users.user.focus();
 return false;
 } 

if (document.users.pass.value=="")
 {
    alert("! کلمه عبور را وارد نماييد");
    document.users.pass.focus();
 return false;
 } 
 
 if (document.users.name.value=="")
 {
    alert("! نام و نام خانوادگی را وارد نماييد");
    document.users.name.focus();
 return false;
 } 
 
 if (document.users.field.value=="")
 {
    alert("! زمینه فعالیت را وارد نماييد");
    document.users.field.focus();
 return false;
 } 
  
  if (document.users.mail.value=="")
 {
    alert("! پست الکترونیک را وارد نماييد");
    document.users.mail.focus();
 return false;
 } 
 
if(document.users.add_user.value==1){
	
		var notice=document.getElementById('notice');
		var user_value = $('#user').val();
		$.post("pages/check_exist.php", {action:"user",user:user_value}, function(response) {
																						 
			var response = eval('(' + response + ')');			
			if (response.success){

			notice.innerHTML = "<br/><p class=\"notice\">نام کاربری <span style=\"color:#690124\">"+user_value+"</span> قبلا در سیستم ثبت شده است !</p>";	
			location.href="#";
			document.users.user.focus();
			return false;
			}else{
			document.users.submit();
			}
		});
		return false;
	}else
	{
		var notice=document.getElementById('notice');
		var olduser_value = $('#old_user').val();
		var user_value = $('#user').val();
		$.post("pages/check_exist.php", {action:"user",user:user_value}, function(response) {
																						 
			var response = eval('(' + response + ')');			

			if (response.success && olduser_value != user_value){
				
			notice.innerHTML = "<br/><p class=\"notice\">نام کاربری <span style=\"color:#690124\">"+user_value+"</span> قبلا در سیستم ثبت شده است !</p>";	
			location.href="#";
			document.users.users.focus();
			return false;
			}else{
			if(confirm("آيا اطلاعات کاربری ويرايش گردد ؟"))
			document.users.submit();
			}
		});
		return false;	
	}

}

function checkForm_file()
{
if (document.file.cat.value=="")
 {
    alert("! نام دسته را انتخاب نماييد");
    document.file.cat.focus();
 return false;
 } 
 if (document.file.name.value=="")
 {
    alert("! نام فایل را وارد نماييد");
    document.file.name.focus();
 return false;
 } 
	if(document.file.new_icon.value == "")
	{
	if(document.file.icon_preview.value == ""){	
 	alert("! آدرس آیکون فایل را وارد نماييد");
    document.file.new_icon.focus();
	return false;
	}
}

	if(document.file.new_image.value == "")
	{
	if(document.file.file_preview.value == ""){	
 	alert("! آدرس فایل را وارد نماييد");
    document.file.new_image.focus();
	return false;
	}
}

if(document.file.edit_file.value == 1)
return confirm("آيا فایل جاري ويرايش گردد ؟");
}


function checkForm_gallery()
{
 	
if (document.gallery.cat.value=="")
 {
    alert("! یک دسته را انتخاب نمایید");
    document.gallery.cat.focus();
 return false;
 } 
 
if (document.gallery.project.value=="")
 {
    alert("! یک پروژه را انتخاب نمایید");
    document.gallery.project.focus();
 return false;
 } 
 if (document.gallery.name.value=="")
 {
    alert("! عنوان تصویر را وارد نماييد");
    document.gallery.name.focus();
 return false;
 } 
 
if(document.gallery.new_image.value=="")
	{
	if(document.gallery.gallery_preview.value == ""){	
 	alert("! آدرس تصوير را وارد نماييد");
    document.gallery.new_image.focus();
	return false;
	}
}
 
 if(document.gallery.comment.value.length >150)
 {
 	alert("! متن توضیحات طولانی است");
    document.gallery.comment.focus();
	return false;
 } 
if(document.gallery.edit_gallery.value == 1)
return confirm("آيا تصویر جاري ويرايش گردد ؟");
}