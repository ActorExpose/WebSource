<?

include('../../dbconnect.php');
	if(isset($_GET['eshow']) && strlen($_GET['eshow']) > 0) {
	$sql = mysql_query("SELECT Eemail,Etime FROM emails WHERE Eemail LIKE '%".$_GET['eshow']."%' ORDER BY Etime DESC");
}elseif($_GET['scope']==3){
	$sql = mysql_query("SELECT Eemail,Etime FROM emails WHERE Epost >= '".$_GET['sdate']."' and Epost <= '".$_GET['fdate']."' ORDER BY Etime DESC");
}else{
	$sql = mysql_query("SELECT Eemail,Etime FROM emails ORDER BY Etime DESC");
}
	while ($record = mysql_fetch_object($sql)){
$list=$list.$record->Eemail.",<br>";
}
echo "<span style='font-family:tahoma,arial;font-size:14px'>".substr($list,0,(strlen($list)-1))."</span>";
?> 