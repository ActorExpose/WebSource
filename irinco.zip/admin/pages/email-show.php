<?
	$eshow = $_GET['eshow'];
	$scope = $_GET['scope'];
	$page = $_GET['page'];
	$sdate = $_GET['sdate'];
	$fdate = $_GET['fdate'];
	if($eshow){
	$location="location.href='?q=email-mg&eshow=$eshow&scope=$scope&page=$page'";
	$qs="&eshow=$eshow&scope=$scope&page=$page";
	}elseif($scope==2){
	$location="location.href='?q=email-mg&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'";
	$qs="&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page";
    }elseif($page){
	$location="location.href='?q=email-mg&page=$page'";
	$qs="&page=$page";
	}else{
	$location="location.href='?q=email-mg'";
	$qs="";
	}
	if(isset($_GET['del']) && $_GET['del'] != 0){
	$id=$_GET['del'];
	mysql_query("DELETE FROM emails WHERE Eid='$id'"); 
	$_GET['del'] = 0;
	echo "<script language=\"javascript\" >".$location."</script>";
	}
		$query = "SELECT * FROM emails WHERE Eid = '".$_GET['show']."'"; 
		$result = mysql_query($query);
		$record = mysql_fetch_object($result);
	?>
    
<p>
  <input type="hidden" name="id" value="<? echo "$record->Eid";?>" />
  <input type="hidden" name="time" value="<? echo "$record->Etime";?>" />
</p>
<p><br/>
</p>
<table width="827" border="0" align="center" cellpadding="0" cellspacing="4" dir="rtl">
			<tr>
			  <td width="22%" height="25" align="left">
		      <label for="name"><strong>ایمیل معرفی کننده&nbsp;</strong></label></td>
<td width="78%">
					<? echo "$record->Ename";?>		  </td>
			</tr>
			<tr >
				<td width="22%" align="left">
			  <label for="name"><strong>نام دوست&nbsp;&nbsp;</strong></label></td>
		  <td height="25"> 
					<? echo "$record->Efriend";?>		  </td>
		  </tr>
			<tr >
				<td width="22%" align="left">
			  <label for="name"><strong>ایمیل دوست&nbsp;&nbsp;</strong></label></td>
				<td height="25" >
					<? echo "$record->Eemail";?>			  </td>
		  </tr>
			<tr >
			  <td width="22%" height="98" >&nbsp;</td>
			  <td ><input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" /><input name="delete" onclick="return delfunc('?q=email-show&del=<?=$record->Eid;?><?=$qs;?>','اطلاعات')" type="button" class="button" id="delete" style="width:70px" value="حذف" /></td>
		    </tr>
</table>
	<br/>
<? mysql_query("UPDATE emails SET Evisited='1' WHERE Eid='".$_GET['show']."'");?>