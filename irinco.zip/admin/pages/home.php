<?
$counter = mysql_num_rows(mysql_query("SELECT id FROM counter"));
?>
<div align="center" style="width:838px;padding-top:105px;padding-bottom:50px;">
<img src="layout/welimg.jpg" width="442" height="55" />
<br /><br /><br /><br /><br />
<strong> تعداد بازدید کنندگان تا کنون</strong><br /><br />
<div id="counter" dir="ltr"> <input type="hidden" name="counter-value" value="0" /></div>
<script type="text/javascript">
/* <![CDATA[ */
$("#counter").flipCounter({
      	 number:0, // the initial number the counter should display, overrides the hidden field
        numIntegralDigits:1, // number of places left of the decimal point to maintain
        numFractionalDigits:0, // number of places right of the decimal point to maintain
        digitClass:"counter-digit", // class of the counter digits
        counterFieldName:"counter-value", // name of the hidden field
        digitHeight:35, // the height of each digit in the flipCounter-medium.png sprite image
        digitWidth:26, // the width of each digit in the flipCounter-medium.png sprite image
        imagePath:"../images/flipCounter-medium.png", // the path to the sprite image relative to your html document
        easing: false, // the easing function to apply to animations, you can override this with a jQuery.easing method
        duration:100, // duration of animations
        onAnimationStarted:false, // call back for animation upon starting
        onAnimationStopped:false, // call back for animation upon stopping
        onAnimationPaused:false, // call back for animation upon pausing
        onAnimationResumed:false // call back for animation upon resuming from pause
});
/* ]]> */
</script>
<script type="text/javascript">
			/* <![CDATA[ */
				jQuery(document).ready(function($) {
					
					$("#counter").flipCounter("startAnimation", {end_number:<?=$counter?>, easing:false, duration:100});
		
								
				});
			/* ]]> */
	</script>
</div>
