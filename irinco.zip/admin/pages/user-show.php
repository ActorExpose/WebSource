<?
	$location="location.href='?q=user-manage'";
	$qs="";
	if(isset($_GET['del']) && $_GET['del'] != 0){
	$id=$_GET['del'];
	mysql_query("DELETE FROM users WHERE id='$id'"); 
	echo "<script language=\"javascript\" >".$location."</script>";
	}
	
if(isset($_POST['edit_user']) && $_POST['edit_user']=='1' && !(isset($_GET['del']) && $_GET['del'] != 0))
	{
$user=$_POST['user'];
$pass=$_POST['pass'];
$name=$_POST['name'];
$birth=$_POST['b_year'].$_POST['b_month'].$_POST['b_day'];
$field=$_POST['field'];
$mail=$_POST['mail'];
$level=$_POST['level'];
$status=$_POST['status'];
$id=$_POST['id'];

	mysql_query ("UPDATE users SET user='$user',pass='$pass',name='$name',mail='$mail',birth='$birth',field='$field',level='$level',status='$status' WHERE id='$id'");

	?>
    	<br />
		<div id="notice" align="center">
        <p  class="success">کاربر <span style="color:#029125"><?=$old_user?></span> با موفقیت ویرایش گردید</p>
		</div>
    <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
}
		$query = "SELECT * FROM users WHERE id = '".$_GET['show']."'"; 
		$result = mysql_query($query);
		$record = mysql_fetch_object($result);
		
	$e_year=substr($record->post,0,4);
	$e_month=substr($record->post,4,2);
	$e_day=substr($record->post,6,2);
	$e_hour=substr($record->post,8,2);
	$e_min=substr($record->post,10,2);
	
	?>
<form class="form" name="users" action="" method="post" enctype="multipart/form-data" onsubmit="return false;">
  <input type="hidden" name="id" value="<? echo "$record->id";?>" /><br />
<table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="700">
<tr class="tr">
				<td height="15" colspan="2" valign="top" class="td"></td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  نام کاربری&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<input name="user" type="text" class="input" id="user" value="<?=$record->user;?>" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  کلمه عبور&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<input name="pass" type="text" class="input" id="pass" value="<?=$record->pass;?>" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  نام و نام خانوادگی&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<input name="name" type="text" class="input" id="name" value="<?=$record->name;?>" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  تاریخ تولد&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
<select name="b_day" id="b_day" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
  <? 
for($i=1;$i<=31;$i++)
{
	if($e_day == $i)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
</select>&nbsp;/&nbsp;<select name="b_month" id="b_month" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
<? 
for($i=1;$i<=12;$i++)
{
	if($e_month == $i)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
</select>&nbsp;/&nbsp;<select name="b_year" id="b_year" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
    <? 
for($i=1300;$i<=1400;$i++)
{
	if($e_year == $i)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
  </select></td>
			</tr>
   			<tr class="tr">
			  <td width="170" height="25" align="left" class="td">زمینه فعالیت&nbsp;&nbsp;</td>
<td height="25" class="td"><input name="field" type="text" class="input" id="field" value="<?=$record->field;?>" size="30" /></td>
			</tr>
   			<tr class="tr">
			  <td width="170" height="25" align="left" class="td">پست الکترونیکی&nbsp;&nbsp;</td>
<td height="25" class="td">
			  <input name="mail" type="text" class="input" id="mail" style="text-align:left;direction:ltr;" value="<?=$record->mail;?>" size="30" />			  </td>
			</tr>
   			<tr class="tr">
			  <td width="170" height="25" align="left" class="td">سطح دسترسی&nbsp;&nbsp;</td>
<td height="25" class="td"><select class="select" name="level" id="level" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">

  <option value="0" <? if($record->level) echo 'selected="selected"' ?> >کاربر عادی</option>
  <option value="1" <? if($record->level) echo 'selected="selected"' ?> >مدیریت</option>
</select></td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			 وضعیت&nbsp;&nbsp;</td>
<td height="25" class="td">
			      <? 
		   if($record->status == 1){
		  ?> 
        <input name="status" type="radio" id="status_0" value="1" checked="checked"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0"/>
        غير فعال
          <?
			}
			else{
			?>
        <input name="status" type="radio" id="status_0" value="1"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0" checked="checked"/>
        غير فعال
          <?
				}
				?></td>
				</tr>
			<tr class="tr">
				<td width="170" height="50" align="left" class="td"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td class="td" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
    </tr>
<tr class="tr">
			  <td width="170" height="48" class="td">&nbsp;</td>
<td class="td">     <input type="hidden" id="old_user" name="old_user" value="<? echo "$record->user";?>" />
			<input type="hidden" value="0" name="add_user" /><input type="hidden" value="1" name="edit_user" /><input name="submit" type="submit" class="button" id="submit" style="width:85px" value="ویرایش" onclick="return checkForm_user()" />&nbsp;<input name="delete" onclick="return delfunc('?q=user-show&del=<?=$record->id;?><?=$qs;?>','اطلاعات')" type="button" class="button" id="delete" style="width:70px" value="حذف" />&nbsp;<input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" /></td>
			</tr>
	</table>
</form>
	<br/>