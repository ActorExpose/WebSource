<?
	if($_POST['eshow']){
	$eshow = $_POST['eshow'];
	}else if($_GET['eshow']){
	$eshow = $_GET['eshow'];
	}
	
	if($_POST['level']){
	$level = $_POST['level'];
	}else if($_GET['level']){
	$level = $_GET['level'];
	}
	
	if($_POST['p_day1']){
	$p_day1=$_POST['p_day1'];
	$p_month1=$_POST['p_month1'];
	$p_year1=$_POST['p_year1'];
	$p_day2=$_POST['p_day2'];
	$p_month2=$_POST['p_month2'];
	$p_year2=$_POST['p_year2'];
	}
	if($_GET['sdate']){
	$sdate=$_GET['sdate'];
	$p_day1=substr($sdate,6,2);
	if(substr($p_day1,0,1)==0)
	$p_day1=substr($p_day1,1,1);
	$p_month1=substr($sdate,4,2);
	if(substr($p_month1,0,1)==0)
	$p_month1=substr($p_month1,1,1);
	$p_year1=substr($sdate,0,4);
	}
	if($_GET['fdate']){
	$fdate=$_GET['fdate'];
	$p_day2=substr($fdate,6,2);
	if(substr($p_day2,0,1)==0)
	$p_day2=substr($p_day2,1,1);
	$p_month2=substr($fdate,4,2);
	if(substr($p_month2,0,1)==0)
	$p_month2=substr($p_month2,1,1);
	$p_year2=substr($fdate,0,4);
	}
	
	if(strlen($p_day1)<2)
	$s_day=0 .$p_day1;
	else
	$s_day=$p_day1;
	if(strlen($p_month1)<2)
	$s_month=0 .$p_month1;
	else
	$s_month=$p_month1;
	$s_year=$p_year1;
	if(strlen($p_day2)<2)
	$f_day=0 .$p_day2;
	else
	$f_day=$p_day2;
	if(strlen($p_month2)<2)
	$f_month=0 .$p_month2;
	else
	$f_month=$p_month2;
	$f_year=$p_year2;
	$sdate=$s_year.$s_month.$s_day;
	$fdate=$f_year.$f_month.$f_day;
 // echo $sdate."<br>";	
  //echo $fdate."<br>";
	if($_POST['scope']){
	$scope = $_POST['scope'];
	}else if ($_GET['scope']){
	$scope = $_GET['scope'];
	}
//*********************************************************
function per_page($link, $offset,$eshow,$scope,$sdate,$fdate) 
{
	global $numofpages, $page;
	
	$pagesstart = round($page-$offset);
	$pagesend = round($page+$offset);
	
	if ($page != "1" && round($numofpages) != "0") 
	{
		if($eshow){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=user-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}elseif($scope==2){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=user-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;sdate='.$sdate.'&amp;fdate='.$fdate.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}else{
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=user-manage&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}
		
		echo str_replace("%page", round($page-1), '<td class="bt_prev" align="center" width="24" height="21"><a href="'.$link.'" title=" صفحه قبلی" style="text-decoration: none;" >&nbsp;&nbsp;<&nbsp;&nbsp;</a></td>');
	}
	else{
			echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;<<&nbsp;</td>';
		echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;<&nbsp;&nbsp;</td>';
	}
	
	
	for($i = 1; $i <= $numofpages; $i++) 
	{ 
		if ($pagesstart <= $i && $pagesend >= $i) 
		{
			if ($i == $page) 
			{
				echo "<td class='curpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
			}
			else 
			{
				echo str_replace("%page", "$i", '<td class="numpage" valign="middle" width="24" height="21"><a href="'.$link.'" style="text-decoration: none;" >&nbsp;&nbsp;'.Ct($i).'&nbsp;&nbsp;</a></td>');	
			}
		}
	}
	if (round($numofpages) == "0") 
	{
		echo "<td class='numpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
	}
	
	if ($page != round($numofpages) && round($numofpages) != "0") 
	{
		echo str_replace("%page", round($page+1), '<td class="bt_next" align="center" width="24" height="21"><a href="'.$link.'" title="صفحه بعدی" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>');
		if($eshow){
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=user-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;&nbsp;>>&nbsp;&nbsp;</a></td>';
		}elseif($scope==2){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=user-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;sdate='.$sdate.'&amp;fdate='.$fdate.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}else{
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=user-manage&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}
	}else{
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;>&nbsp;&nbsp;</td>';
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;>>&nbsp;</td>';
	}
}
$pp = "30";
//******************************************************
if(isset($_GET['del']) && $_GET['del'] != 0){

$id=$_GET['del'];
mysql_query("DELETE FROM users WHERE id='$id'"); 

$_GET['del'] = 0;
}

if(isset($_GET['status']) && $_GET['status'] != 0){

	$id=$_GET['status'];
	
	$result = mysql_query("SELECT * FROM users WHERE id='$id'");
	$record = mysql_fetch_object($result);
	if($record->status == 1){
	mysql_query ("UPDATE users SET status='0' WHERE id='$id'");
	}
	if($record->status == 0){
	mysql_query ("UPDATE users SET status='1' WHERE id='$id'");
	}
	
$_GET['status'] = 0;
}
if(isset($eshow) && strlen($eshow) > 0) {
	if($scope==2)
	$sql = mysql_query("SELECT * FROM users WHERE name LIKE '%$eshow%' ORDER BY id DESC");
	else
	$sql = mysql_query("SELECT * FROM users WHERE user LIKE '%$eshow%' ORDER BY id DESC");
}elseif($scope==6){
	$sql = mysql_query("SELECT * FROM users WHERE level = '$level' ORDER BY id DESC");
}elseif($scope==3){
	$sql = mysql_query("SELECT * FROM users WHERE post >= '$sdate' and post <= '$fdate' ORDER BY id DESC");
}elseif($scope==5){
	$sql = mysql_query("SELECT * FROM users WHERE birth >= '$sdate' and birth <= '$fdate' ORDER BY id DESC");
}else{
	$sql = mysql_query("SELECT * FROM users ORDER BY time DESC");
}
$totalp = mysql_num_rows($sql);
//********************************************************
$numofpages = ceil($totalp / $pp); 
if (!isset($_GET['page']))
{ 
	$page = 1; 
} 
else 
{ 
	$page = $_GET['page']; 
	if($numofpages<$page)
	$page-=1;
} 
$limitvalue = $page * $pp - ($pp);

if(isset($eshow) && strlen($eshow) > 0) {
	if($scope==2)
	$sql = mysql_query("SELECT * FROM users WHERE name LIKE '%$eshow%' ORDER BY id DESC LIMIT $limitvalue, $pp");
	else
	$sql = mysql_query("SELECT * FROM users WHERE user LIKE '%$eshow%' ORDER BY id DESC LIMIT $limitvalue, $pp");
}elseif($scope==6){
	$sql = mysql_query("SELECT * FROM users WHERE level = '$level' ORDER BY id DESC LIMIT $limitvalue, $pp");
}elseif($scope==3){
	$sql = mysql_query("SELECT * FROM users WHERE post >= '$sdate' and post <= '$fdate' ORDER BY id DESC LIMIT $limitvalue, $pp");
}elseif($scope==5){
	$sql = mysql_query("SELECT * FROM users WHERE birth >= '$sdate' and birth <= '$fdate' ORDER BY id DESC LIMIT $limitvalue, $pp");
}else{
	$sql = mysql_query("SELECT * FROM users ORDER BY time DESC LIMIT $limitvalue, $pp");
}
$total = mysql_num_rows($sql);
	
//******************************************************************
?>
<br />
<br />
<form id="form1" name="form1" method="post" action="?q=user-add">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="button" type="submit" name="button" id="button" value="ایجاد کاربر جدید" />
</form>

<br />
<br />
<form id="fshow" name="fshow" method="post" action="?q=user-manage">
<input name="nrow" type="hidden" value="<?=$row?>" />
<input name="jday" id="jday" type="hidden" value="<?=$jday?>" />
<input name="jmonth" id="jmonth" type="hidden" value="<?=$jmonth?>" />
<input name="jyear" id="jyear" type="hidden" value="<?=$jyear?>" />
&nbsp;&nbsp;نمایش بر اساس&nbsp;&nbsp;
<select onchange=" ch_fields()" name="scope" id="scope">
<? if(empty($scope) || $scope==1){?>
  <option value="1" selected="selected">نام کاربری</option>
  <option value="2">نام و نام خانوادگی</option>
  <option value="6">سطح دسترسی</option>
  <option value="3">تاریخ ثبت نام</option>
  <option value="5">تاریخ تولد</option>
  <? } else if($scope==2){?>
  <option value="1">نام کاربری</option>
  <option value="2" selected="selected">نام و نام خانوادگی</option>
  <option value="6">سطح دسترسی</option>
  <option value="3">تاریخ ثبت نام</option>
  <option value="5">تاریخ تولد</option>
  <? } else if($scope==6){?>
  <option value="1">نام کاربری</option>
  <option value="2">نام و نام خانوادگی</option>
  <option value="6" selected="selected">سطح دسترسی</option>
  <option value="3">تاریخ ثبت نام</option>
  <option value="5">تاریخ تولد</option>
    <? } else if($scope==3){?>
  <option value="1">نام کاربری</option>
  <option value="2">نام و نام خانوادگی</option>
  <option value="6">سطح دسترسی</option>
  <option value="3" selected="selected">تاریخ ثبت نام</option>
  <option value="5">تاریخ تولد</option>
    <? } else if($scope==5){?>
  <option value="1">نام کاربری</option>
  <option value="2">نام و نام خانوادگی</option>
  <option value="6">سطح دسترسی</option>
  <option value="3">تاریخ ثبت نام</option>
  <option value="5" selected="selected">تاریخ تولد</option>
  <? }?>
</select>
&nbsp;
<span id="field">

<? if ($scope==6) {?>
<select class="select" name="level" id="level" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
  <option value="0" <? if(!$level) echo 'selected="selected"' ;?> >کاربر عادی</option>
  <option value="1" <? if($level) echo 'selected="selected"'; ?> >مدیریت</option>
</select>
<? } elseif ($scope==3 || $scope==5){?>
<script language="javascript" type="text/javascript">document.getElementById("field").innerHTML=makedate(<?=$p_day1.",".$p_month1.",".$p_year1.",".$p_day2.",".$p_month2.",".$p_year2 ?>);</script>
<? } else{ ?>
<input type="text" name="eshow" id="eshow" class="input" value="<?=$eshow?>" />
<? }?>
</span>
&nbsp;
<input name="sdate" id="jmonth" type="hidden" value="<?=$sdate?>" />
<input name="fdate" id="jyear" type="hidden" value="<?=$fdate?>" />
<input name="submit" type="submit" class="button" id="submit" style="width:70px" value="نمایش" />
</form>
<br />

<p style="color:#996600;">&nbsp;&nbsp;&nbsp;تعداد موارد یافت شده : <strong><?=$totalp?></strong></p><br /><table width="674" align="center" cellpadding="0" cellspacing="0" dir="ltr" class="mtable">
  <tr class="mtitle">
    <td width="60" height="25" align="center" bgcolor="#CCCCCC">حذف</td>
    <td width="60" align="center" bgcolor="#CCCCCC">ویرایش</td>
    <td width="60" align="center" bgcolor="#CCCCCC">وضعیت</td>
    <td width="100" align="center" bgcolor="#CCCCCC">تاریخ عضویت</td>
    <td width="110" align="center" bgcolor="#CCCCCC">سطح دسترسی</td>
    <td width="246" align="center" bgcolor="#CCCCCC">نام کاربری</td>
    <td width="36" align="center" bgcolor="#CCCCCC">رديف</td>
  </tr>
  <?
		$row=1;
while ($record = mysql_fetch_object($sql))
{
		if($total != 0)
		{
		if(fmod($total,2.0)==1){
?>
  <tr class="odd">
    <td height="25" align="center">
      <?
	 if($eshow){
    echo "<a href='?q=user-manage&amp;del=$record->id&eshow=$eshow&scope=$scope&page=$page' ";
	}elseif($scope==6){
    echo "<a href='?q=user-manage&amp;del=$record->id&level=$level&scope=$scope&page=$page' ";
	}elseif($scope==3 || $scope==5){
    echo "<a href='?q=user-manage&amp;del=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page' ";
	}elseif($page){
   echo  "<a href='?q=user-manage&amp;del=$record->id&page=$page' ";
   }else{
   echo  "<a href='?q=user-manage&amp;del=$record->id' ";
	  }
	echo  "onclick=\"return confirm('آيا مطمئن به حذف کاربر ($record->user) مي باشيد ؟')\"> ";
	?>
    <img src="./layout/delete.gif" width="16" height="16" alt="حذف" title="حذف" border="0" /></a></td>
    <td height="25" align="center">
        <?
	if($eshow){
    echo "<a href='?q=user-show&amp;show=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==6){
    echo "<a href='?q=user-show&amp;show=$record->id&level=$level&scope=$scope&page=$page'>";
	}elseif($scope==3 || $scope==5){
    echo "<a href='?q=user-show&amp;show=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=user-show&amp;show=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=user-show&amp;show=$record->id'>";
	  }
	?>
    <img src="./layout/pedit.gif" alt="ویرایش" title="ویرایش" width="16" height="16" border="0" /></a></td>
    <td height="25" align="center"><?
	if($eshow){
    echo "<a href='?q=user-manage&amp;status=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==6){
    echo "<a href='?q=user-manage&amp;status=$record->id&level=$level&scope=$scope&page=$page'>";
	}elseif($scope==3 || $scope==5){
    echo "<a href='?q=user-manage&amp;status=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=user-manage&amp;status=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=user-manage&amp;status=$record->id'>";
	  }
	if ($record->status == 1){
   echo "<img src='./layout/enabled.gif' alt='فعال' title='فعال' width='16' height='16' border='0' />";
    }
	else{
	echo "<img src='./layout/disabled.gif' alt='غير فعال' title='غير فعال' width='16' height='16' border='0' />";
    }
	?>      </a></td>
    <td height="25" align="center"><? $jSend  = explode('@',zone("$record->time",$timezone));
			list( $gyear, $gmonth, $gday ) = explode('/',$jSend[0]);
			list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
			echo Ct($jyear) ."/". Ct($jmonth) ."/". Ct($jday);?></td>
    <td height="25" align="center"><?
	if ($record->level == 1){
   echo "مدیریت";
    }
	else{
	echo "کاربر عادی";
    }
	?></td>
    <td align="center">
    <?
	echo "$record->user";
	 ?></td>
    <td align="center"><?=Ct($row);?></td>
  </tr>
  <?
  }
  else{
  ?>
  <tr class="even">
    <td height="25" align="center"><?
	 if($eshow){
    echo "<a href='?q=user-manage&amp;del=$record->id&eshow=$eshow&scope=$scope&page=$page' ";
	}elseif($scope==6){
    echo "<a href='?q=user-manage&amp;del=$record->id&level=$level&scope=$scope&page=$page' ";
	}elseif($scope==3 || $scope==5){
    echo "<a href='?q=user-manage&amp;del=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page' ";
	}elseif($page){
   echo  "<a href='?q=user-manage&amp;del=$record->id&page=$page' ";
   }else{
   echo  "<a href='?q=user-manage&amp;del=$record->id' ";
	  }
	echo  "onclick=\"return confirm('آيا مطمئن به حذف کاربر ($record->user) مي باشيد ؟')\"> ";
	?>      <img src="./layout/delete.gif" width="16" height="16" alt="حذف" title="حذف" border="0" /></a></td>
    <td height="25" align="center"><?
	if($eshow){
    echo "<a href='?q=user-show&amp;show=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==6){
    echo "<a href='?q=user-show&amp;show=$record->id&level=$level&scope=$scope&page=$page'>";
	}elseif($scope==3 || $scope==5){
    echo "<a href='?q=user-show&amp;show=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=user-show&amp;show=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=user-show&amp;show=$record->id'>";
	  }
	?>      <img src="./layout/pedit.gif" alt="ویرایش" title="ویرایش" width="16" height="16" border="0" /></a></td>
    <td height="25" align="center"><?
	if($eshow){
    echo "<a href='?q=user-manage&amp;status=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==6){
    echo "<a href='?q=user-manage&amp;status=$record->id&level=$level&scope=$scope&page=$page'>";
	}elseif($scope==3 || $scope==5){
    echo "<a href='?q=user-manage&amp;status=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=user-manage&amp;status=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=user-manage&amp;status=$record->id'>";
	  }
	if ($record->status == 1){
   echo "<img src='./layout/enabled.gif' alt='فعال' title='فعال' width='16' height='16' border='0' />";
    }
	else{
	echo "<img src='./layout/disabled.gif' alt='غير فعال' title='غير فعال' width='16' height='16' border='0' />";
    }
	?>      </a></td>
    <td height="25" align="center"><? $jSend  = explode('@',zone("$record->time",$timezone));
			list( $gyear, $gmonth, $gday ) = explode('/',$jSend[0]);
			list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
			echo Ct($jyear) ."/". Ct($jmonth) ."/". Ct($jday);?></td>
    <td height="25" align="center"><?
	if ($record->level == 1){
   echo "مدیریت";
    }
	else{
	echo "کاربر عادی";
    }
	?></td>
    <td align="center"><?
	echo "$record->user";
	 ?></td>
    <td align="center"><?=Ct($row);?></td>
  </tr>
  <?
  }
	}	
	$total--;
	$row++;
}	
?>
</table>
<br />
        <?
if ($numofpages > 1){
echo "<table dir='ltr' border='0' height='21' cellpadding='0' align='center'><tr>";
per_page("?q=user-manage&amp;page=%page", 8);
echo "</tr></table>"; 
}
?> 