<?
if(isset($_POST['edit_info']) && $_POST['edit_info']=='1')
	{
$address=$_POST['address'];
$address2=$_POST['address2'];
$tel1=$_POST['tel1'];
$tel2=$_POST['tel2'];
$tel3=$_POST['tel3'];
$fax1=$_POST['fax1'];
$fax2=$_POST['fax2'];
$mobile1=$_POST['mobile1'];
$mobile2=$_POST['mobile2'];
$postbox=$_POST['postbox'];
$web=$_POST['web'];
$mail=$_POST['mail'];

	mysql_query ("UPDATE information SET address='$address',address2='$address2',tel1='$tel1' ,tel2='$tel2' ,tel3='$tel3' ,fax1='$fax1' ,fax2='$fax2' ,postbox='$postbox' ,mobile1='$mobile1' ,mobile2='$mobile2', web='$web', mail='$mail' WHERE id='".$_POST['id']."'");
	?>
    	<br />
		<div id="notice" align="center">
        <p  class="success">اطلاعات تماس با موفقیت ویرایش گردید</p>
		</div>
    <?
	} 
	$sql = "SELECT * FROM information ORDER BY id DESC";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
?>
<form class="form" name="pro" action="" method="post" enctype="multipart/form-data">
  <br/>
  <table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="800">
    <tr class="tr">
      <td height="15" colspan="4" valign="top" class="td"><input type="hidden" value="<?="$record->id";?>" name="id" /></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">آدرس&nbsp;&nbsp;</td>
      <td width="638" height="25" colspan="3" class="td"><input name="address" type="text" class="input" id="address" value="<?="$record->address";?>" size="80" maxlength="255" />      </td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">Address&nbsp;&nbsp;</td>
      <td width="638" height="25" colspan="3" class="td"><input name="address2" type="text" class="input" id="address2" value="<?="$record->address2";?>" size="80" maxlength="255" />      </td>
    </tr>
        <tr class="tr">
      <td width="150" height="2" align="left" class="td"></td>
      <td height="2" colspan="3" class="td"></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">تلفن&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="tel1" type="text" class="input" id="tel1" value="<?=$record->tel1;?>" size="15" maxlength="20" style="direction:ltr;text-align:left;"/></td>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">Tel&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="tel2" type="text" class="input" id="tel2" value="<?=$record->tel2;?>" size="15" maxlength="20" style="direction:ltr;text-align:left;"/></td>
    </tr>
        <tr class="tr">
      <td width="150" height="2" align="left" class="td"></td>
      <td height="2" colspan="3" class="td"></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">همراه&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="mobile1" type="text" class="input" id="mobile1" value="<?="$record->mobile1";?>" size="15" maxlength="15" style="direction:ltr;text-align:left;"/></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">Mobile&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="mobile2" type="text" class="input" id="mobile2" value="<?="$record->mobile2";?>" size="15" maxlength="15" style="direction:ltr;text-align:left;"/></td>
    </tr>
        <tr class="tr">
      <td width="150" height="2" align="left" class="td"></td>
      <td height="2" colspan="3" class="td"></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">دورنگار&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="fax1" type="text" class="input" id="fax1" value="<?=$record->fax1;?>" size="15" maxlength="15" style="direction:ltr;text-align:left;"/></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">Fax&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="fax2" type="text" class="input" id="fax2" value="<?=$record->fax2;?>" size="15" maxlength="15" style="direction:ltr;text-align:left;"/></td>
    </tr>
        <tr class="tr">
      <td width="150" height="2" align="left" class="td"></td>
      <td height="2" colspan="3" class="td"></td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">وب سایت&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="web" type="text" class="input" id="web" value="<?="$record->web";?>" size="30" maxlength="50" style="direction:ltr;text-align:left;"/>      </td>
    </tr>
    <tr class="tr">
      <td width="150" height="25" align="left" class="td">پست الکترونیک&nbsp;&nbsp;</td>
      <td height="25" colspan="3" class="td"><input name="mail" type="text" class="input" id="mail" value="<?="$record->mail";?>" size="30" maxlength="50" style="direction:ltr;text-align:left;"/>      </td>
    </tr>
    <tr class="tr">
      <td width="150" height="42" align="left" class="td"></td>
<td class="td" width="638">
        <input type="hidden" value="1" name="edit_info" />
  <input name="submit" type="submit" class="button" id="submit" style="width:85px" value="ویرایش" onclick="return confirm('آیا اطلاعات تماس ویرایش گردد ؟')" />
      <input style="width:50px" name="reset" type="reset" class="button" value="مجدد" /></td>
    </tr>
  </table>
  <br/>
</form>
