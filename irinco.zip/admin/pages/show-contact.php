<?
	$eshow = $_GET['eshow'];
	$scope = $_GET['scope'];
	$page = $_GET['page'];
	$sdate = $_GET['sdate'];
	$fdate = $_GET['fdate'];
	if($eshow){
	$location="location.href='?q=inbox&eshow=$eshow&scope=$scope&page=$page'";
	$qs="&eshow=$eshow&scope=$scope&page=$page";
	}elseif($scope==3){
	$location="location.href='?q=inbox&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'";
	$qs="&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page";
    }elseif($page){
	$location="location.href='?q=inbox&page=$page'";
	$qs="&page=$page";
	}else{
	$location="location.href='?q=inbox'";
	$qs="";
	}
	if(isset($_GET['del']) && $_GET['del'] != 0){
	$id=$_GET['del'];
	mysql_query("DELETE FROM contacts WHERE id='$id'"); 
	$_GET['del'] = 0;
	echo "<script language=\"javascript\" >".$location."</script>";
	}
		$query = "SELECT * FROM contacts WHERE id = '".$_GET['show']."'"; 
		$result = mysql_query($query);
		$record = mysql_fetch_object($result);
		
	?>
<p>
  <input type="hidden" name="id" value="<? echo "$record->id";?>" />
  <input type="hidden" name="time" value="<? echo "$record->time";?>" />
</p>
<br />
<table width="800" border="0" align="center" cellpadding="0" cellspacing="4" dir="rtl">
			<tr >
				<td width="180" align="left">
			  <label for="name"><strong>نام و نام خانوادگی :&nbsp;&nbsp;</strong></label></td>
<td height="25"> 
					<? echo "$record->name "." $record->family";?>		  </td>
		  </tr>
			<tr >
				<td width="180" align="left">
			  <label for="name"><strong>شماره تماس :&nbsp;&nbsp;</strong></label></td>
<td height="25"> 
					<? echo "$record->phone";?>		  </td>
		  </tr>
			<tr >
				<td width="180" align="left">
			  <label for="name"><strong>پست الکترونیکی :&nbsp;&nbsp;</strong></label></td>
<td height="25"> 
					<? echo "$record->email";?>		  </td>
		  </tr>
						<tr >
				<td width="180" height="153" align="left" >
				  <label for="name"><strong>محتوای پیغام :&nbsp;&nbsp;</strong></label></td>
				<td colspan="2" rowspan="2" ><textarea name="textarea" cols="50" rows="10" onkeypress="return false;"><? echo "$record->message";?></textarea></td>
			</tr>
						<tr >
						  <td height="19" align="left" >&nbsp;</td>
  </tr>
						
			<tr >
			  <td width="180" height="37" >&nbsp;</td>
              
			  <td ><input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" /><input name="delete" onclick="return delfunc('?q=show-contact&del=<?=$record->id;?><?=$qs;?>','پیغام')" type="button" class="button" id="delete" style="width:70px" value="حذف" /></td>
		    </tr>
</table>
<br/>
</form>
<? mysql_query("UPDATE contacts SET visited='1' WHERE id='".$_GET['show']."'");?>