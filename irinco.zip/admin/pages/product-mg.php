<?	

	if($_POST['select']){
	$select = $_POST['select'];
	}else if($_GET['select']){
	$select = $_GET['select'];
	}
//**************************************************************************
function per_page($link, $offset,$select) 
{
	global $numofpages, $page;
	
	$pagesstart = round($page-$offset);
	$pagesend = round($page+$offset);
	
	if ($page != "1" && round($numofpages) != "0") 
	{
		if($select){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=product-mg&amp;select='.$select.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}else{
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=product-mg&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}
		
		echo str_replace("%page", round($page-1), '<td class="bt_prev" align="center" width="24" height="21"><a href="'.$link.'" title=" صفحه قبلی" style="text-decoration: none;" >&nbsp;&nbsp;<&nbsp;&nbsp;</a></td>');
	}
	else{
			echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;<<&nbsp;</td>';
		echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;<&nbsp;&nbsp;</td>';
	}
	
	
	for($i = 1; $i <= $numofpages; $i++) 
	{ 
		if ($pagesstart <= $i && $pagesend >= $i) 
		{
			if ($i == $page) 
			{
				echo "<td class='curpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
			}
			else 
			{
				echo str_replace("%page", "$i", '<td class="numpage" valign="middle" width="24" height="21"><a href="'.$link.'" style="text-decoration: none;" >&nbsp;&nbsp;'.Ct($i).'&nbsp;&nbsp;</a></td>');	
			}
		}
	}
	if (round($numofpages) == "0") 
	{
		echo "<td class='numpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
	}
	
	if ($page != round($numofpages) && round($numofpages) != "0") 
	{
		echo str_replace("%page", round($page+1), '<td class="bt_next" align="center" width="24" height="21"><a href="'.$link.'" title="صفحه بعدی" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>');
		if($select){
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=product-mg&amp;select='.$select.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>';
		}else{
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=product-mg&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}
	}else{
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;>&nbsp;&nbsp;</td>';
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;>>&nbsp;</td>';
	}
}
$pp = "20";
//******************************************************
	if(isset($_POST['add_products']) && $_POST['add_products']=='1' && (strlen($_POST['name']) > 0 ))
{
$name=$_POST['name'];
$ename=$_POST['ename'];
$cat=$_POST['cat'];
$comment=$_POST['comment'];
$ecomment=$_POST['comment2'];
$status=$_POST['status'];
unset($totalr);
$resultr=mysql_query("SELECT Sid FROM products WHERE Sname = '$name' and Scat ='$cat'");
$totalr = mysql_num_rows($resultr);
if(!$totalr){
	if(!is_dir("../images/products/".$cat))
	mkdir("../images/products/".$cat, 0755);
	
	if (strlen($_FILES['new_image']['name'])>1){
              $imagename = $_FILES['new_image']['name'];
              $source = $_FILES['new_image']['tmp_name'];
              $target = "../images/products/".$cat."/".$imagename;
              move_uploaded_file($source, $target);
              $save = "../images/products/".$cat."/" . $imagename; //This is the new file you saving
              $file = "../images/products/".$cat."/" . $imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
			  
              $modwidth = 197;
			  $modheight = 160;
 
           //   $diff = $height / $modheight;

            //  $modwidth = $width / $diff;
			  
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 
			  
			$file = $imagename;
			//echo $file;
        
        }
	$sql = "SELECT Sorder FROM products WHERE Scat='$cat' ORDER BY Sorder DESC";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	$order=$record->Sorder+1;

	$test = mysql_query ("INSERT INTO products (Sorder,Sname,Sename,Saddpic,Scomment,Secomment,Scat,Sstatus) VALUES ('$order','$name','$ename','$file','$comment','$ecomment','$cat','$status')");

	unset($_POST['name']);
	?>	
    	<br />
		<div id="notice" align="center">
        <p  class="success">محصول <span style="color:#029125"><?=$name?></span> با موفقیت ثبت گردید</p>
</div>
        <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
	   }
}else{?>
	<div id="notice" align="center">
		</div>
       <?
}

if(isset($_GET['del']) && $_GET['del'] != 0){

$del=$_GET['del'];
$resultc=mysql_query("SELECT * FROM products WHERE Sid ='$del'");
	$numc = mysql_num_rows($resultc);
	if($numc>0){
$recordc = mysql_fetch_object($resultc);
$idc=$recordc->Sid;
$sorder=$recordc->Sorder;
//*******************************
$resulto=mysql_query("SELECT * FROM products WHERE Sorder > '$sorder'");
	$numo = mysql_num_rows($resulto);
	if($numo>0){
while($recordo = mysql_fetch_object($resulto)){
	$oid=$recordo->Sid;
	$neworder=$recordo->Sorder - 1;
	mysql_query ("UPDATE products SET Sorder='$neworder' WHERE Sid ='$oid'");
}
}
//*******************************

mysql_query("DELETE FROM products WHERE Sid='$del'");
unlink("../images/products/".$recordc->Scat."/".$recordc->Saddpic);
?>
<br />
		<div id="notice" align="center">
        <p  class="success">محصول <span style="color:#029125"><?=$recordc->Sname?></span> با موفقیت حذف گردید</p>
</div>
<?
}
$_GET['del'] = 0;
}
if(isset($_GET['order']) && $_GET['order'] != 0){

	$dirt=$_GET['dirt'];
	$id=$_GET['order'];
	$resulto=mysql_query("SELECT Sid FROM products");
	$recordo = mysql_num_rows($resulto);
	if(!($recordo==1)){
	if ($dirt == "up" && $id > 0){
	$pid= $id - 1;
	//echo "up";
	}elseif($dirt == "down" && $id > 0){
	$pid= $id + 1;
	//echo "down";
	}
	mysql_query ("UPDATE products SET Sorder='0' WHERE Sorder='$pid'");
	mysql_query ("UPDATE products SET Sorder='$pid' WHERE Sorder='$id'");
	mysql_query ("UPDATE products SET Sorder='$id' WHERE Sorder='0'");
	}
$_GET['order'] = 0;
}

if(isset($_GET['status']) && $_GET['status'] != 0){

	$id=$_GET['status'];
	
	$sql = "SELECT * FROM products WHERE Sid='$id'";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	if($record->Sstatus == 1){
	mysql_query ("UPDATE products SET Sstatus='0' WHERE Sid='$id'");
	}
	if($record->Sstatus == 0){
	mysql_query ("UPDATE products SET Sstatus='1' WHERE Sid='$id'");
	}
	
$_GET['status'] = 0;	
}
	$id=1;
?>

<form class="form" name="products" action="?q=product-mg" method="post" enctype="multipart/form-data" >
<br/>
<table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="800">
<tr class="tr">
				<td height="15" colspan="3" valign="top" class="td"></td>
			</tr>
            			<tr class="tr">
				<td width="150" height="25" align="left" class="td">
			  انتخاب دسته&nbsp;</td>
<td height="25" colspan="2" class="td">
					<select name="cat">
                <option value="" selected="selected">----</option>
                       <? 
			$cat_query = "SELECT * FROM tbcat WHERE Cstatus='1' ORDER BY Corder ASC";
			$result = mysql_query($cat_query);
			while ($recordc = mysql_fetch_object($result)){
			?>
                <option value="<?="$recordc->Cid";?>">
                 <?="$recordc->Cname";?>
                </option>
                <?
				}
				?>
		      </select>&nbsp;</td>
			</tr>
<tr class="tr">
				<td width="150" height="25" align="left" class="td">
			  عنوان محصول (فارسی)&nbsp;</td>
<td height="25" colspan="2" class="td">
					<input name="name" type="text" class="input" id="name" size="30" />			  </td>
			</tr>    
<tr class="tr">
				<td width="150" height="25" align="left" class="td">
	  عنوان محصول (لاتین)&nbsp;</td>
<td height="25" colspan="2" class="td">
			  <input name="ename" type="text" class="input" id="ename" size="30" />			  </td>
			</tr>    
            			<tr class="tr">
				<td width="150" height="25" align="left" class="td">
			  آدرس محصول&nbsp;</td>
<td height="25" colspan="2" class="td"><input name="new_image"  type="file" class="fileUpload" id="new_image"  size="35" />
<input type="hidden" id="products_preview" name="products_preview" value="" /></td>
			</tr>
			<tr class="tr">
				<td width="150" align="left" class="td">
			 توضيح محصول (فارسی)&nbsp;</td>
			  <td colspan="2" valign="top" class="td"><textarea id="comment" dir="rtl" name="comment" cols="60" rows="10"></textarea></td>
		  </tr>
			<tr class="tr">
				<td width="150" align="left" class="td">
			 توضيح محصول (لاتین)&nbsp;</td>
			  <td colspan="2" valign="top" class="td"><textarea id="comment2" dir="rtl" name="comment2" cols="60" rows="10"></textarea></td>
		  </tr>
			<tr class="tr">
			  <td width="150" height="25" align="left" class="td">
			 وضعیت&nbsp;&nbsp;</td>
<td height="25" colspan="2" class="td">
			      <input name="status" type="radio" id="status_0" value="1" checked="checked" />
			      فعال&nbsp;
			    <input name="status" type="radio" id="status_1" value="0" />
غير فعال</td>
			  </tr>
			<tr class="tr">
				<td width="150" height="50" align="left" class="td"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td class="td" width="327" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
		      <td class="td" width="307" ></td>
	</tr>
<tr class="tr">
			  <td width="150" height="48" class="td">&nbsp;</td>
<td colspan="2" class="td">
		<input type="hidden" value="0" name="edit_products" />
        <input type="hidden" value="1" name="add_products" />
		<input name="button" type="submit" class="button" id="button" style="width:85px" value="ثبت محصول" onclick="return checkForm_products();"  />
		<input style="width:50px" name="reset" type="reset" class="button" value="مجدد" /></td>
</tr>
	</table>
 <p>&nbsp;</p><p>&nbsp;</p>
</form>
	<fieldset dir="rtl" class="fieldset">
		<legend class="legend">&nbsp;&nbsp;لیست تصاویر موجود&nbsp;&nbsp;</legend>
	<br/>
<a name="productlist"></a>
<table width="710" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="710">
<form  name="cat" action="#productlist" method="post" >
		<p>&nbsp;&nbsp;&nbsp;&nbsp;نمایش محصولات موجود در دسته&nbsp;&nbsp;
      <? if(!($select)){
	  ?>
      <select size="1" name="select" id="select" onchange="document.cat.submit()" >
        <option value="a" selected="selected">همه</option>
        <? 
			$sql_sel = "SELECT * FROM tbcat WHERE Cstatus='1' ORDER BY Corder ASC";
			$result_sel = mysql_query($sql_sel); 
			while ($records = mysql_fetch_object($result_sel)) 
				{
			?>
        <option value="<?="$records->Cid";?>">
        <?="$records->Cname";?>
        </option>
        <?
				}
				?>
      </select>
      <?
			  }
			  else{
			  ?>
        <select size="1" name="select" id="select" onchange="document.cat.submit()">
              <option value="a">همه</option>
          <? 
			$sql_sel = "SELECT * FROM  tbcat WHERE Cstatus='1' ORDER BY Corder ASC";
			$result_sel = mysql_query($sql_sel); 
			while ($records = mysql_fetch_object($result_sel)) 
				{
			?>
          <? 
		   if($records->Cid == $select){
		  ?>
          <option value="<?=$records->Cid;?>" selected="selected">
          <?=$records->Cname;?></option>
          <?
			}
			else{
			?>
          <option value="<?=$records->Cid;?>">
          <?=$records->Cname;?></option>
          <?
		  }
				}
				?>
        </select>
              <?  
			  }
			  ?>
		  <br/>
        </p>
    </form>
    </td>
  </tr>
    </table>
<br />
 <?
  //******************************************************
  if(isset($select) && (strlen($select) > 0) && $select!="a" ){
	$result = mysql_query("SELECT * FROM products WHERE Scat='$select' ORDER BY Scat , Sorder ASC"); 
	$totalp = mysql_num_rows($result);
}else{
	$result = mysql_query("SELECT * FROM products ORDER BY Scat , Scat ASC"); 
	$totalp = mysql_num_rows($result);
}

//******************************************************************
$numofpages = ceil($totalp / $pp); 
if (!isset($_GET['page']))
{ 
	$page = 1; 
} 
else 
{ 
	$page = $_GET['page']; 
} 
$limitvalue = $page * $pp - ($pp);

  if(isset($select) && (strlen($select) > 0) && $select!="a" ){

   	$result = mysql_query("SELECT * FROM products WHERE Scat='$select' ORDER BY Scat , Sorder ASC LIMIT $limitvalue, $pp"); 
	$total = mysql_num_rows($result);
}else{
$result = mysql_query("SELECT * FROM products ORDER BY Scat , Sorder ASC LIMIT $limitvalue, $pp"); 
	$total = mysql_num_rows($result);
}
	$numofrow = ceil($total / 4); 
?>
<table style="direction:ltr;" width="690" border="0" align="center" cellpadding="0" cellspacing="0">
              <?
  while ($numofrow > 0) {
	?>
              <tr>
                <td width="30" height="19">&nbsp;</td>
                <td colspan="2" valign="top">
                <?
		if($total>0){
		  $record = mysql_fetch_object($result);
		?>
                <table class="pics" width="147" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" rowspan="2"></td>
                    <td height="15" colspan="3"></td>
                    <td width="14" rowspan="2">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="3" align="center" valign="top">
<img src="../images/products/<?=$record->Scat?>/<?=$record->Saddpic?>" alt="<?=$record->Sname?>" width="120" height="97" border='0' title="<?=$record->Sname?>" /></td>
                  </tr>
                  
                  <tr>
                    <td height="38" align="center">&nbsp;</td>
              <td width="53" align="center"><?
	if($page){
   echo  "<a href='?q=product-mg&del=$record->Sid&amp;show=$id&amp;select=$select&page=$page'";
   }else{
   echo  "<a href='?q=product-mg&del=$record->Sid&amp;select=$select&show=$id'";
	  }
	echo  "onclick=\"return confirm('آیا محصول ($record->Sname) حذف شود ؟')\"> ";
	?>
                        حذف</a></td>
                    <td width="2" align="center" style="background:url(/khatam/images/sp_pic.jpg) center no-repeat;"></td>
                    <td width="65" align="center"><?
	if($page){
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;show=$id&amp;select=$select&cat=$record->Scat&page=$page'>";
   }else{
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;select=$select&cat=$record->Scat&show=$id'>";
	  }
	?>
                        ویرایش</a></td>
                    <td align="center">&nbsp;</td>
                  </tr>
                  <tr>
                  <td rowspan="2">&nbsp;</td>
                  <td height="18" colspan="3" align="center" valign="top" bgcolor="#FFFFFF"><table width="120" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td align="center"><?=$record->Sname?></td>
                    </tr>
                  </table></td>
                  <td rowspan="2">&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="15" colspan="3"></td>
                  </tr>
                </table>
                <?
		$total --;
		}
		?>                </td>
                <td width="30" align="right" valign="top">&nbsp;</td>
                <td width="147" valign="top"><?
		if($total>0){
		  $record = mysql_fetch_object($result);
		?>
                  <table class="pics" width="147" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="13" rowspan="2"></td>
                      <td height="15" colspan="3"></td>
                      <td width="14" rowspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="3" align="center" valign="top"><img src="../images/products/<?=$record->Scat?>/<?=$record->Saddpic?>" alt="<?=$record->Sname?>" width="120" height="97" border='0' title="<?=$record->Sname?>" /></td>
                    </tr>
                    <tr>
                      <td height="38" align="center">&nbsp;</td>
                      <td width="53" align="center"><?
	if($page){
   echo  "<a href='?q=product-mg&del=$record->Sid&amp;show=$id&amp;select=$select&page=$page'";
   }else{
   echo  "<a href='?q=product-mg&del=$record->Sid&amp;select=$select&show=$id'";
	  }
	echo  "onclick=\"return confirm('آیا محصول ($record->Sname) حذف شود ؟')\"> ";
	?>
                        حذف</a></td>
                      <td width="2" align="center" style="background:url(/khatam/images/sp_pic.jpg) center no-repeat;"></td>
                      <td width="65" align="center"><?
	if($page){
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;show=$id&amp;select=$select&cat=$record->Scat&page=$page'>";
   }else{
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;select=$select&cat=$record->Scat&show=$id'>";
	  }
	?>
                        ویرایش</a></td>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr>
                      <td rowspan="2">&nbsp;</td>
                      <td height="18" colspan="3" align="center" valign="top" bgcolor="#FFFFFF"><table width="120" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="center"><?=$record->Sname?></td>
                          </tr>
                      </table></td>
                      <td rowspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="15" colspan="3"></td>
                    </tr>
                  </table>
                <?
		$total --;
		}
		?></td>
                <td width="30" align="right" valign="top">&nbsp;</td>
                <td width="147" valign="top"><?
		if($total>0){
		  $record = mysql_fetch_object($result);
		?>
                  <table class="pics" width="147" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="13" rowspan="2"></td>
                      <td height="15" colspan="3"></td>
                      <td width="14" rowspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="3" align="center" valign="top"><img src="../images/products/<?=$record->Scat?>/<?=$record->Saddpic?>" alt="<?=$record->Sname?>" width="120" height="97" border='0' title="<?=$record->Sname?>" /></td>
                    </tr>
                    <tr>
                      <td height="38" align="center">&nbsp;</td>
                      <td width="53" align="center"><?
	if($page){
   echo  "<a href='?q=products&del=$record->Sid&amp;show=$id&amp;select=$select&page=$page'";
   }else{
   echo  "<a href='?q=products&del=$record->Sid&amp;select=$select&show=$id'";
	  }
	echo  "onclick=\"return confirm('آیا محصول ($record->Sname) حذف شود ؟')\"> ";
	?>
                        حذف</a></td>
                      <td width="2" align="center" style="background:url(/khatam/images/sp_pic.jpg) center no-repeat;"></td>
                      <td width="65" align="center"><?
	if($page){
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;show=$id&amp;select=$select&cat=$record->Scat&page=$page'>";
   }else{
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;select=$select&cat=$record->Scat&show=$id'>";
	  }
	?>
                        ویرایش</a></td>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr>
                      <td rowspan="2">&nbsp;</td>
                      <td height="18" colspan="3" align="center" valign="top" bgcolor="#FFFFFF"><table width="120" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="center"><?=$record->Sname?></td>
                          </tr>
                      </table></td>
                      <td rowspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="15" colspan="3"></td>
                    </tr>
                  </table>
                <?
		$total --;
		}
		?></td>
                <td width="30">&nbsp;</td>
                <td width="147" valign="top"><?
		if($total>0){
		  $record = mysql_fetch_object($result);
		?>
                  <table class="pics" width="147" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="13" rowspan="2"></td>
                      <td height="15" colspan="3"></td>
                      <td width="14" rowspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td colspan="3" align="center" valign="top"><img src="../images/products/<?=$record->Scat?>/<?=$record->Saddpic?>" alt="<?=$record->Sname?>" width="120" height="97" border='0' title="<?=$record->Sname?>" /></td>
                    </tr>
                    <tr>
                      <td height="38" align="center">&nbsp;</td>
                      <td width="53" align="center"><?
	if($page){
   echo  "<a href='?q=product-mg&del=$record->Sid&amp;show=$id&amp;select=$select&page=$page'";
   }else{
   echo  "<a href='?q=product-mg&del=$record->Sid&amp;select=$select&show=$id'";
	  }
	echo  "onclick=\"return confirm('آیا محصول ($record->Sname) حذف شود ؟')\"> ";
	?>
                        حذف</a></td>
                      <td width="2" align="center" style="background:url(/khatam/images/sp_pic.jpg) center no-repeat;"></td>
                      <td width="65" align="center"><?
	if($page){
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;show=$id&amp;select=$select&cat=$record->Scat&page=$page'>";
   }else{
   echo  "<a href='?q=product-edit&amp;edit=$record->Sid&amp;select=$select&cat=$record->Scat&show=$id'>";
	  }
	?>
                        ویرایش</a></td>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr>
                      <td rowspan="2">&nbsp;</td>
                      <td height="18" colspan="3" align="center" valign="top" bgcolor="#FFFFFF"><table width="120" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="center"><?=$record->Sname?></td>
                          </tr>
                      </table></td>
                      <td rowspan="2">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="15" colspan="3"></td>
                    </tr>
                  </table>
                <?
		$total --;
		}
		?></td>
                <td width="30">&nbsp;</td>
              </tr>
              
              <tr>
                <td height="20" colspan="10">&nbsp;</td>
              </tr>
              <?
  $numofrow --;
  }
	?>
            </table>	
<br/>

<?
if ($numofpages > 1){
echo "<table dir='ltr' border='0' height='21' cellpadding='0' align='center'><tr>";
if($select){
per_page("?q=product-mg&amp;select=$select&amp;page=%page", 8 ,$select);
}else{
per_page("?q=product-mg&amp;page=%page", 8 ,$select);
}
echo "</tr></table>"; 
}	
	unset($_POST['select']);
	unset($_GET['select']);
	unset($select);
?> 
    <br />
        <br />
  </fieldset>
