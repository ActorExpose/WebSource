<?
		if($_POST['eshow']){
	$eshow = $_POST['eshow'];
	}else if($_GET['eshow']){
	$eshow = $_GET['eshow'];
	}
	
	if($_POST['p_day1']){
	$p_day1=$_POST['p_day1'];
	$p_month1=$_POST['p_month1'];
	$p_year1=$_POST['p_year1'];
	$p_day2=$_POST['p_day2'];
	$p_month2=$_POST['p_month2'];
	$p_year2=$_POST['p_year2'];
	}
	if($_GET['sdate']){
	$sdate=$_GET['sdate'];
	$p_day1=substr($sdate,6,2);
	if(substr($p_day1,0,1)==0)
	$p_day1=substr($p_day1,1,1);
	$p_month1=substr($sdate,4,2);
	if(substr($p_month1,0,1)==0)
	$p_month1=substr($p_month1,1,1);
	$p_year1=substr($sdate,0,4);
	}
	if($_GET['fdate']){
	$fdate=$_GET['fdate'];
	$p_day2=substr($fdate,6,2);
	if(substr($p_day2,0,1)==0)
	$p_day2=substr($p_day2,1,1);
	$p_month2=substr($fdate,4,2);
	if(substr($p_month2,0,1)==0)
	$p_month2=substr($p_month2,1,1);
	$p_year2=substr($fdate,0,4);
	}
	
	if(strlen($p_day1)<2)
	$s_day=0 .$p_day1;
	else
	$s_day=$p_day1;
	if(strlen($p_month1)<2)
	$s_month=0 .$p_month1;
	else
	$s_month=$p_month1;
	$s_year=$p_year1;
	if(strlen($p_day2)<2)
	$f_day=0 .$p_day2;
	else
	$f_day=$p_day2;
	if(strlen($p_month2)<2)
	$f_month=0 .$p_month2;
	else
	$f_month=$p_month2;
	$f_year=$p_year2;
	$sdate=$s_year.$s_month.$s_day;
	$fdate=$f_year.$f_month.$f_day;
 // echo $sdate."<br>";	
  //echo $fdate."<br>";
	if($_POST['scope']){
	$scope = $_POST['scope'];
	}else if ($_GET['scope']){
	$scope = $_GET['scope'];
	}
//*********************************************************
function per_page($link, $offset,$eshow,$scope,$sdate,$fdate) 
{
	global $numofpages, $page;
	
	$pagesstart = round($page-$offset);
	$pagesend = round($page+$offset);
	
	if ($page != "1" && round($numofpages) != "0") 
	{
		if($eshow){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=email-mg&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}elseif($scope==3){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=email-mg&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;sdate='.$sdate.'&amp;fdate='.$fdate.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}else{
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=email-mg&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}
		
		echo str_replace("%page", round($page-1), '<td class="bt_prev" align="center" width="24" height="21"><a href="'.$link.'" title=" صفحه قبلی" style="text-decoration: none;" >&nbsp;&nbsp;<&nbsp;&nbsp;</a></td>');
	}
	else{
			echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;<<&nbsp;</td>';
		echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;<&nbsp;&nbsp;</td>';
	}
	
	
	for($i = 1; $i <= $numofpages; $i++) 
	{ 
		if ($pagesstart <= $i && $pagesend >= $i) 
		{
			if ($i == $page) 
			{
				echo "<td class='curpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
			}
			else 
			{
				echo str_replace("%page", "$i", '<td class="numpage" valign="middle" width="24" height="21"><a href="'.$link.'" style="text-decoration: none;" >&nbsp;&nbsp;'.Ct($i).'&nbsp;&nbsp;</a></td>');	
			}
		}
	}
	if (round($numofpages) == "0") 
	{
		echo "<td class='numpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
	}
	
	if ($page != round($numofpages) && round($numofpages) != "0") 
	{
		echo str_replace("%page", round($page+1), '<td class="bt_next" align="center" width="24" height="21"><a href="'.$link.'" title="صفحه بعدی" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>');
		if($eshow){
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=email-mg&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>';
		}elseif($scope==3){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=email-mg&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;sdate='.$sdate.'&amp;fdate='.$fdate.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}else{
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=email-mg&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}
	}else{
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;>&nbsp;&nbsp;</td>';
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;>>&nbsp;</td>';
	}
}
$pp = "20";
//******************************************************
if(isset($_GET['del']) && $_GET['del'] != 0){

$id=$_GET['del'];
mysql_query("DELETE FROM emails WHERE Eid='$id'"); 

$_GET['del'] = 0;
}
if(isset($eshow) && strlen($eshow) > 0) {
	$sql = mysql_query("SELECT * FROM emails WHERE Eemail LIKE '%$eshow%' ORDER BY Etime DESC");
}elseif($scope==3){
	$sql = mysql_query("SELECT * FROM emails WHERE Epost >= '$sdate' and Epost <= '$fdate' ORDER BY Etime DESC");
}else{
	$sql = mysql_query("SELECT * FROM emails ORDER BY Etime DESC");
}
$totalp = mysql_num_rows($sql);
if(($totalp==0 && empty($eshow) && empty($scope))){
echo "<p>&nbsp;</p><p>&nbsp;</p><center style='font:bold 12px tahoma; color:#990033;'>هيج دوستی معرفی نشده است !</center>";
}
else{
//********************************************************
$numofpages = ceil($totalp / $pp); 
if (!isset($_GET['page']))
{ 
	$page = 1; 
} 
else 
{ 
	$page = $_GET['page']; 
	if($numofpages<$page)
	$page-=1;
} 
$limitvalue = $page * $pp - ($pp);

if(isset($eshow) && strlen($eshow) > 0) {
	$sql = mysql_query("SELECT * FROM emails WHERE Eemail LIKE '%$eshow%' ORDER BY Etime DESC LIMIT $limitvalue, $pp");
}elseif($scope==3){
	$sql = mysql_query("SELECT * FROM emails WHERE Epost >= '$sdate' and Epost <= '$fdate' ORDER BY Etime DESC LIMIT $limitvalue, $pp");
}else{
	$sql = mysql_query("SELECT * FROM emails ORDER BY Etime DESC LIMIT $limitvalue, $pp");
}
$total = mysql_num_rows($sql);
	
//******************************************************************
?>
<br />
<br />
<form id="fshow" name="fshow" method="post" action="?q=email-mg">
<input name="nrow" type="hidden" value="<?=$row?>" />
<input name="jday" id="jday" type="hidden" value="<?=$jday?>" />
<input name="jmonth" id="jmonth" type="hidden" value="<?=$jmonth?>" />
<input name="jyear" id="jyear" type="hidden" value="<?=$jyear?>" />
&nbsp;&nbsp;نمایش بر اساس&nbsp;&nbsp;
<select onchange=" ch_fields()" name="scope" id="scope">
<? if(empty($scope) || $scope==1){?>
  <option value="1" selected="selected">ایمیل</option>
  <option value="3">تاریخ ارسال</option>
  <? } else{?>
  <option value="1">ایمیل</option>
  <option value="3" selected="selected">تاریخ ارسال</option>  
  <? }?>
</select>
&nbsp;
<span id="field">
<? if ($scope!=3){ ?>
<input type="text" name="eshow" id="eshow" class="input" value="<?=$eshow?>" />
<? } else {?>
<script language="javascript" type="text/javascript">document.getElementById("field").innerHTML=makedate(<?=$p_day1.",".$p_month1.",".$p_year1.",".$p_day2.",".$p_month2.",".$p_year2 ?>);</script>
<? }?>
</span>
&nbsp;
<input name="sdate" id="jmonth" type="hidden" value="<?=$sdate?>" />
<input name="fdate" id="jyear" type="hidden" value="<?=$fdate?>" />
<input name="submit" type="submit" class="button" id="submit" style="width:70px" value="نمایش" />
</form>
<br />
<p style="color:#996600;">&nbsp;&nbsp;&nbsp;تعداد موارد یافت شده : <strong><?=$totalp?></strong></p><table width="548" align="center" cellpadding="0" cellspacing="0" dir="ltr" class="mtable">
  <tr class="mtitle">
    <td width="73" height="25" align="center" bgcolor="#CCCCCC" style="border-left:none;">حذف</td>
    <td width="106" align="center" bgcolor="#CCCCCC">تاریخ ارسال</td>
    <td width="317" align="center" bgcolor="#CCCCCC">ایمیل </td>
    <td width="50" align="center" bgcolor="#CCCCCC">رديف</td>
  </tr>
  <?
		$row=1;
while ($record = mysql_fetch_object($sql))
{
		if($total != 0)
		{
		if(fmod($total,2.0)==1){
?>
  <tr class="odd">
    <td height="25" align="center" style="border-left:none;">
        <?
	 if($eshow){
    echo "<a href='?q=email-mg&amp;del=$record->Eid&eshow=$eshow&scope=$scope&page=$page' ";
	}elseif($scope==3){
    echo "<a href='?q=email-mg&amp;del=$record->Eid&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page' ";
	}elseif($page){
   echo  "<a href='?q=email-mg&amp;del=$record->Eid&page=$page' ";
   }else{
   echo  "<a href='?q=email-mg&amp;del=$record->Eid' ";
	  }
	echo  "onclick=\"return confirm('آيا مطمئن به حذف ایمیل ($record->Eemail) مي باشيد ؟')\"> ";
	?>
    <img src="./layout/delete.gif" width="16" height="16" alt="حذف" title="حذف" border="0" /></a></td>
    <td height="25" align="center">
 		<? $jSend  = explode('@',zone("$record->Etime",$timezone));
			list( $gyear, $gmonth, $gday ) = explode('/',$jSend[0]);
			list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
			echo Ct($jyear) ."/". Ct($jmonth) ."/". Ct($jday);?></td>
    <td align="center">
    <? 
	echo "$record->Eemail";
	 ?></td>
    <td align="center"><?=Ct($row);?></td>
  </tr>
  <?
  }
  else{
  ?>
  <tr class="even">
    <td height="25" align="center" style="border-left:none;">
        <?
	 if($eshow){
    echo "<a href='?q=email-mg&amp;del=$record->Eid&eshow=$eshow&scope=$scope&page=$page' ";
	}elseif($scope==3){
    echo "<a href='?q=email-mg&amp;del=$record->Eid&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page' ";
	}elseif($page){
   echo  "<a href='?q=email-mg&amp;del=$record->Eid&page=$page' ";
   }else{
   echo  "<a href='?q=email-mg&amp;del=$record->Eid' ";
	  }
	echo  "onclick=\"return confirm('آيا مطمئن به حذف ایمیل ($record->Eemail) مي باشيد ؟')\"> ";
	?>
<img src="./layout/delete.gif" width="16" height="16" alt="حذف" title="حذف" border="0" /></a></td>
    <td height="25" align="center">
    		<? $jSend  = explode('@',zone("$record->Etime",$timezone));
			list( $gyear, $gmonth, $gday ) = explode('/',$jSend[0]);
			list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
			echo Ct($jyear) ."/". Ct($jmonth) ."/". Ct($jday);?></td>
    <td align="center"><? echo "$record->Eemail"; ?></td>
    <td align="center"><?=Ct($row);?></td>
  </tr>
  <?
  }
	}	
	$total--;
	$row++;
}	
?>
</table>
<? } ?>
<br />
        <?
if ($numofpages > 1){
echo "<table dir='ltr' border='0' height='21' cellpadding='0' align='center'><tr>";
if($eshow){
per_page("?q=email-mg&amp;eshow=$eshow&amp;scope=$scope&amp;page=%page", 8,$eshow,$scope,$sdate,$fdate);
}elseif($scope==3){
per_page("?q=email-mg&amp;scope=$scope&amp;sdate=$sdate&amp;fdate=$fdate&amp;page=%page", 8,$eshow,$scope,$sdate,$fdate);
}else{
per_page("?q=email-mg&amp;page=%page", 8,$eshow,$scope,$sdate,$fdate);
}
echo "</tr></table>"; 
}
?> 
        <div align="center"><br />
<?
	 if($eshow){
    $select="eshow=$eshow&scope=$scope";
	}elseif($scope==3){
   $select="sdate=$sdate&fdate=$fdate&scope=$scope&page=$page";
	}else{
	$select="";
	}
	?>
          <input class="button" type="button" name="submit" id="submit" style="padding:3px;width:130px;" value="ایجاد خروجی برای ارسال" onclick="window.open('./pages/list.php?<?=$select?>');"/>
</div>