<?
include("./editor/fckeditor.php") ;
if(isset($_POST['edit_about']) && $_POST['edit_about']=='1' )
	{
	$which=$_POST['which'];
	$abouttext=$_POST['abouttext'];
	$abouttext2=$_POST['abouttext2'];
	mysql_query ("UPDATE about SET mission='$abouttext',emission='$abouttext2' WHERE id='".$_POST['id']."'");
	?>
    	<br />
		<div id="notice" align="center">
        <p  class="success">متن ماموریت با موفقیت ویرایش گردید </p>
		</div>
    <?
	unset($_POST['edit_about']);
	} 
	$result = mysql_query("SELECT mission,emission,id FROM about"); 
	$record = mysql_fetch_object($result);
?>
<form class="form" name="about" action="" method="post" enctype="multipart/form-data">
<input type="hidden" value="<?="$record->id";?>" name="id" />
  <br/>
  <br/>
  <table width="794" border="0" align="center" cellpadding="0" cellspacing="4">
    <tr class="tr">
      <td height="40" align="center">متن فارسی</td>
    </tr>
    <tr class="tr">
      <td height="6" align="center" valign="top"><textarea id="abouttext" dir="rtl" name="abouttext" cols="110" rows="15"><?=$record->mission?>
      </textarea></td>
    </tr>
    <tr class="tr">
      <td height="40" align="center">متن لاتین</td>
    </tr>
    <tr class="tr">
      <td height="15" align="center" valign="top"><textarea id="abouttext2" dir="rtl" name="abouttext2" cols="110" rows="15"><?=$record->emission?>
      </textarea></td>
    </tr>
    <tr class="tr">
      <td align="left"></td>
    </tr>
    
    <tr class="tr">
      <td height="46" align="center">
        <input type="hidden" value="0" name="which" />
        <input type="hidden" value="1" name="edit_about" />
      <input name="submit1" type="submit" class="button" id="submit1" style="width:85px" value="ویرایش" onclick="return confirm('آیا متن ماموریت ویرایش گردد ؟');"/></td>
  </tr>
  </table>
  <br/>
</form>