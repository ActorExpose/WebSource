<?
	$location="location.href='?q=user-manage'";
	$qs="";
$ytxt='';
$mtxt='';
$dtxt='';
for($i=1300;$i<=1400;$i++)
{
	$ytxt.='<option value="'.$i.'">'.$i.'</option>';
}
for($i=1;$i<=12;$i++)
{
	$mtxt.='<option value="'.$i.'">'.$i.'</option>';
}
for($i=1;$i<=31;$i++)
{
	$dtxt.='<option value="'.$i.'">'.$i.'</option>';
}

//******************************************************
	if(isset($_POST['add_user']) && $_POST['add_user']=='1' && (strlen($_POST['user']) > 0 ))
{
$user=$_POST['user'];
$pass=$_POST['pass'];
$name=$_POST['name'];
$field=$_POST['field'];
$mail=$_POST['mail'];
$level=$_POST['level'];
$status=$_POST['status'];
unset($totalr);
$resultr=mysql_query("SELECT id FROM users WHERE user = '$user'");
$totalr = mysql_num_rows($resultr);
if(!$totalr){
	if(strlen($jday)<2)
	$jday=0 .$jday;
	if(strlen($jmonth)<2)
	$jmonth=0 .$jmonth;
$post_date	= 	$jyear.$jmonth.$jday;

	$b_day=$_POST['b_day'];
	$b_month=$_POST['b_month'];

	if(strlen($b_day)<2)
	$b_day=0 .$b_day;
	if(strlen($b_month)<2)
	$b_month=0 .$b_month;
$birth=$_POST['b_year'].$b_month.$b_day;

	mysql_query ("INSERT INTO users (time,post,user,pass,name,mail,birth,field,activation,activated,level,status) VALUES ('".time()."','$post_date.','$user','$pass','$name','$mail','$birth','$field','true','1','$level','$status')");
	unset($_POST['caption']);
	?>	
    	<br />
		<div id="notice" align="center">
        <p  class="success">کاربر <span style="color:#029125"><?=$user?></span> با موفقیت ثبت گردید</p>
		</div>
        <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
	   }
}else{?>
	<div id="notice" align="center">
		</div>
       <?
}

?>
<form class="form" name="users" action="" method="post" enctype="multipart/form-data" onsubmit="return  false;">
<br/>
<table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="700">
<tr class="tr">
				<td height="15" colspan="2" valign="top" class="td"></td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  نام کاربری&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<input name="user" type="text" class="input" id="user" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  کلمه عبور&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<input name="pass" type="text" class="input" id="pass" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  نام و نام خانوادگی&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<input name="name" type="text" class="input" id="name" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			  تاریخ تولد&nbsp;&nbsp;</td>
<td width="518" height="25" class="td">
					<select class="select" name="b_day" id="b_day" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
					  <?=$dtxt?>
	    </select>&nbsp;/&nbsp;
	    <select class="select" name="b_month" id="b_month" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl"><?=$mtxt?></select>&nbsp;/&nbsp;			  <select class="select" name="b_year" id="b_year" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
	      <?=$ytxt?>
	      </select>	    </td>
			</tr>
   			<tr class="tr">
			  <td width="170" height="25" align="left" class="td">زمینه فعالیت&nbsp;&nbsp;</td>
<td height="25" class="td"><input name="field" type="text" class="input" id="field" size="30" /></td>
			</tr>
   			<tr class="tr">
			  <td width="170" height="25" align="left" class="td">پست الکترونیکی&nbsp;&nbsp;</td>
<td height="25" class="td">
			  <input name="mail" type="text" class="input" id="mail" style="text-align:left;direction:ltr;" size="30" />			  </td>
			</tr>
   			<tr class="tr">
			  <td width="170" height="25" align="left" class="td">سطح دسترسی&nbsp;&nbsp;</td>
<td height="25" class="td"><select class="select" name="level" id="level" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
  <option value="0" selected="selected">کاربر عادی</option>
  <option value="1">مدیریت</option>
</select></td>
			</tr>
            			<tr class="tr">
				<td width="170" height="25" align="left" class="td">
			 وضعیت&nbsp;&nbsp;</td>
<td height="25" class="td">
			      <input name="status" type="radio" id="status_0" value="1" checked="checked" />
			      فعال&nbsp;
			    <input name="status" type="radio" id="status_1" value="0" />
غير فعال</td>
				</tr>
			<tr class="tr">
				<td width="170" height="50" align="left" class="td"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td class="td" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
    </tr>
<tr class="tr">
			  <td width="170" height="48" class="td">&nbsp;</td>
<td class="td">
			<input type="hidden" value="0" name="edit_user" />
       		<input type="hidden" value="1" name="add_user" />
			<input name="button" type="submit" class="button" id="button" style="width:70px" value="ثبت کاربر" onclick="return checkForm_user()" />&nbsp; <input style="width:50px" name="reset" type="reset" class="button" value="مجدد" />&nbsp; <input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" /></td>
			</tr>
	</table>
</form>
    <br />
        <br />