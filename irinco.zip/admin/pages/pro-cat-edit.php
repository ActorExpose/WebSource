<?
	$page = $_GET['page'];
	if($page){
	$location="location.href='?q=pro-cat-mg&page=$page#catlist'";
	}else{
	$location="location.href='?q=pro-cat-mg#catlist'";
	}
	
	if(isset($_POST['edit_cat']) && $_POST['edit_cat']=='1' && (strlen($_POST['name']) > 0 ))
{
$name=$_POST['name'];
$ename=$_POST['ename'];
$new_image=$_FILES['new_image']['tmp_name'];
$cat_preview=$_POST['cat_preview'];
$old_name=$_POST['old_name'];
$order=$_POST['order'];
$comment=$_POST['comment'];
$status=$_POST['status'];
$id=$_POST['id'];
if(strlen($new_image)==0){
$file=$cat_preview;
//echo "100000";
}else{
          if (isset ($_FILES['new_image'])){
		  unlink("../images/category/".$cat_preview);
              $imagename = $_FILES['new_image']['name'];
              $source = $_FILES['new_image']['tmp_name'];
              $target = "../images/category/".$imagename;
              copy($source, $target);
			  
              $save = "../images/category/".$imagename; //This is the new file you saving
              $file = "../images/category/".$imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = 100;
			  $modheight = 100;
 
             // $diff = $width / $modwidth;
 
             // $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 

			$file = $imagename;
			//echo $file;
        }
}

mysql_query ("UPDATE tbcat SET Corder='$order',Cname='$name',Cename='$ename',Caddcat='$file',Ccomment='$comment',Cstatus='$status' WHERE Cid='$id'");
unset($_POST['name']);
	?>
    	<br />
		<div id="notice" align="center">
        <p  class="success">دسته <span style="color:#029125"><?=$old_name?></span> با موفقیت ویرایش گردید</p>
		</div>
    <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
}
	$edit=$_GET['edit'];
	$sql = "SELECT * FROM tbcat WHERE Cid='$edit'";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	$str=trim($record->Ccomment);
	//echo "$str";
	$str=strlen($str);
	//echo "$str";
	/*echo "<script language='javascript' type='application/javascript'>alert('$str')</script>";*/
	$str=255 - $str;

?>
<form class="form" name="cat" action="" method="post" enctype="multipart/form-data" onsubmit="return  false;" >
<input type="hidden" id="id" name="id" value="<? echo "$record->Cid";?>" />
<input type="hidden" id="order" name="order" value="<? echo "$record->Corder";?>" />
		<br/>
<table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="100%;">
			<tr>
				<td height="15" colspan="5" valign="top"></td>
			</tr>
            	<tr>
				<td width="27%" height="25" align="left">عنوان دسته (فارسی)&nbsp;&nbsp;</td>
<td height="25" colspan="4">
					<input type="hidden" id="cat_preview" name="cat_preview" value="<?="$record->Caddcat";?>" />
				  <input name="name" type="text" value="<?="$record->Cname";?>" class="input" id="name" size="30" /></td>
			</tr>
            	<tr>
				<td width="27%" height="25" align="left">عنوان دسته (لاتین)&nbsp;&nbsp;</td>
<td height="25" colspan="4">
					<input type="hidden" id="cat_preview" name="cat_preview" value="<?="$record->Caddcat";?>" />
				  <input name="ename" type="text" value="<?="$record->Cename";?>" class="input" id="ename" size="30" /></td>
			</tr>
          			<tr>
				<td width="27%" height="25" align="left">وضعیت&nbsp;&nbsp;</td>
<td height="25" colspan="4">
		<? 
		   if($record->Cstatus == 1){
		  ?>
        <input name="status" type="radio" id="status_0" value="1" checked="checked"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0"/>
        غير فعال
          <?
			}
			else{
			?> 
        <input name="status" type="radio" id="status_0" value="1"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0" checked="checked"/>
        غير فعال
          <?
				}
				?>                </td>
				</tr>
			<tr>
				<td width="27%" height="50" align="left"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td width="34%" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
		      <td colspan="3" ></td>
	</tr>  
<tr>
			  <td width="27%" height="48">&nbsp;</td>
<td colspan="4">
        <input type="hidden" value="0" name="add_cat" />
        <input type="hidden" value="1" name="edit_cat" />
         <input type="hidden" id="old_name" name="old_name" value="<? echo "$record->Cname";?>" />
		<input name="button" type="submit" class="button" id="button" style="width:80px" value="ويرايش دسته" onclick="return checkForm_cat();" />
		      <input style="width:50px" name="reset" type="reset" class="button" value="مجدد" />
		<input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" />              </td>
			</tr>
	</table>
  <br/>
</form>
<p>&nbsp;</p>