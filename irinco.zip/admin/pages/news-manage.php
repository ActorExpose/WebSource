<?
	if($_POST['eshow']){
	$eshow = $_POST['eshow'];
	}else if($_GET['eshow']){
	$eshow = $_GET['eshow'];
	}
	
	if($_POST['p_day1']){
	$p_day1=$_POST['p_day1'];
	$p_month1=$_POST['p_month1'];
	$p_year1=$_POST['p_year1'];
	$p_day2=$_POST['p_day2'];
	$p_month2=$_POST['p_month2'];
	$p_year2=$_POST['p_year2'];
	}
	if($_GET['sdate']){
	$sdate=$_GET['sdate'];
	$p_day1=substr($sdate,6,2);
	if(substr($p_day1,0,1)==0)
	$p_day1=substr($p_day1,1,1);
	$p_month1=substr($sdate,4,2);
	if(substr($p_month1,0,1)==0)
	$p_month1=substr($p_month1,1,1);
	$p_year1=substr($sdate,0,4);
	}
	if($_GET['fdate']){
	$fdate=$_GET['fdate'];
	$p_day2=substr($fdate,6,2);
	if(substr($p_day2,0,1)==0)
	$p_day2=substr($p_day2,1,1);
	$p_month2=substr($fdate,4,2);
	if(substr($p_month2,0,1)==0)
	$p_month2=substr($p_month2,1,1);
	$p_year2=substr($fdate,0,4);
	}
	
	if(strlen($p_day1)<2)
	$s_day=0 .$p_day1;
	else
	$s_day=$p_day1;
	if(strlen($p_month1)<2)
	$s_month=0 .$p_month1;
	else
	$s_month=$p_month1;
	$s_year=$p_year1;
	if(strlen($p_day2)<2)
	$f_day=0 .$p_day2;
	else
	$f_day=$p_day2;
	if(strlen($p_month2)<2)
	$f_month=0 .$p_month2;
	else
	$f_month=$p_month2;
	$f_year=$p_year2;
	$sdate=$s_year.$s_month.$s_day;
	$fdate=$f_year.$f_month.$f_day;
 // echo $sdate."<br>";	
  //echo $fdate."<br>";
	if($_POST['scope']){
	$scope = $_POST['scope'];
	}else if ($_GET['scope']){
	$scope = $_GET['scope'];
	}
//*********************************************************
function per_page($link, $offset,$eshow,$scope,$sdate,$fdate) 
{
	global $numofpages, $page;
	
	$pagesstart = round($page-$offset);
	$pagesend = round($page+$offset);
	
	if ($page != "1" && round($numofpages) != "0") 
	{
		if($eshow){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=news-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}elseif($scope==2){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=news-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;sdate='.$sdate.'&amp;fdate='.$fdate.'&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}else{
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=news-manage&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		}
		
		echo str_replace("%page", round($page-1), '<td class="bt_prev" align="center" width="24" height="21"><a href="'.$link.'" title=" صفحه قبلی" style="text-decoration: none;" >&nbsp;&nbsp;<&nbsp;&nbsp;</a></td>');
	}
	else{
			echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;<<&nbsp;</td>';
		echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;<&nbsp;&nbsp;</td>';
	}
	
	
	for($i = 1; $i <= $numofpages; $i++) 
	{ 
		if ($pagesstart <= $i && $pagesend >= $i) 
		{
			if ($i == $page) 
			{
				echo "<td class='curpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
			}
			else 
			{
				echo str_replace("%page", "$i", '<td class="numpage" valign="middle" width="24" height="21"><a href="'.$link.'" style="text-decoration: none;" >&nbsp;&nbsp;'.Ct($i).'&nbsp;&nbsp;</a></td>');	
			}
		}
	}
	if (round($numofpages) == "0") 
	{
		echo "<td class='numpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
	}
	
	if ($page != round($numofpages) && round($numofpages) != "0") 
	{
		echo str_replace("%page", round($page+1), '<td class="bt_next" align="center" width="24" height="21"><a href="'.$link.'" title="صفحه بعدی" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>');
		if($eshow){
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=news-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;&nbsp;>>&nbsp;&nbsp;</a></td>';
		}elseif($scope==2){
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=news-manage&amp;eshow='.$eshow.'&amp;scope='.$scope.'&amp;sdate='.$sdate.'&amp;fdate='.$fdate.'&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}else{
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=news-manage&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
		}
	}else{
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;>&nbsp;&nbsp;</td>';
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;>>&nbsp;</td>';
	}
}
$pp = "20";
//******************************************************
if(isset($_GET['del']) && $_GET['del'] != 0){

$del=$_GET['del'];
$result=mysql_query("SELECT * FROM news WHERE id ='$del'");
$numc = mysql_num_rows($result);
if($numc>0){
$record = mysql_fetch_object($result);
if($record->thumb)
unlink("../images/news/sl_".$record->thumb);
unlink("../images/news/".$record->thumb);
unlink("../images/news/thu_".$record->thumb);
mysql_query("DELETE FROM news WHERE id='$del'");
?>
<br />
		<div id="notice" align="center">
        <p  class="success">خبر <span style="color:#029125"><?=$record->caption?></span> با موفقیت حذف گردید</p>
</div>
<?
}
create_feed();
$_GET['del'] = 0;
}

if(isset($_GET['status']) && $_GET['status'] != 0){

	$id=$_GET['status'];
	
	$sql = "SELECT * FROM news WHERE id='$id'";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	if($record->status == 1){
	mysql_query ("UPDATE news SET status='0' WHERE id='$id'");
	}
	if($record->status == 0){
	mysql_query ("UPDATE news SET status='1' WHERE id='$id'");
	}
	create_feed();
	$_GET['status'] = 0;	
}

if(isset($eshow) && strlen($eshow) > 0) {
	if($scope==2)
	$sql = mysql_query("SELECT * FROM news WHERE text LIKE '%$eshow%' ORDER BY time DESC");
	else
	$sql = mysql_query("SELECT * FROM news WHERE caption LIKE '%$eshow%' ORDER BY time DESC");
}elseif($scope==3){
	$sql = mysql_query("SELECT * FROM news WHERE post >= '$sdate' and post <= '$fdate' ORDER BY time DESC");
}else{
	$sql = mysql_query("SELECT * FROM news ORDER BY time DESC");
}
$totalp = mysql_num_rows($sql);
//********************************************************
$numofpages = ceil($totalp / $pp); 
if (!isset($_GET['page']))
{ 
	$page = 1; 
} 
else 
{ 
	$page = $_GET['page']; 
	if($numofpages<$page)
	$page-=1;
} 
$limitvalue = $page * $pp - ($pp);

if(isset($eshow) && strlen($eshow) > 0) {
	if($scope==2)
	$sql = mysql_query("SELECT * FROM news WHERE text LIKE '%$eshow%' ORDER BY time DESC LIMIT $limitvalue, $pp");
	else
	$sql = mysql_query("SELECT * FROM news WHERE caption LIKE '%$eshow%' ORDER BY time DESC LIMIT $limitvalue, $pp");
}elseif($scope==3){
	$sql = mysql_query("SELECT * FROM news WHERE post >= '$sdate' and post <= '$fdate' ORDER BY time DESC LIMIT $limitvalue, $pp");
}else{
	$sql = mysql_query("SELECT * FROM news ORDER BY time DESC LIMIT $limitvalue, $pp");
}
if($sql)
$total = mysql_num_rows($sql);
	
//******************************************************************
?>
<br />
<br />
<form id="fshow" name="fshow" method="post" action="?q=news-manage">
<input name="nrow" type="hidden" value="<?=$row?>" />
<input name="jday" id="jday" type="hidden" value="<?=$jday?>" />
<input name="jmonth" id="jmonth" type="hidden" value="<?=$jmonth?>" />
<input name="jyear" id="jyear" type="hidden" value="<?=$jyear?>" />
&nbsp;&nbsp;نمایش بر اساس&nbsp;&nbsp;
<select onchange=" ch_fields()" name="scope" id="scope">
<? if(empty($scope) || $scope==1){?>
  <option value="1" selected="selected">تیتر اخبار</option>
  <option value="2">محتوای اخبار</option>
  <option value="3">تاریخ ارسال</option>
  <? } else if($scope==2){?>
  <option value="1">تیتر اخبار</option>
  <option value="2" selected="selected">محتوای اخبار</option>
  <option value="3">تاریخ ارسال</option>
  <? }else if($scope==3){?>
  <option value="1">تیتر اخبار</option>
  <option value="2">محتوای اخبار</option>
  <option value="3" selected="selected">تاریخ ارسال</option>
  <? }?>
</select>
&nbsp;
<span id="field">
<? if ($scope!=3){ ?>
<input type="text" name="eshow" id="eshow" class="input" value="<?=$eshow?>" />
<? } else {?>
<script language="javascript" type="text/javascript">document.getElementById("field").innerHTML=makedate(<?=$p_day1.",".$p_month1.",".$p_year1.",".$p_day2.",".$p_month2.",".$p_year2 ?>);</script>
<? }?>
</span>
&nbsp;
<input name="sdate" id="jmonth" type="hidden" value="<?=$sdate?>" />
<input name="fdate" id="jyear" type="hidden" value="<?=$fdate?>" />
<input name="submit" type="submit" class="button" id="submit" style="width:70px" value="نمایش" />
</form>
<br />
<p style="color:#996600;">&nbsp;&nbsp;&nbsp;تعداد موارد یافت شده : <strong><?=$totalp?></strong></p><table width="742" align="center" cellpadding="0" cellspacing="0" dir="ltr" class="mtable">
    <tr class="mtitle">
      <td width="50" height="25" align="center" style="border-left:none;">حذف</td>
      <td width="50" align="center">ويرايش</td>
      <td width="60" align="center">وضعيت</td>
      <td width="75" align="center">تعداد نظرات</td>
      <td width="75" align="center">تعداد بازدید</td>
      <td width="80" align="center">تاریخ ارسال</td>
      <td width="297" align="center">تیتر خبر</td>
      <td width="53" align="center">رديف</td>
    </tr>
    <?	
		$row=1;
	if($sql){
while ($record = mysql_fetch_object($sql)) 
{
		if($total != 0)
		{
		if(fmod($total,2.0)==1){
?>
    <tr class="odd">
      <td height="25" align="center" style="border-left:none;"><?
	 if($eshow){
    echo "<a href='?q=news-manage&amp;del=$record->id&eshow=$eshow&scope=$scope&page=$page' ";
	}elseif($scope==3){
    echo "<a href='?q=news-manage&amp;del=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page' ";
	}elseif($page){
   echo  "<a href='?q=news-manage&amp;del=$record->id&page=$page' ";
   }else{
   echo  "<a href='?q=news-manage&amp;del=$record->id' ";
	  }
	echo  "onclick=\"return confirm('آيا مطمئن به حذف خبر ($record->caption) مي باشيد ؟')\"> ";
	?>
          <img src="./layout/delete.gif" width="16" height="16" alt="حذف" title="حذف" border="0" /> </a></td>
      <td align="center"><?
	if($eshow){
    echo "<a href='?q=news-edit&amp;id=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==3){
    echo "<a href='?q=news-edit&amp;id=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=news-edit&amp;id=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=news-edit&amp;id=$record->id'>";
	  }
	?><img src="./layout/pedit.gif" alt="ويرايش" title="ويرايش" width="16" height="16" border="0" /></a></td>
      <td align="center"><?
	if($eshow){
    echo "<a href='?q=news-manage&amp;status=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==3){
    echo "<a href='?q=news-manage&amp;status=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=news-manage&amp;status=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=news-manage&amp;status=$record->id'>";
	  }
	if ($record->status == 1){
   echo "<img src='./layout/enabled.gif' alt='فعال' title='فعال' width='16' height='16' border='0' />";
    }
	else{
	echo "<img src='./layout/disabled.gif' alt='غير فعال' title='غير فعال' width='16' height='16' border='0' />";
    }
	?>
        </a></td>
      <td align="center"><?
				$resultc = mysql_query("SELECT * FROM comments WHERE parentId='$record->id' and type ='news'");
				if(mysql_num_rows($resultc))
				echo '<a href="?q=comments&pid='.$record->id.'&type=news" target="_blank">'.mysql_num_rows($resultc).'</a>';
				else
				echo '0';
						  ?></td>
      <td align="center"><?
				$res = mysql_query("SELECT * FROM clicks WHERE parentId='$record->id' and type ='news'");
				echo mysql_num_rows($res);
						  ?></td>
      <td align="center" style="direction:rtl;"><? $jSend  = explode('@',zone("$record->time",$timezone));
			list( $gyear, $gmonth, $gday ) = explode('/',$jSend[0]);
			list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
			echo Ct($jyear) ."/". Ct($jmonth) ."/". Ct($jday);?></td>
      <td align="center" style="direction:rtl;"><?="$record->caption";?></td>
      <td align="center"><?=Ct($row);?></td>
    </tr>
    <?
  }
  else{
  ?>
    <tr class="even">
      <td height="25" align="center" style="border-left:none;"><?
	 if($eshow){
    echo "<a href='?q=news-manage&amp;del=$record->id&eshow=$eshow&scope=$scope&page=$page' ";
	}elseif($scope==3){
    echo "<a href='?q=news-manage&amp;del=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page' ";
	}elseif($page){
   echo  "<a href='?q=news-manage&amp;del=$record->id&page=$page' ";
   }else{
   echo  "<a href='?q=news-manage&amp;del=$record->id' ";
	  }
	echo  "onclick=\"return confirm('آيا مطمئن به حذف خبر ($record->caption) مي باشيد ؟')\"> ";
	?>
          <img src="./layout/delete.gif" width="16" height="16"  alt="حذف" title="حذف" border="0" /></a></td>
      <td align="center"><?
	if($eshow){
    echo "<a href='?q=news-edit&amp;id=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==3){
    echo "<a href='?q=news-edit&amp;id=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=news-edit&amp;id=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=news-edit&amp;id=$record->id'>";
	  }
	?>
          <img src="./layout/pedit.gif" width="16" height="16"  alt="ويرايش" title="ويرايش" border="0" /></a></td>
      <td align="center"><?
	if($eshow){
    echo "<a href='?q=news-manage&amp;status=$record->id&eshow=$eshow&scope=$scope&page=$page'>";
	}elseif($scope==3){
    echo "<a href='?q=news-manage&amp;status=$record->id&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'>";
	}elseif($page){
   echo  "<a href='?q=news-manage&amp;status=$record->id&page=$page'>";
   }else{
   echo  "<a href='?q=news-manage&amp;status=$record->id'>";
	  }
	if ($record->status == 1){
   echo "<img src='./layout/enabled.gif' alt='فعال' title='فعال' width='16' height='16' border='0' />";
    }
	else{
	echo "<img src='./layout/disabled.gif' alt='غير فعال' title='غير فعال' width='16' height='16' border='0' />";
    }
	?>
        </a></td>
      <td align="center"><?
				$resultc = mysql_query("SELECT * FROM comments WHERE parentId='$record->id' and type ='news'");
				if(mysql_num_rows($resultc))
				echo '<a href="?q=comments&pid='.$record->id.'&type=news" target="_blank">'.mysql_num_rows($resultc).'</a>';
				else
				echo '0';
						  ?></td>
      <td align="center"><?
				$res = mysql_query("SELECT * FROM clicks WHERE parentId='$record->id' and type ='news'");
				echo mysql_num_rows($res);
						  ?></td>
      <td align="center" style="direction:rtl;"><? $jSend  = explode('@',zone("$record->time",$timezone));
			list( $gyear, $gmonth, $gday ) = explode('/',$jSend[0]);
			list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
			echo Ct($jyear) ."/". Ct($jmonth) ."/". Ct($jday);?></td>
      <td align="center" style="direction:rtl;"><?="$record->caption";?></td>
      <td align="center"><?=Ct($row);?></td>
    </tr>
    <?
  }
	}	
	$total--;
	$row++;
}	
}
?>
  </table>
<br />
        <?
if ($numofpages > 1){
echo "<table dir='ltr' border='0' height='21' cellpadding='0' align='center'><tr>";
if($eshow){
per_page("?q=news-manage&amp;eshow=$eshow&amp;scope=$scope&amp;page=%page", 8,$eshow,$scope,$sdate,$fdate);
}elseif($scope==2){
per_page("?q=news-manage&amp;scope=$scope&amp;sdate=$sdate&amp;fdate=$fdate&amp;page=%page", 8,$eshow,$scope,$sdate,$fdate);
}else{
per_page("?q=news-manage&amp;page=%page", 8,$eshow,$scope,$sdate,$fdate);
}
echo "</tr></table>"; 
}
?> 