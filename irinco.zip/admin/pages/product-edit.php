<?

	if($_POST['cat']){
	$cat = $_POST['cat'];
	}else if($_GET['cat']){
	$cat = $_GET['cat'];
	}
	
	$select = $_GET['select'];
	$page = $_GET['page'];
	if($select){
	$location="location.href='?q=product-mg&show=$show&select=$select&page=$page#productlist'";
    }elseif($page){
	$location="location.href='?q=product-mg&show=$show&page=$page#productlist'";
	}else{
	$location="location.href='?q=product-mg&show=$show#productlist'";
	}
	
	if(isset($_POST['edit_products']) && $_POST['edit_products']=='1' && (strlen($_POST['comment']) > 0 ))
{
$name=$_POST['name'];
$ename=$_POST['ename'];
$cat=$_POST['cat'];
$old_name=$_POST['old_name'];
$oldcat=$_POST['old_cat'];
$comment=$_POST['comment'];
$ecomment=$_POST['comment2'];
$order=$_POST['order'];
$status=$_POST['status'];
$new_image=$_FILES['new_image']['tmp_name'];
$products_preview=$_POST['products_preview'];
$id=$_POST['id'];
if($cat != $oldcat){
	$resulto=mysql_query("SELECT * FROM products WHERE Scat='$oldcat' and Sorder > '$order'");
	while($recordo = mysql_fetch_object($resulto)){
	$oid=$recordo->Sid;
	$neworder=$recordo->Sorder - 1;
	mysql_query ("UPDATE products SET Sorder='$neworder' WHERE Spro='$oldcat' and Sid ='$oid'");
}
	$sql=mysql_query("SELECT * FROM products WHERE Scat='$cat' ORDER BY Sorder DESC");
	$records = mysql_fetch_object($sql);
	$order=$records->Sorder+1;
	
	if(!is_dir("../images/products/".$cat))
	mkdir("../images/products/".$cat, 0755);
	
	copy ( "../images/products/".$oldcat."/".$products_preview, "../images/products/".$cat."/".$products_preview );
	unlink("../images/products/".$oldcat."/".$products_preview);
}

if(strlen($new_image)==0){
$new_image=$products_preview;
$file=$new_image;
}else{	

	if(!is_dir("../images/products/".$cat))
	mkdir("../images/products/".$cat, 0755);
	
          if (strlen($_FILES['new_image']['name'])>1){
		  	  unlink("../images/products/".$cat."/".$products_preview);
              $imagename = $_FILES['new_image']['name'];
              $source = $_FILES['new_image']['tmp_name'];
              $target = "../images/products/".$cat."/".$imagename;
              move_uploaded_file($source, $target);
			  $target_large="../images/products/".$cat."/".$imagename; 
			  copy($target,$target_large);
              $save = "../images/products/".$cat."/" . $imagename; //This is the new file you saving
              $file = "../images/products/".$cat."/" . $imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
 
              list($width, $height) = getimagesize($file) ; 
			  
              $modwidth = 197;
			  $modheight = 160;
 
 
             // $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 
			  
			$file = $imagename;
			//echo $file;
        
        }
		  
		}
mysql_query ("UPDATE products SET Sorder='$order',Sname='$name',Sename='$ename', Saddpic='$file', Scomment='$comment', Secomment='$ecomment', Scat='$cat', Sstatus='$status' WHERE Sid='$id'");
unset($_POST['comment']);
	?>
    	<br />
		<div id="notice" align="center">
        <p  class="success">محصول <span style="color:#029125"><?=$old_name?></span> با موفقیت ویرایش گردید</p>
		</div>
    <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
} 
	$edit=$_GET['edit'];
	$sql = "SELECT * FROM products WHERE Sid='$edit'";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	$str=trim($record->Scomment);

	//echo "$str";
	$str=strlen($str);
	//echo "$str";
	/*echo "<script language='javascript' type='application/javascript'>alert('$str')</script>";*/
	$str=80 - $str;

?>
<form class="form" name="products" action="" method="post" enctype="multipart/form-data" >
<input type="hidden" id="id" name="id" value="<?=$record->Sid;?>" />
		<br/>
<table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="800">
<tr class="tr">
				<td height="15" colspan="3" valign="top" class="td"></td>
			</tr>
            			<tr class="tr">
				<td width="144" height="25" align="left" class="td">
			  انتخاب دسته&nbsp;</td>
<td height="25" colspan="2" class="td">
					<select size="1" name="cat" id="cat">
                <? 
			$sql2 = "SELECT * FROM tbcat WHERE Cstatus='1' ORDER BY Corder ASC";
			$result2 = mysql_query($sql2); 
			while ($record2 = mysql_fetch_object($result2)) 
				{
			?>
          <? 
		   if($record->Scat == $record2->Cid){
		  ?>
                <option value="<?="$record2->Cid";?>" selected="selected"><?="$record2->Cname";?></option>
        <?
		}
		else{
		?>
         		<option value="<?="$record2->Cid";?>"><?="$record2->Cname";?></option>
                <?
		 }
				}
				?>
        </select>&nbsp;</td>
			</tr>
            	<tr class="tr">
				<td width="144" height="25" align="left" class="td">
			 عنوان محصول (فارسی)&nbsp;&nbsp;</td>
<td height="25" colspan="2" class="td">
					<input name="name" type="text" value="<?="$record->Sname";?>" class="input" id="name" size="30" /></td>
			</tr>
            	<tr class="tr">
				<td width="144" height="25" align="left" class="td">
			 عنوان محصول (لاتین)&nbsp;&nbsp;</td>
<td height="25" colspan="2" class="td">
					<input name="ename" type="text" value="<?="$record->Sename";?>" class="input" id="ename" size="30" /></td>
			</tr>
            			<tr class="tr">
				<td width="144" height="25" align="left" class="td">
			  آدرس محصول&nbsp;&nbsp;</td>
<td height="25" class="td"><input name="new_image"  type="file" class="fileUpload" id="new_image"  size="35" /></td>
			<td rowspan="2" valign="top" class="td"><a href="../images/products/<?=$record->Scat?>/<?=$record->Saddpic?>" target="_blank"><img src="../images/products/<?=$record->Scat?>/<?="$record->Saddpic";?>" alt="بزرگنمایی محصول" width="120" height="97" border="0" title="بزرگنمایی محصول"/></a><input type="hidden" id="products_preview" name="products_preview" value="<?=$record->Saddpic?>" /></td>
   			</tr>
			<tr class="tr">
				<td width="144" align="left" class="td">
			  توضيح محصول (فارسی)&nbsp;&nbsp;</td>
			  <td height="155" valign="top" class="td"><textarea id="comment" dir="rtl" name="comment" onkeypress="return check_ch_products()" cols="60" rows="10"><?="$record->Scomment";?>
			  </textarea></td>
          </tr>
		<tr class="tr">
				<td width="144" height="25" align="left" class="td">
			  توضيح محصول (لاتین)&nbsp;&nbsp;</td>
<td height="25" colspan="2" class="td"><textarea id="comment2" dir="rtl" name="comment2" onkeypress="return check_ch_products()" cols="60" rows="10"><?="$record->Secomment";?>
			  </textarea>
</td>
				</tr> 
		<tr class="tr">
				<td width="144" height="25" align="left" class="td">
			 وضعیت نمایش&nbsp;&nbsp;</td>
<td height="25" colspan="2" class="td">
		<? 
		   if($record->Sstatus == 1){
		  ?>
        <input name="status" type="radio" id="status_0" value="1" checked="checked"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0"/>
        غير فعال
          <?
			}
			else{
			?>
        <input name="status" type="radio" id="status_0" value="1"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0" checked="checked"/>
        غير فعال
          <?
				}
				?>                </td>
				</tr> 
			<tr class="tr">
				<td width="144" height="50" align="left" class="td"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td class="td" width="434" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
		      <td class="td" width="206" ></td>
	</tr> 
<tr class="tr">
			  <td width="144" height="48" class="td">&nbsp;</td>
<td colspan="2" class="td">
       	<input type="hidden" value="0" name="add_products" />	
        <input type="hidden" value="1" name="edit_products" />
         <input type="hidden" id="old_cat" name="old_cat" value="<?= $cat?>" />
         <input type="hidden" id="order" name="order" value="<?="$record->Sorder";?>" />
        <input type="hidden" id="old_name" name="old_name" value="<? echo "$record->Sname";?>" />
		<input name="button" type="submit" class="button" id="button" style="width:90px" value="ويرايش محصول" onclick="return checkForm_products();"  />
		<input style="width:50px" name="reset" type="reset" class="button" value="مجدد" />
		<input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" /></td>
			</tr>
	</table>

  <br/>
</form>
<p>&nbsp;</p>