<?
session_start();
$_SESSION['user'] = false;
$_SESSION['login'] = false;
include('../../dbconnect.php');
$user = $_POST['user'];
$pass = $_POST['pass'];
function existUser($var1,$var2)
{
	unset($totalr);
	$resultr = mysql_query("SELECT user FROM users WHERE user='$var1' and pass='$var2' and status='1' and level=1");
	$totalr = mysql_num_rows($resultr);	
	echo "{success:".$totalr."}";
	if($totalr){
	return true;
	}
	return false;
}
if(!empty($user) && !empty($pass)) 
	{
		if(existUser($user,$pass))
		{
			$_SESSION['user'] = $user; //true
			$_SESSION['login'] = true;	
		}	
	}
	else
	echo "{success : false}";
?>