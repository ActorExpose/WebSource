<? 
include("./editor/fckeditor.php") ;
	$eshow = $_GET['eshow'];
	$scope = $_GET['scope'];
	$page = $_GET['page'];
	$sdate = $_GET['sdate'];
	$fdate = $_GET['fdate'];
	
	if($_GET['id'])
	$id=$_GET['id'];
	else
	$id=$_POST['id'];
	
if($eshow){
	$location="location.href='?q=news-manage&eshow=$eshow&scope=$scope&page=$page'";
	$qs="&eshow=$eshow&scope=$scope&page=$page";
	}elseif($scope==3){
	$location="location.href='?q=news-manage&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page'";
	$qs="&sdate=$sdate&fdate=$fdate&scope=$scope&page=$page";
    }elseif($page){
	$location="location.href='?q=news-manage&page=$page'";
	$qs="&page=$page";
	}else{
	$location="location.href='?q=news-manage'";
	$qs="";
	}
	
	if(isset($_POST['edit_news']) && $_POST['edit_news']=='1' && (strlen($_POST['short_comment']) > 0 ))
{
$caption=$_POST['caption'];
$old_caption=$_POST['old_caption'];
$short_comment=$_POST['short_comment'];
$long_comment=$_POST['long_comment'];
$status=$_POST['status'];
		$p_hour=$_POST['p_hour'];
		$p_min=$_POST['p_min'];
		$p_month=$_POST['p_month'];
		$p_day=$_POST['p_day'];
		$p_year=$_POST['p_year'];
		
		if(strlen($p_hour)<2)
		$p_hour=0 .$p_hour;		
		if(strlen($p_min)<2)
		$p_min=0 .$p_min;
		if(strlen($p_day)<2)
		$p_day=0 .$p_day;		
		if(strlen($p_month)<2)
		$p_month=0 .$p_month;
		
$pubdate = $p_year.$p_month.$p_day.$p_hour.$p_min;

$default_image=$_POST['default_image'];
$new_image=$_FILES['new_image']['tmp_name'];
$news_preview=$_POST['news_preview'];
if($default_image != 1){
if(strlen($new_image)==0){
$new_image=$news_preview;
$file=$new_image;
}else{
		if($news_preview){
	   	unlink("../images/news/thu_".$news_preview);
		unlink("../images/news/".$news_preview);
		unlink("../images/news/sl_".$news_preview);
		}
           if (strlen($_FILES['new_image']['name'])>1){
              $imagename = $_FILES['new_image']['name'];
              $source = $_FILES['new_image']['tmp_name'];
              $target = "../images/news/".$imagename;
              move_uploaded_file($source, $target);
                $save = "../images/news/sl_".$imagename; //This is the new file you saving
              $file = "../images/news/".$imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = 525;
			  $modheight = 302;
 
              $diff = $width / $modwidth;
 
             // $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 
			  
			  $save = "../images/news/".$imagename; //This is the new file you saving
              $file = "../images/news/".$imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = 120;
			  $modheight = 120;
 
              $diff = $width / $modwidth;
 
             // $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 
			  
			  $save = "../images/news/thu_".$imagename; //This is the new file you saving
              $file = "../images/news/".$imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = 81;
			  $modheight = 56;
 
              $diff = $width / $modwidth;
 
             // $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 
 
         //   echo "Large image: <img src='../imgproduct/".$imagepath."'><br>"; 
			$file = $imagename;
 
          }
		  
		}
		}else{
			$file ="";
			if($news_preview){
	   	unlink("../images/news/thu_".$news_preview);
		unlink("../images/news/".$news_preview);
		unlink("../images/news/sl_".$news_preview);
			}
		}
mysql_query ("UPDATE news SET caption='$caption',pubdate='$pubdate', thumb='$file', brief='$short_comment', text='$long_comment',status='$status' WHERE id='$id'");
create_feed();
	unset($_POST['long_comment']);
	?>
    	<br />
		<div id="notice" align="center">
        <p  class="success">خبر <span style="color:#029125"><?=$old_caption?></span> با موفقیت ویرایش گردید</p>
		</div>
    <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
}
	$sql = "SELECT * FROM news WHERE id='$id'";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	$str=$record->brief;
	//echo "$str";
	$str=strlen($str);
	//echo "$str";
	/*echo "<script language='javascript' type='application/javascript'>alert('$str')</script>";*/
	$str=150 - $str;
	if ($str<0)
	$str=0;
	
	$e_year=substr($record->pubdate,0,4);
	$e_month=substr($record->pubdate,4,2);
	$e_day=substr($record->pubdate,6,2);
	$e_hour=substr($record->pubdate,8,2);
	$e_min=substr($record->pubdate,10,2);
	
?>
<form class="form" name="pro" action="" method="post" enctype="multipart/form-data" >
  <input type="hidden" id="id" name="id" value="<? echo "$record->id";?>" />
  <br/>
  <table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="800">
<tr class="tr">
				<td height="15" colspan="4" valign="top" class="td"></td>
			</tr>
			<tr class="tr">
				<td width="150" height="25" align="left" class="td">
			  تیتر خبر&nbsp;&nbsp;</td>
<td height="25" colspan="3" class="td">
					<input name="caption" type="text" class="input" id="caption" value="<?="$record->caption";?>" size="30" />			  </td>
			</tr>
            			<tr class="tr">
				<td width="150" height="25" align="left" class="td">تاریخ انتشار&nbsp;&nbsp;</td>
<td dir="ltr" height="25" colspan="3" class="td">&nbsp;
  <select name="p_year" id="p_year" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
    <? 
for($i=1389;$i<=1400;$i++)
{
	if($e_year == $i)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
  </select>
  &nbsp;/&nbsp;
<select name="p_month" id="p_month" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
<? 
for($i=1;$i<=12;$i++)
{
	if($e_month == $i)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
</select>&nbsp;/&nbsp;
<select name="p_day" id="p_day" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
  <? 
for($i=1;$i<=31;$i++)
{
	if($e_day == $i)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
</select>&nbsp;@&nbsp;
<select name="p_hour" id="p_hour" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
<? 
for($i=0;$i<=23;$i++)
{
	//$hour[$i] = $i;
	if($i == $e_hour)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
</select>&nbsp;:&nbsp;
<select name="p_min" id="p_min" style="font-family:Tahoma,Arial; font-size:8pt" dir="rtl">
<? 
for($i=0;$i<=59;$i++)
{
	if($i == $e_min)
	{
		echo "<option selected='selected' value='$i'>$i</option>";
	}
	else
	{
		echo "<option value='$i'>$i</option>";
	}
}
?>
</select> </td>
		  </tr>
			<tr class="tr">
				<td width="150" height="155" align="left" valign="middle" class="td">خلاصه خبر&nbsp;&nbsp;</td>
			  <td height="155" colspan="3" rowspan="2" valign="top" class="td"><textarea name="short_comment" cols="40" rows="8" id="short_comment" dir="rtl" onkeypress="return check_ch(event)"><?=$record->brief;?></textarea>
        <div>حداکثر <span id="character">
          <?="$str"?>
        </span> کاراکتر</div></td>
		  </tr>
			<tr class="tr">
			  <td height="19" align="left" class="td">&nbsp;</td>
    </tr>
			<tr class="tr">
				<td width="150" height="246" align="left" class="td">مشروح خبر&nbsp;&nbsp;</td>
              <td height="246" colspan="3" valign="top" class="td"><?php 

$sBasePath="./editor/";
$oFCKeditor = new FCKeditor('long_comment') ;
$oFCKeditor->BasePath	= $sBasePath ;
$oFCKeditor->Height	= "400px" ;
$oFCKeditor->Value	= $record->text ;
$oFCKeditor->Create() ;
?></td>
          </tr>
			
						<tr class="tr">
				<td height="10" align="left" class="td">&nbsp;</td>
			    <td height="10" colspan="3" align="left" class="td">&nbsp;</td>
		    </tr>
						<tr class="tr">
						  <td height="25" align="left" class="td">تصویر کوچک&nbsp;&nbsp;</td>
		                  <td width="284" height="3" class="td">
   		   	<? 
						   if($record->thumb == ""){
				  ?> 
                     <input name="new_image" disabled="disabled" type="file" class="fileUpload" id="new_image" size="35" />
      		    <?
			}
			else{
			?>
           		  <input name="new_image" type="file" class="fileUpload" id="new_image" size="35" />
        	  <?
				}
				?>                          </td>
		                  <td width="139" class="td">&nbsp;&nbsp;&nbsp;&nbsp;تصویر پیش فرض 
    		   	<? 
						   if($record->thumb == ""){
				  ?> 
					<input type="checkbox" checked="checked" name="default_image" id="default_image" onclick="disable_browse();" />
      		    <?
			}
			else{
			?>
					<input type="checkbox" name="default_image" id="default_image" onclick="disable_browse();" />
        	  <?
				}
				?>                          </td>
		                  <td width="207" rowspan="5" valign="top" class="td"><div id="img_place" style="width:100px;">
    		   	<? 
						   if($record->thumb == ""){
				  ?> 
                          <img src="../images/news/blank.jpg" alt="<?="بدون تصویر";?>" width="100" height="100" title="<?="بدون تصویر";?>"/>
      		    <?
			}
			else{
			?>
					<a href="../images/news/<?="$record->thumb"?>" target="_blank"><img src="../images/news/<?="$record->thumb";?>" width="100" height="100" border="0" alt="بزرگنمایی تصویر" title="بزرگنمایی تصویر"/></a>
        	  <?
				}
				?>
                          </div>
	                      <input type="hidden" id="news_preview" name="news_preview" value="<?="$record->thumb";?>" /></td>
          </tr>
          			<tr class="tr">
				<td width="150" height="25" align="left" class="td">
			 وضعيت انتشار&nbsp;&nbsp;</td>
				<td height="25" colspan="2" class="td">
        	<? 
		   if($record->status == 1){
		  ?> 
        <input name="status" type="radio" id="status_0" value="1" checked="checked"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0"/>
        غير فعال
          <?
			}
			else{
			?>
        <input name="status" type="radio" id="status_0" value="1"/>
        فعال&nbsp;
        <input name="status" type="radio" id="status_1" value="0" checked="checked"/>
        غير فعال
          <?
				}
				?></td>
          </tr>
						<tr class="tr">
						  <td height="25" align="left" class="td">تعداد دفعات بازدید&nbsp;&nbsp;</td>
                          <td colspan="2" class="td"><?
				$res = mysql_query("SELECT * FROM clicks WHERE parentId='$id' and type ='news'");
				echo mysql_num_rows($res);
						  ?></td>
    </tr>
						<tr class="tr">
						  <td height="25" align="left" class="td">تعداد نظرات</td>
                          <td colspan="2" class="td"><?
				$resultc = mysql_query("SELECT * FROM comments WHERE parentId='$record->id' and type ='news'");
				if(mysql_num_rows($resultc))
				echo '<a href="?q=comments&pid='.$record->id.'&type=news" target="_blank">'.mysql_num_rows($resultc).'</a>';
				else
				echo '0';
						  ?></td>
	</tr>	
			<tr class="tr">
				<td width="150" height="50" align="left" class="td"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td colspan="2" class="td" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
          </tr>
	    <tr class="tr">
			  <td width="150" height="48" class="td">&nbsp;</td>
<td colspan="3" class="td">
              <input type="hidden" id="old_caption" name="old_caption" value="<? echo "$record->caption";?>" /> 
      		<input type="hidden" value="0" name="add_news" />
           <input type="hidden" value="1" name="edit_news" />
      <input name="button" type="submit" class="button" id="button" style="width:95px;" value="ويرايش خبر"  onClick="return checkForm_news();" />
        <input style="width:50px" name="reset" type="reset" class="button" value="مجدد"/>
        <input name="submit2" type="button" class="button" id="submit2" style="width:80px" onclick="<?= $location ?>" value="بازگشت" /></td>
		  </tr>
	</table>
</form>