<?
function per_page($link, $offset) 
{
	global $numofpages, $page;
	
	$pagesstart = round($page-$offset);
	$pagesend = round($page+$offset);
	
	if ($page != "1" && round($numofpages) != "0") 
	{
		echo '<td class="bt_first" align="center" width="24" height="21"><a href="?q=pro-cat-mg&amp;page=1" title="اولین صفحه" style="text-decoration: none;" >&nbsp;<<&nbsp;</a></td>';
		
		echo str_replace("%page", round($page-1), '<td class="bt_prev" align="center" width="24" height="21"><a href="'.$link.'" title=" صفحه قبلی" style="text-decoration: none;" >&nbsp;&nbsp;<&nbsp;&nbsp;</a></td>');
	}
	else{
			echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;<<&nbsp;</td>';
		echo '<td  style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;<&nbsp;&nbsp;</td>';
	}
	
	
	for($i = 1; $i <= $numofpages; $i++) 
	{ 
		if ($pagesstart <= $i && $pagesend >= $i) 
		{
			if ($i == $page) 
			{
				echo "<td class='curpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
			}
			else 
			{
				echo str_replace("%page", "$i", '<td class="numpage" valign="middle" width="24" height="21"><a href="'.$link.'" style="text-decoration: none;" >&nbsp;&nbsp;'.Ct($i).'&nbsp;&nbsp;</a></td>');	
			}
		}
	}
	if (round($numofpages) == "0") 
	{
		echo "<td class='numpage' valign='middle' width='24' height='21'>&nbsp;&nbsp;".Ct($i)."&nbsp;&nbsp;</td>";
	}
	
	if ($page != round($numofpages) && round($numofpages) != "0") 
	{
		echo str_replace("%page", round($page+1), '<td class="bt_next" align="center" width="24" height="21"><a href="'.$link.'" title="صفحه بعدی" style="text-decoration: none;" >&nbsp;&nbsp;>&nbsp;&nbsp;</a></td>');
		echo '<td class="bt_last" align="center" width="24" height="21"><a href="?q=pro-cat-mg&amp;page='.round($numofpages).'" title="آخرین صفحه" style="text-decoration: none;" >&nbsp;>>&nbsp;</a></td>';
	}else{
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;&nbsp;>&nbsp;&nbsp;</td>';
		echo '<td style="border:#c8dbdf 1px solid;color:#c8dbdf;" align="center" width="24" height="21">&nbsp;>>&nbsp;</td>';
	}
}
$pp = "10";
//******************************************************
	if(isset($_POST['add_cat']) && $_POST['add_cat']=='1' && (strlen($_POST['name']) > 0 ))
{
$name=$_POST['name'];
$ename=$_POST['ename'];
$comment=$_POST['comment'];
$status=$_POST['status'];
unset($totalr);
$resultr=mysql_query("SELECT Cid FROM tbcat WHERE Cname = '$name'");
$totalr = mysql_num_rows($resultr);
if(!$totalr){

          if (isset ($_FILES['new_image'])){
              $imagename = $_FILES['new_image']['name'];
              $source = $_FILES['new_image']['tmp_name'];
              $target = "../images/category/".$imagename;
              copy($source, $target);
			  
              $save = "../images/category/".$imagename; //This is the new file you saving
              $file = "../images/category/".$imagename; //This is the original file
 
              list($width, $height) = getimagesize($file) ; 
 
              $modwidth = 100;
			  $modheight = 100;
 
             // $diff = $width / $modwidth;
 
             // $modheight = $height / $diff; 
              $tn = imagecreatetruecolor($modwidth, $modheight) ; 
			  
              $image = @imagecreatefromjpeg($file) ; 
			  if(! $image){
              $image = @imagecreatefromgif($file) ; 
			  if(! $image){
              $image = @imagecreatefrompng($file) ; 
			  if(! $image){
              $image = @imagecreatefromwbmp($file) ; 
			  }
			  }
			  }
			  
              imagecopyresampled($tn, $image, 0, 0, 0, 0, $modwidth, $modheight, $width, $height) ; 
			  
              imagejpeg($tn, $save, 100) ; 

			$file = $imagename;
			//echo $file;
        }
		
	//$short_comment=trim($short_comment);
	//	$long_comment=trim($long_comment);
	$sql = "SELECT Corder FROM tbcat ORDER BY Corder DESC";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	$order=$record->Corder+1;
	
	mysql_query ("INSERT INTO tbcat (Corder,Cname,Cename,Caddcat,Ccomment,Cstatus) VALUES ('$order','$name','$ename','$file','$comment','$status')");
	mkdir("../images/products/".mysql_insert_id(), 0755);
	unset($_POST['name']);
	?>	
    	<br />
		<div id="notice" align="center">
        <p  class="success">دسته <span style="color:#029125"><?=$name?></span> با موفقیت ثبت گردید</p>
		</div>
        <?
	}else{?>
	<div id="notice" align="center">
		</div>
       <?
	   }
}else{?>
	<div id="notice" align="center">
		</div>
       <?
}

if(isset($_GET['del']) && $_GET['del'] != 0){

$del=$_GET['del'];
$resultc=mysql_query("SELECT * FROM tbcat WHERE Cid ='$del'");
	$numc = mysql_num_rows($resultc);
	if($numc>0){
$recordc = mysql_fetch_object($resultc);
$idc=$recordc->Cid;
$sorder=$recordc->Corder;
$addcat=$recordc->Caddcat;
//*******************************
$resulto=mysql_query("SELECT * FROM tbcat WHERE Corder > '$sorder'");
	$numo = mysql_num_rows($resulto);
	if($numo>0){
while($recordo = mysql_fetch_object($resulto)){
	$oid=$recordo->Cid;
	$neworder=$recordo->Corder - 1;
	mysql_query ("UPDATE tbcat SET Corder='$neworder' WHERE Cid ='$oid'");
}
}
//*******************************
$resultf=mysql_query("SELECT * FROM products WHERE Scat = '$idc'");
	$numf = mysql_num_rows($resultf);
	if($numf>0){

mysql_query("DELETE FROM products WHERE Scat = '$idc'");
}
$files = glob('../images/products/'.$idc.'/*'); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}
mysql_query("DELETE FROM tbcat WHERE Cid='$del'");
rmdir('../images/products/'.$idc);
}
$_GET['del'] = 0;
echo "<script language=\"javascript\" >location.href='#catlist'</script>";
}
if(isset($_GET['order']) && $_GET['order'] != 0){

	$dirt=$_GET['dirt'];
	$id=$_GET['order'];
	$resulto=mysql_query("SELECT Cid FROM tbcat");
	$recordo = mysql_num_rows($resulto);
	if(!($recordo==1)){
	if ($dirt == "up" && $id > 0){
	$pid= $id - 1;
	//echo "up";
	}elseif($dirt == "down" && $id > 0){
	$pid= $id + 1;
	//echo "down";
	}
	mysql_query ("UPDATE tbcat SET Corder='0' WHERE Corder='$pid'");
	mysql_query ("UPDATE tbcat SET Corder='$pid' WHERE Corder='$id'");
	mysql_query ("UPDATE tbcat SET Corder='$id' WHERE Corder='0'");
	}
$_GET['order'] = 0;
echo "<script language=\"javascript\" >location.href='#catlist'</script>";
}
if(isset($_GET['status']) && $_GET['status'] != 0){

	$id=$_GET['status'];
	
	$sql = "SELECT * FROM tbcat WHERE Cid='$id'";
	$result = mysql_query($sql); 
	$record = mysql_fetch_object($result);
	if($record->Cstatus == 1){
	mysql_query ("UPDATE tbcat SET Cstatus='0' WHERE Cid='$id'");
	}
	if($record->Cstatus == 0){
	mysql_query ("UPDATE tbcat SET Cstatus='1' WHERE Cid='$id'");
	}
echo "<script language=\"javascript\" >location.href='#catlist'</script>";	
$_GET['status'] = 0;	
}
?>
<form class="form" name="cat" action="?q=pro-cat-mg" method="post" enctype="multipart/form-data" onsubmit="return  false;">
<br/>
<table cellpadding="0" cellspacing="4" border="0" dir="rtl" width="100%;">
			<tr>
				<td height="15" colspan="3" valign="top"></td>
			</tr>
            			<tr>
				<td width="28%" height="25" align="left">
			   عنوان دسته (فارسی)&nbsp;&nbsp;</td>
<td height="25" colspan="2">
					<input type="hidden" id="cat_preview" name="cat_preview" value="test" />
					<input name="name" type="text" class="input" id="name" size="30" />			  </td>
			</tr>
            	<tr>
				<td width="27%" height="25" align="left">عنوان دسته (لاتین)&nbsp;&nbsp;</td>
<td height="25" colspan="4">
					<input type="hidden" id="cat_preview" name="cat_preview" value="test" />
				  <input name="ename" type="text" class="input" id="ename" size="30" /></td>
			</tr>
            			<tr>
				<td width="28%" height="25" align="left">
			 وضعیت&nbsp;&nbsp;</td>
<td height="25" colspan="2">
			      <input name="status" type="radio" id="status_0" value="1" checked="checked" />
			      فعال&nbsp;
			    <input name="status" type="radio" id="status_1" value="0" />
غير فعال</td>
				</tr>
			<tr>
				<td width="28%" height="50" align="left"><span style="color:#FF0000">* توضیح&nbsp;&nbsp;</span></td>
			  <td width="28%" id="myPageElement"><span style="color:#000">لطفا تمام فیلدها را پر نمایید .</span></td>
		      <td width="44%" ></td>
	</tr>
<tr>
			  <td width="28%" height="48">&nbsp;</td>
<td colspan="2">
			<input type="hidden" value="0" name="edit_cat" />
       		<input type="hidden" value="1" name="add_cat" />
       		<input name="button" type="submit" class="button" id="button" style="width:70px" value="ثبت دسته" onclick="return checkForm_cat()" />
       		<input style="width:50px" name="reset" type="reset" class="button" value="مجدد" /></td>
			</tr>
	</table>
</form>
<p>&nbsp;</p>
	<fieldset dir="rtl" class="fieldset">
		<legend class="legend">&nbsp;&nbsp;ليست دسته هاي موجود&nbsp;&nbsp;</legend> 
		<br/>
        <br/>
<a name="catlist"></a>
<table width="602" align="center" cellpadding="0" cellspacing="0" dir="ltr" class="mtable">
  <tr class="mtitle">
    <td width="50" height="25" align="center" style="border-left:none;">حذف</td>
    <td width="50" align="center">ويرايش</td>
    <td width="50" align="center">وضعيت</td>
    <td width="370" align="center">نام دسته</td>
    <td width="50" align="center">ترتیب</td>
    <td width="30" align="center">رديف</td>
  </tr>
  <?
  //******************************************************
  
	$result = mysql_query("SELECT * FROM tbcat ORDER BY Corder DESC"); 
	$totalp = mysql_num_rows($result);

//******************************************************************
$numofpages = ceil($totalp / $pp); 
if (!isset($_GET['page']))
{ 
	$page = 1; 
} 
else 
{ 
	$page = $_GET['page']; 
} 
$limitvalue = $page * $pp - ($pp);

   	$result = mysql_query("SELECT * FROM tbcat ORDER BY Corder DESC LIMIT $limitvalue, $pp"); 
	$total = mysql_num_rows($result);

//******************************************************************
	
		$row=1;
while ($record = mysql_fetch_object($result)) 
{
		if($total != 0)
		{
		if(fmod($total,2.0)==1){
?>
  <tr class="odd">
    <td height="25" align="center" style="border-left:none;">
        <?
	if($_GET['page']){
   echo  "<a href='?q=pro-cat-mg&del=$record->Cid&amp;page=$page'";
   }else{
   echo  "<a href='?q=pro-cat-mg&del=$record->Cid'";
	  }
	echo  "onclick=\"return confirm('با حذف دسته ($record->Cname) تمامی  محصولات  موجود در این دسته  حذف خواهد شد ؟')\"> ";
	?>
    <img src="./layout/delete.gif" width="16" height="16" alt="حذف" title="حذف" border="0" /></a></td>
    <td align="center">
    <?
	if($_GET['page']){
   echo  "<a href='?q=pro-cat-edit&amp;edit=$record->Cid&amp;page=$page'>";
   }else{
   echo  "<a href='?q=pro-cat-edit&amp;edit=$record->Cid'>";
	  }
	?>
    <img src="./layout/pedit.gif" alt="ويرايش" title="ويرايش" width="16" height="16" border="0" /></a></td>
    <td align="center">
    <?
	if($_GET['page']){
   echo  "<a href='?q=pro-cat-mg&amp;status=$record->Cid&amp;page=$page'>";
   }else{
   echo  "<a href='?q=pro-cat-mg&amp;status=$record->Cid'>";
	  }
	if ($record->Cstatus == 1){
   echo "<img src='./layout/enabled.gif' alt='فعال' title='فعال' width='16' height='16' border='0' />";
    }
	else{
	echo "<img src='./layout/disabled.gif' alt='غير فعال' title='غير فعال' width='16' height='16' border='0' />";
    }
	?>
    </a></td>
    <td style="direction:rtl;" align="center"><?="$record->Cname";?></td>
    <td align="center">
    <?
    if($record->Corder!=1)
	{
	if($_GET['page']){
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=up&amp;page=$page'>";
	}
	else{
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=up'>";
	}
	?>
    <img src="../images/bottom-order.gif" width="9" height="8" border="0" /></a>
    <?
	}
	else{
	if($_GET['page']){
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=down&amp;page=$page'>";
	}
	else{
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=down'>";
	}
	?>
    <img src="../images/top-order.gif" width="9" height="8" border="0" /></a>
   <?
   }
   ?>   </td>
    <td align="center"><?=Ct($row);?></td>
  </tr>
  <?
  }
  else{
  ?>
  <tr class="even">
    <td height="25" align="center" style="border-left:none;">
           <?
	if($_GET['page']){
   echo  "<a href='?q=pro-cat-mg&del=$record->Cid&amp;page=$page'";
   }else{
   echo  "<a href='?q=pro-cat-mg&del=$record->Cid'";
	  }
	echo  "onclick=\"return confirm('با حذف دسته ($record->Cname) تمامی محصولات موجود در این دسته  حذف خواهد شد ؟')\"> ";
	?>
   <img src="./layout/delete.gif" width="16" height="16"  alt="حذف" title="حذف" border="0" /></a></td>
    <td align="center">
    <?
	if($_GET['page']){
   echo  "<a href='?q=pro-cat-edit&amp;edit=$record->Cid&amp;page=$page'>";
   }else{
   echo  "<a href='?q=pro-cat-edit&amp;edit=$record->Cid'>";
	  }
	?>
    <img src="./layout/pedit.gif" width="16" height="16"  alt="ويرايش" title="ويرايش" border="0" /></a></td>
    <td align="center">
        <?
	if($_GET['page']){
   echo  "<a href='?q=pro-cat-mg&amp;status=$record->Cid&amp;page=$page'>";
   }else{
   echo  "<a href='?q=pro-cat-mg&amp;status=$record->Cid'>";
	  }
	if ($record->Cstatus == 1){
   echo "<img src='./layout/enabled.gif' alt='فعال' title='فعال' width='16' height='16' border='0' />";
    }
	else{
	echo "<img src='./layout/disabled.gif' alt='غير فعال' title='غير فعال' width='16' height='16' border='0' />";
    }
	?>
    </a></td>
    <td style="direction:rtl;" align="center"><?="$record->Cname";?></td>
    <td align="center">
<?
    if($record->Corder!=1)
	{
	if($_GET['page']){
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=up&amp;page=$page'>";
	}
	else{
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=up'>";
	}
	?>
    <img src="../images/bottom-order.gif" width="9" height="8" border="0" /></a>
    <?
	}
	else{
	if($_GET['page']){
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=down&amp;page=$page'>";
	}
	else{
    echo "<a href='?q=pro-cat-mg&order=$record->Corder&dirt=down'>";
	}
	?>
    <img src="../images/top-order.gif" width="9" height="8" border="0" /></a>
   <?
   }
   ?></td>
    <td align="center"><?=Ct($row);?></td>
  </tr>
  <?
  }
	}	
	$total--;
	$row++;
}	
?>
</table>
	<br/>

<?
if ($numofpages > 1){
echo "<table dir='ltr' border='0' height='21' cellpadding='0' align='center'><tr>";
per_page("?q=pro-cat-mg&amp;page=%page", 8);
echo "</tr></table>"; 
}
?> 
    <br />
        <br />
  </fieldset>