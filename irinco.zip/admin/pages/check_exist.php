<?php 
include('../../config.php');


$action=$_POST['action'];
unset($totalr);
if($action=="cat"){
$name=$_POST['name'];
$resultr=mysql_query("SELECT * FROM tbcat WHERE Cname='$name'");
}elseif($action=="user"){
$user=$_POST['user'];
$resultr=mysql_query("SELECT * FROM users WHERE user='$user'");
}elseif($action=="vtour"){
$name=$_POST['name'];
$resultr=mysql_query("SELECT * FROM vtour WHERE Sname='$name'");
}
$totalr = mysql_num_rows($resultr);
		echo "{success:".$totalr."}";
?>