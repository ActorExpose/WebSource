// layerModal
var layerModal = {
    fecha: function (oId) {
        var elem = $('#' + oId), elemIn = $('#' + oId).find('>.in');
        elemIn.hide();
        elem.hide();
    },
    abre: function (oId) {
        var elem = $('#' + oId), elemIn = $('#' + oId).find('>.in');
        if (oId == 'newsletterModal') newsletterForm.reInit();

        if (tmpview.isMobile) {
            $('.modal > .bg').css({ height: $('.wrapper').outerHeight(), width: tmpview.w });
        }
        tmpview.htmlBody.stop().animate({ scrollTop: 0 }, 1000, 'easeOutExpo');
        elem.show();
        elemIn.show();
    }
}

// goMore
var goMore = {
    btn: $('#goMore'),
    init: function (x) {
        if (x == 0 && !tmpview.isMobile) { // 0 - home
            goMore.btn.show();
            goMore.btn.bind('click', function () {
                if (!homepage.ing) {
                    if (tmpview.adjust) {
                        homepage.animaDown();
                    } else {
                        //var fullblockH = homepage.cont.height();
                        tmpview.htmlBody.stop().animate({ scrollTop: fullblockH }, 1000, 'easeOutSine');
                    }
                }
            });
        } else if (x == 1 && !tmpview.isMobile) { // 1 - hotelDetail
            goMore.btn.show();
            goMore.btn.bind('click', function () {
                alert();
                if (!hotelsDetail.ing) {
                    if (tmpview.adjust) { // se estiver na zona de topo/principal
                        hotelsDetail.animaDown();
                    } else {
                        var fullblockH = hotelsDetail.cont.height();
                        tmpview.htmlBody.stop().animate({ scrollTop: fullblockH }, 1000, 'easeOutSine');
                    }
                }
            });
        }
    }
}
// tmpview
var tmpview = {
    win: $(window),
    doc: $(document),
    htmlBody: $('html, body'),
    elHtml: $('html'),
    bod: $('body'),
    ddowns: $('.ddown1, .ddown2, .ddown3'),
    reserv: $('body').find('> .reserv'),
    page: '',
    isMobile: false,
    ie78: false,
    goTop: $('#goTop'),
    scrollTop: 0,
    w: 0,
    h: 0,
    contH: 0,
    fullH: false,
    adjust: true,
    spacer: 'Images/spacer.jpg',
    ha: function (x) { if ($(x).length > 0) return true; },
    permite: function (e, allow) { // ha
        var k;
        k = e.keyCode ? parseInt(e.keyCode) : parseInt(e.charCode);
        if (!((k > 36 && k < 47) || (k > 7 && k < 10))) { // para alem do allow, permite delete, tab, arrows, etc
            return (allow.indexOf(String.fromCharCode(k)) != -1);
        }
    },
    permiteNot: function (e, allow) { // permiteNot
        var k;
        k = e.keyCode ? parseInt(e.keyCode) : parseInt(e.charCode);
        if (!((k > 36 && k < 47) || (k > 7 && k < 10))) { // para alem do allow, permite delete, tab, arrows, etc
            return !(allow.indexOf(String.fromCharCode(k)) != -1);
        }
    },
    nrs: '1234567890',
    nrsTel: '1234567890 .-()',
    datas: '1234567890 -/',
    changeBreadCrumbs: function () {
        if (tmpview.ha(tmpview.breadcrumbs)) {
            var bc = '<ul><li class="home"><a href="/">home</a></li>';
            for (var i = 0; i < tmpview.urls.length; i += 1) {
                bc += '<li><a href="' + tmpview.urls[i][1] + '">' + tmpview.urls[i][0] + '<span>&nbsp;</span></a></li>';
            }
            bc += '</ul>';
            tmpview.breadcrumbs.replaceWith(bc);
            setTimeout(function () {
                tmpview.breadcrumbs = $('.breadcrumbs > ul');
            }, 100);
        }
    },
    changeUrl: function (oUrl) {
        // change url stuff
        window.location.hash = oUrl;
    },
    logout: function () {
        $("#btnLogout").click(function () {
            loginForm.loggedBtn.fadeOut(600);
            loginForm.buttons.fadeIn(600);
        });
    },
    doScrollInit: function () {
        tmpview.goTop.bind('click', function () {
            tmpview.htmlBody.stop().animate({ scrollTop: 0 }, 1000, 'easeOutSine');
            tmpview.goTop.stop().fadeTo(600, 0, function () {
                tmpview.goTop.hide();
            });
        });
        tmpview.win.scroll(tmpview.doScroll);
        tmpview.doScroll();
    },
    doScroll: function () {
        tmpview.scrollTop = tmpview.win.scrollTop();
        if (!tmpview.isMobile) {
            if (tmpview.scrollTop > 600) {
                tmpview.goTop.stop().fadeTo(600, 1);
            } else {
                tmpview.goTop.stop().fadeTo(600, 0, function () {
                    tmpview.goTop.hide();
                });
            }
        }
    },
    doResize: function (handler) {
        tmpview.w = tmpview.win.width();
        tmpview.contH = tmpview.win.height();
        if (hotelsFind.view == 1 && tmpview.contH < 800) {
            tmpview.contH = 800;
            tmpview.adjust = false;
            tmpview.bod.addClass('flow');
        } else if (tmpview.isMobile || tmpview.contH < 700) {
            tmpview.contH = 700;
            tmpview.adjust = false;
            tmpview.bod.addClass('flow');
        } else {
            tmpview.adjust = true;
            tmpview.bod.removeClass('flow');
        }
        switch (tmpview.page) {
            case 'home':
                /*if(homepage.destqsVis&&tmpview.adjust) {
                    homepage.cont.css({height:tmpview.contH});
                }
                if(tmpview.w<1050){
                    homepage.destqs.removeClass().addClass('smallest');
                } else if(tmpview.w<1200){
                    homepage.destqs.removeClass().addClass('smaller');
                } else if(tmpview.w<1350){
                    homepage.destqs.removeClass().addClass('small');
                } else if(tmpview.w<1500){
                    homepage.destqs.removeClass();
                } else if(tmpview.w<1650){
                    homepage.destqs.removeClass().addClass('big');
                } else if(tmpview.w<1800){
                    homepage.destqs.removeClass().addClass('bigger');
                } else {
                    homepage.destqs.removeClass().addClass('biggest');
                }*/
                break;
            case 'detail':
                /*if(hotelsDetail.destqsVis&&tmpview.adjust) {
                    hotelsDetail.cont.css({height:tmpview.contH});
                } else if (!tmpview.adjust) {
                    hotelsDetail.about.stop().css({paddingTop:20});
                }
                if(tmpview.w<1050){
                    hotelsDetail.titulo.removeClass().addClass('title smallest');
                } else if(tmpview.w<1200){
                    hotelsDetail.titulo.removeClass().addClass('title smaller');
                } else if(tmpview.w<1350){
                    hotelsDetail.titulo.removeClass().addClass('title small');
                } else if(tmpview.w<1500){
                    hotelsDetail.titulo.removeClass().addClass('title');
                } else if(tmpview.w<1650){
                    hotelsDetail.titulo.removeClass().addClass('title big');
                } else if(tmpview.w<1800){
                    hotelsDetail.titulo.removeClass().addClass('title bigger');
                } else {
                    hotelsDetail.titulo.removeClass().addClass('title biggest');
                }*/
                break;
            case 'find':
                if (hotelsFind.view == 1) {
                    hotelsFind.cont.stop().css({ height: tmpview.contH - 140 - 4 }, 600);
                    if (tmpview.ha(hFilters.subLists)) {
                        hFilters.mapAreaH = Number(tmpview.contH - 706 + 34);
                        if (hFilters.mapAreaH < 60) hFilters.mapAreaH = 60;
                        hFilters.subLists.addClass('mapArea').css({ 'max-height': hFilters.mapAreaH });
                    }
                }
                break;
            case 'reserv':
                tmpview.reserv.find('> .intro').css({ height: 'auto' });
                var wrapH = $('.wrapper').outerHeight();
                if (wrapH < tmpview.contH) {
                    tmpview.reserv.find('> .intro').css({ height: tmpview.contH - 612 });
                }
                break;
            default:
                break;
        }
        if (typeof handler == 'function') setTimeout(handler, 50);
    },
    resizeInit: function () {
        switch (tmpview.page) {
            case 'home':
                if (!tmpview.isMobile) {
                    tmpview.win.bind('smartresize', function () {
                        tmpview.doResize(homepage.doScroll);
                    });
                }
                tmpview.doResize(homepage.doScroll);
                tmpview.win.scroll(homepage.doScroll);
                //homepage.doScroll();
                break;
            case 'detail':
                /*if(!tmpview.isMobile){
                    tmpview.win.bind('smartresize', function(){
                        tmpview.doResize(hotelsDetail.doScroll);
                    });
                }
                tmpview.doResize(hotelsDetail.doScroll);
                tmpview.win.scroll(hotelsDetail.doScroll);
                hotelsDetail.doScroll();*/
                break;
            case 'find':
                if (!tmpview.isMobile) {
                    tmpview.win.bind('smartresize', function () {
                        tmpview.doResize();
                    });
                }
                tmpview.doResize();
                break;
            case 'reserv':
                if (!tmpview.isMobile) {
                    tmpview.win.bind('smartresize', function () {
                        tmpview.doResize();
                    });
                }
                tmpview.doResize();
                break;
            default:
                break;
        }
    },
    gootobook: function () {
        tmpview.htmlBody.animate({
            scrollTop: $(".findYour").offset().top-200
        }, 2000);
    },
    init: function () {
        /* isMobile? */
       

        if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|J2ME|Windows Mobile|Windows Phone)/)) {
            tmpview.isMobile = true;
            var viewportmeta = document.querySelector('meta[name="viewport"]');
            tmpview.bod.addClass('mobile');
            tmpview.elHtml.removeClass('msvopacity');
            if (navigator.userAgent.match(/(iPhone|iPod|iPad)/)) { tmpview.bod.addClass('ipad'); }
            
            $('.block1[onclick], #sliderBlock3 li[onclick], .msv-carousel header[onclick], .block14[onclick], .block15[onclick], #findView li[onclick], .btnDdown3[onclick], .btnOption[onclick], .findRefine header[onclick],.filters li[onclick], .results li[onclick], .show li[onclick], .btn5[onclick], .block8[onclick], .block9[onclick], #gotobook[onclick]').hammer().on("tap", function (event) {
                var handler = $(this).attr('onclick');
                eval(handler);
            });
            $('a.btn15').hammer().on("tap", function (event) {
                var handler = $(this).attr('href');
                window.open(handler, '_self');
            });

            $('.not-touch').hide();
            $('.is-touch').show();
            $('.is-touch select').uniform();

            $('#langipad select').change(function () {
                location.href = $(this).val();
            });

        } else {
            /* isMac? */
            if ($.client.os == 'Mac') {
                tmpview.elHtml.addClass('mac');
            }
            /* isSafari? */
            var userAgent = navigator.userAgent.toLowerCase();
            $.browser.chrome = /chrome/.test(navigator.userAgent.toLowerCase());
            if ($.browser.chrome) {
                $.browser.safari = false;
                tmpview.elHtml.addClass('chrome');
            }
            if ($.browser.safari) {
                tmpview.elHtml.removeClass('msvopacity chrome').addClass('safari');
            }
            /* is ie78? */
            if ($.browser.msie) {
                if ($.browser.version < 9) {
                    tmpview.ie78 = true;
                } else {
                    tmpview.elHtml.addClass('ie9');
                }
            }
        }


        $('.tip').each(function () {
            $(this).msvTip(); // msv plugin
        });

        // ddowns 
        var qtsDdowns = tmpview.ddowns.length,
            nDdowns = 0,
            funcDdowns = function () {
                nDdowns += 1;
                if (nDdowns < qtsDdowns) {
                    setTimeout(function () {
                        tmpview.ddowns.eq(nDdowns).msvDropDown(nDdowns); // msv plugin
                        tmpview.ddowns.eq(nDdowns).msvDropKeyScroll(funcDdowns); // msv plugin
                    }, 100);
                }
            };

        setTimeout(function () {
            tmpview.ddowns.eq(nDdowns).msvDropDown(nDdowns); // msv plugin
            tmpview.ddowns.eq(nDdowns).msvDropKeyScroll(funcDdowns); // msv plugin
        }, 200);

        //logout
        if (tmpview.ha('#logged')) tmpview.logout();

        // modals
        if (tmpview.ha('#newsletterForm')) newsletterForm.init();

        // inst/forms
        //if (tmpview.ha('#searchForm')) searchForm.init();
        if (tmpview.ha('#bookForm')) bookForm.init();
        if (tmpview.ha('#offersAvailForm')) offersAvailForm.init();
        if (tmpview.ha('#contactosForm')) contactForm.init();

        //if (tmpview.ha('#contactosHotForm')) contactHotForm.init();

        if (tmpview.ha('#hoteliersForm')) hoteliersForm.init();
        if (tmpview.ha('#publicidadeForm')) pubForm.init();
        if (tmpview.ha('#recrutaForm')) trabForm.init();
        if (tmpview.ha('#pressForm')) pressForm.init();
        if (tmpview.ha('#reservForm')) reservForm.init();
        if (tmpview.ha('#findViewForm')) findViewForm.init();

        // homepage
        if (tmpview.ha('#homeDestqs')) homepage.init();

        // hotelsDetail
        if (tmpview.ha('.hotelMain')) hotelsDetail.init();
        if (tmpview.ha('#hotelDetailsTab1')) $('#hotelDetailsTab1 ul > li').last().addClass('last');

        // hotelsFind
        if (tmpview.ha('#findRefine')) hotelsFind.init();
        // tailorMade
        if (tmpview.ha('#tailorForm')) tailorForm.init();
        if (tmpview.ha('#comboForm')) comboForm.init();

        // reserv
        if (tmpview.ha(tmpview.reserv)) {
            tmpview.page = 'reserv';
            tmpview.resizeInit();
        }

        // addthis init
        if (tmpview.ha('.addthis_toolbox')) {
            setTimeout(function () {
                addthis.init();
            }, 2200);
        }

        if (tmpview.ha('.sliderBlock1')) $('.block6').find('.price > .value').msvCoinSize();
        if (tmpview.ha('.offersDetail')) $('.lateralOffer').find('.price > .value').msvCoinSize();
        if (tmpview.ha('.reservForm')) $('.lateralReserv').find('.price > .value').msvCoinSize();
        if (tmpview.ha('.ccForm')) $('.lateralReserv').find('.price > .value').msvCoinSize();
        if (tmpview.ha('.views')) $('.block15 .value').msvCoinSize();

        if (tmpview.ha('#sliderBlock1')) $('#sliderBlock1').msvSlideBlock(1012, 0, false); // msvSlideBlock plugin (distancia,delay,autoAnim)
        if (tmpview.ha('#sliderBlock5')) $('#sliderBlock5').msvSlideBlock(990, 0, false);
        if (tmpview.ha('#sliderBlock6')) $('#sliderBlock6').msvSlideBlock(918, 0, false);
        if (tmpview.ha('#sliderBlock8')) $('#sliderBlock8').msvSlideBlock(1012, 0, false);
        if (tmpview.ha('#sliderBlock9')) $('#sliderBlock9').msvSlideBlock(990, 0, false);
        if (tmpview.ha('#sliderBlock10')) $('#sliderBlock10').msvSlideBlock10(0, false);
        if (tmpview.ha('.galHoriz')) $('.galHoriz').msvGalHoriz(640, 144, 4); // msvGalHoriz plugin (aLargura,aLargThumbs,thumbsVisiveis)
        if (tmpview.ha('.circleSlider')) $('.circleSlider').msvSlideBlock(500, 0, false);
        if (tmpview.ha('.msv-carousel')) $('.msv-carousel').carouselPlugin();

        if (tmpview.ha('.findYour')) {
            var nameCont = $('.findYour .name');
            var textName = nameCont.text();
            var countchars = textName.length;
            if (countchars > 24 && countchars < 30) nameCont.css({ 'font-size': 18 });
            if (countchars > 30) nameCont.css({ 'font-size': 16 });
        }

        //Custom check and radio buttons
        if (tmpview.ha('input[type=checkbox]')) $('input[type=checkbox]').customInput();
        if (tmpview.ha('input[type=radio]')) $('input[type=radio]').customInput();

        tmpview.doScrollInit();

    }
}
/* onDomReady */
$(function () {
    tmpview.init();
});