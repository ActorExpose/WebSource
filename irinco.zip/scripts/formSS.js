function callBackFormSS(handler) {

    var params = {
        title: $("#titleCallBackId").val(),
        name : $("#name1CallBackInput").val(),
        lastName : $("#name2CallBackInput").val(),
        countryPhoneNumber: $("#phone1CallBackInput").val(),
        phoneNumber: $("#phone2CallBackInput").val(),
        email: $("#emailCallBackInput").val(),
        contactDay: $("#dayCallBackInput").val(),
        contactHour: $("#hour1CallBackInput").val() + ":" + $("#hour2CallBackInput").val(),
        propertyOfInterest : $("#propertyCallBackInput").val(),
        Observations: $("#observationsCallBackInput").val(),
        location: $("#locatCallBackInput").val(),
        countryId: $("#countryCallBackId").val(),
        culture: culture
    };

    if (params.title != undefined && params.title != null) {
        params.title = params.title.replace("titleCallBack", "");
    }

    var url = "/base/services/GlobalAssistance.aspx";
    $.post(url, params, function (data) {
        if (data != '') {
            data = eval('(' + data + ')');
            handler(data);
        }
        else {
            handler({ Message: "Erro Servidor", Status: false });
        }
        isSendComment = false;
    });

}

function dropSelectedtext(imputId) {
    var elem = $("#" + imputId);
    var selId = elem.val();
    return elem.next().find("li[id=" + selId + "]").text();
}


/// ----------------------------------------- Search Module -----------------------------------------


$(document).ready(function () {

    showhideInputDefaultValue($("#keywordSearch"));
    bindReservDatesChange();
    hideShowReset();
    setVideoOnClick();
    searchBar.init();
});

function showhideInputDefaultValue(elem) {   
/* incorporei antigo quicksearch */
    
    //Para o enter n�o fazer submit do form
    $(".searchForm").submit(function () {     
        return false;
    });

    var url =qUrlBase+"pquickSearch",
        sugestCol = $('#searchForm').find('> .col1'),
        sugestElem = $('.sugestion'),
        sugestUL = $('.sugestion').find('ul'),
        sugestLoader = $('#sugestLoader'),
        sugestTimer = 0,
        waitToSearch = 0,
        requestGet = false,
        sugestTimrStart = function(x){
                        clearTimeout(sugestTimer);
                        sugestTimer = setTimeout(function(){
                            sugestUnbindHov();
                            sugestHide();
                        },x);  
                    },
        sugestBindHov = function(){
                            sugestUnbindHov();
                            if(!tmpview.isMobile){
                                sugestCol.bind('mouseenter', function(){
                                    clearTimeout(sugestTimer);
                                });  
                                sugestElem.bind('mouseenter', function(){
                                    clearTimeout(sugestTimer);
                                });
                                sugestCol.bind('mouseleave', function(){
                                    sugestTimrStart(2000);
                                });                 
                                sugestElem.bind('mouseleave', function(){
                                    sugestTimrStart(2000);
                                });                            
                            }
                            sugestElem.bind('mousedown',function(){
                                clearTimeout(sugestTimer);
                            });
                        },
        sugestUnbindHov = function(){
                            sugestCol.unbind('mouseenter');
                            sugestElem.unbind('mouseenter');
                            sugestElem.unbind('mousedown');
                            sugestCol.unbind('mouseleave');     
                            sugestElem.unbind('mouseleave');
                        },              
        sugestHide = function() {
                        sugestElem.fadeTo(400,0,function(){
                            sugestElem.hide();
                        });
                    },
        code = 0,
        osLis = 0,
        osLisCount = 0,
        oText = '',
        aux = '',
        actual = -1,
        aLista = $('.sugestion').find('> .cont'),
        aListaH = 76,
        actualTop = 0,
        oEnter = false,
        hoverNormal = true,
        goHoverNormal = function(){
                hoverNormal = true;
                osLis.removeClass('actual');
                sugestUL.removeClass('keyUp');
        },         
        goHoverStop = function(){
                hoverNormal = false;
                sugestUL.addClass('keyUp');
        },         
        goToLi = function(){
                if(hoverNormal) goHoverStop();
                osLis.removeClass('actual');
                osLis.eq(actual).addClass('actual');
                // coloca lista na pos0 - necessario para calcular position().top dos lis
                aLista.scrollTop(0);
                actualTop = osLis.eq(actual).position().top;
                if(actualTop>Number(aListaH-70)) {
                    aLista.scrollTop(-Number(aListaH-70-actualTop));
                }
        },
        liIndex = [],
        mouseLi = function(){
                    aLista.on('mousewheel', function(event, delta) {
                        aLista.scrollTop(Number(aLista.scrollTop()+( delta < 0 ? 1 : -1 ) * 30));
                        event.preventDefault();
                        return false;
                    });
                    goHoverStop(); 
                    aLista.on('mouseenter', function() {
                        tmpview.htmlBody.bind('mousewheel', function(event, delta) {
                            return false;
                        });
                    });
                    aLista.on('mouseleave', function() {
                        tmpview.htmlBody.unbind('mousewheel');
                    });
                },        
        touchLi = function(intIndex){
                    liIndex[intIndex] = false;
                    osLis.eq(intIndex).on('touchstart', function(e) {
                         liIndex[intIndex] = true; 
                    });                                    
                    osLis.eq(intIndex).on('touchend', function(e) {
                         if(liIndex[intIndex]){  // se nao arrastou: click
                            $(this).trigger('click');
                         }
                    }); 
                    osLis.eq(intIndex).on('touchmove', function(e) {
                         liIndex[intIndex] = false;
                    });
                };

    elem.bind('keyup', function (e) {
                    if (!$(this).hasClass('writing')) $(this).addClass('writing');
                    if (elem.val().length < 3) {

                        sugestElem.fadeTo(400, 0);

                    }
                    clearTimeout(sugestTimer);
                    clearTimeout(waitToSearch);
                    if (requestGet) {
                        requestGet.abort();
                    }
                    code = (e.keyCode ? e.keyCode : e.which);
                    if (code == 13) { // enter
                        
                        if (oEnter || actual == -1) {
                            
                        } else if (actual > -1) {
                            osLis.eq(actual).trigger('click');
                            oEnter = true;
                            e.preventDefault();
                            return false;
                        } 
                       
                    }
                    
                    if (code == 38) { // up
                        oEnter = false;
                        actual == 0 ? actual = osLisCount - 1 : actual--;
                        goToLi();
                        return false;
                    } else if (code == 40) { // down
                        oEnter = false;
                        actual == osLisCount - 1 ? actual = 0 : actual++;
                        goToLi();
                        return false;
                    } else {
                        oEnter = false;
                        oText = encodeURIComponent(elem.val());
                        
                        if (oText.length >= 3) {
                            
                            aLista.hide();
                            sugestBindHov();
                            var propertieType = $("#propTypeSearchId").val();
                            var vista = vista = $("#viewHighSearchId").val();
                            var interest = $("#interestsSearchId").val();

                            aux = url + "?text=" + oText;// + "&propertieType" + propertieType + "&vista="; +vista;

                            window.lastX = 0;
                            window.lastY = 0;

                            sugestElem.fadeTo(400, 1);
                            sugestLoader.addClass('full').stop().fadeTo(600, 1);
                            
                            waitToSearch = setTimeout(function () {
                            
                                aLista.scrollTop(0);
                                requestGet = $.ajax({
                                    type: "GET",
                                    url: aux,
                                    success: function (data) {
                                        //console.log(data);
                                        //console.log(sugestUL);
                                        sugestUL.html(data);
                                        aLista.show();
                                        setTimeout(function () {
                                            actual = -1;
                                            osLis = sugestUL.find('> li');
                                            osLisCount = osLis.length;
                                            osLis.last().addClass('last');
                                            aListaH = sugestElem.height();
                                            mouseLi();
                                            sugestLoader.stop().fadeTo(600, 0, function () {
                                                sugestLoader.removeClass('full');
                                                sugestH = sugestElem.height();
                                                osLis.each(function (intIndex) {
                                                    osLis.eq(intIndex).on('mousemove', function(e) {   
                                                        if(window.lastX !== e.clientX || window.lastY !== e.clientY){
                                                            if(!hoverNormal) goHoverNormal();
                                                            actual = intIndex;
                                                        }
                                                        window.lastX = e.clientX;
                                                        window.lastY = e.clientY;
                                                    });
                                                });            
                                                if(tmpview.isMobile){
                                                    liIndex = [];
                                                    osLis.each(function (intIndex) {
                                                        touchLi(intIndex);
                                                    });
                                                }
                                            });
                                        }, 200);
                                        requestGet = null;
                                    }
                                });
                            }, 500);

                            /*$.get(aux, function (data) {
                            sugestUL.html(data);
                            setTimeout(function () {
                            actual = -1;
                            osLis = sugestUL.find('> li');
                            osLisCount = osLis.length;
                            osLis.last().addClass('last');
                            aListaH = sugestElem.height();
                            sugestLoader.stop().fadeTo(600,0,function(){
                            sugestLoader.removeClass('full');
                            sugestH = sugestElem.height();
                            });
                            }, 200);
                            });*/
                        }
                    }
                });

    elem.focus(function () {
        if (elem.val() == elem[0].defaultValue)
            elem.val("");
    });

    elem.blur(function () {
        if (elem.val() == "") {
            elem.val(elem[0].defaultValue);
            elem.removeClass('writing');
        }
    });

}
function hideShowReset() {

    if ($("hideShowReset")) 
    {
        if ($("#refine li.on").size() != 0 || $("#destinHotelSearchInput").val() != $("#textdefVal").val()) {
            $("#btnReset").show();
        }
        else {
            $("#btnReset").hide();
            //$("#destinHotelSearchInput").val($("#textdefVal").val());
        }
            
    }
}



function bookRoomGoToAs() {

    var GroupBooking = $("#groupBookChkBox:checked").size() != 0;
    reservType = 1;
    if (GroupBooking)
        reservType = 2;

    var dateInit = $("#checkInBookInput").val().replace("/", "-").replace("/", "-");
    var dateEnd = $("#checkOutBookInput").val().replace("/", "-").replace("/", "-");
    var nAdults = $("#" + $("#adultsBookId").val()).html();
    var nChilds = $("#" + $("#childrenBookId").val()).html();
    var url=$("#reservationUrl").val();
    url += "?GroupBooking=" + GroupBooking + "&dateInit=" + dateInit + "&dateEnd=" + dateEnd + "&nChilds=" + nChilds + "&nAdults=" + nAdults + "&reservType=" + reservType;
    location.href = url;

}

function BuildDateForBooking(hasDates, checkInDate, checkOutDate) {
    if (hasDates) {
        //Fazer replace de / por - just in case... e assumo que as datas est�o no formato yyyy-mm-dd
        var inDate = checkInDate.replace("/", "-").replace("/", "-");
        var outDate = checkOutDate.replace("/", "-").replace("/", "-");

        var arrInDate = inDate.split('-');
        var arrOutDate = outDate.split('-');
        return '&checkin_monthday=' + arrInDate[2] + '&checkin_year_month=' + arrInDate[0] + '-' + arrInDate[1] + '&checkout_monthday=' + arrOutDate[2] + '&checkout_year_month=' + arrOutDate[0] + '-' + arrOutDate[1] + '&do_availability_check=1'

    } else {


        return '&checkin_monthday=0&checkin_year_month=0&checkout_monthday=0&checkout_year_month=0&do_availability_check=1&idf=off'




    }


}

function gotoBooking(urlToRedirect) {
    layerModal.abre('bookModal');
    setTimeout(function () {
        location.href = urlToRedirect;
    }, 6000);
}

function bookRoomGoTo(originalUrl) {
    var dateInit = $("#checkInSearchInput").val().replace("/", "-").replace("/", "-");
    var dateEnd = $("#checkOutSearchInput").val().replace("/", "-").replace("/", "-");
    var nodates = $('#nodatecheck').is(':checked');
    var dates = BuildDateForBooking(!nodates, dateInit, dateEnd);
    var url = originalUrl + dates;

    $("#findViewForm").attr("action", url);
    $("#findViewForm").submit();

    

    //$("#findViewForm").submit(function () {
    //    window.open(url); return false;
    //});
    //$("#falsebook").click();
}
function bookRoomSpecialOfferGoTo(originalUrl) {
    var dateInit = $("#checkInOffersAvailInput").val().replace("/", "-").replace("/", "-");
    var dateEnd = $("#checkOutOffersAvailInput").val().replace("/", "-").replace("/", "-");
    var nodates = $('#nodatecheck').is(':checked');
    var dates = BuildDateForBooking(!nodates, dateInit, dateEnd);
    var url = originalUrl + dates;


    $("#offersAvailForm").attr("action", url);
    $("#offersAvailForm").submit();


}

function registration() {
    this.title = $("#titleSignUPId").val();
    this.firstName = $("#name1SignUPInput").val();
    this.LastName = $("#name2SignUPInput").val();
    this.countryId = $("#contrySignUPId").val();
    this.email = $("#email1SignUPInput").val();
    this.phone1 = $("#phone1SignUPInput").val();
    this.phone2 = $("#phone2SignUPInput").val();
    this.pwd = $("#password1SignUPInput").val();
    this.receiveInfo = $("#ofertasSignUPChkBox:checked").size() != 0;
    this.agree = $("#termosSignUPChkBox:checked").size() != 0;
}

function registrationSubmit(handler) {

    var url = "/base/services/SubmitRegistration";
    var reserv = new registration();
    $.post(url, reserv, function (data) {
        data = eval( '('+data+')' );
        handler(data);
    });

}

function updateRegistration() {

    this.title = $("#titleProfileId").val().replace("I","");
    this.firstName = $("#name1ProfileInput").val();
    this.lastName = $("#name2ProfileInput").val();
    this.countryId = $("#contryProfileId").val();
    this.email = $("#email1ProfileInput").val();
    this.phone1 = $("#phone1ProfileInput").val();
    this.phone2 = $("#phone2ProfileInput").val();
    this.pwd = $("#password1ProfileInput").val();
    this.receiveInfo = $("#ofertasProfileChkBox:checked").size() != 0;
}

function updateRegistrationSubmit(handler) {
    var url = "/base/services/SubmitUpdateRegistration";
    var profile = new updateRegistration();
    $.post(url, profile, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

function loginSubmit(handler) {
    args = { userLoginInput: $("#userLoginInput").val(), passwordLoginInput: $("#passwordLoginInput").val() };
    var url = "/base/services/SubmitLogin";
    var reserv = new registration();
    $.post(url, args, function (data) {
        data = eval('(' + data + ')');
        handler(data);
        if ($("div.wrapper.reserv") && data.Status)
            location.href = location.href;
    });
}

function logOut() {
    var url = "/base/services/DoLogOut";
    $.post(url, function () {
        setTimeout(function () {
            location.href = "/en";
        }, 300);
    });

    
}

function resendLoginData(handler) {

    var url = "/base/services/ResendLoginData";
    args = { emailRecupInput:  $("#emailRecupInput").val()};
    $.post(url, args, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

function resetTextInput() {
    
    $('#keywordSearch').val($('#keywordSearch')[0].defaultValue);
    $('#keywordSearch').blur();
    //$('#textdefVal').val();
    //console.log()
    //$('#destinHotelSearchInput').val($('#textdefVal').val());
    //$('#destinHotelSearchInput')[0].defaultValue = $('#textdefVal').val();
    //$('#destinHotelSearchInput').blur(); 

}

function bindReservDatesChange() {
   // $("input#checkInReservInput").datepicker({ onClose: function () { alert("swqsq") } });
    //$("#checkInReservInput").change(function () { alert("sqwsqsq") });

//    $("#checkInReservInput, #checkOutReservInput").each(function () {
//        
//        this.change(function () {
//            console.log("sqsq");
//        });
//    });
}

function setVideoOnClick() {

    $("#sliderBlock10 .slider li").click(function () {
        $("#sliderBlock10 .slider li").removeClass("on");
        $(this).addClass("on");
        $("#youtubeVideo").attr("src", $(this).attr("Murl"));
    });
}

function registrationConfirm() {

    this.title = $("#titleSumId").val();
    this.firstName = $("#name1SumInput").val();
    this.LastName = $("#name2SumInput").val();
    this.address1 = $("#address1SumInput").val();
    this.address2 = $("#address2SumInput").val();
    this.zip1 = $("#zip1SumInput").val();
    this.zip2 = $("#zip2SumInput").val();
    this.location = $("#locationSumInput").val();

    this.countryId = $("#countrySumId").val();
    this.email = $("#email1SumInput").val();
    this.phone1 = $("#phone1SumInput").val();
    this.phone2 = $("#phone2SumInput").val();

    this.rateId = $("#rateId").val();
    this.stateInfo = $("#stateInfo").val();

    this.cardSum = $("#cardSumId").val();
    this.cardNumber = $("#cardNrSumInput").val();
    this.cardHolderName = $("#holderSumInput").val();
    this.cardMonth = $("#exp1SumInput").val();
    this.cardYear = $("#exp2SumInput").val();
    this.agree = $("input#check1:checked").size() != 0; 

}

function confirmReservation(handler) {

    var url = "/base/services/ConfirmReservation";
    var reserv = new registrationConfirm();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });

}

//---------------- Tailor Made -----------------------

function tailorMade() {
    this.titleId = $('#titleTailorId').val().replace('titleTailor','');
    this.firstName = $('#name1TailorInput').val();
    this.lastName = $('#name2TailorInput').val();
    this.request = $('#mindTailorInput').val();
    this.email = $('#email1TailorInput').val();
}

function sendTailorMade(handler) {
    var url = "/base/services/SubmitTailorMade.aspx";
    var reserv = new tailorMade();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

//---------------- Forms bottom -----------------------

function advertising() {
    this.titleId = $('#titlePubId').val().replace('titlePub', '');
    this.firstName = $('#name1PubInput').val();
    this.lastName = $('#name2PubInput').val();
    this.email = $('#emailPubInput').val();
    this.phoneCountry = $('#phone1PubInput').val();
    this.phone = $('#phone2PubInput').val();
    this.company = $('#companyPubInput').val();
    this.message = $('#messagePubInput').val();
    
}

function sendAdvertising(handler) {
    var url = "/base/services/SubmitAdvertising.aspx";
    var reserv = new advertising();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

function contact() {
    this.titleId = $('#titleContactId').val().replace('titleContact', '');
    this.firstName = $('#name1ContactInput').val();
    this.lastName = $('#name2ContactInput').val();
    this.email = $('#emailContactInput').val();
    this.phoneCountry = $('#phone1ContactInput').val();
    this.phone = $('#phone2ContactInput').val();
    this.location = $('#locatContactInput').val();
    this.message = $('#commentContactInput').val();
    this.culture = culture;
}

function sendContact(handler) {
    
    var url = "/base/services/SubmitContact.aspx";
    if (tmpview.ha('#typeForm')) {
        url = "/base/services/SubmitContactHot.aspx";

    }
    var reserv = new contact();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

function comboOffers() {
    this.titleId = $('#titleComboId').val().replace('titleCombo', '');
    this.firstName = $('#name1ComboInput').val();
    this.lastName = $('#name2ComboInput').val();
    this.email = $('#email1ComboInput').val();
    this.request = $('#mindComboInput').val();
    this.countryId = $('#countryComboId').val();
    this.checkIn = $('#checkInComboInput').val();
    this.checkOut = $('#checkOutComboInput').val();
    this.adults = $('#adultsComboId').val().replace('adultsCombo', '');
    this.children = $('#childrenComboId').val().replace('childrenCombo', '');
    this.nodeId = comboOfferId;
}


function sendComboOffer(handler) {
    var url = "/base/services/SubmitComboOffers.aspx";
    var reserv = new comboOffers();
    if ($("#checkInComboInput").val() != '' || $("#checkOutComboInput").val() != '') {
        var checkParams = {
            specialOfferId: comboOfferId,
            dateInit: $("#checkInComboInput").val().replace("/", "-").replace("/", "-"),
            dateEnd: $("#checkOutComboInput").val().replace("/", "-").replace("/", "-")
        };

        var checkUrl = "/base/services/ValidateSpecialOffer.aspx";
        $.get(checkUrl, checkParams, function (checkData) {
            if (checkData != '') {
                checkData = eval('(' + checkData + ')');
                if (!checkData.Status) {
                    handler(checkData);
                } else {
                    $.post(url, reserv, function (data) {
                        data = eval('(' + data + ')');
                        handler(data);
                    });
                }
            }
        });
    } else {
        $.post(url, reserv, function (data) {
            data = eval('(' + data + ')');
            handler(data);
        });
    }

    
    

}



function hoteliers() {
    this.titleId = $('#titleHotelierId').val().replace('titleHotelier', '');
    this.firstName = $('#name1HotelierInput').val();
    this.lastName = $('#name2HotelierInput').val();
    this.email = $('#emailHotelierInput').val();
    this.hotelProperty = $('#propHotelierInput').val();
    this.location = $('#locatHotelierInput').val();
    this.country = $('#countryHotelierInputId').val();
    this.url = $('#urlHotelierInput').val();
    this.position = $('#cargoHotelierInput').val();
    this.adicionalComments = $('#commentHotelierInput').val();
    this.viewConsiderations = $('#consdHotelierInput').val();
}

function sendHoteliers(handler) {
    var url = "/base/services/SubmitHoteliers.aspx";
    var reserv = new hoteliers();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

function workWithUs() {
    this.titleId = $('#titleRecrutId').val().replace('titleRecrut', '');
    this.firstName = $('#name1RecrutInput').val();
    this.lastName = $('#name2RecrutInput').val();
    this.email = $('#emailRecrutInput').val();
    this.phoneCountry = $('#phone1RecrutInput').val();
    this.phone = $('#phone2RecrutInput').val();
    this.country = $('#countryRecrutInputId').val();
    this.cv = $('#fileName').val();
}

function sendWorkWithUs(handler) {
    var url = "/base/services/SubmitWorkWithUs.aspx";
    var reserv = new workWithUs();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

function newsletter() {

    this.title = $("#titleNewsletterId").val().replace("I", "");
    this.firstName = $("#name1NewsletterInput").val();
    this.lastName = $("#name2NewsletterInput").val();
    this.countryId = $("#contryNewsletterId").val();
    this.email = $("#emailNewsletterInput").val();
    this.culture = culture;

}

function submitNewsletter(handler) {

    var newsl = new newsletter();
    var url = "/base/services/SubmitNewsLetter.aspx";
    $.post(url, newsl, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });

}

function pressCenter() {
    this.titleId = $('#titlePressId').val().replace('titlePress', '');
    this.firstName = $('#name1PressInput').val();
    this.lastName = $('#name2PressInput').val();
    this.email = $('#emailPressInput').val();
    this.phoneCountry = $('#phone1ContactInput').val();
    this.phone = $('#phone2ContactInput').val();
    this.pressEntity = $('#entityPressInput').val();
    this.message = $('#messagePressInput').val();
    this.culture = culture;
}

function sendPressCenter(handler) {
    var url = "/base/services/SubmitPressCenter.aspx";
    var reserv = new pressCenter();
    $.post(url, reserv, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });
}

var searchBar = {

    destinHotelSearchInput: $("#destinHotelSearchInput"),
    checkInSearchInput: $("#checkInSearchInput"),
    checkOutSearchInput: $("#checkOutSearchInput"),
    sugestCol: $('#searchForm').find('> .col1'),
    sugestElem: $('.sugestion'),
    sugestUnbindHov: function () {
        searchBar.sugestCol.unbind('mouseenter');
        searchBar.sugestElem.unbind('mouseenter');
        searchBar.sugestElem.unbind('mousedown');
        searchBar.sugestCol.unbind('mouseleave');
        searchBar.sugestElem.unbind('mouseleave');
    },
    sugestHide: function () {
        searchBar.sugestElem.stop().fadeTo(400, 0, function () {
            searchBar.sugestElem.stop().hide();
        });
    },


    // 0 - searchList, 1-singleresult;
    baseUrl: $("#_BaseUrl").val(),
    urlType: 0,
    location: '',
    city: '',
    brand: '',
    vista: '',
    interest: '',
    destination: '',
    pais: '',
    setText: function (newTxt) {
        searchBar.reset();
        searchBar.destinHotelSearchInput.val(newTxt);
        searchBar.sugestHide();
        searchBar.sugestUnbindHov();
    },
    reset: function () {
        searchBar.location = '';
        searchBar.city = '';
        searchBar.brand = '';
        searchBar.vista = '';
        searchBar.interest = '';
    },
    onClicK: function () {

//        var viewType = 0;

//        intSelIdx = $("#findView li.on").index();
//        if (intSelIdx == -1 || intSelIdx == 0)
//            viewType = 0 // list

//        if (intSelIdx == 1)
//            viewType = 2 // mapview

//        if (intSelIdx == 2)
//            viewType = 1 // imageview

////                var vista = searchBar.vista; //$("#viewHighSearchId").val();
////        ////        //var propertieType = $("#propTypeSearchId").val();

////        //        var pais = searchBar.pais;
            
        


        var url = $(".searchForm").data("url");

        //var propertieType = $("#propTypeSearchId").val();
        var textVal = $("#keywordSearch").val();
        var textdefVal = $("#keywordSearch")[0].defaultValue;
        //var GroupBooking = $("#groupSearchChkBox:checked").size() != 0;
        //var dateInit = $("#checkInSearchInput").val().replace("/", "-").replace("/", "-");
        //var dateEnd = $("#checkOutSearchInput").val().replace("/", "-").replace("/", "-");
        //var nAdults = $("#" + $("#adultsSearchId").val()).html();
        //var nChilds = $("#" + $("#childrenSearchId").val()).html();
        //var vista = vista = $("#viewHighSearchId").val();
        //var interest = $("#interestsSearchId").val();

        if (textVal == textdefVal)
            return false;

        url += "?text=" + encodeURI(textVal) + "&viewType=0";
        url += "&allQuery=" + encodeURI(textVal)+"-0";


        window.open(url, "_self");

        //if (vista != '-1')
        //searchBar.vista = "," + vista;

        //if (interest != '') 
        //{
        //    searchBar.interest = interest;
        //}


        //if (searchBar.urlType == 1) {
        //    url = searchBar.baseUrl;
        //    if (searchBar.checkOutSearchInput.val() != 'Check-Out' && searchBar.checkInSearchInput.val() != 'Check-In') {

        //        url += 'reservation?' + "GroupBooking=" + GroupBooking + "&dateInit=" + dateInit + "&dateEnd=" + dateEnd + "&nChilds=" + nChilds + "&nAdults=" + nAdults + "&viewType=" + viewType;
        //    }
        //    else {
        //        url += "?GroupBooking=" + GroupBooking + "&dateInit=" + dateInit + "&dateEnd=" + dateEnd + "&nChilds=" + nChilds + "&nAdults=" + nAdults + "&viewType=" + viewType;
        //    }
        //}
        //else {
        //    url = searchBar.baseUrl + "?text=" + encodeURI(textVal) + "&destination=" + searchBar.destination + "&propertieType=" + propertieType + "&interest=" + searchBar.interest + "&location=" + searchBar.location + "&city=" + searchBar.city + "&brand=" + searchBar.brand + "&vista=" + searchBar.vista + "&GroupBooking=" + GroupBooking + "&dateInit=" + dateInit + "&dateEnd=" + dateEnd + "&nChilds=" + nChilds + "&nAdults=" + nAdults + "&viewType=" + viewType + "&pais=" + searchBar.pais;
        //}
        
    },
    init: function () {
        //$("#searchSbmt").click(function () {
        //    searchBar.onClicK();
        //});
    }
}


function UpdateComboOfferCC() {
    this.typeId = $("#typeId").val();
    this.Id = $("#uniqueId").val();
    this.cardSum = $("#cardCCId").val().replace('cardCC','');
    this.cardNumber = $("#cardNrCCInput").val();
    this.cardHolderName = $("#holderCCInput").val();
    this.cardMonth = $("#exp1CCInput").val();
    this.cardYear = $("#exp2CCInput").val();

}
function submitUpdateComboOfferCC(handler) {

    var newsl = new UpdateComboOfferCC();
    var url = "/base/services/ComboOfferUpdateCreditCardInfo.aspx";
    $.post(url, newsl, function (data) {
        data = eval('(' + data + ')');
        handler(data);
    });




}


function trackOutboundLink(category, action) {

    try {
        _gaq.push(['_trackEvent', category, action]);
    } catch (err) { }

    //setTimeout(function () {
    //    document.location.href = link.href;
    //}, 100);
}
