﻿var homepage = {
    cont: $('.fullBlock'),
    destqs: $('#homeDestqs'),
    block1: $('.sliderBlock1'),
    whyUs: $('.whyUs'),
    destqsVis: true,
    anima: true,
    ing: false,
    animaUp: function () {
        homepage.ing = true;
        homepage.destqsVis = true;
        homepage.anima = true;
        tmpview.htmlBody.bind('mousewheel', function (event, delta) {
            return false;
        });
        setTimeout(function () {
            homepage.whyUs.removeClass('abs');
            homepage.ing = false;
        }, 1000);
    },
    init: function () {
        tmpview.page = 'home';
        tmpview.resizeInit();
        $('.block2').find('> .price > .value').msvCoinSize();
        $('.block1').find('> .price > .value').msvCoinSize();				
        if (tmpview.ha('#goMore')) goMore.init(0);

        if (tmpview.ha('#sliderBlock2')) $('#sliderBlock2').msvSlideSpecial(350, 0, false);
        if (tmpview.ha('#sliderBlock3')) $('#sliderBlock3').msvSlideBlock(990, 0, false);
    }
}