// findRefine - arrays estado
var arrFilters = {
    "main": [false, false, false, false, false, false],
    "price": [false, false, false, false],
    "location": [false, false],
    "view": [false, false, false, false, false, false, false, false],
    "type": [false, false, false, false, false],
    "interests": [false, false],
    "brand": [false, false, false, false, false, false, false, false, false]
}
// END: findRefine - arrays estado

// hFilters
var hFilters = {
  cont:    $('#findRefine'),
  mainList:  $('#refine'),
  subLis:    $('#refine').find('> ul > li'),
  subLists:  $('#refine').find('.filters'),
  subLCount:  $('#refine').find('.filters').length,  
  loader:    $('#refineLoader'),
  mapAreaH:   0,   
  ing:    false,
  mainToggle:  function(){
          if(!hFilters.ing) {
            if(hFilters.cont.hasClass('on')){
              hFilters.cont.removeClass('on');
              hFilters.mainList.slideUp(800, 'easeInOutQuad');
            } else {
              // se search Expanded: remove search Expanded
              if(hotelsFind.view==1&&searchForm.expanded){
                $('.sugestion').hide().css({'opacity':0});
                searchForm.expanded = false;
                searchForm.btnExpand.removeClass('on');
                searchForm.block.animate({height:70},800,'easeOutExpo');
                searchForm.hr.animate({width:117},800,'easeOutExpo');              
                searchForm.advanced.fadeOut(800,'easeOutExpo');
                hotelsFind.findWrap.animate({top:192},800,'easeOutExpo');
              }              
              hFilters.mainList.slideDown(800, 'easeInOutQuad', function(){
                hFilters.cont.addClass('on');
              });
            }
          }
        },
  subToggle:  function(indx) {
          if(hotelsFind.view==1) { // se estiver no mapa so mostra um de cada vez
            if(hFilters.subLis.eq(indx).hasClass('on')){
              hFilters.slideU(indx);
            } else {
              for (var i=0;i<hFilters.subLCount;i+=1){
                if(i!=indx&&hFilters.subLis.eq(i).hasClass('on')){
                  hFilters.slideU(i);
                }
              }
              hFilters.slideD(indx);
            }            
          } else { // se estiver na lista ou img mostra/esconde subs
            if(hFilters.subLis.eq(indx).hasClass('on')){
              hFilters.slideU(indx);
            } else {
              hFilters.slideD(indx);
            }          
          }
        },
  slideU: function(_qual){
          hFilters.subLists.eq(_qual).slideUp(600, 'easeInOutQuad', function(){
            arrFilters.main[_qual] = false;
            hFilters.subLis.eq(_qual).removeClass('on');
          });
        },
  slideD:    function(_qual){
          hFilters.subLists.eq(_qual).slideDown(600, 'easeInOutQuad', function(){
            arrFilters.main[_qual] = true;
            hFilters.subLis.eq(_qual).addClass('on');            
          });    
        },        
  change:    function(_arrName,_indx,_url){
          hFilters.ing = true;
          if (arrFilters[_arrName][_indx] == true) { // marca/desmarca o filtro clicado
            arrFilters[_arrName][_indx] = false;
          } else {
            arrFilters[_arrName][_indx] = true;
          }
          hFilters.mainList.fadeTo(600,0.01);
          setTimeout(function(){                            
            hFilters.loader.addClass('full').fadeTo(600,1,function(){
              // loadDoAjax
              hFilters.loadDoAjax(_url,hFilters.loadDoOk);
            });
          },400);
        },  
  loadDoAjax:  function(oUrl,handler){
          $.get(oUrl,function(data){
            if(hotelsFind.view==1){
              hFilters.cont.css({'max-height':Number(tmpview.contH-420)});
            }            
            hFilters.mainList.replaceWith(data);              
            hFilters.loader.fadeTo(600,0,function(){
              hFilters.loader.removeClass('full');
              handler();
              $('.findPagin1 li[onclick], .findPagin2 li[onclick]').hammer().on("tap", function (event) {
                  var handler = $(this).attr('onclick');
                  eval(handler);
              });
            });
          });
        },  
  loadDoOk:  function(){
          if(hotelsFind.view==1) hotelsMap.change(); // map change
          setTimeout(function(){
            hFilters.mainList = $('#refine');  
            hFilters.subLis = $('#refine').find('> ul > li');
            hFilters.subLists = $('#refine').find('.filters');
            hFilters.mainList.fadeTo(600,1);
            hFilters.ing = false;           
            hFilters.cont.css({'max-height':''}); 
            tmpview.doResize();
            $('#btnReset').hammer().on("tap", function (event) {
                var handler = $(this).attr('onclick');
                eval(handler);
            });
          },100);
        }
}
// hotelsFind
var hotelsFind = {
    wrap: $('.wrapper'),
    sBlock: $('.searchForm'),
    cont: $('.findCont'),
    header: $('.findHeader'),
    headerElems: $('.findHeader').find('h1, .breadcrumbs'),
    contOrder: $('.findOrder'),
    contPag1: $('.findPagin1'),
    contPag2: $('.findPagin2'),
    findWrap: $('.findWrapper'),
    findWrapIn: $('.findWrapper > .in'),
    contList: $('#findList'),
    rpp1: $('#rpp1'),
    rpp2: $('#rpp2'),
    showing1: $('#showing1'),
    showing2: $('#showing2'),
    loader: $('#findListLoader'),
    viewCont: $('#findView'),
    viewBtns: $('#findView').find('li'),
    rrp1Li: $('#rpp1').find('li').not('.text'),
    rrp2Li: $('#rpp2').find('li').not('.text'),
    orderBtns: $('.findOrder').find('.btnDdown3'),
    view: 0, // 0-list, 1-map, 2-image
    rppN: 0, // 0-10, 1-20, 2-30
    order: 0, // 0, 1, 2 ,3 (nome, preço, recentes, visitados)
    ing: false,
    coins: function(){
            $('.findResults').find('.viewInfo > .price').msvCoinSize(); // msvCoinSize plugin
            $('.findResultsSmall').find('.hover > .value').msvCoinSize(); // msvCoinSize plugin          
          },
    change: function (_view, _order, _rpp, _url, handler, changeFilters) {
        
        if (!hotelsFind.ing) {
            //console.log("vazio ou muda filtros da esquerda");
            // vazio ou muda filtros da esquerda
            setTimeout(function () { hotelsFind.ing = true;  handler();  }, 400);
            //console.log("changeFilters: " + changeFilters + " _view:" + _view + " _rpp:" + _rpp);
            
            if (changeFilters) {
                hFilters.mainList.fadeTo(600, 0.01);
                setTimeout(function () {
                    hFilters.loader.addClass('full').fadeTo(600, 1, function () {
                        //// loadDoAjax
                        //hFilters.loadDoAjax(_url, hFilters.loadDoOk);
                    });
                }, 400);
            }

            
            if (_view > -1) { // muda view
                if (_view != hotelsFind.view) {
                    if (_view == 1) { // ir de listagem p/ mapa
                        if (searchForm.expanded) {
                            setTimeout(function () {
                                searchForm.btnExpand.trigger('click');
                            }, 400);
                            setTimeout(hotelsMap.mostra, 500);
                        } else {
                            hotelsMap.mostra();
                        }
                    } else if (hotelsFind.view == 1) { // ir de mapa p/ listagem
                        //hFilters.cont.css({ 'max-height': '' });
                        if (searchForm.expanded) {
                            setTimeout(function () {
                                searchForm.btnExpand.trigger('click');
                            }, 400);
                            setTimeout(function () {
                                hotelsMap.esconde(function () {
                                    hotelsFind.loadDoAjax(_url, hotelsFind.loadDoOk);
                                });
                            }, 500);
                        } else {
                            hotelsMap.esconde(function () {
                                hotelsFind.loadDoAjax(_url, hotelsFind.loadDoOk);
                            });
                        }
                    } else { // ir de listagem p/ listagem
                        setTimeout(function () {
                            hotelsFind.loadFades(_url);
                        }, 400);
                    }
                    setTimeout(function () {
                        hotelsFind.view = _view;
                        hotelsFind.viewBtns.removeClass('on');
                        hotelsFind.viewBtns.eq(_view).addClass('on');
                        //alert(hotelsFind.viewBtns.size())
                    }, 400);
                }
            } else if (_order > -1) { // muda order
                if (_order != hotelsFind.order && hotelsFind.view != 1) {
                    hotelsFind.order = _order;
                    hotelsFind.orderBtns.removeClass('on');
                    hotelsFind.orderBtns.eq(_order).addClass('on');
                    // loadfades
                    hotelsFind.loadFades(_url);
                }
            } else if (_rpp > -1) { // muda results per page
                if (_rpp != hotelsFind.rppN && hotelsFind.view != 1) {
                    hotelsFind.rppN = _rpp;
                    hotelsFind.rrp1Li.removeClass('on');
                    hotelsFind.rrp2Li.removeClass('on');
                    hotelsFind.rrp1Li.eq(_rpp).addClass('on');
                    hotelsFind.rrp2Li.eq(_rpp).addClass('on');
                    // loadfades
                    hotelsFind.loadFades(_url);
                }
            } else { // muda pagina
                //alert(hotelsFind.view);
                hotelsFind.loadFades(_url);
                //                if (hotelsFind.view != 1) {
                //                    // loadfades
                //                    alert("2");
                //                   
                //                }
            }
          
            if(hotelsFind.view==1){
              //hFilters.cont.css({'max-height':Number(tmpview.contH-420)});
            } 



        }
    },
    loadFades: function (oUrl) {

        hotelsFind.contList.fadeTo(600, 0.01);
        //setTimeout(function () {
        if (hotelsFind.view != 1) {
            // loadDoAjax
            hotelsFind.loadDoAjax(oUrl, hotelsFind.loadDoOk);
            tmpview.htmlBody.stop().animate({scrollTop: 0}, 600);
            hotelsFind.loader.addClass('full').fadeTo(600, 1, function () {

            });
        }
        else {
            hotelsFind.loadDoAjax(oUrl, hotelsFind.loadDoOk);
        }
        //}, 100);

    },
    loadDoAjax: function (oUrl, handler) {

        $.get(oUrl, function (data) {

            if (hotelsFind.view != 1) {

                dataAll = $(data);

                var data1 = $(data).find('#showing1'),
                data2 = $(data).find('#showing2'),
                data3 = $(data).filter('#findList'),
                data5 = $(data).find('#rpp1'),
                data6 = $(data).find('#rpp2');
                data7 = $(data).find('#findModuleUl').parent().parent();

                hotelsFind.showing1.replaceWith(data1);
                hotelsFind.showing2.replaceWith(data2);
                hotelsFind.contList.replaceWith(data3);
                hotelsFind.rpp1.replaceWith(data5);
                hotelsFind.rpp2.replaceWith(data6);

                if (data7 != null && data7 != undefined && data7.html() != null && data7.html() != undefined)
                {
                    $("#findModule").replaceWith(data7);
                }
                    
            }



            var data9 = $(data).filter('script');
            var data4 = $(data).filter('#findRefine');

            var data8 = $(data).filter('#findView');
            if (data8 != null && data8 != undefined && data8.html() != null && data8.html() != undefined) {
                if (hotelsFind.view != 1)
                    $('#findView').replaceWith(data8);
                else {
                    hotelsFind.viewBtns.eq(0).attr("onclick", data8.find("li").eq(0).attr("onclick"));
                    hotelsFind.viewBtns.eq(2).attr("onclick", data8.find("li").eq(2).attr("onclick"));
                }
            }




            if (hotelsFind.view == 1) {
                hotelsFind.viewBtns.removeClass('on');
                hotelsFind.viewBtns.eq(1).addClass('on');
            }

            if (data4 != null && data4 != undefined && data4.html() != null && data4.html() != undefined) {
                data4 = data4.find("#refine");
                hFilters.mainList.replaceWith(data4);
                hFilters.loader.fadeTo(600, 0, function () {
                    hFilters.loader.removeClass('full');
                    hFilters.loadDoOk();
                });
            }


            hideShowReset();

            hotelsFind.loader.fadeTo(600, 0, function () {
                hotelsFind.loader.removeClass('full');
                if (hotelsFind.view != 1) {
                    handler();
                }
            });

            eval(data9.html());

            if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|J2ME|Windows Mobile|Windows Phone)/)) {
                 $('.block14[onclick], .block15[onclick], #findView li[onclick], .btnDdown3[onclick], .btnOption[onclick], .findRefine header[onclick],.filters li[onclick], .results li[onclick], .show li[onclick]').hammer().on("tap", function (event) {
                    var handler = $(this).attr('onclick');
                    eval(handler);
                });
            }

        });
    },
    loadDoOk: function () {
        setTimeout(function () {
            if (hotelsFind.view != 1) {
                hotelsFind.contList = $('#findList');
                hotelsFind.showing1 = $('#showing1');
                hotelsFind.showing2 = $('#showing2');
                hotelsFind.rpp1 = $("#rpp1");
                hotelsFind.rpp2 = $("#rpp2");
                hotelsFind.rrp1Li = $('#rpp1').find('li').not('.text');
                hotelsFind.rrp2Li = $('#rpp2').find('li').not('.text');
                hotelsFind.orderBtns = $('.findOrder').find('.btnDdown3');
                hotelsFind.viewBtns = $('#findView').find('li')
                hotelsFind.cont.removeAttr('style');

            }
            hotelsFind.coins();
            hotelsFind.contList.fadeTo(600, 1);
            tmpview.doResize();
            hotelsFind.ing = false;
        }, 100);
    },
    init: function () {
        tmpview.page = 'find';
        tmpview.resizeInit();
        hotelsFind.contList.fadeTo(600, 1);
        msvMap.infoBoxCont = $('.findCont');
        hotelsFind.coins();
        if (hotelsFind.viewBtns.eq(1).hasClass('on')) { // mapa
            hotelsFind.view = 1;
            hotelsMap.pageInit();
        } else if (hotelsFind.viewBtns.eq(2).hasClass('on')) { // img view
            hotelsFind.view = 2;
        }
    }
}

var dataAll;

// hotelsMap
var hotelsMap = {
    cont: $('#findMap'),
    map: $('#map'),
    controls: $('#mapViewControls'),
    change: function () {
        msvMap.endMarkers();
        msvMap.init2();
        setTimeout(function () {
            hotelsFind.ing = false;
        }, 600);
    },
    esconde: function (handler) {
        tmpview.elHtml.removeClass('map');
        if (tmpview.ha('#mapDiv')) $('#mapDiv').remove();
        tmpview.htmlBody.stop().animate({ scrollTop: 0 }, 800);
        hFilters.cont.stop().fadeTo(800, 0);
        hotelsMap.cont.stop().fadeTo(800, 0, function () {
            hotelsMap.controls.hide();
            hotelsFind.cont.removeClass('mapOn');
            hotelsFind.findWrap.removeAttr('style');
            hotelsFind.contList.css({ opacity: 0.01 });
            hotelsFind.showing1.css({ opacity: 0.01 });
            hotelsFind.showing2.css({ opacity: 0.01 });
            hotelsFind.wrap.stop().removeClass('searchAbs').animate({ paddingTop: 240 }, 800);
            hotelsFind.sBlock.stop().animate({ top: -71 }, 800);
            hotelsFind.header.removeClass('small').animate({ height: 100 }, 800);
            hotelsFind.headerElems.animate({ top: 39 }, 800);
            hotelsFind.viewCont.animate({ top: 19 }, 800);
        });
        setTimeout(function () {
            hFilters.cont.stop().fadeTo(800, 1);
            hotelsFind.contOrder.fadeTo(800, 1);
            hotelsFind.contPag1.fadeTo(800, 1);
            hotelsFind.contPag2.fadeTo(800, 1);
            tmpview.htmlBody.stop().animate({ scrollTop: 0 }, 800);
            hotelsFind.loader.addClass('full').fadeTo(800, 1, function () {
                hFilters.subLists.removeClass('mapArea').css({ 'max-height': '' });
                hFilters.subLis.filter('.on').css({ width: 'auto', 'display': 'block' });
                hotelsMap.map.empty().removeAttr('style');
                msvMap.endMarkers();
                handler();
            });
        }, 1800);
    },
    mostra: function () {
        if (hFilters.cont.hasClass('on')) {
            for (var i = 0; i < hFilters.subLCount; i += 1) {
                if (hFilters.subLis.eq(i).hasClass('on')) hFilters.slideU(i);
            }
            hFilters.mainToggle();
            setTimeout(hotelsMap.mostra2, 1000);
        } else {
            for (var i = 0; i < hFilters.subLCount; i += 1) {
                if (hFilters.subLis.eq(i).hasClass('on')) hFilters.subLis.hide();
            }
            setTimeout(hotelsMap.mostra2, 200);
        }
        $("#findModule").fadeOut(800);
    },
    mostra2: function () {
        tmpview.elHtml.addClass('map');
        hotelsFind.contOrder.stop().fadeTo(800, 0);
        hotelsFind.contPag1.stop().fadeTo(800, 0);
        hotelsFind.contPag2.stop().fadeTo(800, 0);
        hFilters.cont.stop().fadeTo(800, 0);
        hotelsFind.findWrap.css({ 'border-top': 'none', 'paddingTop': '1px' });
        tmpview.contH = tmpview.win.height();
        if (tmpview.contH < 800) {
            tmpview.contH = 800;
            tmpview.adjust = false;
            tmpview.bod.addClass('flow');
        } else {
            tmpview.adjust = true;
            tmpview.bod.removeClass('flow');
        }
        hFilters.mapAreaH = Number(tmpview.contH - 706 + 34);
        if (hFilters.mapAreaH < 60) hFilters.mapAreaH = 60;
        hFilters.cont.css({ 'max-height': '' });
        hFilters.subLists.addClass('mapArea').css({ 'max-height': hFilters.mapAreaH });
        hotelsFind.contList.stop().fadeTo(800, 0, function () {
            hotelsFind.cont.stop().animate(
                 { height: tmpview.contH - 69 - 4 },
                {
                    duration: 800,
                    step: function () {
                        hotelsFind.cont.css('overflow', 'visible');
                    },
                    complete: function () {
                        hotelsFind.cont.css('overflow', 'visible');
                    }
                }
            );
            tmpview.htmlBody.stop().animate({ scrollTop: 0 }, 800);
            hotelsFind.wrap.stop().animate({ paddingTop: 140 }, 800);
            hotelsFind.sBlock.stop().animate({ top: 110 }, 800);
            hotelsFind.findWrap.stop().animate({ top: 263 }, 800);
            hotelsFind.header.animate({ height: 79 }, 800);
            hotelsFind.headerElems.animate({ top: 29 }, 800);
            hotelsFind.viewCont.animate({ top: 9 }, 800);
        });
        setTimeout(function () {
            hotelsFind.cont.stop().addClass('mapOn').css({ height: tmpview.contH - 140 - 4 });
            hotelsMap.cont.stop().fadeTo(800, 1, function () {
                hFilters.cont.stop().fadeTo(800, 1);
                hotelsMap.controls.show();
                //hotelsFind.wrap.stop().addClass('searchAbs');
                //hotelsFind.header.addClass('small');
                hotelsFind.findWrap.stop().css({ top: 192 });
                hotelsFind.contOrder.hide();
                hotelsFind.contPag1.hide();
                hotelsFind.contPag2.hide();
                hotelsFind.contList.hide();
                if (typeof msvMapBtns == 'undefined') {
                    msvMap.init(); // mapa
                } else {
                    msvMap.reInit(); // mapa
                }
                hotelsFind.ing = false;
            });
        }, 1000);
    },
    pageInit: function () { // qd se inicia pagina no mapa
        hFilters.mapAreaH = Number(tmpview.contH - 706 + 34);
        if (hFilters.mapAreaH < 60) hFilters.mapAreaH = 60;
        hFilters.cont.css({ 'max-height': '' });
        hFilters.subLists.addClass('mapArea').css({ 'max-height': hFilters.mapAreaH });
        if (Modernizr.touch) { 
            hFilters.cont.css({ 'max-height': Number(tmpview.contH - 380) });
            $('#findRefine > header').hammer().on("tap", function (event) {
                var handler = $(this).attr('onclick');
                eval(handler);
            });            
        }
        hFilters.mainToggle();

        hotelsFind.sBlock.css({ top: 110 });
        hotelsFind.viewCont.css({ top: 9 });
        hotelsFind.cont.addClass('mapOn').css({ height: tmpview.contH - 140 - 4 });
        hotelsMap.cont.css({ 'opacity': 1, 'display': 'block' });
        hotelsMap.controls.show();
        hotelsFind.wrap.css({ paddingTop: 140 });
        hotelsFind.header.css({ height: 79 });
        hotelsFind.headerElems.css({ top: 29 });
        hotelsFind.findWrap.css({ 'border-top': 'none', 'paddingTop': '1px', 'top': '192px' });
        hotelsFind.contOrder.hide();
        hotelsFind.contPag1.hide();
        hotelsFind.contPag2.hide();
        hotelsFind.contList.hide();
        msvMap.init(); // mapa
        
        
    }
}