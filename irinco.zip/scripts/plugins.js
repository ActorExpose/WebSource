window.onerror = null;
/*
 *
 * msvChangeList plugin
 *
 */

$.fn.msvChangeList = function () {
    return this.each(function () {
        var _this = $(this),
			/* elements */
			_ul = _this.find('> div > ul'),
			_count = _ul.length,
			_oldOn = 0,
			_on = 0,
			_nav = _this.find('> nav'),
			_prev = _nav.find('.btnPrev'),
			_next = _nav.find('.btnNext'),
			_navLi = _nav.find('li').not(_prev).not(_next),
			/* anim */
			_speed = 1000,
			_easeFx = 'easeOutExpo',
			/*
			 * change list
			 */
			mudaOn = function (indx) {
			    _oldOn = _on;
			    _on = indx;
			    _ul.eq(_oldOn).stop().fadeTo(_speed, 0, _easeFx, function () {
			        $(this).hide();
			    });
			    _ul.eq(_on).stop().fadeTo(_speed, 1, _easeFx);
			    _navLi.eq(_oldOn).removeClass();
			    _navLi.eq(_on).removeClass().addClass('on');
			    checkSetas();
			},
			checkSetas = function () {
			    _prev.removeClass('off');
			    _next.removeClass('off');
			    if (_on == 0) _prev.addClass('off');
			    if (_on == _count - 1) _next.addClass('off');
			}
        // setas
        _ul.each(function (intIndex) {
            $(this).find('> li:even').addClass('bg');
        });
        _ul.eq(0).fadeTo(600, 1);
        if (_count > 1) {
            checkSetas();
            _navLi.each(function (intIndex) {
                $(this).bind('click', function () {
                    if (!$(this).hasClass('on')) mudaOn(intIndex);
                });
            });
            _prev.bind('click', function () {
                if (!$(this).hasClass('off')) {
                    mudaOn(_on - 1);
                }
            });
            _next.bind('click', function () {
                if (!$(this).hasClass('off')) {
                    mudaOn(_on + 1);
                }
            });
            // qd elem destruido (c/ jquery: .remove, .html, etc)
            _this.bind('destroyed', function () {
                _this.unbind('destroyed');
                _this = null;
            });
        }
    });
}

/*
 *
 * msvTip plugin
 *
 */
$.fn.msvTip = function (oIndx) {
    return this.each(function () {
        var _tip = $(this),
			_tipPai = _tip.parent(),
			_open = false,
			_fx = 'easeOutExpo',
			_openF = function () {
			    _tip.stop().show().fadeTo(1000, 1, _fx);
			},
			_closeF = function () {
			    _tip.stop().fadeTo(100, 0, _fx, function () {
			        $(this).hide();
			    });
			};

        // qd elem destruido (c/ jquery: .remove, .html, etc)
        _tip.bind('destroyed', function () {
            _tip.unbind('destroyed');
            _tip = null;
        });

        if (tmpview.isMobile) {
            _tipPai.bind('click', function () {
                if (!_open) {
                    _open = true;
                    _openF();
                    _tip.bind('click', function () {
                        _closeF();
                    });
                } else {
                    _open = false;
                    _closeF();
                    _tip.unbind('click');
                }
            });
        } else {
            _tipPai.hover(
				function () {
				    _openF();
				},
				function () {
				    _closeF();
				}
			);
        }
    });
}
/*
 *
 * msvSlideHome plugin
 *
 */
$.fn.msvSlideHome = function (oArray) {
    return this.each(function () {
        var _this = $(this),
			_array = oArray,
			_cont = _this.find('article'),

			_contVis = 0,
			_lowres = _cont.find('.lowres'),
			_lowresLayer = _cont.find('.lowresLayer'),
			_imgs = _cont.find('img').not('.lowres'),
			_imgsVis = _imgs.eq(0),

			_count = _imgs.length,
			_countVis = 0,
			_index = 0,
			_loadIndx = 0,
			_aspectRatio = 1.5,	// 1500x1000
			_dur = 9000, // 9000,
			_easeFx = 'easeOutExpo',
			/* descr */
			_descr = _this.find('.descr'),
			/* nav */
			_nav = _this.find('> nav'),
			_navLi = _nav.find('li'),
			_navLiVis = 0,
			_goPrev = $('#goPrev'),
			_goNext = $('#goNext'),
			/*
			 * load imgs
			 */
			loadImg = function () {
			    if (_loadIndx < _count && _this != null) {
			        if (typeof _array[_loadIndx] !== 'undefined' && _array[_loadIndx] !== null && _array[_loadIndx] !== '') {
			            doLoad();
			        } else {
			            loadedNot();
			        }
			    }
			},
			loaded = [],
			doLoad = function () { // img load
			    var aSrc = _array[_loadIndx],
		        	aImg = _imgs.eq(_loadIndx),
		        	oLoad;

			    aImg.attr('src', aSrc);
			    if (!$.browser.msie) {
			        aImg.attr('src', "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=="); //ie will do funky things if this is here (show the image as an X, only show half of the image, etc)
			    }
			    aImg.unbind("load error");
			    aImg.bind('load error', function (e) {
			        loaded.push(aImg);
			        oLoad = $.data(aImg, 'loaded', ('error' == e.type) ? false : true);
			        if (oLoad) {
			            loadedOk();
			        } else {
			            loadedNot();
			        }
			    });
			    if (!$.browser.msie) {
			        aImg.attr('src', aSrc); //needed for potential cached images
			    } else if (this.complete || this.complete === undefined) {
			        aImg.attr('src', aSrc);
			    }
			},
			loadedOk = function (domObject) {
			    if (_count > 1) { // se ha varios destaques
			        _cont.eq(_loadIndx).addClass('vis');
			        _navLi.eq(_loadIndx).addClass('vis');
			        if (_countVis == 0) { // primeiro destaque carregado com sucesso
			            setTimeout(function () {
			                if (_loadIndx != 0) { // se o destaque eq(0) falhou, troca por este que é o primeiro carregado com sucesso
			                    ing = true;
			                    _cont.eq(0).css({ 'z-index': 1 });
			                    _cont.eq(_loadIndx).css({ 'z-index': 2 }).fadeIn(1000, function () {
			                        _cont.eq(0).hide();
			                        ing = false;
			                    });
			                } else {
			                    _cont.eq(0).css({ 'z-index': '2' }).show();
			                }
			                _lowres.stop().fadeTo(2000, 0, _easeFx);
			                _lowresLayer.stop().fadeTo(2000, 0, _easeFx);

			                slideInit();
			                _loadIndx += 1;
			                loadImg();
			            }, 600);
			        } else {
			            slideReInit();
			            _loadIndx += 1;
			            loadImg();
			        }
			    } else { // se so ha um destaque
			        setTimeout(function () {
			            _lowres.stop().fadeTo(2000, 0, _easeFx);
			            _lowresLayer.stop().fadeTo(2000, 0, _easeFx);
			        }, 600);
			        _loadIndx += 1;
			        loadImg();
			    }
			},
			loadedNot = function (domObject) {
			    _loadIndx += 1;
			    loadImg();
			},
			/*
			 * resize
			 */
			bgActivo = 0,
			bgTop = 0,
			bgLeft = 0,
			bgW = 0,
			resizeBg = function () {
			    if (_this != null) {
			        tmpview.w = bgW = tmpview.win.width();
			        tmpview.h = tmpview.win.height();
			        if (tmpview.isMobile && tmpview.w < 990) tmpview.w = bgW = 990;
			        if (tmpview.adjust) {
			            if (tmpview.isMobile || tmpview.h < 700) {
			                tmpview.h = 560; // 700-140
			            } else {
			                tmpview.h -= 140;
			            }
			            if (bgW < 1200) bgW = 1200;
			            if ((bgW / tmpview.h) < _aspectRatio) {
			                tmpview.fullH = true;
			                bgLeft = Math.round((tmpview.h * _aspectRatio - bgW) / 2);
			                bgW = tmpview.h * _aspectRatio;
			                if (_loadIndx == 0) {
			                    _lowres.stop().removeAttr('style').css({ height: tmpview.h, width: bgW, top: 0, left: -bgLeft });
			                }
			                _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ height: tmpview.h, width: bgW, top: 0, left: -bgLeft });
			            } else {
			                tmpview.fullH = false;
			                bgTop = Math.round((bgW / _aspectRatio - tmpview.h) / 2);
			                bgLeft = Math.round((bgW - tmpview.w) / 2);
			                if (_loadIndx == 0) {
			                    _lowres.stop().removeAttr('style').css({ width: bgW, top: -bgTop, left: -bgLeft });
			                }
			                _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: bgW, top: -bgTop, left: -bgLeft });
			            }
			        } else {  // flow
			            var contH = Math.round((tmpview.w * 0.6666666) + 140);
			            homepage.cont.css({ height: contH });
			            if (_loadIndx == 0) {
			                _lowres.stop().removeAttr('style').css({ width: tmpview.w, top: 0, left: 0 });
			            }
			            _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: tmpview.w, top: 0, left: 0 });
			        }
			    }
			},
			/*
			 * slide imgs
			 */
			oldBg,
			ing = false,
			autoSlide = function () {
			    if (_this != null && !ing && _countVis > 1) {
			        if (homepage.anima) {  // se estiver na zona de topo/principal
			            doSlide(-1);
			        } else {
			            resetTimer(); // se nao estiver adia animacoes
			        }
			    }
			},
			doSlide = function (indx) {
			    resetTimer();
			    ing = true;
			    oldBg = bgActivo;
			    if (indx == -1 || indx == -2) {
			        if (indx == -1) {
			            bgActivo == _countVis - 1 ? bgActivo = 0 : bgActivo++;
			        } else {
			            bgActivo == 0 ? bgActivo = _countVis - 1 : bgActivo--;
			        }
			        homepage.bgActivo = bgActivo;
			        animaInit();
			    } else if (indx < _countVis && !_navLiVis.eq(indx).hasClass('on')) {
			        bgActivo = indx;
			        homepage.bgActivo = bgActivo;
			        animaInit();
			    }
			},
			animaInit = function () {
			    _navLiVis.removeClass('on');
			    _navLiVis.eq(bgActivo).addClass('on');
			    _contVis.eq(oldBg).css({ 'z-index': 1 });
			    if (tmpview.adjust) {
			        if (tmpview.fullH) {
			            _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ height: tmpview.h, width: bgW, top: 0, left: -bgLeft });
			        } else {
			            _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: bgW, top: -bgTop, left: -bgLeft });
			        }
			    } else {  // flow
			        _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: tmpview.w, top: 0, left: 0 });
			    }
			    _contVis.eq(bgActivo).css({ 'z-index': 2 }).fadeIn(1000, function () {
			        _contVis.eq(oldBg).hide();
			        ing = false;
			        resetTimer();
			    });
			},
			timedSlide = setTimeout(autoSlide, _dur),
			resetTimer = function () {
			    clearTimeout(timedSlide);
			    timedSlide = setTimeout(autoSlide, _dur + 500);
			},
			slideInit = function () {
			    _countVis = 1;
			    _contVis = _this.find('article.vis');
			    _imgsVis = _contVis.find('img').not('.lowres');
			    _navLiVis = _nav.find('.vis');
			    _navLiVis.eq(0).addClass('on');
			},
			slideReInit = function () {
			    _countVis += 1;
			    if (_countVis > 1) {
			        resetTimer();
			        _contVis = _this.find('article.vis');
			        _imgsVis = _contVis.find('img').not('.lowres');
			        _navLiVis = _nav.find('.vis');
			        _navLiVis.each(function (intIndex) {
			            $(this).unbind('click');
			            $(this).bind('click', function () {
			                if (!$(this).hasClass('on') && !ing) doSlide(intIndex);
			            });
			        });
			        if (_countVis == 2) {
			            _goPrev.bind('click', function () {
			                if (!ing) doSlide(-2);
			            });
			            _goNext.bind('click', function () {
			                if (!ing) doSlide(-1);
			            });
			            _goPrev.fadeTo(600, 1);
			            _goNext.fadeTo(600, 1);
			        }
			    }
			};

        // qd elem destruido (c/ jquery: .remove, .html, etc)
        _this.bind('destroyed', function () {
            _this.unbind('destroyed');
            _this = null;
        });
        // init
        if (!tmpview.isMobile) {
            tmpview.win.bind('smartresize', function () {
                resizeBg();
            });
        }
        _cont.eq(0).css({ 'z-index': '2' }).show();
        resizeBg();
        setTimeout(function () {
            _lowresLayer.stop().fadeTo(400, .5, _easeFx);
        }, 100);
        setTimeout(function () {
            // init img loading
            loadImg();
        }, 800);
    });
}
/*
 *
 * msvSlideHotel plugin
 *
 */
$.fn.msvSlideHotel = function (oArray) {
    return this.each(function () {
        var _this = $(this),
			_array = oArray,
			_cont = _this.find('figure'),
			_contVis = 0,
			_lowres = _cont.find('.lowres'),
			_lowresLayer = _cont.find('.lowresLayer'),
			_imgs = _cont.find('img').not('.lowres'),
			_imgsVis = _imgs.eq(0),
			_count = _imgs.length,
			_countVis = 0,
			_index = 0,
			_loadIndx = 0,
			_aspectRatio = 1.5,	// 1500x1000
			_dur = 8000,
			_vis = 4,
			_auto = true,
			/* txt */
			_btnInfo = $('#btnInfo'),
			_txt = _btnInfo.find('> .tip > p').not('.hoverP'),
			/* nav */
			_nav = $('#hotelImgsNav'),
			_navUl = _nav.find('ul'),
			_navBg = _navUl.find('> .hovBg'),
			_navLi = _navUl.find('> li').not(_navBg),
			_navLiVis = 0,
			_prev = _nav.find('.btnPrev'),
			_next = _nav.find('.btnNext'),
			_goPrev = $('#goPrev'),
			_goNext = $('#goNext'),
			_navIndex = 0,
			_dist = 170,
			_speed = 1000,
			_easeFx = 'easeOutExpo',
			/*
			 * load imgs
			 */
			loadImg = function () {
			    if (_loadIndx < _count && _this != null) {
			        if (typeof _array[_loadIndx] !== 'undefined' && _array[_loadIndx] !== null && _array[_loadIndx] !== '') {
			            doLoad();
			        } else {
			            loadedNot();
			        }
			    }
			},
			loaded = [],
			doLoad = function () { // img load
			    var aSrc = _array[_loadIndx],
		        	aImg = _imgs.eq(_loadIndx),
		        	oLoad;

			    aImg.attr('src', aSrc);
			    if (!$.browser.msie) {
			        aImg.attr('src', "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=="); //ie will do funky things if this is here (show the image as an X, only show half of the image, etc)
			    }
			    aImg.unbind("load error");
			    aImg.bind('load error', function (e) {
			        loaded.push(aImg);
			        oLoad = $.data(aImg, 'loaded', ('error' == e.type) ? false : true);
			        if (oLoad) {
			            loadedOk();
			        } else {
			            loadedNot();
			        }
			    });
			    if (!$.browser.msie) {
			        aImg.attr('src', aSrc); //needed for potential cached images
			    } else if (this.complete || this.complete === undefined) {
			        aImg.attr('src', aSrc);
			    }
			},
			loadedOk = function (domObject) {
			    if (_count > 1) { // se ha varios destaques
			        _cont.eq(_loadIndx).addClass('vis');
			        _navLi.eq(_loadIndx).addClass('vis');
			        if (_countVis == 0) { // primeiro destaque carregado com sucesso
			            setTimeout(function () {
			                if (_loadIndx != 0) { // se o destaque eq(0) falhou, troca por este que é o primeiro carregado com sucesso
			                    ing = true;
			                    // actualiza text tip
			                    hotelImgsTxt.splice(0, _loadIndx);
			                    _txt.html(hotelImgsTxt[0]);
			                    if (hotelImgsTxt[_index] != '') {
			                        _btnInfo.fadeTo(600, 1);
			                    } else {
			                        _btnInfo.fadeTo(600, 0, function () {
			                            $(this).hide();
			                        });
			                    }

			                    _index = _loadIndx;
			                    _cont.eq(0).css({ 'z-index': 1 });
			                    _cont.eq(_loadIndx).css({ 'z-index': 2 }).fadeIn(1000, function () {
			                        _cont.eq(0).hide();
			                        ing = false;
			                    });
			                } else {
			                    _cont.eq(0).css({ 'z-index': '2' }).show();
			                }
			                _lowres.stop().fadeTo(2000, 0, _easeFx);
			                _lowresLayer.stop().fadeTo(2000, 0, _easeFx);

			                slideInit();
			                _loadIndx += 1;
			                loadImg();
			            }, 600);
			        } else {
			            slideReInit();
			            _loadIndx += 1;
			            loadImg();
			        }
			    } else { // se so ha um destaque
			        setTimeout(function () {
			            _lowres.stop().fadeTo(2000, 0, _easeFx);
			            _lowresLayer.stop().fadeTo(2000, 0, _easeFx);
			        }, 600);
			        _loadIndx += 1;
			        loadImg();
			    }
			},
			loadedNot = function (domObject) {
			    _loadIndx += 1;
			    loadImg();
			},
			/*
			 * resize
			 */
			bgActivo = 0,
			bgTop = 0,
			bgLeft = 0,
			bgW = 0,
			resizeBg = function () {
			    if (_this != null) {
			        tmpview.w = bgW = tmpview.win.width();
			        tmpview.h = tmpview.win.height();
			        if (tmpview.isMobile && tmpview.w < 990) tmpview.w = bgW = 990;
			        if (tmpview.adjust) {
			            if (tmpview.isMobile || tmpview.h < 700) {
			                tmpview.h = 560; // 700-140
			            } else {
			                tmpview.h -= 140;
			            }
			            if (bgW < 1200) bgW = 1200;
			            if ((bgW / tmpview.h) < _aspectRatio) {
			                tmpview.fullH = true;
			                bgLeft = Math.round((tmpview.h * _aspectRatio - bgW) / 2);
			                bgW = tmpview.h * _aspectRatio;
			                if (_loadIndx == 0) {
			                    _lowres.stop().removeAttr('style').css({ height: tmpview.h, width: bgW, top: 0, left: -bgLeft });
			                }
			                _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ height: tmpview.h, width: bgW, top: 0, left: -bgLeft });
			            } else {
			                tmpview.fullH = false;
			                bgTop = Math.round((bgW / _aspectRatio - tmpview.h) / 2);
			                bgLeft = Math.round((bgW - tmpview.w) / 2);
			                if (_loadIndx == 0) {
			                    _lowres.stop().removeAttr('style').css({ width: bgW, top: -bgTop, left: -bgLeft });
			                }
			                _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: bgW, top: -bgTop, left: -bgLeft });
			            }
			        } else {  // flow
			            var contH = Math.round((tmpview.w * 0.6666666) + 140);
			            hotelsDetail.cont.css({ height: contH });
			            if (_loadIndx == 0) {
			                _lowres.stop().removeAttr('style').css({ width: tmpview.w, top: 0, left: 0 });
			            }
			            _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: tmpview.w, top: 0, left: 0 });
			        }
			    }
			},
			/*
			 * slide imgs
			 */
			oldBg,
			ing = false,
			autoSlide = function () {
			    if (_this != null && !ing && hotelsBtns.imgs && _countVis > 1) {
			        if (hotelsDetail.anima) {  // se estiver na zona de topo/principal
			            doSlide(-1);
			        } else {
			            resetTimer(); // se nao estiver adia animacoes
			        }
			    }
			},
			doSlide = function (indx) {
			    if (_auto) resetTimer();
			    ing = true;
			    oldBg = bgActivo;
			    if (indx == -1 || indx == -2) {
			        if (indx == -1) {
			            bgActivo == _countVis - 1 ? bgActivo = 0 : bgActivo++;
			        } else {
			            bgActivo == 0 ? bgActivo = _countVis - 1 : bgActivo--;
			        }
			        _index = bgActivo;
			        homepage.bgActivo = bgActivo;
			        if (_countVis > _vis) {
			            if (_navIndex < _index - _vis + 1 || _navIndex > _index + _vis) _navIndex = _index;
			            if (_navIndex > _countVis - _vis) _navIndex = _countVis - _vis;
			            _navUl.stop().animate({ left: -Number(_navIndex * _dist) }, _speed, _easeFx);
			        } else {
			            _navIndex = 0;
			        }
			        checkSetas();
			        animaInit();
			    } else if (indx < _countVis && !_navLiVis.eq(indx).hasClass('on')) {
			        bgActivo = _index = indx;
			        homepage.bgActivo = bgActivo;
			        animaInit();
			    }
			},
			animaInit = function () {
			    _navLiVis.removeClass('on');
			    _navLiVis.eq(bgActivo).addClass('on');
			    _contVis.eq(oldBg).css({ 'z-index': 1 });
			    mudaOn();
			    if (tmpview.adjust) {
			        if (tmpview.fullH) {
			            _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ height: tmpview.h, width: bgW, top: 0, left: -bgLeft });
			        } else {
			            _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: bgW, top: -bgTop, left: -bgLeft });
			        }
			    } else {  // flow
			        _imgsVis.eq(bgActivo).stop().removeAttr('style').css({ width: tmpview.w, top: 0, left: 0 });
			    }
			    _contVis.eq(bgActivo).css({ 'z-index': 2 }).fadeIn(1000, function () {
			        _contVis.eq(oldBg).hide();
			        ing = false;
			        if (_auto) resetTimer();
			    });
			},
			timedSlide = setTimeout(autoSlide, _dur),
			resetTimer = function () {
			    clearTimeout(timedSlide);
			    timedSlide = setTimeout(autoSlide, _dur + 500);
			},
			slideInit = function () {
			    _countVis = 1;
			    _contVis = _this.find('figure.vis');
			    _imgsVis = _contVis.find('img').not('.lowres');
			    _navUl.css({ 'width': Number(_dist) });
			    _navLiVis = _navUl.find('> .vis');
			    _navLiVis.eq(0).addClass('on');
			},
			slideReInit = function () {
			    _countVis += 1;
			    _navUl.css({ 'width': Number(_dist * _countVis) });
			    if (_countVis > 1) {
			        if (_auto) resetTimer();
			        _contVis = _this.find('figure.vis');
			        _imgsVis = _contVis.find('img').not('.lowres');
			        _navLiVis = _navUl.find('> .vis');
			        _navLiVis.each(function (intIndex) {
			            $(this).unbind('click');
			            $(this).bind('click', function () {
			                if (!$(this).hasClass('on') && !ing) doSlide(intIndex);
			            });
			        });
			        if (_countVis == 2) {
			            _goPrev.bind('click', function () {
			                if (!ing) {
			                    doSlide(-2);
			                    if (hotelsBtns.imgs && hotelsBtns.imgsNav) hotelsBtns.hideImgsNav(function () { });
			                    hotelsDetail.titleHide(hotelsDetail.title5sec);
			                }
			            });
			            _goNext.bind('click', function () {
			                if (!ing) {
			                    doSlide(-1);
			                    if (hotelsBtns.imgs && hotelsBtns.imgsNav) hotelsBtns.hideImgsNav(function () { });
			                    hotelsDetail.titleHide(hotelsDetail.title5sec);
			                }
			            });
			            _goPrev.fadeTo(600, 1);
			            _goNext.fadeTo(600, 1);
			        }
			        // se mais que 4 img
			        if (_countVis == _vis + 1) {
			            _prev.bind('click', function () {
			                if (!$(this).hasClass('off')) {
			                    _navIndex -= 1;
			                    _navUl.stop().animate({ left: -Number(_navIndex * _dist) }, _speed, _easeFx);
			                    checkSetas();
			                }
			            });
			            _next.bind('click', function () {
			                if (!$(this).hasClass('off')) {
			                    _navIndex += 1;
			                    _navUl.stop().animate({ left: -Number(_navIndex * _dist) }, _speed, _easeFx);
			                    checkSetas();
			                }
			            });
			            _prev.fadeTo(600, 1);
			            _next.fadeTo(600, 1);
			        }
			    }
			},
			checkSetas = function () {
			    if (_countVis > _vis) {
			        _prev.removeClass('off');
			        _next.removeClass('off');
			        if (_navIndex == 0) _prev.addClass('off');
			        if (_navIndex == _countVis - _vis) _next.addClass('off');
			    }
			},
			mudaOn = function () {
			    _navBg.stop().animate({ left: Number(_index * _dist) }, _speed, _easeFx);
			    mudaTxt();
			},
			mudaTxt = function () {
			    _txt.html(hotelImgsTxt[_index]);
			    if (hotelImgsTxt[_index] != '') {
			        _btnInfo.fadeTo(600, 1);
			    } else {
			        _btnInfo.fadeTo(600, 0, function () {
			            $(this).hide();
			        });
			    }
			}

        // qd elem destruido (c/ jquery: .remove, .html, etc)
        _this.bind('destroyed', function () {
            _this.unbind('destroyed');
            _this = null;
        });
        // init
        if (!tmpview.isMobile) {
            tmpview.win.bind('smartresize', function () {
                resizeBg();
            });
        }
        _cont.eq(0).css({ 'z-index': '2' }).show();
        mudaTxt();
        resizeBg();
        setTimeout(function () {
            _lowresLayer.stop().fadeTo(400, .5, _easeFx);
        }, 100);
        setTimeout(function () {
            // init img loading
            loadImg();
        }, 800);
    });
}

/*
 *
 * msvSlideBlock plugin
 *
 */
$.fn.msvSlideBlock = function (aDistancia, oDelay, oAuto) {
    return this.each(function () {
        var _this = $(this),
			/* elements */
			_ul = _this.find('.slider > ul'),
			_index = 0,
			/* nav */
			_nav = _this.find('header > nav'),
			_navLi = _nav.find('li'),
			_count = _navLi.length,
			_prev = _this.find('.btnPrev'),
			_next = _this.find('.btnNext'),
			_setas = false,
			/* anim */
			_dist = aDistancia,
			_delay = oDelay,
			_speed = _dist * 1.6,
			_easeFx = 'easeOutExpo',
			_dur = 7000,
			_auto = oAuto,
            _ing = true,

			/*
			 * slide imgs
			 */
			doSlide = function (indx) {
			    clearTimeout(timedSlide);
			    if (indx == -1) { // autoslide
			        _index == _count - 1 ? _index = 0 : _index++;
			    } else {
			        _index = indx;
			    }
			    _ul.stop().animate({ left: -_index * (_dist) }, _speed, _easeFx, function () {
			        _ing = true;
			    });
			    checkNav();
			    restartTimer();
			},
			autoSlide = function () {
			    if (_this != null && _auto) doSlide(-1);
			},
			timedSlide = 0,
			restartTimer = function () {
			    timedSlide = setTimeout(autoSlide, _dur + 500);
			},
			checkNav = function () {
			    _navLi.removeClass();
			    _navLi.eq(_index).addClass('on');
			    if (_setas) checkSetas();
			},
			checkSetas = function () {
			    _prev.removeClass('off');
			    _next.removeClass('off');
			    if (_index == 0) _prev.addClass('off');
			    if (_index == _count - 1) _next.addClass('off');
			}
        if (_this.attr('id') == 'sliderDestqClientes') {
            _nav = $('#sliderDestqClientesNav');
            _navLi = _nav.find('li');
            _count = _navLi.length;
        }
        if (_count == 0) {
            _ul.css({ width: _dist });
        } else {
            _ul.css({ width: _count * _dist });
        }

        // setas
        if (tmpview.ha(_prev)) {  // se houver setas
            _setas = true;
            checkSetas();
            _prev.bind('click', function () {
                if (!$(this).hasClass('off')) {
                    doSlide(_index - 1);
                }
            });
            _next.bind('click', function () {
                if (!$(this).hasClass('off')) {
                    doSlide(_index + 1);
                }
            });            
        }
        // nav
        _navLi.eq(0).addClass('on');
        _navLi.each(function (intIndex) {
            $(this).bind('click', function () {
                if (!$(this).hasClass('on')) doSlide(intIndex);
            });
        });

        if (Modernizr.touch) {
            _ul.hammer().on("swipeleft", function (event) {
                if (_index < _count - 1 && _ing) doSlide(_index + 1);
                _ing = false;
            });
            _ul.hammer().on("swiperight", function (event) {
                if (_index > 0 && _ing) doSlide(_index - 1);
                _ing = false;
            });
        }

        // qd elem destruido (c/ jquery: .remove, .html, etc)
        _this.bind('destroyed', function () {
            _this.unbind('destroyed');
            _this = null;
        });
        // init
        if (_auto) timedSlide = setTimeout(autoSlide, _dur + _delay);
    });
}

/*
 *
 * msvSlideBlock10 plugin // lateral
 *
 */
$.fn.msvSlideBlock10 = function (oDelay, oAuto) {
    return this.each(function () {
        var _this = $(this),
			/* elements */
			_ul = _this.find('.slider > ul'),
			_index = 0,
			_old = 0,
			/* nav */
			_nav = _this.find('nav'),
			_navLi = _nav.find('li'),
			_count = _navLi.length,
			/* anim */
			_delay = oDelay,
			_easeFx = 'easeOutExpo',
			_dur = 7000,
			_auto = oAuto,
			/*
			 * slide imgs
			 */
			doSlide = function (indx) {
			    clearTimeout(timedSlide);
			    _old = _index;
			    if (indx == -1) { // autoslide
			        _index == _count - 1 ? _index = 0 : _index++;
			    } else {
			        _index = indx;
			    }
			    if (tmpview.ie78) {
			        _ul.eq(_old).hide();
			        _ul.eq(_index).show();
			    } else {
			        _ul.eq(_old).stop().fadeTo(1000, 0, function () {
			            $(this).hide();
			        });
			        _ul.eq(_index).stop().fadeTo(1000, 1);
			    }
			    checkNav();
			    if (_auto) restartTimer();
			},
			autoSlide = function () {
			    if (_this != null && _auto) doSlide(-1);
			},
			timedSlide = 0,
			restartTimer = function () {
			    timedSlide = setTimeout(autoSlide, _dur + 500);
			},
			checkNav = function () {
			    _navLi.removeClass();
			    _navLi.eq(_index).addClass('on');
			}

        // nav
        _navLi.eq(0).addClass('on');
        _navLi.each(function (intIndex) {
            $(this).bind('click', function () {
                if (!$(this).hasClass('on')) doSlide(intIndex);
            });
        });
        // qd elem destruido (c/ jquery: .remove, .html, etc)
        _this.bind('destroyed', function () {
            _this.unbind('destroyed');
            _this = null;
        });
        // init
        _ul.each(function () {
            $(this).find('> li').eq(0).addClass('noBord');
        });
        _ul.eq(0).show();
        _navLi.eq(0).addClass('on');
        if (_auto) timedSlide = setTimeout(autoSlide, _dur + _delay);
    });
}

/*
 *
 * msvSlideSpecial plugin
 *
 */
$.fn.msvSlideSpecial = function (aDistancia, oDelay, oAuto) {
    return this.each(function () {
        var _this = $(this),
			/* elements */
			_slider = _this.find('.slider'),
			_fotos = _this.find('.fotos > ul'),
			_textos = _this.find('.textos > ul'),
			_index = 0,
			/* nav */
			_nav = _this.find('nav'),
			_navLi = _nav.find('li'),
			_count = _navLi.length,
			/* anim */
			_dist = aDistancia,
			_delay = oDelay,
			_speed = aDistancia * 3,
			_easeFx = 'easeOutExpo',
			_dur = 7000,
			_auto = oAuto,
			/*
			 * slide imgs
			 */
			doSlide = function (indx) {
			    clearTimeout(timedSlide);
			    if (indx == -1) { // autoslide
			        _index == _count - 1 ? _index = 0 : _index++;
			    } else {
			        _index = indx;
			    }
			    _fotos.stop().animate({ top: -_index * _dist }, _speed, _easeFx);
			    _textos.stop().animate({ bottom: -_index * _dist }, _speed, _easeFx);
			    checkNav();
			    restartTimer();
			},
			autoSlide = function () {
			    if (_this != null && _auto) doSlide(-1);
			},
			timedSlide = 0,
			restartTimer = function () {
			    timedSlide = setTimeout(autoSlide, _dur + 500);
			},
			checkNav = function () {
			    _navLi.removeClass();
			    _navLi.eq(_index).addClass('on');
			};

        if (_count > 0) {
            // nav
            _navLi.eq(0).addClass('on');
            _navLi.each(function (intIndex) {
                $(this).bind('click', function () {
                    if (!$(this).hasClass('on')) doSlide(intIndex);
                    return false;
                });
            });
            // init
            if (_auto) timedSlide = setTimeout(autoSlide, _dur);
        }
        _slider.bind('click', function () {
            location.href = sliderBlock2Links[_index];
        });

        if (navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|J2ME|Windows Mobile|Windows Phone)/)) {
            _slider.hammer().on("tap", function (event) {
                location.href = sliderBlock2Links[_index];
            });
        }

        // qd elem destruido (c/ jquery: .remove, .html, etc)
        _this.bind('destroyed', function () {
            _this.unbind('destroyed');
            _this = null;
        });

    });
}

/*
 *
 * msvGalHoriz plugin
 *
 */
$.fn.msvGalHoriz = function (aLargura, aLargThumbs, thumbsVisiveis) {
    return this.each(function () {
        var _this = $(this),
			_larg = aLargura,
			_thumbLarg = aLargThumbs,
			_vis = thumbsVisiveis,
			_dist = 0,
			slider = _this.find('> .slider'),
			cont = slider.find('> ul'),
			_count = cont.find('> li').length,
			contNav = _this.find('> .sliderNav'),
			navUl = contNav.find('> ul'),
			navBg = navUl.find('> .hovBg'),
			navLi = contNav.find('li').not(navBg),
			_prev = _this.find('> .btnPrev'),
			_next = _this.find('> .btnNext'),
			_on = 0,
			_index = 0,
			_speed = 0,
			_easeFx = 'easeOutExpo',
			checkSetas = function () {
			    _prev.removeClass('off');
			    _next.removeClass('off');
			    if (_index == 0) _prev.addClass('off');
			    if (_index == _count - 1) _next.addClass('off');
			},
			changeImg = function () {
			    cont.stop().animate({ left: -Number(_on * _larg) }, _speed, _easeFx);
			    checkSetas();
			},
			doSlide = function (indx) {
			    _index = indx;
			    navUl.stop().animate({ left: -Number(_index * _dist) }, _speed, _easeFx);
			    checkSetas();
			},
			mudaOn = function () {
			    navBg.stop().animate({ left: Number(_on * _thumbLarg) }, _speed, _easeFx);
			};

        cont.css({ 'width': Number(_larg * _count) });
        navUl.css({ 'width': Number(_thumbLarg * _count) });
        navLi.each(function (intIndex) {
            $(this).bind('click', function () {
                _on = intIndex;
                changeImg();
                mudaOn();
            });
        });

        if (_count > 1) {
            _count = Math.ceil(_count / _vis);
            _dist = Number(_vis * _thumbLarg);
            _speed = Number(_dist * 2);
            _next.removeClass('off');
            _prev.bind('click', function () {
                if (!$(this).hasClass('off')) {
                    doSlide(_index - 1);
                }
            });
            _next.bind('click', function () {
                if (!$(this).hasClass('off')) {
                    doSlide(_index + 1);
                }
            });
            checkSetas();
        }
    });
}

/*
 *
 * msvSlideImgTxt plugin
 *
 */
$.fn.msvSlideImgTxt = function (aDist, oAuto) {
    return this.each(function () {
        var _this = $(this),
			_imgs = _this.find('> .fotos'),
			_txt = _this.find('> .textos'),
			_nav = _this.find('> nav'),
			_imgsSlider = _imgs.find('> ul'),
			_imgsSliderLi = _imgsSlider.find('> li'),
			_count = _imgsSliderLi.length,
			_txtLi = _txt.find('li'),
			_navLi = _nav.find('li'),
			_oldOn = 0,
			_on = 0,
			/* anim */
			_dist = aDist,
			_speed = _dist * 2,
			_easeFx = 'easeOutExpo',
			_dur = 7000,
			_auto = oAuto,
			initTimer = 0,
			autoSlide = function () {
			    _oldOn = _on;
			    _on == _count - 1 ? _on = 0 : _on++;
			    mudaOn();
			},
			reseTimer = function () {
			    initTimer = setTimeout(autoSlide, Number(_dur + 1000));
			},
			mudaOn = function () {
			    if (_auto) {
			        clearTimeout(initTimer);
			        reseTimer();
			    }
			    _imgsSlider.stop().animate({ left: -Number(_on * _dist) }, _speed, _easeFx);
			    _txtLi.eq(_oldOn).stop().fadeTo(1000, 0, function () {
			        $(this).hide();
			    });
			    _txtLi.eq(_on).stop().fadeTo(1000, 1);
			    _navLi.eq(_oldOn).removeClass();
			    _navLi.eq(_on).removeClass().addClass('on');
			};
        _imgsSlider.css({ width: Number(_count * _dist) });
        _txtLi.eq(0).fadeTo(600, 1);
        if (_count > 1) {
            _navLi.each(function (intIndex) {
                $(this).bind('click', function () {
                    _oldOn = _on;
                    _on = intIndex;
                    mudaOn();
                });
            });
            if (_auto) {
                clearTimeout(initTimer);
                reseTimer();
            }
        }
    });
}

/* msvDropDown plugin */
$.fn.msvDropDown = function (indx) {
    return this.each(function () {
        var oBtn = $(this),
			count = oBtn.length,
			oWrap = $(this).find('> .wrap'),
			oSpan = oWrap.find('> span'),
			oInputSS = $('#' + oSpan.attr('id') + 'Id'),
			oValorSS = oInputSS.val(),  // hidden div p server side
			oHtmlSS = oSpan.html(),
			aList = $(this).find('> .ddList'),
			osLi = aList.find('li'),
			build = function (oBtn, oSpan, oInputSS, oValorSS, oHtmlSS, aList, osLi) {
			    osLi.removeClass();
			    oSpan.html(oHtmlSS);
			    $('#' + oValorSS).addClass('on');
			    setTimeout(function () {
			        oSpan.css({ 'position': 'relative' });
			    }, 200);
			    oBtn.bind('click  touchend', function () {
			        if (oBtn.hasClass('on')) {
			            if (!navigator.userAgent.match(/(iPhone|iPod|iPad|Android|BlackBerry|J2ME|Windows Mobile|Windows Phone)/)) oBtn.trigger('mouseleave');
			        } else {
			            aList.show();
			            oBtn.addClass('on');
			            oInputSS.trigger('focus'); // para despoletar accao no msvDropKeyScroll		
			        }
			    });
			    oBtn.mouseleave(function () {
			        oInputSS.trigger('blur'); // para despoletar accao no msvDropKeyScroll
			        aList.hide();
			        oBtn.removeClass('on');
			        osLi.removeClass('actual');
			    });
			    osLi.each(function () {
			        $(this).click(function () {
			            if (!$(this).hasClass('on')) {
			                osLi.removeClass();
			                $(this).addClass('on');
			                oBtn.trigger('mouseleave');
			                muda($(this).html(), $(this).attr('id'));
			            }
			            return false;
			        });
			    });
			    function muda(oHtml, oValorSS) {
			        oSpan.html(oHtml);
			        oInputSS.val(oValorSS);
			        oInputSS.trigger('change'); // trigger change event
			    }
			};

        if (oValorSS != '') {
            oHtmlSS = $('#' + oValorSS).html();
        }
        oBtn.css({ 'z-index': Number(100 - indx) });
        build(oBtn, oSpan, oInputSS, oValorSS, oHtmlSS, aList, osLi);
        setTimeout(function () {
            oBtn.msvDropKeyScroll(); // msv plugin
        }, 200);
    });
}

/* msvDropKeyScroll plugin */
$.fn.msvDropKeyScroll = function (_callback) {
    return this.each(function () {
        var el = $(this),
			elInp = el.find('input'),
			aLista = el.find('.ddList > div'),
			osLis = el.find('li'),
			osLisCount = osLis.length,
			keyPositions = {},
			charact = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
			i, j, k, actual = 0, actualTop = 0, aListaH = 0,
			letterCheck = function (_code) {
			    var theChar = String.fromCharCode(_code).toLowerCase(), theCount = 0;
			    if (_code == 38) { // up
			        actual == 0 ? actual = osLisCount - 1 : actual--;
			        goToChar();
			        return false;
			    } else if (_code == 40) { // down
			        actual == osLisCount - 1 ? actual = 0 : actual++;
			        goToChar();
			        return false;
			    } else if (theChar in keyPositions) {
			        theCount = keyPositions[theChar].length;
			        if (theCount > 1) {
			            // para todos as posicoes/lis do char
			            for (k = 0; k < theCount; k += 1) {
			                // se actual estiver antes desta posicao/li, actual = este li
			                if (keyPositions[theChar][k] > actual) {
			                    actual = keyPositions[theChar][k];
			                    goToChar();
			                    break;
			                    // se chegamos ao fim da drop, actual = primeira posicao/li da lista
			                } else if (k == theCount - 1) {
			                    actual = keyPositions[theChar][0];
			                    goToChar();
			                }
			            }
			        } else {
			            actual = keyPositions[theChar][0];
			            goToChar();
			        }
			    }
			},
			goToChar = function () {
			    osLis.removeClass('actual');
			    osLis.eq(actual).addClass('actual');
			    // coloca lista na pos0 - necessario para calcular position().top dos lis
			    aLista.scrollTop(0);
			    actualTop = osLis.eq(actual).position().top;
			    if (actualTop > Number(aListaH - 31)) {
			        aLista.scrollTop(-Number(aListaH - 31 - actualTop));
			    }
			}

        // indexa posicao de todos os caracteres
        for (i = 0; i < 36; i += 1) {
            // para todos os li da drop
            for (j = 0; j < osLisCount; j += 1) {
                // se caractere "existir"
                if (osLis.eq(j).text().charAt(0).toLowerCase() == charact[i]) {  // faster than .substr(0,1)
                    if (charact[i] in keyPositions) {
                        keyPositions[charact[i]].push(j);
                    } else {
                        keyPositions[charact[i]] = [j];
                    }
                }
            }
        }
        elInp.bind('blur', function () {
            tmpview.doc.unbind('keydown');
            tmpview.doc.unbind('keyup');
        });
        elInp.bind('focus', function () {
            tmpview.doc.unbind('keydown');
            tmpview.doc.unbind('keyup');
            tmpview.doc.bind('keydown', function (e) {
                return false;
            });
            tmpview.doc.bind('keyup', function (e) {
                var code = (e.keyCode ? e.keyCode : e.which);
                if (aListaH == 0) aListaH = aLista.height();
                if (code == 13) { // enter
                    osLis.each(function () {
                        if ($(this).hasClass('actual')) {
                            $(this).trigger('click');
                            return false;
                        }
                    });
                } else {
                    letterCheck(code);
                }
            });
        });
        if (typeof _callback == 'function') {
            _callback.call(this);
        }
    });
}

/* msvDropValidOnChange plugin */
$.fn.msvDropValidOnChange = function () {
    return this.each(function () {
        var _this = $(this),
			_parent = $(this).parents('.ddown2'),
			oError = 0;
        _this.bind('change', function () {
            oError = _parent.find('div.error');
            if (tmpview.ha(oError)) {
                if (!oError.hasClass('ok')) { oError.addClass('ok'); }
            } else {
                _parent.append('<div class="error ok"></div>');
            }
        });

    });
}

/* msvCoinSize plugin */
$.fn.msvCoinSize = function () {
    return this.each(function () {
        var _this = $(this),
        	_s = _this.find('> p').not('.euro').text();
        if (_s.length > 10) {
            _this.addClass('coin11');
        } else if (_s.length > 8) {
            _this.addClass('coin9');
        } else if (_s.length > 6) {
            _this.addClass('coin7');
        } else if (_s.length > 4) {
            _this.addClass('coin5');
        }
    });
}

/*
 *
 * By Maggie Wachs and Scott Jehl - and Changed by Massive Lda
 *
 */
$.fn.customInput = function () {
    return this.each(function () {
        var _this = $(this),
			_label = 0,
			_input = 0,
			_allInputs = 0,
		createCustom = function () {
		    _label = $('label[for=' + _this.attr('id') + ']');
		    _input = (_this.is('[type=checkbox]')) ? 'checkbox' : 'radio';
		    $('<div class="custom-' + _input + '"></div>').insertBefore(_this).append(_this, _label);
		    _allInputs = $('input[name=' + _this.attr('name') + ']');
		    _label.hover(
				function () {
				    $(this).addClass('hover');
				    if (_input == 'checkbox' && _this.is(':checked')) {
				        $(this).addClass('checkedHover');
				    }
				},
				function () { $(this).removeClass('hover checkedHover'); }
			);
		    _this.bind('updateState', function () {
		        if (_this.is(':checked')) {
		            if (_this.is(':radio')) {
		                _allInputs.each(function () {
		                    $('label[for=' + $(this).attr('id') + ']').removeClass('checked');
		                });
		            };
		            _label.addClass('checked');
		        }
		        else { _label.removeClass('checked checkedHover checkedFocus'); }
		    })
			.trigger('updateState')
			.click(function () {
			    $(this).trigger('updateState');
			})
			.focus(function () {
			    _label.addClass('focus');
			    if (_input == 'checkbox' && _this.is(':checked')) {
			        $(this).addClass('checkedFocus');
			    }
			})
			.blur(function () { _label.removeClass('focus checkedFocus'); });
		}
        if (_this.is('[type=checkbox],[type=radio]')) createCustom();
    });
}

/*
 *
 * Full width carousel plugin - FALTA DEPOIS FUNCIONAR COM O ARRAY
 *
 */
$.fn.carouselPlugin = function () {
    return this.each(function () {
        var _this = $(this),
			_slider = _this.find('> .slider'),
			_articles = _slider.find('> article'),
			_count = _articles.length,
			_initcount = _count,
			_prev = _this.find('#goPrev'),
			_next = _this.find('#goNext'),
			_ocult = _this.find('.ocult'),
			_elements = _this.find('> .slider, > .in, > .bulletNav, .whyUs'),
			_loader = $('#carouselloader'),

			_bulletNav = _this.find('.bulletNav'),
			_bulletLi = _bulletNav.find('li'),
			_bulletCount = _bulletLi.length,

			_index = 0,
			_width = 990,

			_ratio = 0.65,

			_speed = 1000,
			_hWidth = 0,
			_left = 0,
			_animateW = 0,

			_eq = 0,

			_auto = true,
			_dur = 7000,
			_timedSlide = 0,

			_clickevnt = true,
            _timerfade = 0;
            _itsClick = false;

			calculate = function () {
			    _prev.css({ top: Math.round(_this.height() / 2) });
			    _next.css({ top: Math.round(_this.height() / 2) });

			    _hWidth = _count * _width;
			    _left = -Number(Math.round(_width - ((tmpview.bod.width() / _width - 1) * _width / 2)));
			    _ocult.css({ width: _width - Math.abs(_left) + 1 });
			    if (!_left) _left = 0;
			    _slider.css({ left: _left });
			},
			calculatePosLeft = function () {
			    _slider.css({ left: _left });
			    _articles = _slider.find('> article');
			    var thisOne = _articles.first();
			    _articles.first().remove();
			    _slider.append(thisOne);
			},
			calculatePosRight = function () {
			    _slider.css({ left: _left });
			    _articles = _slider.find('> article');
			    var thisOne = _articles.last();
			    _articles.last().remove();
			    _slider.prepend(thisOne);
			},
			doSlide = function (where) {
                
			    clearTimeout(_timedSlide);
			    _clickevnt = false;

			    _index += where;
			    if (_index > _bulletCount - 1) _index = 0;
			    if (_index < 0) _index = _bulletCount - 1;

			    _bulletLi.removeClass();
			    _bulletLi.eq(_index).addClass('current');

			    if (where > 0) {
			        _animateW = _left - _width;
			        _slider.stop().animate({ left: _animateW }, _speed, 'easeInOutExpo', function () {
			            calculatePosLeft();
			            textAnimation();
			            _clickevnt = true;
			        });
			    } else {
			        _animateW = _left;
			        _slider.stop().animate({ left: _animateW }, _speed, 'easeInOutExpo', function () { _clickevnt = true; textAnimation(); });
			    }

			    restartTimer();
			},
			doSlideBullet = function (where) {

			    clearTimeout(_timedSlide);
			    _clickevnt = false;


			    var seeWhere = where - _index;
			    if (seeWhere < -1 && _initcount > 3) seeWhere = _count - (Math.abs(_index - where));

			    _index = where;

			    //Avança 1
			    if (seeWhere == 1 || seeWhere == -Math.abs(_bulletCount - 1)) {
			        _animateW = _left - _width;
			        _slider.stop().animate({ left: _animateW }, _speed, 'easeInOutExpo', function () {
			            calculatePosLeft();
			            _clickevnt = true;
			            textAnimation();
			        });

			    //Retrocede 1	
			    } else if (seeWhere == -1 || seeWhere == _bulletCount - 1) {
			        _slider.css({ left: _left - _width });
			        _articles = _slider.find('> article');
			        var thisOne = _articles.last();
			        _articles.last().remove();
			        _slider.prepend(thisOne);
			        _animateW = _left;
			        _slider.stop().animate({ left: _animateW }, _speed, 'easeInOutExpo', function () { _clickevnt = true; textAnimation(); });

			    //Retrocede ou avança mais que 1
			    } else {
			        _animateW = _left - (_width * Math.abs(seeWhere));
			        _slider.stop().animate({ left: _animateW }, _speed, 'easeInOutExpo', function () {
			            for (var i = 0; i < Math.abs(seeWhere) ; i++) { calculatePosLeft(); textAnimation(); }
			            _clickevnt = true;
			        });
			    }

			    _bulletLi.removeClass();
			    _bulletLi.eq(where).addClass('current');

			    restartTimer();
			},
			restartTimer = function () {
			    _timedSlide = setTimeout(autoSlide, _dur + 500);
			},
			autoSlide = function () {
			    if (_auto) doSlide(1);
			},
			duplicate = function () {
			    _slider.append(_articles.clone());
			    _articles = _slider.find('> article');
			    _count = _articles.length;
			}

        //Duplicate all articles before make calcs
        if (_count == 3) duplicate();

        //Makes all main calcules
        calculate(); calculatePosRight();

        //Auto Slide
        if (_auto) _timedSlide = setTimeout(autoSlide, _dur);

        //Sets slider width
        _slider.css({ width: _hWidth });

        function textAnimation() {
            var articlecont = _slider.find('> article');
            if (tmpview.ha('.hotelMain') || tmpview.ha('.callfadetext')) {
                if (_itsClick) {
                    clearTimeout(_timerfade);
                    articlecont.find('header').hide();
                    _timerfade = setTimeout(function () {
                        articlecont.eq(1).find('header').fadeIn(600);
                    }, 1500);
                    _itsClick = false;
                } else {
                    articlecont.find('header').show();
                }
                
            } else {
                articlecont.find('header').hide();
                articlecont.eq(1).find('header').fadeIn(600);
            }
        }

        //Previous and Next Buttons
        _prev.bind('click touchend', function () {
            if (_clickevnt) {
                _slider.css({ left: _left - _width });
                _articles = _slider.find('> article');
                var thisOne = _articles.last();
                _articles.last().remove();
                _slider.prepend(thisOne);
                setTimeout(function () {
                    if (tmpview.ha('.hotelMain') || tmpview.ha('.callfadetext')) {
                        var articlecont = _slider.find('> article');
                        articlecont.find('header').hide();
                    }
                }, _speed-500);
                _itsClick = true;
                doSlide(-1);
            }
        });
        _next.bind('click touchend', function () {
            if (_clickevnt) {
                setTimeout(function () {
                    if (tmpview.ha('.hotelMain') || tmpview.ha('.callfadetext')) {
                        var articlecont = _slider.find('> article');
                        articlecont.find('header').hide();
                    }
                }, _speed - 500);
                _itsClick = true;
                doSlide(1);
            }
        });

        _slider.hammer().on("swipeleft", function (event) {
            if (_clickevnt) {
                setTimeout(function () {
                    if (tmpview.ha('.hotelMain') || tmpview.ha('.callfadetext')) {
                        var articlecont = _slider.find('> article');
                        articlecont.find('header').hide();
                    }
                }, _speed - 500);
                _itsClick = true;
                doSlide(1);
            }
        });
        _slider.hammer().on("swiperight", function (event) {
            if (_clickevnt) {
                _slider.css({ left: _left - _width });
                _articles = _slider.find('> article');
                var thisOne = _articles.last();
                _articles.last().remove();
                _slider.prepend(thisOne);
                setTimeout(function () {
                    if (tmpview.ha('.hotelMain') || tmpview.ha('.callfadetext')) {
                        var articlecont = _slider.find('> article');
                        articlecont.find('header').hide();
                    }
                }, _speed - 500);
                _itsClick = true;
                doSlide(-1);
            }
        });

        _bulletLi.bind('click touchend', function () {
            if (_clickevnt && !$(this).hasClass('current')) {
                doSlideBullet($(this).index());
            }
        });

        function responsive() {
            _articles = _slider.find('> article');
            _slider.css({ width: _hWidth });
        }

        //responsive();
        tmpview.win.bind('resize', function () {
            //responsive();
            calculate();
        });

        //Loader stuff

        _articles.waitForImages(function () {
            _elements.hide();
            _loader.fadeOut(400, function () {
                _elements.fadeIn(400);
            });
        });
        textAnimation();
    });
}