﻿var reply;
var pre=0;
var myVar;
var tout;
var check=0;

function isEMailAddr(elem) {
    var str = elem.value;
    str = str.toLowerCase();
    if (str.indexOf("@") > 1) {
        var addr = str.substring(0, str.indexOf("@"));
        var domain = str.substring(str.indexOf("@") + 1, str.length);
        // at least one top level domain required
        if (domain.indexOf(".") == -1) {
            //alert("Verify the domain portion of the email address.");
            return false;
        }
        // parse address portion first, character by character
        for (var i = 0; i < addr.length; i++) {
            oneChar = addr.charAt(i).charCodeAt(0);
            // dot or hyphen not allowed in first position; dot in last
            if ((i == 0 && (oneChar == 45 || oneChar == 46))  || 
                (i == addr.length - 1 && oneChar == 46)) {
             //   alert("Verify the user name portion of the email address.");
                return false;
            }
            // acceptable characters (- . _ 0-9 a-z)
            if (oneChar == 45 || oneChar == 46 || oneChar == 95 || 
                (oneChar > 47 && oneChar < 58) || (oneChar > 96 && oneChar < 123)) {
                continue;
            } else {
             //   alert("Verify the user name portion of the email address.");
                return false;
            }
        }
        for (i = 0; i < domain.length; i++) {
            oneChar = domain.charAt(i).charCodeAt(0);
            if ((i == 0 && (oneChar == 45 || oneChar == 46)) || 
                ((i == domain.length - 1  || i == domain.length - 2) && oneChar == 46)) {
             //   alert("Verify the domain portion of the email address.");
                return false;
            }
            if (oneChar == 45 || oneChar == 46 || oneChar == 95 || 
                (oneChar > 47 && oneChar < 58) || (oneChar > 96 && oneChar < 123)) {
                continue;
            } else {
             //   alert("Verify the domain portion of the email address.");
                return false;
            }
        }
        return true;
    }
  //  alert("The email address may not be formatted correctly. Please verify.");
    return false;
}

function chkKeyDigit(event) {
	if(navigator.appName=='Netscape')
      var k = event.which;
	  else
	  var k = event.keyCode;
	  if(k==0 || k==8){
		return true;  
	  }
      else if (k < 48 || k > 57) {
            return false;
      }
      return true;
}

function showForm(){

	if(document.getElementById('commentForm').style.display=='block'){
	$("#commentForm").slideUp("hide");
	}else{
	$("#commentForm").slideDown("show");
	}
	
}


function show_msg(){
		document.getElementById('name').style.disabled=false;
		document.getElementById('phone').style.disabled=false;
		document.getElementById('message').style.disabled=false;
		document.getElementById('email2').style.disabled=false;
		document.getElementById('submit').style.disabled=false;
		document.getElementById('clear').style.disabled=false;
		
		document.getElementById('name').value='Name:';
		document.getElementById('phone').value='Phone:';
		document.getElementById('message').value='Message:';	
		document.getElementById('email2').value='E-mail:';
	    document.getElementById('contact_error').innerHTML='<span class="sendMessage" style="display:block">Your message sent successfully !</span>';	
}

		
function SubmitForm() {
	if(document.getElementById('name').value=="" || document.getElementById('name').value=="Name:" || document.getElementById('phone').value=="" || document.getElementById('phone').value=="Phone:" || document.getElementById('message').value=="" || document.getElementById('message').value=="Messages:" ){
	document.getElementById('contact_error').innerHTML='<span class="errorMessage" style="display:block">Please fill in all fields !</span>';	
 }else if(!isEMailAddr(document.getElementById('email2'))){
	 document.getElementById('contact_error').innerHTML='<span class="errorMessage" style="display:block">Please Enter an valid E-mail Address !</span>';	
 }else{
	 	if(confirm("Are you sure ?")){
			var name_value = $('#name').val();
			var phone_value = $('#phone').val();
			var msg_value = $('#message').val();
			var email_value = $('#email2').val();
		document.getElementById('name').style.disabled=true;
		document.getElementById('phone').style.disabled=true;
		document.getElementById('message').style.disabled=true;
		document.getElementById('email2').style.disabled=true;
		document.getElementById('submit').style.disabled=true;
		document.getElementById('clear').style.disabled=true;
		document.getElementById('contact_error').innerHTML='<span class="waitMessage" style="display:block">Please wait ...</span>';
		$.post("modules/add_contact.php", {name:name_value,phone:phone_value,email:email_value,message:msg_value }, function(response) {
			//timeout();				
			var response = eval('(' + response + ')');			
			//alert(response.success);
			if (response.success){
				setTimeout("show_msg()", 3000);
			}
		  });
		}
	}
}


function show_msg2(){
		document.getElementById('name').style.disabled=false;
		document.getElementById('phone').style.disabled=false;
		document.getElementById('message').style.disabled=false;
		document.getElementById('email2').style.disabled=false;
		document.getElementById('submit').style.disabled=false;
		document.getElementById('clear').style.disabled=false;
		
		document.getElementById('name').value='نام :';
		document.getElementById('phone').value='تلفن :';
		document.getElementById('message').value='متن پیغام :';	
		document.getElementById('email2').value='پست الکترونیکی :';
	    document.getElementById('contact_error').innerHTML='<span class="sendMessage" style="display:block">! پیغام شما با موفقیت ارسال گردید</span>';	
}

		
function SubmitForm2() {
	if(document.getElementById('name').value=="" || document.getElementById('name').value=="نام :" || document.getElementById('phone').value=="" || document.getElementById('phone').value=="تلفن :" || document.getElementById('message').value=="" || document.getElementById('message').value=="متن پیغام :" ){
	document.getElementById('contact_error').innerHTML='<span class="errorMessage" style="display:block">! لطفا تمامی فیلدها را به صورت کامل پر کنید</span>';	
 }else if(!isEMailAddr(document.getElementById('email2'))){
	 document.getElementById('contact_error').innerHTML='<span class="errorMessage" style="display:block">! لطفا یک آدرس ایمیل معتبر وارد نمایید</span>';	
 }else{
	 	if(confirm("آیا مطمئن هستید ؟")){
			var name_value = $('#name').val();
			var phone_value = $('#phone').val();
			var msg_value = $('#message').val();
			var email_value = $('#email2').val();
		document.getElementById('name').style.disabled=true;
		document.getElementById('phone').style.disabled=true;
		document.getElementById('message').style.disabled=true;
		document.getElementById('email2').style.disabled=true;
		document.getElementById('submit').style.disabled=true;
		document.getElementById('clear').style.disabled=true;
		document.getElementById('').innerHTML='<span class="waitMessage" style="display:block">... کمی صبر کنید</span>';
		$.post("modules/add_contact.php", {name:name_value,phone:phone_value,email:email_value,message:msg_value }, function(response) {
			//timeout();				
			var response = eval('(' + response + ')');			
			//alert(response.success);
			if (response.success){
				setTimeout("show_msg2()", 3000);
			}
		  });
		}
	}
}


function ret2(){	
document.getElementById('bt_submit').style.filter='alpha(opacity=100)'; // IE
document.getElementById('bt_submit').style.opacity='1'; // FF

}

function timeout(){
document.getElementById('waitMessage').style.display='none';	
document.getElementById('sendMessage').style.display='block';
document.getElementById('bt_submit').style.filter='alpha(opacity=100)'; // IE
document.getElementById('bt_submit').style.opacity='1'; // FF
document.getElementById('bt_submit').style.disabled='false';
document.getElementById('bt_submit').style.cursor='pointer';
document.getElementById('email').disabled='';
document.getElementById('email').value='';
}

function repeated(){
document.getElementById('waitMessage').style.display='none';
document.getElementById('error1').style.display='block';
document.getElementById('bt_submit').style.filter='alpha(opacity=100)'; // IE
document.getElementById('bt_submit').style.opacity='1'; // FF
document.getElementById('bt_submit').style.disabled='false';
document.getElementById('bt_submit').style.cursor='pointer';
document.getElementById('email').disabled='';
document.getElementById('email').value='';
}

	function submit_me() {
		
		document.getElementById('sendMessage').style.display='none';
		document.getElementById('error1').style.display='none';
		document.getElementById('error2').style.display='none';
		if( isEMailAddr(document.getElementById('email') )){
		document.getElementById('waitMessage').style.display='block';
		document.getElementById('bt_submit').style.filter='alpha(opacity=60)'; // IE
		document.getElementById('bt_submit').style.opacity='0.6'; // FF
		document.getElementById('bt_submit').style.disabled='true';
	   document.getElementById('bt_submit').style.cursor='default';
	   	document.getElementById('email').disabled='true';
		var email_value = $('#email').val();
		
		$.post("modules/ajax_subscribe.php", {email:email_value }, function(response) {
			//timeout();				
			var response = eval('(' + response + ')');			
			//alert(response.success);
			if (response.success=="1"){
				setTimeout("repeated()", 3000);
			}
			else if (response.success=="2"){
				setTimeout("timeout()", 3000);
			}
		  });
		
	//setTimeout("timeout()", 3000); // delete this line
		}else{
			document.getElementById('email').focus();	
		document.getElementById('sendMessage').style.display='none';
		document.getElementById('error1').style.display='none';
		document.getElementById('error2').style.display='none';
	document.getElementById('error2').style.display='block';	
		setTimeout("ret2()", 3000);
		
		}
		
				}

function ch_enter(e) {
      var k = (e.which)? e.which : e.keyCode;
      if (k == 13) {
          submit_me();
      }
}
	