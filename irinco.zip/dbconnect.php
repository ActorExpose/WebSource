<?
$db_user 			= 	"root";			// db username
$db_pass 			= 	"";				// db password
$db_host 			= 	"localhost";	// db host
$db 				= 	"irin";			// db

mysql_connect($db_host,$db_user,$db_pass);
mysql_select_db($db) or die( "Unable to select database");
?>