<?
if (eregi('config', $_SERVER['PHP_SELF'])) {
    exit();
}  
session_start();

include_once('dbconnect.php');

$time=time();
$offset=4.5;
$timezone=3600*$offset;

$today = getdate($time+$timezone);

function cleanall() 
{
	foreach($_POST as $key => $val) 
	{
		$_POST[$key] = addslashes(htmlspecialchars($val, ENT_QUOTES));
		$$key = addslashes(htmlspecialchars($val, ENT_QUOTES));
	}
	foreach($_GET as $key => $val) 
	{
		$_GET[$key] = addslashes(htmlspecialchars($val, ENT_QUOTES));
		$$key = stripslashes(htmlspecialchars($val, ENT_QUOTES));
	}
}
//cleanall();
//Farsi date
function diving($a,$b) {
    return (int) ($a / $b);
}
function gre_2_jalali ($g_y, $g_m, $g_d)
{
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);     

   $gy = $g_y-1600;
   $gm = $g_m-1;
   $gd = $g_d-1;

   $g_day_no = 365*$gy+diving($gy+3,4)-diving($gy+99,100)+diving($gy+399,400);

   for ($i=0; $i < $gm; ++$i)
      $g_day_no += $g_days_in_month[$i];
   if ($gm>1 && (($gy%4==0 && $gy%100!=0) || ($gy%400==0)))
      /* leap and after Feb */
      $g_day_no++;
   $g_day_no += $gd;

   $j_day_no = $g_day_no-79;

   $j_np = diving($j_day_no, 12053); /* 12053 = 365*33 + 32/4 */
   $j_day_no = $j_day_no % 12053;

   $jy = 979+33*$j_np+4*diving($j_day_no,1461); /* 1461 = 365*4 + 4/4 */

   $j_day_no %= 1461;

   if ($j_day_no >= 366) {
      $jy += diving($j_day_no-1, 365);
      $j_day_no = ($j_day_no-1)%365;
   }

   for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
      $j_day_no -= $j_days_in_month[$i];
   $jm = $i+1;
   $jd = $j_day_no+1;
   
   return array($jy, $jm, $jd);
}
//Farsi Number
function Ct($srting) 
{
	$num0="۰";
	$num1="۱";
	$num2="۲";
	$num3="۳";
	$num4="۴";
	$num5="۵";
	$num6="۶";
	$num7="۷";
	$num8="۸";
	$num9="۹";	
	$stringtemp="";
	$len=strlen($srting);
	for($sub=0;$sub<$len;$sub++)
	{
	 if(substr($srting,$sub,1)=="0")$stringtemp.=$num0;
	 elseif(substr($srting,$sub,1)=="1")$stringtemp.=$num1;
	 elseif(substr($srting,$sub,1)=="2")$stringtemp.=$num2;
	 elseif(substr($srting,$sub,1)=="3")$stringtemp.=$num3;
	 elseif(substr($srting,$sub,1)=="4")$stringtemp.=$num4;
	 elseif(substr($srting,$sub,1)=="5")$stringtemp.=$num5;
	 elseif(substr($srting,$sub,1)=="6")$stringtemp.=$num6;
	 elseif(substr($srting,$sub,1)=="7")$stringtemp.=$num7;
	 elseif(substr($srting,$sub,1)=="8")$stringtemp.=$num8;
	 elseif(substr($srting,$sub,1)=="9")$stringtemp.=$num9;
	 else $stringtemp.=substr($srting,$sub,1);
	}
return   $stringtemp;
}
//Farsi Month
/* monthname function */
define('_JDF_Far','فروردین');
define('_JDF_Ord','اردیبهشت');
define('_JDF_Kho','خرداد');
define('_JDF_Tir','تیر');
define('_JDF_Mor','مرداد');
define('_JDF_Sha','شهریور');
define('_JDF_Meh','مهر');
define('_JDF_Aba','آبان');
define('_JDF_Aza','آذر');
define('_JDF_Dey','دی');
define('_JDF_Bah','بهمن');
define('_JDF_Esf','اسفند');
//Convert 2 Farsi Month
function jalaly_month_name($j_month)
{
    if($j_month=="1") return _JDF_Far;
    if($j_month=="2") return _JDF_Ord;
    if($j_month=="3") return _JDF_Kho;
    if($j_month=="4") return _JDF_Tir;
    if($j_month=="5") return _JDF_Mor;
    if($j_month=="6") return _JDF_Sha;
    if($j_month=="7") return _JDF_Meh;
    if($j_month=="8") return _JDF_Aba;
    if($j_month=="9") return _JDF_Aza;
    if($j_month=="10") return _JDF_Dey;
	if($j_month=="11") return _JDF_Bah;
    if($j_month=="12") return _JDF_Esf;
}

$p_year			=	$_POST['p_year'];	
$p_month		=	$_POST['p_month'];
$p_day			= 	$_POST['p_day'];

$p_hour			=	$_POST['p_hour'];
$p_min			=	$_POST['p_min'];

$dates = date("Y-m-d",$time+$timezone); 
list( $gyear, $gmonth, $gday ) = preg_split ( '/-/', $dates );
list( $jyear, $jmonth, $jday ) = gre_2_jalali($gyear, $gmonth, $gday);
$jmon = jalaly_month_name($p_month);
$postdate			= 	$jday.'/'.$jmonth.'/'.$jyear;
$year				= 	$p_year; 
$month 				= 	$jmon;
$smonth 			= 	$p_month;
$day				= 	$p_day;
$posttime 			= 	date( "H:i",$time+$timezone);
$photostamp			= 	date( "Y-m-d",$time+$timezone)."-";
$filestamp			=	date( "Y-m-d",$time+$timezone)."-";

switch (date("w",$time+$timezone)){

case 6 :
	$pday="شنبه";
	
break;

case 0 :
	$pday="يكشنبه";

break;
case 1 :
	$pday="دوشنبه";

break;
case 2 :
	$pday="سه شنبه";

break;
case 3 :
	$pday="چهار شنبه";

break;
case 4 :
	$pday="پنج شنبه";

break;
case 5 :
	$pday="جمعه";

break;

}

$user_ip = $_SERVER['REMOTE_ADDR'];
$useragent = ($_SERVER['HTTP_USER_AGENT']);
if (isset($_SERVER)) 
{ 
	if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) 
    { 
    	$user_ip = $_SERVER["HTTP_X_FORWARDED_FOR"]; 
    } 
    elseif (isset($_SERVER["HTTP_CLIENT_IP"])) 
    { 
         $user_ip = $_SERVER["HTTP_CLIENT_IP"]; 
    } 
    else 
    { 
         $user_ip = $_SERVER["REMOTE_ADDR"]; 
    } 
} 
else 
{ 
	if ( getenv( 'HTTP_X_FORWARDED_FOR' ) ) 
    { 
        $user_ip = getenv( 'HTTP_X_FORWARDED_FOR' ); 
    } 
    elseif ( getenv( 'HTTP_CLIENT_IP' ) ) 
    { 
         $user_ip = getenv( 'HTTP_CLIENT_IP' ); 
    } 
    else 
    { 
      	$user_ip = getenv( 'REMOTE_ADDR' ); 
    } 
} 

$q    				= 	$_GET['q'];
$newsyear			= 	$_GET['newsyear'];
$newsmonth			= 	$_GET['newsmonth'];
$id    				= 	$_REQUEST['id'];
$flag 				=   $_POST['flag'];
$comment			=	$_POST['comment'];
$commentid			=	$_POST['commentid'];
$commentname		= 	$_POST['commentname'];
$commentmail		= 	$_POST['commentmail'];
$commentwebsite		= 	$_POST['commentwebsite'];
$humanverif			= 	$_POST['humanverif'];
$humanverifcheck	= 	$_POST['humanverifcheck'];
$hide_mail			=   $_POST['hide_mail'];
$rate				=	$_POST['rate'];
$searchstring		= 	$_POST['searchstring'];

$style				= 	$_POST['style'];
$websitetitle		= 	$_POST['websitetitle'];
$adminmail			= 	$_POST['adminmail'];
$metadescription	= 	$_POST['metadescription'];
$metakeywords		= 	$_POST['metakeywords'];
$metalanguage		= 	$_POST['metalanguage'];
$metakeywords		= 	$_POST['metakeywords'];
$metaauthor			= 	$_POST['metaauthor'];
$uploadabsolute		= 	$_POST['uploadabsolute'];
$uploadrelative		=	$_POST['uploadrelative'];
$siteurl			=	$_POST['siteurl'];
$limitnews			=	$_POST['limitnews'];

$ip 				=	$_POST['ip'];
$reason 			=	$_POST['reason'];
$legnth 			=	$_POST['legnth'];

$title				=	$_POST['title'];
$newstext			=	$_POST['newstext'];
$pagestext			=   $_POST['pagestext'];
$filename			=	$_POST['filename'];
$filetype			=	$_POST['filetype'];
$icon				=	$_POST['icon'];

$ptitle				=	$_POST['ptitle'];
$priority			=	$_POST['priority'];
$pagetext			=	$_POST['pagetext'];

$cat 				=	$_POST['cat'];
$category			=	$_POST['category'];
$topic				=	$_REQUEST['topic'];
$newtopic			=	$_POST['newtopic'];
$submit				=   $_POST['submit'];
$cookie				=   $_POST['cookie'];

$refer 				= 	$_SERVER['HTTP_REFERER'];
$referer 			=	$_SERVER['HTTP_REFERER'];
$pagetrack			= 	$_SERVER['REQUEST_URI'];


if($cookie)
{
	setcookie("name", "$commentname", time()+31536000);
	setcookie("email","$commentmail", time()+31536000);
	setcookie("site", "$commentwebsite", time()+31536000);
}

// Description: calculates the micro time

class microTimer {
    function start() {
        global $starttime;
        $mtime = microtime ();
        $mtime = explode (' ', $mtime);
        $mtime = $mtime[1] + $mtime[0];
        $starttime = $mtime;
    }
    function stop() {
        global $starttime;
        $mtime = microtime ();
        $mtime = explode (' ', $mtime);
        $mtime = $mtime[1] + $mtime[0];
        $endtime = $mtime;
        $totaltime = round (($endtime - $starttime), 5);
        return $totaltime;
    }
}

function zone($time, $offset = 0)
{
	$timecode = 'Y/m/d @ h:i:s A';
	return date($timecode, $time + $offset);
}
function add_comma($recp){
    unset($pcount);
	unset($oldprice);
	unset($price);
	unset($newprice);
    $price=array();
	$oldprice=str_split($recp);//4
	//print_r($price);
	//$price=array_reverse($price);
	$pcount=count($oldprice)/3;
	if(!is_float($pcount))
	$pcount-=1;
	$pcount=floor($pcount);//1
	while($pcount>0){
	for($i=0;$i<3;$i++){
	$nprice=array_pop($oldprice); 
	array_push($price,$nprice);
	}
    array_push($price,",");
	$pcount--;
     }
	 while($oldprice){ 
	 $pvalue=array_pop($oldprice);
	  array_push($price,$pvalue);
	 }
	 $price=array_reverse($price);
	 foreach($price as $value)
	 $newprice.=$value;
	 return($newprice);
  }
?>