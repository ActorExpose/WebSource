<?php /* Smarty version 3.1.27, created on 2018-10-21 06:01:18
         compiled from "/home/succdtiy/investbest.club/tmpl/header_install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12741957385bcc4e6edda841_10013687%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '96aaacd707feb387b4362d4288f8d7c4f019cd38' => 
    array (
      0 => '/home/succdtiy/investbest.club/tmpl/header_install.tpl',
      1 => 1529459634,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12741957385bcc4e6edda841_10013687',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5bcc4e6edded59_60001709',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5bcc4e6edded59_60001709')) {
function content_5bcc4e6edded59_60001709 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '12741957385bcc4e6edda841_10013687';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>HYIP Manager Pro. Install Script.</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFF2" link="#666699" vlink="#666699" alink="#666699" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" >
<center>
<table width="760" border="0" cellpadding="0" cellspacing="0" height=100<?php echo '%>';?>
  <tr> 
    <td valign=top height=142>
      <table cellspacing=0 cellpadding=0 border=0 width=100% height=142>
	    <tr>
		  <td background="images/ver.gif" bgcolor=#FF8D00><img src="images/top.gif" width=304 height=142 border="0" align=left></td>
 	    </tr>
	  </table>
     </td>
  </tr>




  <tr> 
    <td valign="top">
	 <table cellspacing=0 cellpadding=1 border=0 width=100% height=100% bgcolor=#ff8d00>
	   <tr>
	     <td>
           <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
             <tr bgcolor="#FFFFFF" valign="top"> 
              <td bgcolor="#FFFFFF" valign="top" width=99<?php echo '%>';?>
            <!-- Main: Start -->
            <table width="100%" height="100%" border="0" cellpadding="10" cellspacing="0" class="forTexts">
              <tr>
                <td width=100% height=100% valign=top>
<b>HYIP Manager. Install script.</b>
<br><br>
<center><?php }
}
?>