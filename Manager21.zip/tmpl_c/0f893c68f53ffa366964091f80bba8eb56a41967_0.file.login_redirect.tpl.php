<?php /* Smarty version 3.1.27, created on 2019-09-28 10:34:13
         compiled from "/home/acwabtmg/bitcointrade.space/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:5212691705d8f6f65500a88_44789182%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0f893c68f53ffa366964091f80bba8eb56a41967' => 
    array (
      0 => '/home/acwabtmg/bitcointrade.space/tmpl/login_redirect.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5212691705d8f6f65500a88_44789182',
  'variables' => 
  array (
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5d8f6f65510896_61759383',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d8f6f65510896_61759383')) {
function content_5d8f6f65510896_61759383 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/acwabtmg/bitcointrade.space/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5212691705d8f6f65500a88_44789182';
?>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="0; URL=<?php echo smarty_modifier_myescape(encurl("?a=account"));?>
">
</head>
<body>
<center>
Hello <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
. You are redirecting to your 
<a href=?a=account>account</a> now.
<body>
</html><?php }
}
?>