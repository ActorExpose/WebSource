<?php /* Smarty version 3.1.27, created on 2020-12-08 12:48:54
         compiled from "/home/hwjxrsil/aionitecapital.pw/tmpl/footer_install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:17245153185fcfbc86694fd7_97483106%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b0151a92bd8ed79e8b253df3bc06d60f11d5a72' => 
    array (
      0 => '/home/hwjxrsil/aionitecapital.pw/tmpl/footer_install.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17245153185fcfbc86694fd7_97483106',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5fcfbc86696826_69210150',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5fcfbc86696826_69210150')) {
function content_5fcfbc86696826_69210150 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '17245153185fcfbc86694fd7_97483106';
?>

              </td>
              </tr>
            </table>
            <!-- Main: END -->

              </td>
             </tr>
           </table>
		  </td>
		 </tr>
	   </table>
	 </td>
  </tr>



  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">All Rights Reserved. <a href='http://www.goldcoders.com' class="forCopyright">HYIP Manager</a></div></td>
  </tr>
</table>
</center></body>
</html>
<?php }
}
?>