<?php /* Smarty version 3.1.27, created on 2020-12-08 12:59:06
         compiled from "/home/hwjxrsil/aionitecapital.pw/tmpl/after_registration.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:7759315115fcfbeea12d862_73015560%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b3caf05ed56f7abfd6118eb1ef7ce7173304f336' => 
    array (
      0 => '/home/hwjxrsil/aionitecapital.pw/tmpl/after_registration.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7759315115fcfbeea12d862_73015560',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5fcfbeea15a9d2_23730711',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5fcfbeea15a9d2_23730711')) {
function content_5fcfbeea15a9d2_23730711 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '7759315115fcfbeea12d862_73015560';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h3>Registration completed:</h3><br>

Thank you for joining our program.<br>
You are now an official member of this program. You can login to your account to start investing with us and use all the services that are available for our members.
<br>
<br>

<b>Important:</b> Do not provide your login and password to anyone!

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>