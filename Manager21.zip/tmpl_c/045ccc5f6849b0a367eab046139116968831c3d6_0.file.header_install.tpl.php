<?php /* Smarty version 3.1.27, created on 2019-08-18 04:23:43
         compiled from "/home/agfippvd/yooobit.pw/tmpl/header_install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:20406536875d590b0f580a35_65070557%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '045ccc5f6849b0a367eab046139116968831c3d6' => 
    array (
      0 => '/home/agfippvd/yooobit.pw/tmpl/header_install.tpl',
      1 => 1529459634,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20406536875d590b0f580a35_65070557',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5d590b0f58dcd3_73666343',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d590b0f58dcd3_73666343')) {
function content_5d590b0f58dcd3_73666343 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '20406536875d590b0f580a35_65070557';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>HYIP Manager Pro. Install Script.</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFF2" link="#666699" vlink="#666699" alink="#666699" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" >
<center>
<table width="760" border="0" cellpadding="0" cellspacing="0" height=100<?php echo '%>';?>
  <tr> 
    <td valign=top height=142>
      <table cellspacing=0 cellpadding=0 border=0 width=100% height=142>
	    <tr>
		  <td background="images/ver.gif" bgcolor=#FF8D00><img src="images/top.gif" width=304 height=142 border="0" align=left></td>
 	    </tr>
	  </table>
     </td>
  </tr>




  <tr> 
    <td valign="top">
	 <table cellspacing=0 cellpadding=1 border=0 width=100% height=100% bgcolor=#ff8d00>
	   <tr>
	     <td>
           <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
             <tr bgcolor="#FFFFFF" valign="top"> 
              <td bgcolor="#FFFFFF" valign="top" width=99<?php echo '%>';?>
            <!-- Main: Start -->
            <table width="100%" height="100%" border="0" cellpadding="10" cellspacing="0" class="forTexts">
              <tr>
                <td width=100% height=100% valign=top>
<b>HYIP Manager. Install script.</b>
<br><br>
<center><?php }
}
?>