<?php /* Smarty version 3.1.27, created on 2020-12-08 12:48:54
         compiled from "/home/hwjxrsil/aionitecapital.pw/tmpl/install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:13721691045fcfbc86637317_50743452%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2c48eef293a324423040d79e4b65e65a54a0456d' => 
    array (
      0 => '/home/hwjxrsil/aionitecapital.pw/tmpl/install.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13721691045fcfbc86637317_50743452',
  'variables' => 
  array (
    'wrong_license' => 0,
    'wrong_mysql_data' => 0,
    'installed' => 0,
    'form_data' => 0,
    'hostname' => 0,
    'script_path' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5fcfbc86686ea5_39551749',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5fcfbc86686ea5_39551749')) {
function content_5fcfbc86686ea5_39551749 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/hwjxrsil/aionitecapital.pw/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '13721691045fcfbc86637317_50743452';
echo $_smarty_tpl->getSubTemplate ("header_install.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<?php if ($_smarty_tpl->tpl_vars['wrong_license']->value == 1) {?>
</center>
Wrong license.<br><br>

Please contact <a href="http://www.goldcoders.com">www.goldcoders.com</a> if you bought license to this host.
<br><br>
<center>
<?php }?>


<?php if ($_smarty_tpl->tpl_vars['wrong_mysql_data']->value) {?>
</center>
Wrong mysql data.<br><br>

Please be sure you entered right mysql host, mysql database name, mysql login, mysql password.<br>
Ask this information your hosting provider if you not sure.
<br><br>
<center>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['installed']->value != 1) {?>
<form method=post>
<input type=hidden name=a value=install>
<table cellspacing=2 cellpadding=2 border=0>
<tr>
 <th colspan=2>MySQL data</th>
</tr><tr>
 <td>Mysql host:</td>
 <td><input type=text name=mysql_host value='<?php if ($_smarty_tpl->tpl_vars['form_data']->value['mysql_host']) {
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['mysql_host']);
} else { ?>localhost<?php }?>' class=inpts size=30></td>
</tr><tr>
 <td>Mysql database name:</td>
 <td><input type=text name=mysql_db value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['mysql_db']);?>
' class=inpts size=30></td>
</tr><tr>
 <td>Mysql username:</td>
 <td><input type=text name=mysql_username value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['mysql_username']);?>
' class=inpts size=30></td>
</tr><tr>
 <td>Mysql password:</td>
 <td><input type=text name=mysql_password value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['mysql_password']);?>
' class=inpts size=30></td>
</tr><tr>
 <th colspan=2>License data:</th>
</tr><tr>
 <td>Host:</td>
 <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['hostname']->value);?>
</td>
</tr><tr>
 <td>License key:</td>
 <td><input type=text name=license_string value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['license_string']);?>
' class=inpts size=30></td>
</tr><tr>
 <th colspan=2>Admin account data:</th>
</tr><tr>
 <td>E-mail:</td>
 <td><input type=text name=admin_email value='<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['admin_email']);?>
' class=inpts size=30></td>
</tr><tr>
 <td>Password:</td>
 <td><input type=password name=admin_password value='' class=inpts size=30></td>
</tr><tr>
 <td>&nbsp;</td>
 <td><input type=submit value='Install' class=sbmt></td>

</tr></table>
</form>
<?php } else { ?>
<h1>Script successfully installed!</h1>
<br><br>
<table cellspacing=0 cellpadding=1 border=0 width=400><tr><td>
Please delete install.php file for security reason.<br><br>

Path to script: <a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['script_path']->value);?>
" target=_blank><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['script_path']->value);?>
</a><br>
Admin login: admin<br>
Admin password: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['form_data']->value['admin_password']);?>
<br><br>

Login to admin area, go to settings screen and specify your sitename, payment accounts and other information.<br>
</td></tr></table>
<?php }?>

<?php echo $_smarty_tpl->getSubTemplate ("footer_install.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>