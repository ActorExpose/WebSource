<?php /* Smarty version 3.1.27, created on 2019-09-28 10:24:06
         compiled from "/home/acwabtmg/bitcointrade.space/tmpl/footer_install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2305847335d8f6d0655f399_08346720%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '294a16fb7cf73b8e8e2a6b500941c1aef49327e2' => 
    array (
      0 => '/home/acwabtmg/bitcointrade.space/tmpl/footer_install.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2305847335d8f6d0655f399_08346720',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5d8f6d06561938_21052613',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d8f6d06561938_21052613')) {
function content_5d8f6d06561938_21052613 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2305847335d8f6d0655f399_08346720';
?>

              </td>
              </tr>
            </table>
            <!-- Main: END -->

              </td>
             </tr>
           </table>
		  </td>
		 </tr>
	   </table>
	 </td>
  </tr>



  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">All Rights Reserved. <a href='http://www.goldcoders.com' class="forCopyright">HYIP Manager</a></div></td>
  </tr>
</table>
</center></body>
</html>
<?php }
}
?>