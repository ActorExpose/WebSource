<?php /* Smarty version 3.1.27, created on 2019-08-18 04:23:43
         compiled from "/home/agfippvd/yooobit.pw/tmpl/footer_install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:10335751405d590b0f594cc0_52746739%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ff246aebcdf6969c30f717d6db9850227639878' => 
    array (
      0 => '/home/agfippvd/yooobit.pw/tmpl/footer_install.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10335751405d590b0f594cc0_52746739',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5d590b0f598ed9_00552278',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d590b0f598ed9_00552278')) {
function content_5d590b0f598ed9_00552278 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '10335751405d590b0f594cc0_52746739';
?>

              </td>
              </tr>
            </table>
            <!-- Main: END -->

              </td>
             </tr>
           </table>
		  </td>
		 </tr>
	   </table>
	 </td>
  </tr>



  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">All Rights Reserved. <a href='http://www.goldcoders.com' class="forCopyright">HYIP Manager</a></div></td>
  </tr>
</table>
</center></body>
</html>
<?php }
}
?>