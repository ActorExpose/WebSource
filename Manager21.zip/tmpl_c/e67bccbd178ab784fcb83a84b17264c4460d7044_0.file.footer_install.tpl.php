<?php /* Smarty version 3.1.27, created on 2018-10-21 06:01:18
         compiled from "/home/succdtiy/investbest.club/tmpl/footer_install.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:9865410125bcc4e6ede1674_44737337%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e67bccbd178ab784fcb83a84b17264c4460d7044' => 
    array (
      0 => '/home/succdtiy/investbest.club/tmpl/footer_install.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9865410125bcc4e6ede1674_44737337',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5bcc4e6ede2d11_54539426',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5bcc4e6ede2d11_54539426')) {
function content_5bcc4e6ede2d11_54539426 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '9865410125bcc4e6ede1674_44737337';
?>

              </td>
              </tr>
            </table>
            <!-- Main: END -->

              </td>
             </tr>
           </table>
		  </td>
		 </tr>
	   </table>
	 </td>
  </tr>



  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">All Rights Reserved. <a href='http://www.goldcoders.com' class="forCopyright">HYIP Manager</a></div></td>
  </tr>
</table>
</center></body>
</html>
<?php }
}
?>