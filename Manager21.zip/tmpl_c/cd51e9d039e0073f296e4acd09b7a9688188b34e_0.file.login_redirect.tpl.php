<?php /* Smarty version 3.1.27, created on 2020-12-08 12:59:15
         compiled from "/home/hwjxrsil/aionitecapital.pw/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:18471550155fcfbef337a0b5_70117247%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cd51e9d039e0073f296e4acd09b7a9688188b34e' => 
    array (
      0 => '/home/hwjxrsil/aionitecapital.pw/tmpl/login_redirect.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18471550155fcfbef337a0b5_70117247',
  'variables' => 
  array (
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5fcfbef33a7c27_49519955',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5fcfbef33a7c27_49519955')) {
function content_5fcfbef33a7c27_49519955 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/hwjxrsil/aionitecapital.pw/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '18471550155fcfbef337a0b5_70117247';
?>
<html>
<head>
<META HTTP-EQUIV=Refresh CONTENT="0; URL=<?php echo smarty_modifier_myescape(encurl("?a=account"));?>
">
</head>
<body>
<center>
Hello <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
. You are redirecting to your 
<a href=?a=account>account</a> now.
<body>
</html><?php }
}
?>