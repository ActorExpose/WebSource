<?php /* Smarty version 3.1.27, created on 2019-09-28 10:34:05
         compiled from "/home/acwabtmg/bitcointrade.space/tmpl/after_registration.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:3692715815d8f6f5d9c45a0_52469090%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0cb7f1c182af5d240d83806c54822ff767c5ee99' => 
    array (
      0 => '/home/acwabtmg/bitcointrade.space/tmpl/after_registration.tpl',
      1 => 1529459628,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3692715815d8f6f5d9c45a0_52469090',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5d8f6f5d9d20d6_92901229',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5d8f6f5d9d20d6_92901229')) {
function content_5d8f6f5d9d20d6_92901229 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '3692715815d8f6f5d9c45a0_52469090';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h3>Registration completed:</h3><br>

Thank you for joining our program.<br>
You are now an official member of this program. You can login to your account to start investing with us and use all the services that are available for our members.
<br>
<br>

<b>Important:</b> Do not provide your login and password to anyone!

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>