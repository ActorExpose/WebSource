<?php
/****************奇乐网站授权管理系统 商业版 客户端*************/
/*                                                             */
/*  auth.qilewl.com (C)2018 qilewl.com Inc.                    */
/*  This is NOT a freeware, use is subject to license terms    */
/*  奇乐网站授权管理系统是商业软件,使用于商业用途请购买授权    */
/*  V1.0.0 2018                                                */
/*  官方网址：http://www.qilewl.com                            */ 
/*                                                             */                      
/***************************************************************/

 // 调试模式 
 define('APP_DEBUG',true);  //true 开启调试模式 false 关闭

 // 防止恶意访问
define('IN_AUTH', true);

require './auth.inc.php';

define('AUTH_CORE',__DIR__.'/qilecms/');  //定义核心目录

require "./qilecms/start.php";  //初始化文件

