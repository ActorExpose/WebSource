<?php

define('UPDATE_API_URL',"http://guarantee-free-auth.qilecms.com/");  // 服务端通信地址


define('AUTOBACKUP',true); //自动备份  true 备份 false 不备份

define('BACKUP_DIR',AUTH_ROOT_PATH.'data/backup/'); //备份文件存放目录

/***  需要服务端同步设置的常量 ***/
define('CLIENT_API_KEY','FKqalUm79Cnz6Y2q'); //如服务端没有修改，客户端可不修改。用户不得随意修改，通信密钥，客户端与服务端必须一致，否则升级信息无法解密

define('VERSION',AUTH_ROOT_PATH?AUTH_ROOT_PATH:AUTH_ROOT_PATH); //默认当前目录，如放在网站根目录，请用 WEB_APP_PATH