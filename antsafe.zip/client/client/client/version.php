<?php
/****************奇乐网站授权管理系统 商业版 客户端*************/
/*                                                             */
/*  auth.qilewl.com (C)2018 qilewl.com Inc.                    */
/*  This is NOT a freeware, use is subject to license terms    */
/*  奇乐网站授权管理系统是商业软件,使用于商业用途请购买授权    */
/*  V1.0.0 2018                                                */
/*  官方网址：http://www.qilewl.com                            */ 
/*                                                             */                      
/***************************************************************/

define('QILE_AUTH_NAME', '奇乐中介担保系统免费版');
define('QILE_AUTH_VERSION', '1.0.7');
define('QILE_AUTH_DATE', '20180105');

