<?php
if (!defined('IN_AUTH')) exit('Access Denied');
/** 调试模式状态 */
if(APP_DEBUG == true){
	error_reporting(E_ALL);
	ini_set('display_errors','On');
 }else{
	 error_reporting(0);
	 ini_set('display_errors','Off');
 }

date_default_timezone_set("PRC");





//初始化部分
$controller = !empty($_GET['c'])?addslashes(ucfirst($_GET['c'])):'Index';  //控制器
$action     = !empty($_GET['a'])?addslashes($_GET['a']):'Index';  //方法
$controller_file =  AUTH_ROOT_PATH.'app/controller/'.$controller.'.php';
if(!is_file($controller_file)){
   exit('请求控制器文件不存在');
}
require $controller_file;

if(!class_exists($controller)){
    exit($action.'请求控制不存在');
    
}

$obj = new $controller;


if(!method_exists($obj,$action)){
    exit($action.'请求方法不存在');
}
$obj->$action();


