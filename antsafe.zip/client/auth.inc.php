<?php
/****************奇乐网站授权管理系统 商业版 客户端*************/
/*                                                             */
/*  auth.qilewl.com (C)2018 qilewl.com Inc.                    */
/*  This is NOT a freeware, use is subject to license terms    */
/*  奇乐网站授权管理系统是商业软件,使用于商业用途请购买授权    */
/*  V1.0.0 2018                                                */
/*  官方网址：http://www.qilewl.com                            */ 
/*                                                             */                      
/***************************************************************/

error_reporting(0);
date_default_timezone_set("PRC");

define('AUTH_ROOT_PATH',str_replace('\\','/',dirname(__FILE__)).'/'); //授权客户端根目录
define('WEB_APP_PATH',str_replace('\\','/',dirname(dirname(__FILE__))).'/');  //用户WEB应用根目录

require AUTH_ROOT_PATH."client_config.php";  //客户端配置
require AUTH_ROOT_PATH."server_config.php";  //服务端配置

require VERSION."version.php";  //版本

// 加载函数
require AUTH_ROOT_PATH."app/common.php";

// 加载类库
require AUTH_ROOT_PATH."qilecms/libary/PclZip.php";
