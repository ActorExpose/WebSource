<?php
// 用户需要配置的部分
define('CLIENT_AUTH_CODE','a9be42f67e7dbac15454523c8404fc9c'); //网站客户端授权码,授权后可获得
