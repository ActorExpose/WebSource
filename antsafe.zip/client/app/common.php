<?php
/****************奇乐网站授权管理系统 商业版 客户端*************/
/*                                                             */
/*  auth.qilewl.com (C)2018 qilewl.com Inc.                    */
/*  This is NOT a freeware, use is subject to license terms    */
/*  奇乐网站授权管理系统是商业软件,使用于商业用途请购买授权    */
/*  V1.0.0 2018                                                */
/*  官方网址：http://www.qilewl.com                            */ 
/*                                                             */                      
/***************************************************************/

function I($name,$default='',$filter='addslashes'){
  // $name 名称
  // $default 默认值
  // $filter 过滤类型
  $data = isset($name)?$filter(trim($name)):$default;
  return $data;
}

function getAPI($url){
  $json = file_get_contents($url);
  $arr = json_decode($json,true);
  return $arr;
}
function successJson($msg,$data='',$code=0){
    $arr = array(
    'code' => $code, //默认 0 成功 -1 失败
    'msg'  => $msg,
    'data' => $data,
   );
   exit(json_encode($arr));

}
function errorJson($msg,$data='',$code=-1){
  $arr = array(
  'code' => $code, //默认 0 成功 -1 失败
  'msg'  => $msg,
  'data' => $data,
 );
 exit(json_encode($arr));

}


//删除目录
function delDir($dir) {
    if (!is_dir($dir)) {
        return false;
    }
    $handle = opendir($dir);
    while (($file = readdir($handle)) !== false) {
        if ($file != "." && $file != "..") {
            is_dir("$dir/$file") ? del_dir("$dir/$file") : @unlink("$dir/$file");
        }
    }
    if (readdir($handle) == false) {
        closedir($handle);
        @rmdir($dir);
    }
}


//删除文件
function delFile($dirName){
    if(file_exists($dirName) && $handle=opendir($dirName)){
        while(false!==($item = readdir($handle))){
            if($item!= "." && $item != ".."){
                if(file_exists($dirName.'/'.$item) && is_dir($dirName.'/'.$item)){
                    delFile($dirName.'/'.$item);
                }else{
                    if(unlink($dirName.'/'.$item)){
                        return true;
                    }
                }
            }
        }
        closedir( $handle);
    }
}


//下载远程压缩包到本地
function httpcopy($down_url,$savedir="", $timeout=1060) {
    $info = json_decode(file_get_contents($down_url),true); 

   $url = encryptDecrypt(CLIENT_API_KEY,$info['data']['encryptUrl'],true); //解密
    if(empty($url)){
      return false;  //解密失败
    }
   
    $url = trim(str_replace(" ","%20",$url));
    $file = pathinfo($url,PATHINFO_BASENAME);  //返回  文件名.zip
    $filename = pathinfo($url,PATHINFO_FILENAME);  //返回  文件名称
    !is_dir($savedir) && @mkdir($savedir,0755,true);
    if(function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        $temp = curl_exec($ch);         
        if(@file_put_contents($savedir.$file,$temp) && !curl_error($ch)) {
            return $file;
        } else {
            return false;
        }
        curl_close($ch);
    } else {
 
        $opts = array(
            "http"=>array(
            "method"=>"GET",
            "header"=>"",
            "timeout"=>$timeout)
        );
        $context = stream_context_create($opts);
        if(@copy($url,$savedir.$file, $context)) {
            return $file;
        } else {
        
            return false;
        }
    }

}
//加密解密函数
 function encryptDecrypt($key,$string,$decrypt)
  {

    // $decrypt = true 解密
  // $decrypt = false 加密
    $key=md5($key);
    $key_length=strlen($key);
    $string=$decrypt=='true'?base64_decode($string):substr(md5($string.$key),0,8).$string;
    $string_length=strlen($string);
    $rndkey=$box=array();
    $result='';
    for($i=0;$i<=255;$i++)
    {
      $rndkey[$i]=ord($key[$i%$key_length]);
      $box[$i]=$i;
    }
    for($j=$i=0;$i<256;$i++)
    {
      $j=($j+$box[$i]+$rndkey[$i])%256;
      $tmp=$box[$i];
      $box[$i]=$box[$j];
      $box[$j]=$tmp;
    }
    for($a=$j=$i=0;$i<$string_length;$i++)
    {
      $a=($a+1)%256;
      $j=($j+$box[$a])%256;
      $tmp=$box[$a];
      $box[$a]=$box[$j];
      $box[$j]=$tmp;
      $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
    }
    if($decrypt=='true')
    {
      if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8))
      {
        return substr($result,8);
      }
      else
      {
        return'';
      }
    }
    else
    {
      return str_replace('=','',base64_encode($result));
    }
  }

function check_auth(){
   $hosturl = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
   $info = getAPI(UPDATE_API_URL.'?a=check_auth&version='.QILE_VERSION.'&domain='.$hosturl.'&code='.CLIENT_AUTH_CODE);
   // print_r($info );
  if($info['code'] == 117){
      return '<span class="layui-badge layui-bg-gray"><i class="layui-icon">&#x1007;</i> 已过期, 如需继续使用授权请联系 '.$info['data']['contact'].'</span>';
  }elseif($info['code'] !='' && $info['code'] == 0){
      $new_version = check_new_version();
      $html = '<span class="layui-badge layui-bg-green"  ><i class="layui-icon">&#xe616;</i> 已授权 '.$new_version.'</span>';
      return $html;
  }else{
       return '<span class="layui-badge"><i class="layui-icon">&#x1007;</i> 未授权,如需授权请联系 '.$info['data']['contact'].'</span>';
  }
  
}

function check_new_version(){
   $hosturl = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);
   $result = getAPI(UPDATE_API_URL.'?a=get_new_version&version='.QILE_VERSION.'&domain='.$hosturl.'&code='.CLIENT_AUTH_CODE);
   if($result['code'] == 110){
      return $result['msg'];
   }else{
      return $result['msg'].$result['data']['name'];
   }

}