<?php
class Update{
    //前置方法
    public function __construct()
    {
         $this->version      = QILE_AUTH_VERSION;  //版本号 
         $this->version_name = QILE_AUTH_NAME; //版本名称
         $this->hosturl = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']);

         
    }
    //升级检查
    public function check(){
         //检测新版本，并且获得新版本信息
            $newVersion = getAPI(UPDATE_API_URL.'/update.php?a=check_new_version&version='.$this->version.'&domain='.$this->hosturl.'&code='.CLIENT_AUTH_CODE);
 
            if(empty($newVersion)){
                errorJson('接口异常');
            }

 
            //无新版不需要升级
            if($newVersion['code'] >= 1){
                    errorJson($newVersion['msg'],'',2);
            }
      
            //发现新版需要升级
            if($newVersion['data']['name'] > $this->version){
       
                            $msg  = '新版本号：'.$this->version_name.' v'.$newVersion['data']['name'].'<br>';
                            $msg = $newVersion['data']['content'];
                            $data = 'v'.$newVersion['data']['name'];
                     successJson($msg,$data,1);
             }


            
    }

    public function start()
    {
        //开始更新程序
        //升级接口 
            $updateData = getAPI(UPDATE_API_URL.'/update.php?a=update&version='.$this->version.'&domain='.$this->hosturl.'&code='.CLIENT_AUTH_CODE);
      
           $this->newVersion =$updateData['data']['new_version'];
            if($updateData['code']  >= 1){
                successJson($updateData['msg']); 
            }
                $updateDataName = $updateData['data']['file'];
            
            if (strstr($updateDataName, 'zip')){
                // 下载数据
                $downUrl = UPDATE_API_URL.'/update.php?a=down&version='.$this->version.'&file='.$updateDataName.'&domain='.$this->hosturl.'&code='.CLIENT_AUTH_CODE;
          
                    $update_dir = AUTH_ROOT_PATH.'data/update/'; //升级包存放目录
                    $updatezip_path = $update_dir.$updateDataName;  //升级包存放文件名称
                    //删除升级包目录
                        delDir($update_dir);
                      $getfile = file_get_contents($downUrl);
                    if(empty($getfile)){
                        errorJson('升级包已经丢失或者不存在','','1002'); 
                    }
                            //下载升级包
                        if(!file_exists($update_dir.$updateDataName)){
                                
                                    if(!httpcopy($downUrl,$update_dir)){
                               
                                                errorJson('升级包解密失败或者升级包不存在，请联系服务商处理','','1002'); 
                                        }
                        
                        }
                        //获得升级包所有文件名称
                            $updatezip =  new PclZip($updatezip_path);
                                if (($list = $updatezip->listContent()) == 0) {
                                    
                                            errorJson('获取的压缩包可能已经损坏','','1002'); 
                                }
                                    $filename =array();
                                    foreach($list as $v){
                                        if(is_file(AUTH_ROOT_PATH.$v['filename'])){
                                        array_push($filename,AUTH_ROOT_PATH.$v['filename']);   
                                        }
                                    }
                        
                                $all_file = implode(',',$filename);        
                                unset($list);

                        // 开启备份
                            if(AUTOBACKUP == true){
                                //第一步：备份上一个升级前的网站所有程序
                                $backup_name = str_replace('.zip','',$updateDataName);
                                //$zip_path：备份的压缩包存放路径和名称
                                $zip_path = AUTH_ROOT_PATH.'data/backup/'.$backup_name.'_backup.zip';
                                if(!is_dir(AUTH_ROOT_PATH.'data/backup/')){
                                    @mkdir(AUTH_ROOT_PATH.'data/backup/',0755);
                                }
                                $zip = new PclZip($zip_path);
                                $list = $zip->create($all_file);
                                        if($list == 0){
                                    
                                            errorJson('备份失败 : '.$zip->errorInfo(true),'','1002'); 
                                        }             
                                    }


                        // 第二步 : 解压升级包 
                            $unzip_path = WEB_APP_PATH;  //解压的目录  网站根目录
                            $archive = new PclZip($updatezip_path); 
                            $_SESSION['update_file_path'] = $updatezip_path;
                            if ($archive -> extract(PCLZIP_OPT_PATH,$unzip_path, PCLZIP_OPT_REPLACE_NEWER) == 0){
                           
                                errorJson('远程升级文件不存在,升级失败!','','1002'); 
                            }else{
                                //升级数据库
                                $sqlfile = $update_dir.'update.sql';
                                if(file_exists($sqlfile)){
                                    
                                        $sql = file_get_contents($sqlfile);
                                        if($sql){
                                        $sql = str_replace("ql_",TABLE_PREFIX,$sql);
                                            foreach(explode(";[\r\n]+", $sql) as $v){ 
                                                $Db->query($v);
                                            }
                                        }
                                }
                            }
                                //升级完成，删除升级包
                                delDir($update_dir);
                           
                                //加升级锁
                                file_put_contents(AUTH_ROOT_PATH.'data/update.lock',$this->newVersion);

                                $res = getAPI(UPDATE_API_URL.'/update.php?a=set_success&version='.$this->version.'&domain='.$this->hosturl.'&code='.CLIENT_AUTH_CODE);

                                successJson('恭喜您，升级完成!'); 

                    }else{
                            errorJson($updateDataName,'','-1'); 
            }
    }
   

    
}