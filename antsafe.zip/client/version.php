<?php
define('QILE_AUTH_NAME', '奇乐中介担保系统免费版');
define('QILE_AUTH_VERSION', '1.2.9');
define('QILE_AUTH_DATE', '20200807');

