<?php
include 'extend/Page.php';
// //分页配置
return [
    'type'     => 'think\driver\Page',
    'var_page' => 'page',
   
];