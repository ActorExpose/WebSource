<?php

//  SETUP - SQL
//  ######################################################################################################  //

//  BACKUP DB
    //                   HOST         USER   PASSWORD  DATABASE
    #$sql[] = db_backup("localhost", "root", "",       "adserver"); // REPEAT THIS LINE FOR EACH DB
    #$sql[] = db_backup("localhost", "root", "root",   "adserver"); // REPEAT THIS LINE FOR EACH DB
    // DEL THE # IN FRONT OF $SQL[] = ... IF YOU WANT TO SETUP AND USE THE MYSQL BACKUP FUNCTION !!

//  ######################################################################################################  //
