<?php

//  SETUP - https://www.dropbox.com/developers/apps
//  ######################################################################################################

    $boxKey    = 'l9ulbi1entq55k9'; // Dropbox API v2 "App key"
    $boxSecret = 'h0xtyp23qae7di6'; // Dropbox API v2 "App secret"

//  ######################################################################################################
