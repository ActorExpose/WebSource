<?php

require 'emailHelper.php';

sendMail();