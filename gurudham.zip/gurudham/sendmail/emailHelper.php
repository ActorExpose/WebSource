<?php

{
	require 'PHPMailer-master/PHPMailerAutoload.php';

	function sendMail($to,$message,$type)
	{
	   /* $mail->isSMTP();
$mail->Host = 'localhost';
$mail->SMTPAuth = false;
$mail->SMTPAutoTLS = false; 
$mail->Port = 25; */

		$mail = new PHPMailer;
		//Enable SMTP debugging. 
		// $mail->SMTPDebug = 2;                               
		//Set PHPMailer to use SMTP.
	   $mail->IsMail();
		//$mail->IsSMTP();            
		//Set SMTP host name                          
		//$mail->Host = "smtp.gmail.com";
		$mail->Host = "mail.mohnifoundation.org";
		 //$mail->Host = "secure.emailsrvr.com";

		//Set this to true if SMTP host requires authentication to send email
		$mail->SMTPAuth = true;                       
		//Provide username and password
		$mail->Username =  "info@mohnifoundation.org";
		$mail->Password =  "@info!";
		//If SMTP requires TLS encryption then set it
		//$mail->SMTPSecure = "SSL";                     
		//Set TCP port to connect to 
		$mail->Port = 587;
		//$mail->Port = 465; 
		$mail->From = "info@mohnifoundation.org";
		$mail->FromName = "MohniFoundation";

		$mail->addAddress($to, "MohniFoundation");
        $mail->AddCC("samuelmishra8888@gmail.com");
        $mail->AddCC("neeraj@mohnifoundation.org");
		$mail->isHTML(true);

		$mail->Subject = $type;
		$mail->Body = "<i>".$message."</i>";
		$mail->AltBody = "";

		if(!$mail->send()){
		    // return $mail;

			return false;
		  //return "Mailer Error: " . $mail->ErrorInfo;
		} 
		else{
		    return true;
	   //  	return "success ". $mail->ErrorInfo;
		    //	echo "Message has been sent successfully";
		}
	}
}

?>