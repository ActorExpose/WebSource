<?php 
require 'sendmail/emailHelper.php';
if(isset($_POST) && !empty($_POST)){
    $message = "Name: ".$_POST['name']."<br>";
    $message .= "Email: ".$_POST['email']."<br>";
    $message .= "Phone: ".$_POST['mobile']."<br>";
    $message .= "About: ".$_POST['about']."<br>";
    @sendMail("mishraneeraj7777@gmail.com",$message,"Contact Form Data");
}

$base_url = 'http://www.salosh.co.in';
$company_name = 'Company';
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

 <meta charset="UTF-8"/><title>IPD </title>

<meta name="keywords" content="" >

<meta name="description" content="" >

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400%7CSource+Sans+Pro:700" rel="stylesheet">

<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

<link type="text/css" rel="stylesheet" href="css/owl.carousel.css" />
<link type="text/css" rel="stylesheet" href="css/owl.theme.default.css" />

<link rel="stylesheet" href="css/font-awesome.min.css">

<link type="text/css" rel="stylesheet" href="css/style.css" />

<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<header id="home">

<nav id="main-navbar">
<div class="container">
<div class="navbar-header">

<div class="navbar-brand">
<a class="logo" href="<?= $base_url; ?>"><img src="img/Logo.png" alt="logo"></a>
</div>


<button class="navbar-toggle-btn">
<i class="fa fa-bars"></i>
</button>



</div>



<ul class="navbar-menu nav navbar-nav navbar-right">
<li><a href="<?= $base_url; ?>">Home</a></li>
<li><a href="#about">About</a></li>
<li><a href="#plans">Plans</a>
</li>
<li><a href="#activities">Activities</a>
</li>
<li><a href="#contact">Contact</a></li>

</ul>

</div>
</nav>


<div id="home-owl" class="owl-carousel owl-theme">

<div class="home-item">

<div class="section-bg" style="background-image: url(img/background-1.jpg);"></div>


<div class="home">
<div class="container">
<div class="row">
<div class="col-md-8">
<div class="home-content">
<h1>Project Bhuli</h1>
<p class="lead">	Expansion of our menstruation education program from rural areas to urban areas in India.
	Menstrual education contributes to the spreads of women’s school’senrollment and social advancement.
</p>
<a href="#causes" class="primary-button">View Causes</a>
</div>
</div>
</div>
</div>
</div>

</div>


<div class="home-item">

<div class="section-bg" style="background-image: url(img/background-2.jpg);"></div>


<div class="home">
<div class="container">
<div class="row">
<div class="col-md-8">
<div class="home-content">
<h1>Target Population</h1>
<p class="lead">A village of district nanital named Ghuggu kham and Pangot, also   The project covered 30 children living in the slum area their parents were working as ragpickers and exertion profile .</p>
<a href="#events" class="primary-button">Join Us Now!</a>
</div>
</div>
</div>
</div>
</div>

</div>
<div class="home-item">

<div class="section-bg" style="background-image: url(img/background-1.jpg);"></div>


<div class="home">
<div class="container">
<div class="row">
<div class="col-md-8">
<div class="home-content">
<h1>Become A Volunteer</h1>
<p class="lead">We believe
Volunteers do not necessarily have the time, they just have the heart. “You make a living by what you get. You make a life by what you give.”
</p>
<a href="#events" class="primary-button">Join Us Now!</a>
</div>
</div>
</div>
</div>
</div>

</div>


</div>

</header>


<div id="about" class="section">

<div class="container">

<div class="row">

<div class="col-md-5">
<div class="section-title">
<h2 class="title">Welcome to <?= $company_name; ?></h2>
<p class="about-content"> <?= $company_name; ?> is started with the aim of improving the lives of rural children and women and to achieve this we are  conducting  the donation programmes, provided basic education to the children along with the awareness regarding their personal hygiene.</p>
</div>
<div class="about-content">
<p>We help mothers and children survive and thrive so they can look forward to a healthy old age.</p>
<!-- <a href="#" class="primary-button">Read More</a> -->
</div>
</div>


<div class="col-md-offset-1 col-md-6">
<a href="javascript:void(0)" class="about-video">
<!--<i class="play-icon fa fa-play"></i>-->
<img src="img/about.jpg" alt="">
</a>
</div>

</div>

</div>

</div>



<div id="plans" class="section">

<div class="container">

<div class="row">

<div class="col-md-10 col-md-offset-1">
<div class="section-title text-center">
<h2 class="title">Our Plan</h2>


<div class="col-md-12">
<div class="event">
<div class="event-img">
<a href="javascript:void(0)">
<img src="img/event-1.jpg" alt="">
</a>
</div>
<div class="event-content">
<h3><a href="javascript:void(0)">Education- Day care centres </a></h3>
<!--<ul class="event-meta">
<li><i class="fa fa-clock-o"></i> 24 October, 2018 | 8:00AM - 11:00PM</li>
<li><i class="fa fa-map-marker"></i> 2736 Hinkle Deegan Lake Road</li>
</ul>-->
<p>Education is the most powerful catalyst for social transformation.</p>
</div>
</div>
</div>


<div class="col-md-12">
<div class="event">
<div class="event-img">
<a href="javascript:void(0)">
<img src="img/event-2.jpg" alt="">
</a>
</div>
<div class="event-content">
<h3><a href="javascript:void(0)">Donation camps</a></h3>
<!--<ul class="event-meta">
<li><i class="fa fa-clock-o"></i> 24 October, 2018 | 8:00AM - 11:00PM</li>
<li><i class="fa fa-map-marker"></i> 2736 Hinkle Deegan Lake Road</li>
</ul>-->
<p>Education is both the means as well as the end to a better life.</p>
</div>
</div>
</div>

<div class="clearfix visible-md visible-lg"></div>

<div class="col-md-12">
<div class="event">
<div class="event-img">
<a href="javascript:void(0)">
<img src="img/event-3.jpg" alt="">
</a>
</div>
<div class="event-content">
<h3><a href="javascript:void(0)">Providing urban suplies to rural mankinds as a tool for rural development</a></h3>
<!--<ul class="event-meta">
<li><i class="fa fa-clock-o"></i> 24 October, 2018 | 8:00AM - 11:00PM</li>
<li><i class="fa fa-map-marker"></i> 2736 Hinkle Deegan Lake Road</li>
</ul>-->
<p>Without proper food, clothing and shelter, life for them is full of struggles we would give up anything to help these children fullfill their dreams and live a better life.</p>
</div>
</div>
</div>


<div class="col-md-12">
<div class="event">
<div class="event-img">
<a href="javascript:void(0)">
<img src="img/event-4.jpg" alt="">
</a>
</div>
<div class="event-content">
<h3><a href="javascript:void(0)">Health & Nutrition- Organizing Swachh Pathshala</a></h3>
<!--<ul class="event-meta">
<li><i class="fa fa-clock-o"></i> 24 October, 2018 | 8:00AM - 11:00PM</li>
<li><i class="fa fa-map-marker"></i> 2736 Hinkle Deegan Lake Road</li>
</ul>-->
<p>Many a times we notices poor children begging on the streets sitting on tavements or just rooming around. </p>
</div>
</div>
</div>

</div>

</div>

</div>
</div>
</div>

<div class="section">

<div class="section-bg" style="background-image: url(img/background-2.jpg);" data-stellar-background-ratio="0.5"></div>


<div class="container">

<div class="row">

<div class=" col-md-6">
<div class="cta-content text-center">
<h1>Our Mission</h1>
<p class="lead">To provide the  children with basic education and to sensitize them towards their own hygiene and surrounding. Better health for everyone, everywhere</p>
</div>
</div>
<div class=" col-md-6">
<div class="cta-content text-center">
<h1>Our Vision</h1>
<p class="lead">Make the rural population self sufficient so that they can atleast have different employment alternatives to provide for themselves and attain hygiene standards.</p>
</div>
</div>

</div>

</div>

</div>






<div id="activities" class="section">

<div class="container">

<div class="row">

<div class="col-md-10 col-md-offset-1">
<div class="section-title text-center">
<h2 class="title">ACTIVITIES AND LEARNINGS</h2>
<div class="row">
    <div class="col-md-6"><p class="sub-title">
        <hr>
A. Education- Day care centres<br><hr>

C. Virtual events e.g painting compition <br><hr>

E. Project bhuli I.e awareness for girls hygiene <br><hr>

G. Providing urban suplies to rural mankinds as a tool for rural development<br><hr>

</p></div>
    <div class="col-md-6"><p class="sub-title">
<hr>
B. Donation camps <br><hr>

D. Providing multiple employment options<br><hr>

F. Health & Nutrition- Organizing Swachh Pathshala<br><hr>

H. Family planning and Healthy Practices regarding everyday life<br><hr>

</p></div>
</div>

</div>
</div>



</div>

</div>

</div>




<div id="testimonial" class="section">

<div class="section-bg" style="background-image: url(img/background-2.jpg);" data-stellar-background-ratio="0.5"></div>


<div class="container">

<div class="row">

<div class="col-md-12">
<div id="testimonial-owl" class="owl-carousel owl-theme">

<div class="testimonial">
<div class="testimonial-meta">
<div class="testimonial-img">
<img src="img/avatar-2.jpg" alt="">
</div>
<h3>Dr Utkarsh saxena</h3>
<span>Volunteer</span>
</div>
<div class="testimonial-quote">
<blockquote>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
</blockquote>
</div>
</div>


<div class="testimonial">
<div class="testimonial-meta">
<div class="testimonial-img">
<img src="img/avatar-1.jpg" alt="">
</div>
<h3>Dr Suvarna singh</h3>
<span>Volunteer</span>
</div>
<div class="testimonial-quote">
<blockquote>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
</blockquote>
</div>
</div>


<div class="testimonial">
<div class="testimonial-meta">
<div class="testimonial-img">
<img src="img/avatar-2.jpg" alt="">
</div>
<h3>Pankaj joshi</h3>
<span>Volunteer</span>
</div>
<div class="testimonial-quote">
<blockquote>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
</blockquote>
</div>
</div>


<div class="testimonial">
<div class="testimonial-meta">
<div class="testimonial-img">
<img src="img/avatar-1.jpg" alt="">
</div>
<h3>Suraiya Khan</h3>
<span>Volunteer</span>
</div>
<div class="testimonial-quote">
<blockquote>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
</blockquote>
</div>
</div>


<div class="testimonial">
<div class="testimonial-meta">
<div class="testimonial-img">
<img src="img/avatar-1.jpg" alt="">
</div>
<h3>Nikita mishra</h3>
<span>Volunteer</span>
</div>
<div class="testimonial-quote">
<blockquote>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
</blockquote>
</div>
</div>

</div>
</div>

</div>

</div>

</div>




<footer id="contact" class="section">

<div class="container">

<div class="row">

<div class="col-md-5">
<div class="footer">
<div class="footer-logo">
<a class="logo" href="http:mohnifoundation.org"><img src="img/Logo.png" alt=""></a>
</div>
<p> <?= $company_name; ?> was started with the aim of making the lives of rural children better, and focusing to improve their life style. </p>
<ul class="footer-contact">

<li><i class="fa fa-phone"></i> 000-000-0000</li>
<li><i class="fa fa-envelope"></i> <a href="mailto:info@company.org">info@company.org</a></li>
</ul>
</div>
</div>


<div class="col-md-3">
</div>


<div class="col-md-4">
<div class="footer">
<h3 class="footer-title">Contact-us</h3>
<form class="footer-newsletter" method="POST" action=" <?= $base_url; ?>">
<input class="input" name="name" type="text" required placeholder="Enter your name">
<input class="input" name="email" type="email" required placeholder="Enter your email">
<input class="input" name="mobile" type="text" required placeholder="Enter your mobile">
<input class="input" name="about" type="text" required placeholder="About you...">
<button class="primary-button">Submit</button>
</form>

<ul class="footer-social">
<li><a href="http://facebook.com"><i class="fa fa-facebook"></i></a></li>
<li><a href="http://linkedin.com"><i class="fa fa-linkedin"></i></a></li>
<li><a href="http://instagram.com"><i class="fa fa-instagram"></i></a></li>
</ul>
</div>
</div>

</div>


<div id="footer-bottom" class="row">
<div class="col-md-6 col-md-push-6">
<ul class="footer-nav">

<li><a href="<?= base_url; ?>">Home</a></li>
<li><a href="#about">About</a></li>
<li><a href="#plans">Plans</a>
</li>
<li><a href="#activities">Activities</a>
</li>
<li><a href="#contact">Contact</a></li>
</ul>
</div>
<div class="col-md-6 col-md-pull-6">
<div class="footer-copyright">
<span>
 &copy; Copyright  <?= $company_name; ?>  
</span>
</div>
</div>
</div>

</div>

</footer>


<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/main.js"></script>


</body>

</html>
