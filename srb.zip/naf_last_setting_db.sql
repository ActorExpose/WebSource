-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 26, 2019 at 06:04 AM
-- Server version: 5.7.24
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `naf`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_account`
--

DROP TABLE IF EXISTS `tbl_account`;
CREATE TABLE IF NOT EXISTS `tbl_account` (
  `Acc_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `Acc_Code` varchar(50) NOT NULL,
  `Acc_Tr_Type` varchar(25) DEFAULT NULL,
  `Acc_Name` varchar(200) NOT NULL,
  `Acc_Type` varchar(50) NOT NULL,
  `Acc_Description` varchar(255) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Acc_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assets`
--

DROP TABLE IF EXISTS `tbl_assets`;
CREATE TABLE IF NOT EXISTS `tbl_assets` (
  `as_id` int(11) NOT NULL AUTO_INCREMENT,
  `as_date` date DEFAULT NULL,
  `as_name` varchar(50) DEFAULT NULL,
  `as_qty` int(11) DEFAULT NULL,
  `as_rate` decimal(10,2) DEFAULT NULL,
  `as_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `branchid` int(11) DEFAULT NULL,
  PRIMARY KEY (`as_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_accounts`
--

DROP TABLE IF EXISTS `tbl_bank_accounts`;
CREATE TABLE IF NOT EXISTS `tbl_bank_accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_number` varchar(250) NOT NULL,
  `bank_name` varchar(250) NOT NULL,
  `branch_name` varchar(250) DEFAULT NULL,
  `initial_balance` float NOT NULL,
  `saved_by` int(11) NOT NULL,
  `saved_datetime` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_datetime` datetime DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `account_name` varchar(500) NOT NULL,
  `account_type` varchar(200) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bank_transactions`
--

DROP TABLE IF EXISTS `tbl_bank_transactions`;
CREATE TABLE IF NOT EXISTS `tbl_bank_transactions` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `transaction_date` date NOT NULL,
  `transaction_type` varchar(10) NOT NULL,
  `amount` float NOT NULL,
  `note` varchar(500) DEFAULT NULL,
  `saved_by` int(11) NOT NULL,
  `saved_datetime` datetime NOT NULL,
  `branch_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`transaction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brand`
--

DROP TABLE IF EXISTS `tbl_brand`;
CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `brand_SiNo` int(11) NOT NULL AUTO_INCREMENT,
  `ProductCategory_SlNo` int(11) NOT NULL,
  `brand_name` varchar(100) NOT NULL,
  `status` char(2) NOT NULL,
  `brand_branchid` int(11) NOT NULL,
  PRIMARY KEY (`brand_SiNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brunch`
--

DROP TABLE IF EXISTS `tbl_brunch`;
CREATE TABLE IF NOT EXISTS `tbl_brunch` (
  `brunch_id` int(11) NOT NULL AUTO_INCREMENT,
  `Brunch_name` varchar(3000) CHARACTER SET utf8 NOT NULL,
  `Brunch_title` varchar(3000) CHARACTER SET utf8 NOT NULL,
  `Brunch_address` text CHARACTER SET utf8 NOT NULL,
  `Brunch_sales` varchar(1) NOT NULL COMMENT 'Wholesales = 1, Retail = 2',
  `add_date` date NOT NULL,
  `add_time` datetime NOT NULL,
  `add_by` char(50) NOT NULL,
  `update_by` char(50) NOT NULL,
  `status` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`brunch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_brunch`
--

INSERT INTO `tbl_brunch` (`brunch_id`, `Brunch_name`, `Brunch_title`, `Brunch_address`, `Brunch_sales`, `add_date`, `add_time`, `add_by`, `update_by`, `status`) VALUES
(1, 'Akash DTH', 'COXS BAZAR', 'Husnia Super Market, North Rumalier Chara,Ward No 05, Cox\"s Bazar Poursobha, Cox\"s Bazar Mobile: 01819751198, Email: nafelectronicscox@gmail.com', '', '0000-00-00', '0000-00-00 00:00:00', '', 'Admin', 'a'),
(2, 'Naf ', 'Coxs Bazar', 'Husnia Super Market, North Rumalier Chara,Ward No 05, Cox\"s Bazar Poursobha, Cox\"s Bazar\nMobile: 01819751198, Email: nafelectronicscox@gmail.com', '2', '0000-00-00', '2019-10-26 17:12:09', 'Admin', 'Admin', 'a'),
(3, 'Coxs Bazar Electronics', 'Coxs Electronics', 'Coxs Bazar', '2', '0000-00-00', '2019-12-16 11:00:29', 'Admin', '', 'a'),
(4, 'Smart Home applaines', 'Coxs Bazar', 'Husnia Super Market, North Rumalier Chara,Ward No 05, Cox\"s Bazar Poursobha, Cox\"s Bazar Mobile: 01819751198, Email: smarthomecox@gmail.com', '2', '0000-00-00', '2019-12-16 17:29:20', 'Admin', 'Admin', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cashregister`
--

DROP TABLE IF EXISTS `tbl_cashregister`;
CREATE TABLE IF NOT EXISTS `tbl_cashregister` (
  `Transaction_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Transaction_Date` varchar(20) NOT NULL,
  `IdentityNo` varchar(50) DEFAULT NULL,
  `Narration` varchar(100) NOT NULL,
  `InAmount` decimal(18,2) NOT NULL,
  `OutAmount` decimal(18,2) NOT NULL,
  `Description` longtext NOT NULL,
  `Status` char(1) DEFAULT NULL,
  `Saved_By` varchar(50) DEFAULT NULL,
  `Saved_Time` datetime DEFAULT NULL,
  `Edited_By` varchar(50) DEFAULT NULL,
  `Edited_Time` datetime DEFAULT NULL,
  PRIMARY KEY (`Transaction_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cashtransaction`
--

DROP TABLE IF EXISTS `tbl_cashtransaction`;
CREATE TABLE IF NOT EXISTS `tbl_cashtransaction` (
  `Tr_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Tr_Id` varchar(50) NOT NULL,
  `Tr_date` date NOT NULL,
  `Tr_Type` varchar(20) NOT NULL,
  `Tr_account_Type` varchar(50) NOT NULL,
  `Supplier_SlID` int(11) NOT NULL,
  `Customer_SlID` int(11) NOT NULL,
  `Acc_SlID` int(11) NOT NULL,
  `Acc_Code` varchar(50) DEFAULT NULL,
  `Tr_Description` varchar(255) NOT NULL,
  `In_Amount` decimal(18,2) NOT NULL,
  `Out_Amount` decimal(18,2) NOT NULL,
  `ChequeNumber` int(16) NOT NULL,
  `Tr_Bank_Id` int(11) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(100) NOT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `Tr_branchid` int(11) NOT NULL,
  PRIMARY KEY (`Tr_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_checks`
--

DROP TABLE IF EXISTS `tbl_checks`;
CREATE TABLE IF NOT EXISTS `tbl_checks` (
  `id` int(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cus_id` int(20) DEFAULT NULL,
  `SM_id` int(20) UNSIGNED DEFAULT NULL,
  `bank_name` varchar(250) DEFAULT NULL,
  `branch_name` varchar(250) DEFAULT NULL,
  `check_no` varchar(250) DEFAULT NULL,
  `check_amount` decimal(18,2) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `check_date` timestamp NULL DEFAULT NULL,
  `remid_date` timestamp NULL DEFAULT NULL,
  `sub_date` timestamp NULL DEFAULT NULL,
  `note` varchar(250) DEFAULT NULL,
  `check_status` char(5) DEFAULT 'Pe' COMMENT 'Pe =Pending, Pa = Paid',
  `status` char(5) NOT NULL DEFAULT 'a',
  `created_by` varchar(250) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `branch_id` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_color`
--

DROP TABLE IF EXISTS `tbl_color`;
CREATE TABLE IF NOT EXISTS `tbl_color` (
  `color_SiNo` int(11) NOT NULL AUTO_INCREMENT,
  `color_name` varchar(100) NOT NULL,
  `status` char(2) NOT NULL,
  PRIMARY KEY (`color_SiNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

DROP TABLE IF EXISTS `tbl_company`;
CREATE TABLE IF NOT EXISTS `tbl_company` (
  `Company_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Company_Name` varchar(150) NOT NULL,
  `Repot_Heading` text NOT NULL,
  `Company_Logo_org` varchar(250) NOT NULL,
  `Company_Logo_thum` varchar(250) NOT NULL,
  `Invoice_Type` int(11) NOT NULL,
  `Currency_Name` varchar(50) DEFAULT NULL,
  `Currency_Symbol` varchar(10) DEFAULT NULL,
  `SubCurrency_Name` varchar(50) DEFAULT NULL,
  `print_type` int(11) NOT NULL,
  `company_BrunchId` int(11) NOT NULL,
  PRIMARY KEY (`Company_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`Company_SlNo`, `Company_Name`, `Repot_Heading`, `Company_Logo_org`, `Company_Logo_thum`, `Invoice_Type`, `Currency_Name`, `Currency_Symbol`, `SubCurrency_Name`, `print_type`, `company_BrunchId`) VALUES
(1, 'Naf Electronics And Motors DTH ', 'Husnia Super Market, North Rumalier Chara,Ward No 05, Cox\"s Bazar Poursobha, Cox\"s Bazar   Mobile: 01819751198, Email: nafelectronicscox@gmail.com', 'NafGroupbd-Logo-teknaf1.jpg', 'NafGroupbd-Logo-teknaf1.jpg', 1, 'BDT', NULL, NULL, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_country`
--

DROP TABLE IF EXISTS `tbl_country`;
CREATE TABLE IF NOT EXISTS `tbl_country` (
  `Country_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `CountryName` varchar(50) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Country_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_currentinventory`
--

DROP TABLE IF EXISTS `tbl_currentinventory`;
CREATE TABLE IF NOT EXISTS `tbl_currentinventory` (
  `inventory_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `purchase_quantity` float NOT NULL,
  `purchase_return_quantity` float NOT NULL,
  `sales_quantity` float NOT NULL,
  `sales_return_quantity` float NOT NULL,
  `damage_quantity` float NOT NULL,
  `transfer_from_quantity` float NOT NULL,
  `transfer_to_quantity` float NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`inventory_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `Customer_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Customer_Code` varchar(50) NOT NULL,
  `Customer_Name` varchar(150) NOT NULL,
  `Customer_Type` varchar(50) NOT NULL,
  `Customer_Phone` varchar(50) NOT NULL,
  `Customer_Mobile` varchar(15) NOT NULL,
  `Customer_Email` varchar(50) NOT NULL,
  `Customer_OfficePhone` varchar(50) NOT NULL,
  `Customer_Address` varchar(300) NOT NULL,
  `owner_name` varchar(250) DEFAULT NULL,
  `Country_SlNo` int(11) NOT NULL,
  `area_ID` int(11) NOT NULL,
  `Customer_Web` varchar(50) NOT NULL,
  `Customer_Credit_Limit` decimal(18,2) NOT NULL,
  `previous_due` decimal(18,2) NOT NULL,
  `image_name` varchar(1000) DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `Customer_brunchid` int(11) NOT NULL,
  PRIMARY KEY (`Customer_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Customer_SlNo`, `Customer_Code`, `Customer_Name`, `Customer_Type`, `Customer_Phone`, `Customer_Mobile`, `Customer_Email`, `Customer_OfficePhone`, `Customer_Address`, `owner_name`, `Country_SlNo`, `area_ID`, `Customer_Web`, `Customer_Credit_Limit`, `previous_due`, `image_name`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Customer_brunchid`) VALUES
(1, 'C00001', 'MD TAREK', 'retail', '', '01819751198', '', '01619001600', 'COXS BAZAR', 'TAREK', 0, 6, '', '1000000.00', '0.00', NULL, 'a', 'Admin', '2019-12-15 17:02:38', NULL, NULL, 1),
(2, 'C00002', 'M/S Rahin Enterprise', 'retail', '', '01815334819', '', '01815334819', 'South Taraboniarchara, Main Road, Coxsbazar', 'Md Rohan', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:30:00', 'Admin', '2019-12-21 16:46:00', 1),
(3, 'C00003', 'Musfiq Enterprise', 'retail', '', '01818425288', '', '', ' South Taraboniarchara, Main Road, Coxsbazar', 'Monir Alom', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:32:40', 'Admin', '2019-12-21 16:45:53', 1),
(4, 'C00004', 'Smart Electronics & Appliance', 'retail', '', '01619001600', '', '01618610101', 'Taraboniarchara, Main Road, Coxsbazar', 'Md Ismail', 0, 10, '', '100000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:35:08', 'Admin', '2019-12-18 23:22:38', 1),
(5, 'C00005', 'Hasan Audio Complex', 'retail', '', '01902841750', '', '', 'Eden Garden City, Laldigir Par, Coxsbazar', 'Md Hasan', 0, 10, '', '30000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:37:02', 'Admin', '2019-12-21 16:45:44', 1),
(6, 'C00006', 'Baizid Electronics', 'retail', '', '01835295309', '', '', 'Eden Garden City, Laldigir Par, Coxsbazar', 'Nurul Islam', 0, 10, '', '30000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:46:33', 'Admin', '2019-12-21 16:45:34', 1),
(7, 'C00007', 'Alif Electronics', 'retail', '', '01789661301', '', '', 'Bonghobondhu Sorok, Coxsbazar', 'Nurul Islam', 0, 10, '', '30000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:48:08', 'Admin', '2019-12-21 16:45:16', 1),
(8, 'C00008', 'Nokia Electronics', 'retail', '', '01855751164', '', '', 'Bonghobondhu Sorok, Coxsbazar', 'Abu Taher', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 17:49:26', 'Admin', '2019-12-21 16:45:08', 1),
(9, 'C00009', 'Radio Palace Electronics', 'retail', '', '01819133006', '', '', 'Bonghobondhu Sorok, Coxsbazar', 'Mohammad Ali', 0, 10, '', '30000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:08:16', 'Admin', '2019-12-21 16:45:00', 1),
(10, 'C00010', 'Mohna Digital', 'retail', '', '01818369722', '', '', 'Bonghobondhu Sorok, Coxsbazar', 'Russel', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:11:02', 'Admin', '2019-12-21 16:48:22', 1),
(11, 'C00011', 'Cox Tell', 'retail', '', '01851814865', '', '', 'A B Super Market, Prodhan Sorok, Coxsbazar', 'Aminur Rahman', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:12:46', 'Admin', '2019-12-21 16:48:15', 1),
(12, 'C00012', 'Promise Electronics', 'retail', '', '01618501380', '', '', 'Bonghobondhu Sorok, Coxsbazar', 'Md Sahab Uddin', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:14:14', 'Admin', '2019-12-21 16:47:51', 1),
(13, 'C00013', 'Alauddin Recording House', 'retail', '', '01827570787', '', '', 'Mermaid Bhovon, Bonghobondhu Sorok, Coxsbazar', 'Md Enamul Haque', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:17:31', 'Admin', '2019-12-21 16:47:41', 1),
(14, 'C00014', 'Sea Tech Systems', 'retail', '', '01812551227', '', '', 'Jafar Complex, Kacaripahar Road, Coxsbazar', 'Md shafiullah', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:18:25', 'Admin', '2019-12-21 16:47:33', 1),
(15, 'C00015', 'N Islam & Brothers', 'retail', '', '01813717171', '', '', 'Jawotola Main Road, Coxsbazar', 'Md Islam', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:19:18', 'Admin', '2019-12-21 16:47:19', 1),
(16, 'C00016', 'Chadmoni Electronics', 'retail', '', '01818994693', '', '', 'Anderson Road, Coxsbazar', 'Nikil Chandra', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:20:19', 'Admin', '2019-12-21 16:46:44', 1),
(17, 'C00017', 'A R Electronics', 'retail', '', '01830477397', '', '', 'Anderson Road, Coxsbazar', 'Md Younus', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:27:17', 'Admin', '2019-12-21 16:47:13', 1),
(18, 'C00018', 'Monir Watch & Electronics', 'retail', '', '01829452077', '', '', '8 no M. B. Shopping complex 32/6, 7 Anderson Road, Coxsbazar', 'Alhaj Monir Ahmed', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:29:03', 'Admin', '2019-12-21 16:46:25', 1),
(19, 'C00019', 'Sohel Video Mobile Centre', 'retail', '', '01815527363', '', '', 'New Circuit House Road, Moddom Bahar Chara, Coxsbazar', 'Abdur Rahim ', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:31:00', 'Admin', '2019-12-21 16:46:17', 1),
(20, 'C00020', 'Alauddin Electronics', 'retail', '', '01873123455', '', '', 'Asa Shopping Complex, Bazar Ghata, Coxsbazar', 'Md Parvez', 0, 10, '', '500000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:37:04', 'Admin', '2019-12-21 16:50:17', 1),
(21, 'C00021', 'Electronics World', 'retail', '', '01721161746', '', '', '1st floor, Islam Tower, Bazar Ghata, Coxsbazar', 'Tawhidul Hasan', 0, 10, '', '500000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:38:57', 'Admin', '2019-12-21 16:50:25', 1),
(22, 'C00022', 'Coxsbazar  Electronics', 'retail', '', '01825404097', '', '', ' Bazar Ghata Main Road , Coxsbazar', 'Abdullah', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:41:11', 'Admin', '2019-12-21 16:50:42', 1),
(23, 'C00023', 'Planet Communication', 'retail', '', '01619532457', '', '', '2nd Floor, M Ali Plaza, Tekpara, Coxsbazar', 'Md Robiul Hasan', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 18:45:23', 'Admin', '2019-12-21 16:50:08', 1),
(24, 'C00024', 'Signtech Corporation', 'retail', '', '01611525266', '', '', ' Ali Plaza, Tekpara, Coxsbazar', 'Nahian Fayez', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 19:52:50', 'Admin', '2019-12-21 16:49:42', 1),
(25, 'C00025', 'Kalam Enterprise', 'retail', '', '01812684699', '', '', 'Himchori Road, kolatoli, Coxsbazar', 'Abul Kalam', 0, 10, '', '500000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 19:54:06', 'Admin', '2019-12-21 16:49:29', 1),
(26, 'C00026', 'Rayan Electronics', 'retail', '', '01812001721', '', '', 'Hossain Shopping Complex, 2nd Floor, Main Road, Link Road, Coxsbazar', 'Makshudur Rahman', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 19:55:43', 'Admin', '2019-12-21 16:49:07', 1),
(27, 'C00027', 'Monowara Enterprise', 'retail', '', '01775693148', '', '', 'Main Road, Bangla Bazar, Jhilongjha, Coxsbazar', 'Lutfur Rahman', 0, 10, '', '500000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 19:56:49', 'Admin', '2019-12-21 16:49:18', 1),
(28, 'C00028', 'M/S S M Auto', 'retail', '', '01848464163', '', '', 'Coufoldhndhi Bazar, Coxsbazar Sadar', 'S M Hasem', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 20:19:55', 'Admin', '2019-12-21 16:48:54', 1),
(29, 'C00029', 'Novel Enterpriose', 'retail', '', '01872111140', '', '', 'Majir Ghat, Kuruskul Road, Coxsbazar', 'Tarikul Islam', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 20:21:00', 'Admin', '2019-12-21 16:48:36', 1),
(30, 'C00030', 'M/S Makkah Electronics', 'retail', '', '01842261023', '', '', 'Madrasa Market, Juarianala, Ramu, Coxsbazar', 'Ansarul Karim', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 20:22:23', 'Admin', '2019-12-21 16:52:24', 1),
(31, 'C00031', 'Khan Electronics Park', 'retail', '', '01816466538', '', '', 'School Market 2nd Floor, Coumohni, Ramu, Coxsbazar', 'Jamil Uddin', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 20:23:35', 'Admin', '2019-12-21 16:52:29', 1),
(32, 'C00032', 'Sojon Electronics', 'retail', '', '01619910019', '', '', 'Uttor Miachori, Cha Bagan Bazar, Ramu, Coxsbazar', 'Titu Barua', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 20:24:37', 'Admin', '2019-12-21 16:52:35', 1),
(33, 'C00033', 'Rubel Electronics', 'retail', '', '01826980808', '', '', 'Gorjonia Bazar, Ramu, Coxsbazar', 'Md Rubel', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-18 20:25:42', 'Admin', '2019-12-21 16:52:18', 1),
(34, 'C00034', 'Fast Electronics', 'retail', '', '01839416190', '', '', 'Kabir Tower, Naikhongchari Bazar, Bandarban', 'Md Ismail', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:36:23', 'Admin', '2019-12-21 16:52:13', 1),
(35, 'C00035', 'Sohid Electronics & Digital', 'retail', '', '01823969160', '', '', 'Shop No: 1, Iqra Market, Naikhongchari Bazar, Bandarban', 'Md Sohidullah', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:42:06', 'Admin', '2019-12-21 16:52:07', 1),
(36, 'C00036', 'Hridoy Electronics & Telecom', 'retail', '', '01813251094', '', '', 'Shop No: 2, Iqra Market, Naikhongchari Bazar, Bandarban', 'Rupon Chandara Nath', 0, 12, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:45:13', 'Admin', '2019-12-21 16:52:01', 1),
(37, 'C00037', 'S M  Enterprice', 'retail', '', '01816776320', '', '', 'Islamia Shopping Complex, Bus Station, Eidgao, Coxsbazar', 'Sahjahan Chowdory', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:48:15', 'Admin', '2019-12-21 16:51:53', 1),
(38, 'C00038', 'Grameen Sourbiddut', 'retail', '', '01818675219', '', '', 'Anu Mia Sikder Building, Bus Station, Eidgao, Coxsbazar', 'A N M Amzad Hossain', 0, 10, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:49:49', 'Admin', '2019-12-21 16:51:48', 1),
(39, 'C00039', 'Public Media Computer', 'retail', '', '01819052749', '', '', 'Rukeya shopping Complex, Moriccha, Ukhiya, Coxsbazar', 'Md Jamal Uddin', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:51:41', 'Admin', '2019-12-21 16:51:41', 1),
(40, 'C00040', 'Jahangir Electronics & Hardware', 'retail', '', '01858574014', '', '', '2nd Floor, New Market, Moriccha, Ukhiya, Coxsbazar', 'Jahangir Alam', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:53:13', 'Admin', '2019-12-21 16:53:19', 1),
(41, 'C00041', 'Joynal Electronics', 'retail', '', '01829698813', '', '', 'Abbas Uddin Shopping Complex, 2nd floor, Coat Bazar, Ukhiya, Coxsbazar', 'MD Joynal Abedin', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:56:52', 'Admin', '2019-12-21 16:53:25', 1),
(42, 'C00042', 'S K Cable Network', 'retail', '', '01818239021', '', '', '1st floor, Amin Market, Coat Bazar Ukiya, Coxsbazar', 'Md Soyod Alam', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:58:34', 'Admin', '2019-12-21 16:53:30', 1),
(43, 'C00043', 'Mukta  Cable Network', 'retail', '', '01819368063', '', '', 'Shop 2, Arafat Hotel , Ukhiya, Coxsbazar', 'Md Jasim', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 19:59:58', 'Admin', '2019-12-21 16:53:47', 1),
(44, 'C00044', 'Mustafa Computer & Technology', 'retail', '', '01819519474', '', '', 'Mosque Market, Ukhiya, Coxsbazar', 'Md Mustafa Kamal', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:03:27', 'Admin', '2019-12-21 16:53:12', 1),
(45, 'C00045', 'M/S Mamun Enterprise', 'retail', '', '01734539168', '', '', 'Kutupalong Purbo Para, Ukhiya, Coxsbazar', 'Zahangir Alam', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:05:29', 'Admin', '2019-12-21 16:53:08', 1),
(46, 'C00046', 'Hakim & Sons Electronics', 'retail', '', '01874205191', '', '', 'Thaingkhali, Main Road,Ukhiya, Cox\'s Bazar', 'Sahab Uddin', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:06:51', 'Admin', '2019-12-21 16:53:02', 1),
(47, 'C00047', 'Hakim & Sons Electronics 2', 'retail', '', '01830083483', '', '', 'Palong Khali Ukhiya, Cox\'s Bazar', 'Sahab Uddin', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:08:32', 'Admin', '2019-12-21 16:52:57', 1),
(48, 'C00048', 'Hakim & Sons Solar & Masenary', 'retail', '', '01818286046', '', '', 'Bus Stason Palong Khali Ukhiya, Cox\'s Bazar', 'Sahab Uddin', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:10:08', 'Admin', '2019-12-21 16:52:52', 1),
(49, 'C00049', 'Tamim Telecom', 'retail', '', '01817777281', '', '', 'Palong Khali Ukhiya, Cox\'s Bazar', 'Tamim', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:13:17', 'Admin', '2019-12-21 16:52:47', 1),
(50, 'C00050', 'Lutfur Telecom & IT Center', 'retail', '', '01744215979', '', '', ' Palong Khali Bazar, Ukhiya, Coxsbazar', 'Lutfur Rahman', 0, 13, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:15:00', 'Admin', '2019-12-21 16:55:07', 1),
(51, 'C00051', 'Z M Electronics', 'retail', '', '01816099910', '', '', 'Hnila Bus Station, Teknaf, Coxsbazar', 'Abdul Aziz', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:16:29', 'Admin', '2019-12-21 16:54:59', 1),
(52, 'C00052', 'M Alom Electronics', 'retail', '', '01819536175', '', '', 'Purbo Sikder Para, Hnila, Teknaf, Coxsbazar', 'Mohammed Alom', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:17:40', 'Admin', '2019-12-21 16:54:53', 1),
(53, 'C00053', 'Abbas Electronics', 'retail', '', '01850125959', '', '', 'Moddom Hnila, Teknaf, Coxsbazar', 'Abbas Ali', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:19:13', 'Admin', '2019-12-21 16:54:27', 1),
(54, 'C00054', 'Ittadi Store', 'retail', '', '01819073330', '', '', 'Thana Road, Teknaf, Coxsbazar', 'MD Yakub', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:20:55', 'Admin', '2019-12-21 16:54:45', 1),
(55, 'C00055', 'Electronics Plaza', 'retail', '', '01616111365', '', '', 'Zila Parisad Market, Teknaf, Coxsbazar', 'Md ayub', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:22:33', 'Admin', '2019-12-21 16:54:33', 1),
(56, 'C00056', 'Mujammel Computer & Electronics', 'retail', '', '01813909351', '', '', 'Samlapur Bazar, Teknaf', 'Mujammel Haque', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:23:45', 'Admin', '2019-12-21 16:54:21', 1),
(57, 'C00057', 'Shajid Enterprise', 'retail', '', '01822240777', '', '', 'Alom company Mkt, Samlapur Bazar, Teknaf', 'Abul  Monjur', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:24:51', 'Admin', '2019-12-21 16:54:12', 1),
(58, 'C00058', 'M K Electronics', 'retail', '', '01611117873', '', '', 'Noa Para Teknaf Cox\'s Bazar', 'Samsul Uddin', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:26:09', 'Admin', '2019-12-21 16:54:03', 1),
(59, 'C00059', 'Almas Sourbiddut', 'retail', '', '01837767135', '', '', 'Nhila Bazar Teknaf Cox\'s Bazar', 'Almas', 0, 14, '', '50000.00', '0.00', NULL, 'a', 'Md Riaz', '2019-12-19 20:28:00', 'Admin', '2019-12-21 16:53:58', 1),
(60, 'C00060', 'Zia Enterprices', 'retail', '', '01846999008', '', '', 'Ramu ,Coxs Bazar', 'zia', 0, 12, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:00:39', 'Admin', '2019-12-21 17:07:14', 4),
(61, 'C00061', 'Taj Enterprices', 'retail', '', '01840000221', '', '', 'Ramu ,Coxs Bazar', 'Taj', 0, 12, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:01:56', 'Admin', '2019-12-21 17:07:01', 4),
(62, 'C00062', 'Aurjo Gift Corner', 'retail', '', '01860627457', '', '', 'Ramu ,Coxs Bazar', 'Aurjo', 0, 12, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:03:11', 'Admin', '2019-12-21 17:06:56', 4),
(63, 'C00063', 'Momota Electronics', 'retail', '', '01875527656', '', '', 'Eidgah Sador, Coxs Bazar', 'Momota', 0, 12, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:04:44', 'Admin', '2019-12-21 17:06:48', 4),
(64, 'C00064', 'MS Traders', 'retail', '', '01817227487', '', '', 'Eidgah Sadar,Coxs Bazar', 'MD', 0, 12, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:08:16', 'Admin', '2019-12-21 17:06:41', 4),
(65, 'C00065', 'Techno ', 'retail', '', '01618610101', '', '', 'Taraboniachara, Man Road, Coxs bazar', 'MD Ismail', 0, 10, '', '5000000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:11:05', 'Admin', '2019-12-20 11:13:02', 4),
(66, 'C00066', 'Ishak Traders', 'retail', '', '01839079358', '', '', 'Ukhia Sadar, Coxs Bazar', 'Ishak ', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:16:18', 'Admin', '2019-12-21 17:06:33', 4),
(67, 'C00067', 'Asim Crocrij', 'retail', '', '01868674920', '', '', 'Cartbazar.Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:19:01', 'Admin', '2019-12-21 17:06:26', 4),
(68, 'C00068', '99 Shop ', 'retail', '', '01812342157', '', '', 'Cartbazar.Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:20:42', 'Admin', '2019-12-21 17:06:20', 4),
(69, 'C00069', 'Seva Gas Stor', 'retail', '', '01619707426', '', '', 'Cartbazar.Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:21:59', 'Admin', '2019-12-21 17:06:13', 4),
(70, 'C00070', 'Shahamo Jidia Crocrij', 'retail', '', '01864916816', '', '', 'Cartbazar.Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:23:37', 'Admin', '2019-12-21 17:06:08', 4),
(71, 'C00071', 'MM Crocrij', 'retail', '', '01640696007', '', '', 'Cartbazar.Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:24:42', 'Admin', '2019-12-21 17:06:02', 4),
(72, 'C00072', 'Mitaly Gas House', 'retail', '', '01839565782', '', '', 'Taraboniasora,Coxs Bazar', 'MD', 0, 10, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:26:22', 'Admin', '2019-12-21 17:05:56', 4),
(73, 'C00073', 'Tayub Store', 'retail', '', '01831564887', '', '', 'Eidor Sadar, Coxs Bazar', 'Tayub', 0, 10, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:46:49', 'Admin', '2019-12-21 17:05:43', 4),
(74, 'C00074', 'Forstar Crocarij', 'retail', '', '01943363131', '', '', 'Moricca Bazar,Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:51:31', 'Admin', '2019-12-21 17:05:33', 4),
(75, 'C00075', 'Delower Telicom', 'retail', '', '01824242475', '', '', 'Ramo, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:52:50', 'Admin', '2019-12-21 17:04:02', 4),
(76, 'C00076', 'Ifat Traders', 'retail', '', '01812930567', '', '', 'Ukhia', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:54:04', 'Admin', '2019-12-21 17:03:55', 4),
(77, 'C00077', 'Ma Crocaij and Gift', 'retail', '', '01872030301', '', '', 'Ukhia', 'Md', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:55:51', 'Admin', '2019-12-21 17:03:49', 4),
(78, 'C00078', 'MY HOME', 'retail', '', '01919751198', '', '', 'Bazar Gata . Coxs Bazar', 'MD', 0, 10, '', '200000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:57:42', NULL, NULL, 4),
(79, 'C00079', 'Hamim Electronic', 'retail', '', '01819725565', '', '', 'Ramu. Coxs bazar', 'MD', 0, 10, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 11:58:52', 'Admin', '2019-12-21 17:03:39', 4),
(80, 'C00080', 'Ahsam', 'retail', '', '01815354012', '', '', 'Bazar Gata, Coxs Bazar', 'Ahsam', 0, 10, '', '250000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:00:05', NULL, NULL, 4),
(81, 'C00081', 'Naikhonchary Pertrol Pump', 'retail', '', '01816908552', '', '', 'Naikhonchary Bazar, Ramu', 'MD', 0, 10, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:02:09', 'Admin', '2019-12-21 17:03:28', 4),
(82, 'C00082', 'Nur Crocarij', 'retail', '', '01819185474', '', '', 'Boro Bazar, Coxs bazar Sadar', 'MD', 0, 10, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:03:49', 'Admin', '2019-12-21 17:03:22', 4),
(83, 'C00083', 'Hossein Crocarij', 'retail', '', '01818157466', '', '', 'Eidgah,Coxs bazar', 'MD', 0, 15, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:05:38', 'Admin', '2019-12-21 17:03:14', 4),
(84, 'C00084', 'Allaherdan 2', 'retail', '', '01943363130', '', '', 'Ukhia', 'MD', 0, 13, '', '500000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:07:41', 'Admin', '2019-12-21 17:03:06', 4),
(85, 'C00085', 'AK Enterprices', 'retail', '', '01813676302', '', '', '01813676302', 'MD', 0, 11, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:09:06', 'Admin', '2019-12-21 17:02:57', 4),
(86, 'C00086', 'Mokka Crocarij', 'retail', '', '01863371727', '', '', 'Eidgao, Coxs Bazr', 'MD', 0, 15, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:11:00', 'Admin', '2019-12-21 17:02:38', 4),
(87, 'C00087', 'Hisam Traders', 'retail', '', '01812930568', '', '', 'Cartbazer,Ukhia', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:12:42', 'Admin', '2019-12-21 17:02:30', 4),
(88, 'C00088', 'Zahed Entrprices', 'retail', '', '01876548173', '', '', 'Eidgao ,Coxs Bazar', 'MD', 0, 15, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:14:43', 'Admin', '2019-12-21 17:02:23', 4),
(89, 'C00089', 'Arif Enterprices', 'retail', '', '01819025666', '', '', 'Eidgao', 'MD', 0, 15, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:15:49', 'Admin', '2019-12-21 17:02:17', 4),
(90, 'C00090', 'Palong Trders', 'retail', '', '01814922810', '', '', 'Ukhia', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:19:13', 'Admin', '2019-12-21 17:02:10', 4),
(91, 'C00091', 'Hak  Enterprics', 'retail', '', '01818245131', '', '', 'Ukhia, Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:21:20', 'Admin', '2019-12-21 17:02:04', 4),
(92, 'C00092', 'Morsed Enterprics', 'retail', '', '01845666629', '', '', 'Larpara , Coxs Bazar', 'MD', 0, 13, '', '150000.00', '0.00', NULL, 'a', 'Admin', '2019-12-20 12:23:11', 'Admin', '2019-12-21 17:01:53', 4),
(93, 'C00093', 'ghvcg', 'retail', '', '+65+652', '', '', 'hjknblkj', 'kloihkj', 0, 1, '', '100000.00', '0.00', NULL, 'a', 'Admin', '2019-12-21 14:20:19', 'Admin', '2019-12-21 14:20:46', 3),
(94, 'C00094', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 14:02:18', NULL, NULL, 1),
(95, 'C00095', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 14:13:51', NULL, NULL, 1),
(96, 'C00096', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 15:01:35', 'Admin', '2019-12-25 15:06:03', 1),
(97, 'C00097', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 17:35:57', 'Admin', '2019-12-25 17:36:14', 1),
(98, 'C00098', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 17:40:30', 'Admin', '2019-12-25 17:40:56', 1),
(99, 'C00099', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 17:50:47', 'Admin', '2019-12-25 17:51:10', 1),
(100, 'C00100', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 17:52:35', 'Admin', '2019-12-25 17:52:58', 1),
(101, 'C00101', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:02:02', 'Admin', '2019-12-25 18:02:31', 1),
(102, 'C00102', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:18:38', 'Admin', '2019-12-25 18:18:53', 1),
(103, 'C00103', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:19:28', 'Admin', '2019-12-25 18:19:42', 1),
(104, 'C00104', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:23:12', 'Admin', '2019-12-25 18:25:16', 1),
(105, 'C00105', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:29:45', 'Admin', '2019-12-25 18:30:03', 1),
(106, 'C00106', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:31:31', 'Admin', '2019-12-25 18:36:03', 1),
(107, 'C00107', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 18:47:02', 'Admin', '2019-12-25 18:58:10', 1),
(108, 'C00108', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 19:00:26', 'Admin', '2019-12-25 19:01:18', 1),
(109, 'C00109', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 19:05:20', 'Admin', '2019-12-25 19:05:40', 1),
(110, 'C00110', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 19:08:49', 'Admin', '2019-12-25 19:12:21', 1),
(111, 'C00111', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', '0.00', NULL, 'a', 'Admin', '2019-12-25 21:51:56', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_payment`
--

DROP TABLE IF EXISTS `tbl_customer_payment`;
CREATE TABLE IF NOT EXISTS `tbl_customer_payment` (
  `CPayment_id` int(11) NOT NULL AUTO_INCREMENT,
  `CPayment_date` date DEFAULT NULL,
  `CPayment_invoice` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `CPayment_customerID` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `CPayment_TransactionType` varchar(20) DEFAULT NULL,
  `CPayment_amount` decimal(18,2) DEFAULT NULL,
  `out_amount` float NOT NULL DEFAULT '0',
  `CPayment_Paymentby` varchar(50) DEFAULT NULL,
  `CPayment_notes` varchar(225) CHARACTER SET latin1 DEFAULT NULL,
  `CPayment_brunchid` int(11) DEFAULT NULL,
  `CPayment_previous_due` float NOT NULL DEFAULT '0',
  `CPayment_Addby` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  `CPayment_AddDAte` date DEFAULT NULL,
  `CPayment_status` varchar(1) DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  `CPayment_UpdateDAte` date DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`CPayment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_damage`
--

DROP TABLE IF EXISTS `tbl_damage`;
CREATE TABLE IF NOT EXISTS `tbl_damage` (
  `Damage_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Damage_InvoiceNo` varchar(50) NOT NULL,
  `Damage_Date` date NOT NULL,
  `Damage_Description` varchar(300) NOT NULL,
  `status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `Damage_brunchid` int(11) NOT NULL,
  PRIMARY KEY (`Damage_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_damagedetails`
--

DROP TABLE IF EXISTS `tbl_damagedetails`;
CREATE TABLE IF NOT EXISTS `tbl_damagedetails` (
  `DamageDetails_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Damage_SlNo` int(11) NOT NULL,
  `Product_SlNo` int(11) NOT NULL,
  `DamageDetails_DamageQuantity` int(11) NOT NULL,
  `damage_amount` float NOT NULL,
  `status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`DamageDetails_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
CREATE TABLE IF NOT EXISTS `tbl_department` (
  `Department_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Department_Name` varchar(50) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Department_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_designation`
--

DROP TABLE IF EXISTS `tbl_designation`;
CREATE TABLE IF NOT EXISTS `tbl_designation` (
  `Designation_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Designation_Name` varchar(50) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Designation_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

DROP TABLE IF EXISTS `tbl_district`;
CREATE TABLE IF NOT EXISTS `tbl_district` (
  `District_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `District_Name` varchar(50) NOT NULL,
  `status` char(10) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`District_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`District_SlNo`, `District_Name`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`) VALUES
(1, 'Dhaka', 'a', 'Admin', '2019-09-17 22:59:32', NULL, NULL),
(2, 'Jessore', 'd', 'Admin', '2019-09-17 22:59:37', NULL, NULL),
(3, 'Kustia', 'd', 'Admin', '2019-09-17 22:59:43', NULL, NULL),
(4, 'Khulna', 'd', 'Admin', '2019-09-17 22:59:50', NULL, NULL),
(5, 'Magura', 'd', 'Admin', '2019-09-17 22:59:55', NULL, NULL),
(6, 'Coxs Bazaar', 'a', 'Admin', '2019-09-17 23:00:02', 'Admin', '2019-12-15 19:26:04'),
(7, 'Chittagong', 'd', 'Admin', '2019-09-17 23:00:08', NULL, NULL),
(8, 'Mymenshing', 'd', 'Admin', '2019-09-17 23:00:15', NULL, NULL),
(9, 'Narayangonj', 'd', 'Admin', '2019-09-17 23:00:23', NULL, NULL),
(10, 'Coxs Bazar Sadar', 'a', 'Admin', '2019-12-16 23:24:06', NULL, NULL),
(11, 'Naikkongchori', 'a', 'Admin', '2019-12-16 23:25:04', NULL, NULL),
(12, 'Ramu', 'a', 'Admin', '2019-12-16 23:25:30', 'Admin', '2019-12-18 17:33:57'),
(13, 'Ukhia', 'a', 'Admin', '2019-12-16 23:26:16', NULL, NULL),
(14, 'Teknaf', 'a', 'Admin', '2019-12-16 23:26:35', NULL, NULL),
(15, 'Eidgao', 'a', 'Admin', '2019-12-20 11:47:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

DROP TABLE IF EXISTS `tbl_employee`;
CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `Employee_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Designation_ID` int(11) NOT NULL,
  `Department_ID` int(11) NOT NULL,
  `Employee_ID` varchar(50) NOT NULL,
  `Employee_Name` varchar(150) NOT NULL,
  `Employee_JoinDate` date NOT NULL,
  `Employee_Gender` varchar(20) NOT NULL,
  `Employee_BirthDate` date NOT NULL,
  `Employee_NID` varchar(50) NOT NULL,
  `Employee_ContactNo` varchar(20) NOT NULL,
  `Employee_Email` varchar(50) NOT NULL,
  `Employee_MaritalStatus` varchar(50) NOT NULL,
  `Employee_FatherName` varchar(150) NOT NULL,
  `Employee_MotherName` varchar(150) NOT NULL,
  `Employee_PrasentAddress` text NOT NULL,
  `Employee_PermanentAddress` text NOT NULL,
  `Employee_Pic_org` varchar(250) NOT NULL,
  `Employee_Pic_thum` varchar(250) NOT NULL,
  `salary_range` int(11) NOT NULL,
  `status` char(10) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) NOT NULL,
  `AddTime` varchar(50) NOT NULL,
  `UpdateBy` varchar(50) NOT NULL,
  `UpdateTime` varchar(50) NOT NULL,
  `Employee_brinchid` int(11) NOT NULL,
  PRIMARY KEY (`Employee_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`Employee_SlNo`, `Designation_ID`, `Department_ID`, `Employee_ID`, `Employee_Name`, `Employee_JoinDate`, `Employee_Gender`, `Employee_BirthDate`, `Employee_NID`, `Employee_ContactNo`, `Employee_Email`, `Employee_MaritalStatus`, `Employee_FatherName`, `Employee_MotherName`, `Employee_PrasentAddress`, `Employee_PermanentAddress`, `Employee_Pic_org`, `Employee_Pic_thum`, `salary_range`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Employee_brinchid`) VALUES
(1, 1, 1, 'E1001', 'MD TAREK', '2019-05-19', 'Male', '1986-06-14', '', '01819751198', 'hello.tareq.teknaf@gmail.com', 'married', 'NOR AZIZ', 'SONA MAHER', 'TEKNAF COXS BAZAR', 'COXS BAZAR', 'Management-NAF-GROUP-TEKNAF-MD-1.jpg', 'Management-NAF-GROUP-TEKNAF-MD-1.jpg', 15000, 'a', 'Admin', '2019-12-15 17:10:29', 'Admin', '2019-12-18 20:10:30', 1),
(2, 2, 2, 'E1002', 'Abdul Mobin Hero', '2019-12-01', 'Male', '2002-07-27', '', '01866492333', 'hero@gmail.com', 'unmarried', 'Md Abdullh', 'Hakra Bagum', 'Bahachara coxs bazar', 'Bahachara coxs bazar', '297f3e45-e941-4b9d-bed3-a35f816dc166.jpg', '297f3e45-e941-4b9d-bed3-a35f816dc166.jpg', 10000, 'a', 'Admin', '2019-12-15 17:17:46', 'Admin', '2019-12-18 20:11:18', 1),
(3, 4, 1, 'E1003', 'Amimul Ahsan Riaz', '2019-12-08', 'Male', '1986-02-10', '', '01811929982', 'riazhahsan86@gmail.com', 'married', 'Mozib Ullah', 'Jahanara Begum', 'C/O=Mojib Ullah master bari.Village=Char Jogobondo.Post Hazir Hat 3731 Thana KAMAL NAGAR', 'SAME', 'Amimul_Ahsan_Riaz.jpg', 'Amimul_Ahsan_Riaz.jpg', 15000, 'a', 'Md Riaz', '2019-12-15 18:34:23', 'Admin', '2019-12-18 20:17:07', 1),
(4, 5, 4, 'E1004', 'Tarek  Installer', '2019-12-01', 'Male', '2019-12-16', '', '01660194607', '', 'unmarried', '', '', 'COXS BAZAR', 'COXS BAZAR', 'tareq_in.jpg', 'tareq_in.jpg', 10000, 'a', 'Admin', '2019-12-16 20:25:00', 'Admin', '2019-12-18 20:10:57', 1),
(5, 5, 4, 'E1005', 'Md Rajo Installer', '2019-12-16', 'Male', '2019-05-19', '', '01660194614', '', 'married', '', '', 'COXS BAZAR', '', '', '', 10000, 'a', 'Admin', '2019-12-16 20:33:11', 'Admin', '2019-12-18 14:59:53', 1),
(6, 1, 3, 'E1006', 'MD TAREK', '2019-11-06', 'Male', '2019-12-19', '', '01819751198', '', 'married', 'NO', 'NO', 'COXS BAZAR', 'COXS BAZAR', '', '', 15000, 'a', 'Admin', '2019-12-19 18:57:35', '', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee_payment`
--

DROP TABLE IF EXISTS `tbl_employee_payment`;
CREATE TABLE IF NOT EXISTS `tbl_employee_payment` (
  `employee_payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `Employee_SlNo` int(11) NOT NULL,
  `payment_date` date DEFAULT NULL,
  `month_id` int(11) NOT NULL,
  `payment_amount` decimal(18,2) NOT NULL,
  `deduction_amount` decimal(18,2) NOT NULL,
  `status` varchar(1) DEFAULT NULL,
  `save_by` char(30) NOT NULL,
  `save_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_by` int(11) DEFAULT NULL,
  `update_date` varchar(12) NOT NULL,
  `paymentBranch_id` int(11) NOT NULL,
  PRIMARY KEY (`employee_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_expense_head`
--

DROP TABLE IF EXISTS `tbl_expense_head`;
CREATE TABLE IF NOT EXISTS `tbl_expense_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `head_name` varchar(100) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `status` enum('a','d') DEFAULT 'a',
  `saved_by` int(11) DEFAULT NULL,
  `saved_datetime` datetime DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_month`
--

DROP TABLE IF EXISTS `tbl_month`;
CREATE TABLE IF NOT EXISTS `tbl_month` (
  `month_id` int(11) NOT NULL AUTO_INCREMENT,
  `month_name` char(30) NOT NULL,
  PRIMARY KEY (`month_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_month`
--

INSERT INTO `tbl_month` (`month_id`, `month_name`) VALUES
(1, 'August-2019'),
(2, 'January-2019'),
(3, 'February-2019'),
(4, 'March-2019'),
(5, 'April-2019'),
(6, 'May-2019'),
(7, 'June-2019'),
(8, 'September-2019'),
(9, 'October-2019'),
(10, 'November-2019'),
(11, 'December-2019');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `Product_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Product_Code` varchar(50) NOT NULL,
  `Product_Name` varchar(150) NOT NULL,
  `ProductCategory_ID` int(11) NOT NULL,
  `color` int(11) NOT NULL,
  `brand` int(11) NOT NULL,
  `size` varchar(11) NOT NULL DEFAULT 'na',
  `vat` float NOT NULL,
  `Product_ReOrederLevel` int(11) NOT NULL,
  `Product_Purchase_Rate` decimal(18,2) NOT NULL,
  `Product_SellingPrice` decimal(18,2) NOT NULL,
  `Product_MinimumSellingPrice` decimal(18,2) NOT NULL,
  `Product_WholesaleRate` decimal(18,2) NOT NULL,
  `one_cartun_equal` varchar(20) NOT NULL,
  `is_service` varchar(10) NOT NULL DEFAULT 'false',
  `Unit_ID` int(11) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(100) NOT NULL,
  `AddTime` varchar(30) NOT NULL,
  `UpdateBy` varchar(50) NOT NULL,
  `UpdateTime` varchar(30) NOT NULL,
  `Product_branchid` int(11) NOT NULL,
  PRIMARY KEY (`Product_SlNo`),
  UNIQUE KEY `Product_Code` (`Product_Code`)
) ENGINE=InnoDB AUTO_INCREMENT=1253 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`Product_SlNo`, `Product_Code`, `Product_Name`, `ProductCategory_ID`, `color`, `brand`, `size`, `vat`, `Product_ReOrederLevel`, `Product_Purchase_Rate`, `Product_SellingPrice`, `Product_MinimumSellingPrice`, `Product_WholesaleRate`, `one_cartun_equal`, `is_service`, `Unit_ID`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Product_branchid`) VALUES
(1, 'P00001', 'STB Combo With Singie LNB Akash Dth', 7, 0, 0, 'na', 0, 0, '3326.00', '3574.00', '0.00', '3400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:32:07', 'Admin', '2019-12-15 20:41:15', 1),
(2, 'P00002', 'Cable Combo Pack 10 Meter Akash Dth', 8, 0, 0, 'na', 0, 0, '270.00', '300.00', '0.00', '280.00', '', 'false', 2, 'a', 'Abdul Mobin Hero', '2019-12-15 17:32:55', 'Admin', '2019-12-16 13:22:06', 1),
(3, 'P00003', 'Dish with assembly Combo Pack  Akash Dth', 9, 0, 0, 'na', 0, 0, '838.00', '928.00', '0.00', '900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:33:31', 'Admin', '2019-12-15 20:05:06', 1),
(4, 'P00004', 'Connector Indoor / Outdoore Combo Pack Akash Dth', 10, 0, 0, 'na', 0, 0, '90.00', '100.00', '0.00', '96.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:34:20', 'Admin', '2019-12-15 20:46:57', 1),
(5, 'P00005', 'Dish with assembly Singie Pack Akash Dth', 11, 0, 0, 'na', 0, 0, '865.00', '928.00', '0.00', '928.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:34:54', 'Admin', '2019-12-16 21:04:14', 1),
(6, 'P00006', 'LNB SINGLE Combo Pack Akash Dth', 12, 0, 0, 'na', 0, 0, '255.00', '282.00', '0.00', '275.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:35:31', 'Admin', '2019-12-15 20:12:43', 1),
(7, 'P00007', 'Remot STB Combo Pack Akash Dth', 13, 0, 0, 'na', 0, 0, '300.00', '400.00', '0.00', '350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:35:52', 'Admin', '2019-12-15 20:14:27', 1),
(8, 'P00008', 'STB With Singie Akash Dth', 14, 0, 0, 'na', 0, 0, '3322.00', '3574.00', '0.00', '3400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:36:13', 'Admin', '2019-12-15 20:15:37', 1),
(9, 'P00009', 'LNB (SINGLE) Akash Dth', 15, 0, 0, 'na', 0, 0, '255.00', '282.00', '0.00', '275.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:36:54', 'Admin', '2019-12-15 20:20:32', 1),
(10, 'P00010', '1F5-RXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:37:35', 'Admin', '2019-12-16 16:36:40', 1),
(11, 'P00011', 'WWP-WT05C Horse Power  WALTON', 52, 0, 0, 'na', 0, 0, '2900.00', '2900.00', '0.00', '2900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:46:49', 'Abdul Mobin Hero', '2019-12-21 17:30:22', 1),
(12, 'P00012', 'WWP-WT10J Horse Power  WALTON', 51, 0, 0, 'na', 0, 0, '5900.00', '5900.00', '0.00', '5900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:48:01', 'Admin', '2019-12-16 16:58:05', 1),
(13, 'P00013', 'WCW-WSL2401-Wok Pan  Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:48:57', 'Admin', '2019-12-16 16:38:13', 1),
(14, 'P00014', 'WCW-FS2201 22CM  Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:49:35', 'Admin', '2019-12-16 16:38:23', 1),
(15, 'P00015', 'Marcel Gas Stove-MGS-GNS1', 115, 0, 0, 'na', 0, 0, '3990.00', '3990.00', '0.00', '3990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:50:11', 'Admin', '2019-12-21 16:34:02', 1),
(16, 'P00016', 'WFO-JET-0101-RXXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '10990.00', '10990.00', '0.00', '10990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:50:51', 'Abdul Mobin Hero', '2019-12-21 17:48:24', 1),
(17, 'P00017', 'WVF-GV40GM Vacuum Flask', 65, 0, 0, 'na', 0, 0, '2150.00', '2150.00', '0.00', '2150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:51:31', 'Admin', '2019-12-17 09:45:46', 1),
(18, 'P00018', '1X1-0101-RXXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '13550.00', '13550.00', '0.00', '13550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:52:12', 'Admin', '2019-12-16 14:44:07', 1),
(19, 'P00019', '1X1-0101-CDBX  Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:53:01', 'Admin', '2019-12-16 14:44:17', 1),
(20, 'P00020', '1A5-0101-RXXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:54:21', 'Admin', '2019-12-16 14:44:28', 1),
(21, 'P00021', '1B6-RDXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '17990.00', '17990.00', '0.00', '17990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:55:45', 'Admin', '2019-12-16 14:48:11', 1),
(22, 'P00022', '1B6-MBXX  Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '17990.00', '17990.00', '0.00', '17990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:57:15', 'Admin', '2019-12-16 14:48:17', 1),
(23, 'P00023', '1B6-RXXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '18200.00', '18200.00', '0.00', '18200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 17:57:47', 'Admin', '2019-12-16 14:48:23', 1),
(24, 'P00024', '1B6-GDEL-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '19500.00', '19500.00', '0.00', '19500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:09:33', 'Admin', '2019-12-16 14:48:30', 1),
(25, 'P00025', '1D4-GDEL-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '21250.00', '21250.00', '0.00', '21250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:10:20', 'Admin', '2019-12-16 14:48:36', 1),
(26, 'P00026', '1D4-RXXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '20090.00', '20090.00', '0.00', '20090.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:11:06', 'Admin', '2019-12-16 14:48:42', 1),
(27, 'P00027', '1D4-MBXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '20100.00', '20100.00', '0.00', '20100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:11:37', 'Admin', '2019-12-16 14:48:48', 1),
(28, 'P00028', '1D4-RDXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '20050.00', '20050.00', '0.00', '20050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:12:22', 'Admin', '2019-12-16 14:49:03', 1),
(29, 'P00029', '1D4-RXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '20090.00', '20090.00', '0.00', '20090.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:13:55', 'Admin', '2019-12-16 14:49:09', 1),
(30, 'P00030', '1F3-GDEL-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '22250.00', '22250.00', '0.00', '22250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:14:31', 'Admin', '2019-12-16 14:49:24', 1),
(31, 'P00031', '1F3-RXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '21100.00', '21100.00', '0.00', '21100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:14:59', 'Admin', '2019-12-16 14:49:16', 1),
(32, 'P00032', 'WD4-MT55-VC100-HIL-1.397m Walton LED Television', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'd', 'Md Riaz', '2019-12-15 18:15:35', '', '', 1),
(33, 'P00033', '1F3-RDXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '20990.00', '20990.00', '0.00', '20990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:15:39', 'Admin', '2019-12-16 14:49:30', 1),
(34, 'P00034', '1F3-MBXX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '20850.00', '20850.00', '0.00', '20850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:16:07', 'Admin', '2019-12-16 14:49:38', 1),
(35, 'P00035', 'WFA-1F5-RXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '19290.00', '19290.00', '0.00', '19290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:17:15', 'Abdul Mobin Hero', '2019-12-21 17:51:15', 1),
(36, 'P00036', '1H5-ELED-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '24790.00', '24790.00', '0.00', '24790.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:21:01', 'Admin', '2019-12-16 14:44:46', 1),
(37, 'P00037', '1H5-RNXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25100.00', '25100.00', '0.00', '25100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:21:30', 'Admin', '2019-12-16 14:44:54', 1),
(38, 'P00038', '1H5-ELXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25250.00', '25250.00', '0.00', '25250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:22:04', 'Admin', '2019-12-16 14:45:02', 1),
(39, 'P00039', '1H5-GDXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '26900.00', '26900.00', '0.00', '26900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:22:53', 'Admin', '2019-12-16 14:45:10', 1),
(40, 'P00040', '1H5-GDEL-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27400.00', '27400.00', '0.00', '27400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:24:07', 'Admin', '2019-12-16 14:45:18', 1),
(41, 'P00041', '2X1-ELED-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25150.00', '25150.00', '0.00', '25150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:24:33', 'Admin', '2019-12-16 14:45:26', 1),
(42, 'P00042', '2X1-RNXX-XX Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25690.00', '25690.00', '0.00', '25690.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:25:06', 'Admin', '2019-12-16 14:45:33', 1),
(43, 'P00043', '2X1-RXXX-RP Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25450.00', '25450.00', '0.00', '25450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:26:03', 'Admin', '2019-12-16 14:45:40', 1),
(44, 'P00044', '2X1-ELXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '26140.00', '26140.00', '0.00', '26140.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:27:02', 'Admin', '2019-12-16 14:45:47', 1),
(45, 'P00045', '2X1-GDXX-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27800.00', '27800.00', '0.00', '27800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:28:35', 'Admin', '2019-12-16 14:45:55', 1),
(46, 'P00046', '2X1-GDEL-XX Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '28300.00', '28300.00', '0.00', '28300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:29:02', 'Admin', '2019-12-16 14:46:06', 1),
(47, 'P00047', '2A3-RXXX-CP Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:30:07', 'Admin', '2019-12-16 14:50:14', 1),
(48, 'P00048', '2A3-RLXX-CP- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:30:45', 'Admin', '2019-12-16 14:50:21', 1),
(49, 'P00049', '2A3-RLXX-RP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '22990.00', '22990.00', '0.00', '22990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:31:18', 'Admin', '2019-12-16 14:54:59', 1),
(50, 'P00050', '2A3-RXXX-RP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:32:06', 'Admin', '2019-12-16 14:52:06', 1),
(51, 'P00051', '2A3-RLXX-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:33:06', 'Admin', '2019-12-16 14:51:31', 1),
(52, 'P00052', '2A3-ELXX-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:34:45', 'Admin', '2019-12-16 14:50:27', 1),
(53, 'P00053', '2A3-NEXX-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '22990.00', '22990.00', '0.00', '22990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:35:39', 'Admin', '2019-12-16 14:50:41', 1),
(54, 'P00054', '2A3-GDXX--Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:36:30', 'Admin', '2019-12-16 14:50:56', 1),
(55, 'P00055', '2A3-GDE-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25300.00', '25300.00', '0.00', '25300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:37:24', 'Admin', '2019-12-16 14:50:49', 1),
(56, 'P00056', '2A8-GDEL-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '28500.00', '28500.00', '0.00', '28500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:38:17', 'Admin', '2019-12-16 14:46:13', 1),
(57, 'P00057', '2A8-GDXX-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27300.00', '27300.00', '0.00', '27300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:39:13', 'Admin', '2019-12-16 14:46:20', 1),
(58, 'P00058', '2A8-CDBX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25700.00', '25700.00', '0.00', '25700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:40:20', 'Admin', '2019-12-16 14:46:27', 1),
(59, 'P00059', '2A8-ELXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25700.00', '25700.00', '0.00', '25700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:42:46', 'Admin', '2019-12-16 14:46:33', 1),
(60, 'P00060', '2B0-ELEX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25750.00', '25750.00', '0.00', '25750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 18:44:33', 'Admin', '2019-12-17 10:55:32', 1),
(61, 'P00061', '2B0-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25790.00', '25790.00', '0.00', '25790.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:05:46', 'Admin', '2019-12-17 10:56:25', 1),
(62, 'P00062', '2B0-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '23550.00', '23550.00', '0.00', '23550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:06:43', 'Admin', '2019-12-16 14:52:00', 1),
(63, 'P00063', '2B6-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '32250.00', '32250.00', '0.00', '32250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:07:32', 'Admin', '2019-12-16 14:46:39', 1),
(64, 'P00064', '2B6-ELED-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27050.00', '27050.00', '0.00', '27050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:08:16', 'Admin', '2019-12-16 14:46:44', 1),
(65, 'P00065', '2B6-RNXX-RP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27540.00', '27540.00', '0.00', '27540.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:08:51', 'Admin', '2019-12-17 11:10:38', 1),
(66, 'P00066', '2B6-ELXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27850.00', '27850.00', '0.00', '27850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:09:22', 'Admin', '2019-12-16 14:47:00', 1),
(67, 'P00067', '2B6-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '31050.00', '31050.00', '0.00', '31050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:10:43', 'Admin', '2019-12-17 11:09:54', 1),
(68, 'P00068', '2B6-GDEL-XXX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '32250.00', '32250.00', '0.00', '32250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:15:24', 'Admin', '2019-12-17 11:08:15', 1),
(69, 'P00069', '2D4-RXXX-CP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '24600.00', '24600.00', '0.00', '24600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:16:10', 'Admin', '2019-12-17 11:05:38', 1),
(70, 'P00070', '2D4-RLXX-CP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25200.00', '25200.00', '0.00', '25200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:18:17', 'Admin', '2019-12-17 11:02:50', 1),
(71, 'P00071', '2D4-NEXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25900.00', '25900.00', '0.00', '25900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:18:52', 'Admin', '2019-12-16 14:51:45', 1),
(72, 'P00072', '2D4-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '26950.00', '26950.00', '0.00', '26950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:21:43', 'Admin', '2019-12-17 11:00:05', 1),
(73, 'P00073', '2D4-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27400.00', '27400.00', '0.00', '27400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:22:34', 'Admin', '2019-12-17 10:59:18', 1),
(74, 'P00074', '2D4-RXXX-RP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25200.00', '25200.00', '0.00', '25200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:23:17', 'Admin', '2019-12-17 10:58:28', 1),
(75, 'P00075', '2D4-RLXX-RP-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '24600.00', '24600.00', '0.00', '24600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:23:51', 'Admin', '2019-12-17 11:21:59', 1),
(76, 'P00076', '2D4-RLXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25200.00', '25200.00', '0.00', '25200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:24:25', 'Admin', '2019-12-17 11:21:03', 1),
(77, 'P00077', '2D4-RXXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25200.00', '25200.00', '0.00', '25200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:24:58', 'Admin', '2019-12-17 11:19:42', 1),
(78, 'P00078', '2E0-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '28500.00', '28500.00', '0.00', '28500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:25:36', 'Admin', '2019-12-17 11:18:50', 1),
(79, 'P00079', '2E4-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '31950.00', '31950.00', '0.00', '31950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:26:09', 'Admin', '2019-12-16 14:47:26', 1),
(80, 'P00080', '2E4-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '30700.00', '30700.00', '0.00', '30700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:26:41', 'Admin', '2019-12-16 14:47:37', 1),
(81, 'P00081', '2E0-ELXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:27:12', 'Admin', '2019-12-16 14:47:44', 1),
(82, 'P00082', '2E0-ELED-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:27:35', 'Admin', '2019-12-16 14:47:49', 1),
(83, 'P00083', '2E0-CDBX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:27:57', 'Admin', '2019-12-16 14:47:55', 1),
(84, 'P00084', '2H2-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '29900.00', '29900.00', '0.00', '29900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:28:25', 'Admin', '2019-12-17 11:12:26', 1),
(85, 'P00085', '2H2-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '29100.00', '29100.00', '0.00', '29100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:28:58', 'Admin', '2019-12-16 19:23:37', 1),
(86, 'P00086', '2H2-CRXX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '25990.00', '25990.00', '0.00', '25990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:29:23', 'Admin', '2019-12-16 19:28:45', 1),
(87, 'P00087', '2N5-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '30750.00', '30750.00', '0.00', '30750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:29:46', 'Admin', '2019-12-16 19:28:14', 1),
(88, 'P00088', '2N5-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '29750.00', '29750.00', '0.00', '29750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:30:19', 'Admin', '2019-12-16 19:27:45', 1),
(89, 'P00089', '2N5-ELNX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '27450.00', '27450.00', '0.00', '27450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:30:45', 'Admin', '2019-12-16 19:27:13', 1),
(90, 'P00090', '2N5-CRXX-XX-Walton Direct Cool Refrigeratorr', 1, 0, 0, 'na', 0, 0, '26850.00', '23850.00', '0.00', '26850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:31:07', 'Admin', '2019-12-16 19:26:44', 1),
(91, 'P00091', '2N5-RXXX-XX-Walton Direct Cool Refrigeratorr', 1, 0, 0, 'na', 0, 0, '26650.00', '26650.00', '0.00', '26650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:31:37', 'Admin', '2019-12-16 19:26:17', 1),
(92, 'P00092', '3X7-GDEL-XX-Walton Direct Cool Refrigeratorr', 1, 0, 0, 'na', 0, 0, '32400.00', '32400.00', '0.00', '32400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:32:18', 'Admin', '2019-12-16 19:25:23', 1),
(93, 'P00093', '3X7-GDXX-XX-Walton Direct Cool Refrigeratorr', 1, 0, 0, 'na', 0, 0, '31500.00', '31500.00', '0.00', '31500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:32:55', 'Admin', '2019-12-16 19:24:48', 1),
(94, 'P00094', '3X7-ELXX-XX-Walton Direct Cool Refrigeratorr', 1, 0, 0, 'na', 0, 0, '30400.00', '30400.00', '0.00', '30400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:33:22', 'Admin', '2019-12-16 19:24:13', 1),
(95, 'P00095', '3X7-NEXX-XX-Walton Direct Cool Refrigeratorr', 1, 0, 0, 'na', 0, 0, '29800.00', '29800.00', '0.00', '29800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:34:06', 'Admin', '2019-12-16 19:33:11', 1),
(96, 'P00096', '3X9-GDEL-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '33750.00', '33750.00', '0.00', '33750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:34:42', 'Admin', '2019-12-16 19:32:44', 1),
(97, 'P00097', '3X9-GDXX-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '32500.00', '32500.00', '0.00', '32500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:35:11', 'Admin', '2019-12-16 14:54:52', 1),
(98, 'P00098', '3X9-ELNX-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '30990.00', '30990.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:35:38', 'Admin', '2019-12-16 19:32:46', 1),
(99, 'P00099', '3A2-GDEL-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '32650.00', '32650.00', '0.00', '32650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:36:17', 'Admin', '2019-12-16 19:31:09', 1),
(100, 'P00100', '3A2-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '31650.00', '31650.00', '0.00', '31650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:36:57', 'Admin', '2019-12-16 14:55:42', 1),
(101, 'P00101', '3A2-ELNX-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '29750.00', '29750.00', '0.00', '29750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:37:21', 'Admin', '2019-12-16 19:30:42', 1),
(102, 'P00102', '3A2-NXXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '28750.00', '28750.00', '0.00', '28750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:38:44', 'Admin', '2019-12-16 19:30:16', 1),
(103, 'P00103', '3A2-CRXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '28050.00', '28050.00', '0.00', '28050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:39:07', 'Admin', '2019-12-16 14:55:35', 1),
(104, 'P00104', '3A7-GDNE-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '32200.00', '32200.00', '0.00', '32200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:39:44', 'Admin', '2019-12-16 19:29:25', 1),
(105, 'P00105', '3A7-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '31700.00', '31700.00', '0.00', '31700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:40:03', 'Admin', '2019-12-17 11:36:05', 1),
(106, 'P00106', '3A7-ELEX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '30590.00', '30590.00', '0.00', '30590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:40:28', 'Admin', '2019-12-17 11:35:10', 1),
(107, 'P00107', '3A7-NXXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '29590.00', '29590.00', '0.00', '29590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:40:52', 'Admin', '2019-12-17 11:32:54', 1),
(108, 'P00108', '3B0-GDXX--Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '32700.00', '32700.00', '0.00', '32700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:41:12', 'Admin', '2019-12-17 11:31:33', 1),
(109, 'P00109', '3B0-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '33250.00', '33250.00', '0.00', '33250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:42:02', 'Admin', '2019-12-17 11:30:41', 1),
(110, 'P00110', '3B0-NXXX--Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '30450.00', '30450.00', '0.00', '30450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:42:30', 'Admin', '2019-12-17 11:29:13', 1),
(111, 'P00111', '3B0-CRXX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '29400.00', '29400.00', '0.00', '29400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:42:48', 'Admin', '2019-12-17 11:27:53', 1),
(112, 'P00112', '3B0-RXXX--Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '29400.00', '29400.00', '0.00', '29400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:43:09', 'Admin', '2019-12-17 11:27:11', 1),
(113, 'P00113', '3C3-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '33200.00', '33200.00', '0.00', '33200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:43:25', 'Admin', '2019-12-16 19:34:29', 1),
(114, 'P00114', '3D8-GDXX-0103-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '35600.00', '35600.00', '0.00', '35600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:43:42', 'Admin', '2019-12-16 19:33:55', 1),
(115, 'P00115', '3D8-GDEL-0103-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '36500.00', '36500.00', '0.00', '36500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:43:58', 'Admin', '2019-12-16 19:36:52', 1),
(116, 'P00116', '3D8-GDNE-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '36200.00', '36200.00', '0.00', '36200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:44:21', 'Admin', '2019-12-16 19:36:31', 1),
(117, 'P00117', '3D8-GDXX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '35600.00', '35600.00', '0.00', '35600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:44:42', 'Admin', '2019-12-16 19:36:51', 1),
(118, 'P00118', '3D8-NEXX-WDirect Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '33900.00', '33900.00', '0.00', '33900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:45:47', 'Admin', '2019-12-16 19:36:06', 1),
(119, 'P00119', '3D8-NEXX-0103-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '36200.00', '36200.00', '0.00', '36200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:46:21', 'Admin', '2019-12-16 19:34:04', 1),
(120, 'P00120', '3D8-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '36500.00', '36500.00', '0.00', '36500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:46:45', 'Admin', '2019-12-16 19:36:07', 1),
(121, 'P00121', '3E8-GDXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '36350.00', '36350.00', '0.00', '36350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:47:34', 'Admin', '2019-12-17 11:39:51', 1),
(122, 'P00122', '3E8-ELEX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '36250.00', '36250.00', '0.00', '36250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:48:17', 'Admin', '2019-12-17 11:39:17', 1),
(123, 'P00123', '3E8-ELNX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '35750.00', '35750.00', '0.00', '35750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:48:42', 'Admin', '2019-12-17 11:38:41', 1),
(124, 'P00124', '3E8-CRXX-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '33650.00', '33650.00', '0.00', '33650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:49:04', 'Admin', '2019-12-17 11:38:02', 1),
(125, 'P00125', '3F5-GDEL-XX-Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 0, '39900.00', '39900.00', '0.00', '39900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:49:31', 'Admin', '2019-12-16 20:20:35', 1),
(126, 'P00126', '3F5-GDEL-XX-Inverter Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '40900.00', '40900.00', '0.00', '40900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:49:57', 'Admin', '2019-12-16 20:20:54', 1),
(127, 'P00127', '3F5-GDXX-XX- Walton Direct Cool Refrigerator', 18, 0, 0, 'na', 0, 1, '37700.00', '37700.00', '0.00', '37700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:53:40', 'Admin', '2019-12-16 20:21:25', 1),
(128, 'P00128', '3F5-NEXX-XX- Inverter Walton Direct Cool Refrigeratorr', 22, 0, 0, 'na', 0, 0, '35300.00', '35300.00', '0.00', '35300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:53:56', 'Admin', '2019-12-16 20:15:56', 1),
(129, 'P00129', '3F5-NEXX-XX-Walton Direct Cool Refrigeratorr', 18, 0, 0, 'na', 0, 0, '34300.00', '34300.00', '0.00', '34300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:55:03', 'Admin', '2019-12-16 20:22:14', 1),
(130, 'P00130', 'WNM-1N5-RXXX-0102-RP Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '27200.00', '27200.00', '0.00', '27200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:55:22', 'Admin', '2019-12-16 20:24:44', 1),
(131, 'P00131', 'WNM-1N5-RXXX-RP Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '27200.00', '27200.00', '0.00', '27200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:56:11', 'Admin', '2019-12-16 20:24:09', 1),
(132, 'P00132', 'WNM-2A7-RXXX-RP Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '28500.00', '28500.00', '0.00', '28500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:56:25', 'Admin', '2019-12-16 20:25:22', 1),
(133, 'P00133', 'WNM-2A7-GDEL-XX- Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '30900.00', '30900.00', '0.00', '30900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:56:39', 'Admin', '2019-12-16 20:25:53', 1),
(134, 'P00134', 'WNC-3B3-NXXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '35500.00', '35500.00', '0.00', '35500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:56:51', 'Admin', '2019-12-16 20:26:42', 1),
(135, 'P00135', 'WNC-3B3-GDXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '36900.00', '36900.00', '0.00', '36900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:57:11', 'Admin', '2019-12-16 20:35:45', 1),
(136, 'P00136', 'WNH-3H6-GDEL-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '41500.00', '41500.00', '0.00', '41500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:57:32', 'Admin', '2019-12-16 20:34:52', 1),
(137, 'P00137', 'WNH-3H6-HDXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '38990.00', '38990.00', '0.00', '38990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:57:49', 'Admin', '2019-12-16 20:34:03', 1),
(138, 'P00138', 'WNH-3H6-HDDD-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '39990.00', '39990.00', '0.00', '39990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:58:08', 'Admin', '2019-12-16 20:32:52', 1),
(139, 'P00139', 'WNH-4C0-HDXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '46990.00', '46990.00', '0.00', '46990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:58:25', 'Admin', '2019-12-16 20:32:14', 1),
(140, 'P00140', 'WNH-4CO-RXXX-0102-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '45990.00', '45990.00', '0.00', '45990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:58:44', 'Admin', '2019-12-16 20:31:35', 1),
(141, 'P00141', 'WNH-4F7-RXXX-0101-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '47990.00', '47990.00', '0.00', '47990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:59:04', 'Admin', '2019-12-16 20:30:50', 1),
(142, 'P00142', 'WNJ-5A2-RXXX-0101-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '49200.00', '49200.00', '0.00', '49200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 19:59:42', 'Admin', '2019-12-16 20:29:43', 1),
(143, 'P00143', 'WNJ-5A2-RXXX-0102-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '49200.00', '49200.00', '0.00', '49200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:00:04', 'Admin', '2019-12-16 20:29:18', 1),
(144, 'P00144', 'WNJ-5B6-RXXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '51900.00', '51900.00', '0.00', '51900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:00:23', 'Admin', '2019-12-16 20:28:00', 1),
(145, 'P00145', 'WNJ-5B6-KPXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '54900.00', '54900.00', '0.00', '54900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:01:40', 'Admin', '2019-12-16 20:42:27', 1),
(146, 'P00146', 'WNL-5G5-RXXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '52900.00', '52900.00', '0.00', '52900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:02:58', 'Admin', '2019-12-16 20:41:51', 1),
(147, 'P00147', 'WNL-5G5-CDBX-010-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '52200.00', '52200.00', '0.00', '52200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:03:26', 'Admin', '2019-12-16 20:43:45', 1),
(148, 'P00148', 'WNJ-5E5-0101-(555LT) Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '52200.00', '52200.00', '0.00', '52200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:04:02', 'Admin', '2019-12-16 20:41:15', 1),
(149, 'P00149', 'WNI-5F3-RXXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '59900.00', '59900.00', '0.00', '59900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:04:31', 'Admin', '2019-12-16 20:40:37', 1),
(150, 'P00150', 'WNI-5F3-GDEL-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '64900.00', '64900.00', '0.00', '64900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:05:06', 'Admin', '2019-12-16 20:39:41', 1),
(151, 'P00151', 'WNI-5F3-GDEL-DD Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '69900.00', '69900.00', '0.00', '69900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:05:30', 'Admin', '2019-12-16 20:39:16', 1),
(152, 'P00152', 'WNJ-5H5-RXXX-0101-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '53500.00', '53500.00', '0.00', '53500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:06:04', 'Admin', '2019-12-16 20:38:46', 1),
(153, 'P00153', 'WNN-5N2-RXXX-XX Walton Non Frost Refrigerator', 19, 0, 0, 'na', 0, 0, '54500.00', '54500.00', '0.00', '54500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:07:09', 'Admin', '2019-12-16 20:38:17', 1),
(154, 'P00154', 'WCF-1D5-RXXX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '19450.00', '19450.00', '0.00', '19450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:07:57', 'Admin', '2019-12-16 20:37:27', 1),
(155, 'P00155', 'WCF-1D5-RRXX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 1, '19650.00', '19650.00', '0.00', '19650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:09:41', 'Admin', '2019-12-16 20:53:10', 1),
(156, 'P00156', 'WCF-1D5-GDEL-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '21950.00', '21950.00', '0.00', '21950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:10:35', 'Admin', '2019-12-16 20:52:01', 1),
(157, 'P00157', 'CF-1D5-GDEL-GX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '28200.00', '28200.00', '0.00', '28200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:10:58', 'Admin', '2019-12-17 11:43:42', 1),
(158, 'P00158', 'WCF-2T5-FHLX-GX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '25550.00', '25550.00', '0.00', '25550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:13:56', 'Admin', '2019-12-16 20:49:55', 1),
(159, 'P00159', 'WCF-2T5-RXXX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '24190.00', '24190.00', '0.00', '24190.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:14:32', 'Admin', '2019-12-16 20:49:07', 1),
(160, 'P00160', 'WCF-2T5-FHXX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '24290.00', '24290.00', '0.00', '24290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:14:57', 'Admin', '2019-12-16 20:48:20', 1),
(161, 'P00161', 'WCF-2T5-FHLX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '24490.00', '24490.00', '0.00', '24490.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:15:26', 'Admin', '2019-12-16 20:47:40', 1),
(162, 'P00162', 'WCF-2E5-EHLX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '27950.00', '27950.00', '0.00', '27950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:16:29', 'Admin', '2019-12-16 20:47:07', 1),
(163, 'P00163', 'WCG-2E5-RXLX-XX- Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '27550.00', '27550.00', '0.00', '27550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:17:21', 'Admin', '2019-12-16 20:46:37', 1),
(164, 'P00164', 'WCG-3J0-RXXX-XX Freezer (Deep)  Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '32290.00', '32290.00', '0.00', '32290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:17:55', 'Admin', '2019-12-16 20:45:21', 1),
(165, 'P00165', 'WCG-3J0-DDXX-XX Freezer (Deep)  Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '30900.00', '30900.00', '0.00', '30900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:18:26', 'Admin', '2019-12-17 11:50:58', 1),
(166, 'P00166', 'WCG-3J0-RXLX-XX Freezer (Deep)  Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '30700.00', '30700.00', '0.00', '30700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:19:37', 'Admin', '2019-12-17 11:49:32', 1),
(167, 'P00167', 'WCG-3J0-RXXX-GX Freezer (Deep) Walton_Freezer_Deep_Refrigerator', 20, 0, 0, 'na', 0, 0, '32290.00', '32290.00', '0.00', '32290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:20:00', 'Admin', '2019-12-17 11:46:01', 1),
(168, 'P00168', 'LNB (DUL) Akash Dth', 16, 0, 0, 'na', 0, 0, '428.00', '473.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-15 20:23:03', '', '', 2),
(169, 'P00169', 'W55E3000AS-Smart-1.397m Walton LED Television', 22, 0, 0, 'na', 0, 0, '69900.00', '69900.00', '0.00', '69900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:24:00', 'Admin', '2019-12-16 20:13:13', 1),
(170, 'P00170', 'LNB (QUAD) Akash Dth', 17, 0, 0, 'na', 0, 0, '865.00', '946.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-15 20:24:36', '', '', 2),
(171, 'P00171', 'WSD55FD-1.397m Walton LED Television', 22, 0, 0, 'na', 0, 0, '59900.00', '59900.00', '0.00', '59900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:24:47', 'Admin', '2019-12-16 20:11:38', 1),
(172, 'P00172', 'W49E3000AS-Smart-1.245m Walton LED Television', 22, 0, 0, 'na', 0, 0, '65900.00', '65900.00', '0.00', '65900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:25:28', 'Admin', '2019-12-16 20:11:11', 1),
(173, 'P00173', 'WSD49FD-1.245m Walton LED Television', 22, 0, 0, 'na', 0, 0, '49900.00', '49900.00', '0.00', '49900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:26:01', 'Admin', '2019-12-16 20:10:03', 1),
(174, 'P00174', 'WE4-MX43-SB100-HIL-1.09m Walton LED Television', 22, 0, 0, 'na', 0, 0, '42900.00', '42900.00', '0.00', '42900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:26:40', 'Admin', '2019-12-16 20:09:18', 1),
(175, 'P00175', 'WD4-TS43-KS220-HIL-1.09m Walton LED Television', 22, 0, 0, 'na', 0, 0, '34900.00', '34900.00', '0.00', '34900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:27:16', 'Admin', '2019-12-16 20:08:48', 1),
(176, 'P00176', 'WD4-TS43-DL220-Smart-HIL Walton LED Television', 22, 0, 0, 'na', 0, 0, '34900.00', '34900.00', '0.00', '34900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:28:02', 'Admin', '2019-12-16 20:08:20', 1),
(177, 'P00177', 'WD1-TS43-FV100-HIL-1.09m Walton LED Television', 22, 0, 0, 'na', 0, 0, '29900.00', '29900.00', '0.00', '29900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:30:37', 'Admin', '2019-12-16 20:07:34', 1),
(178, 'P00178', 'WD437TS25-HIL-1.09m Walton LED Television', 22, 0, 0, 'na', 0, 0, '29990.00', '29990.00', '0.00', '29990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:31:21', 'Admin', '2019-12-16 20:07:03', 1),
(179, 'P00179', 'WE396AFH-HIL LED Walton Television', 22, 0, 0, 'na', 0, 0, '25990.00', '25990.00', '0.00', '25990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:35:16', 'Admin', '2019-12-16 20:06:10', 1),
(180, 'P00180', 'WE396AFH-150-HIL Walon LED Television', 22, 0, 0, 'na', 0, 0, '25990.00', '25990.00', '0.00', '25990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:36:16', 'Admin', '2019-12-16 20:05:42', 1),
(181, 'P00181', 'WE-DH32V-Voice  Control HD Smart LED Walton LED Television', 22, 0, 0, 'na', 0, 0, '24990.00', '24990.00', '0.00', '24990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:38:50', 'Admin', '2019-12-16 20:05:02', 1),
(182, 'P00182', 'WE4-DH32-BY220-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '21900.00', '21900.00', '0.00', '21900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:39:34', 'Admin', '2019-12-16 20:04:26', 1),
(183, 'P00183', 'WE4-DH32-BX220-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '21900.00', '21900.00', '0.00', '21900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:40:02', 'Admin', '2019-12-16 20:04:01', 1),
(184, 'P00184', 'WD4-EF32-SV200-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '22800.00', '22800.00', '0.00', '22800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:40:37', 'Admin', '2019-12-16 20:02:53', 1),
(185, 'P00185', 'WD1-JX32-HN100-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:41:04', 'Admin', '2019-12-16 20:02:05', 1),
(186, 'P00186', 'WD1-JX32-EL100-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:42:20', 'Admin', '2019-12-16 20:01:47', 1),
(187, 'P00187', 'WD1-JX32-SY100-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:44:11', 'Admin', '2019-12-16 20:01:29', 1),
(188, 'P00188', 'WD1-JX32-BC100-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:45:29', 'Admin', '2019-12-16 20:00:50', 1),
(189, 'P00189', 'WD1-JX32-TS100-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:46:21', 'Admin', '2019-12-16 20:00:30', 1),
(190, 'P00190', 'WD1-JX32-TS200-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:47:05', 'Admin', '2019-12-16 20:00:07', 1),
(191, 'P00191', 'WD1-JX32-SY200-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:47:50', 'Admin', '2019-12-16 19:59:44', 1),
(192, 'P00192', 'WD1-JX32-BC200-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:48:30', 'Admin', '2019-12-16 19:59:22', 1),
(193, 'P00193', 'WD326JX-Silver/Black-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '18500.00', '18500.00', '0.00', '18500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:49:28', 'Admin', '2019-12-16 19:58:38', 1),
(194, 'P00194', 'W32Q19-Black-813mm Walton LED Television', 1, 0, 0, 'na', 0, 0, '17500.00', '17500.00', '0.00', '17500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:50:09', 'Admin', '2019-12-16 19:57:47', 1),
(195, 'P00195', 'WD1-JX32-TS150-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '17290.00', '17290.00', '0.00', '17290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:50:59', 'Admin', '2019-12-16 19:57:05', 1),
(196, 'P00196', 'WD1-JX32-TS250-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '17290.00', '17290.00', '0.00', '17290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:52:09', 'Admin', '2019-12-16 19:56:29', 1),
(197, 'P00197', 'W32Q20-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '16500.00', '16500.00', '0.00', '16500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:53:00', 'Admin', '2019-12-16 19:55:47', 1),
(198, 'P00198', 'WD1-JX32-SY150-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '16990.00', '16990.00', '0.00', '16990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:53:52', 'Admin', '2019-12-16 19:55:03', 1),
(199, 'P00199', 'WD1-JX32-SY250-HIL-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '16990.00', '16990.00', '0.00', '16990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:55:07', 'Admin', '2019-12-16 19:54:01', 1),
(200, 'P00200', 'WD326JX-150-813mm Waltone LED Television', 22, 0, 0, 'na', 0, 0, '16990.00', '16990.00', '0.00', '16990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:55:56', 'Admin', '2019-12-16 19:52:31', 1),
(201, 'P00201', 'WD1-JX32-SY250-HIL-813mm- Walton LED Television', 22, 0, 0, 'na', 0, 0, '16990.00', '16990.00', '0.00', '16990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:56:49', 'Admin', '2019-12-21 17:14:20', 1),
(202, 'P00202', 'WD326JX-150-813mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '16990.00', '16990.00', '0.00', '16990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:57:21', 'Admin', '2019-12-16 19:49:01', 1),
(203, 'P00203', 'WBD28FT6-HIL-711mm Walton LED Television', 1, 0, 0, 'na', 0, 0, '15500.00', '15500.00', '0.00', '15500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:58:06', 'Admin', '2019-12-16 19:48:10', 1),
(204, 'P00204', 'WD1-DT24-MC150-Silver/Black Walton LED Television', 22, 0, 0, 'na', 0, 0, '12990.00', '12990.00', '0.00', '12990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:58:54', 'Admin', '2019-12-16 19:46:51', 1),
(205, 'P00205', 'WD1-DT24-MC110-HIL-610mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '12990.00', '12990.00', '0.00', '12990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 20:59:46', 'Admin', '2019-12-16 19:46:27', 1),
(206, 'P00206', 'WD1-DT24-RL110-HIL-610mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '12500.00', '12500.00', '0.00', '12500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:01:06', 'Admin', '2019-12-16 19:45:52', 1),
(207, 'P00207', 'WD1-DT24-ML100-Silver/Black Walton LED Television', 22, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:01:46', 'Admin', '2019-12-16 13:37:46', 1),
(208, 'P00208', 'W24D19-610mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '11990.00', '11990.00', '0.00', '11990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:04:22', 'Admin', '2019-12-16 19:43:16', 1),
(209, 'P00209', 'WE1-BX20-RT200-BT Speaker Walton LED Television', 22, 0, 0, 'na', 0, 0, '10900.00', '10900.00', '0.00', '10900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:05:31', 'Admin', '2019-12-17 12:02:52', 1),
(210, 'P00210', 'WSE20BX6-Silver/Black-508mm Walton LED Television', 22, 0, 0, 'na', 0, 0, '10900.00', '10900.00', '0.00', '10900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:10:29', 'Admin', '2019-12-16 19:42:04', 1),
(211, 'P00211', 'Remote(WRC-02) Walton LED Television', 32, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:12:18', 'Admin', '2019-12-17 12:01:44', 1),
(212, 'P00212', 'WSN-Riverine-12A-1Ton Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '36900.00', '36900.00', '0.00', '36900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:16:32', 'Admin', '2019-12-17 11:59:41', 1),
(213, 'P00213', 'WSN 18K-ECXXA  Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '45900.00', '45900.00', '0.00', '45900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:17:29', 'Admin', '2019-12-17 11:58:53', 1),
(214, 'P00214', 'WSN-18K-RXXXA Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '45900.00', '45900.00', '0.00', '45900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:18:31', 'Admin', '2019-12-17 11:58:09', 1),
(215, 'P00215', 'WSN-RIVERINE-18A Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '49900.00', '49900.00', '0.00', '49900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:59:24', 'Admin', '2019-12-17 12:22:32', 1),
(216, 'P00216', 'WSN-VENTURI-18A Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '49900.00', '49900.00', '0.00', '49900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 21:59:42', 'Admin', '2019-12-17 12:21:36', 1),
(217, 'P00217', 'WSI-RIVERINE-18C Walton Air-Conditioner', 22, 0, 0, 'na', 0, 0, '63500.00', '63500.00', '0.00', '63500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 22:00:01', 'Admin', '2019-12-17 12:20:32', 1),
(218, 'P00218', 'WSI-VENTURI-18C Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '63500.00', '63500.00', '0.00', '63500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 22:00:15', 'Admin', '2019-12-17 12:20:03', 1),
(219, 'P00219', 'WSI-RIVERINE-18C-Smart Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '63500.00', '63500.00', '0.00', '63500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 22:00:28', 'Admin', '2019-12-17 12:16:56', 1),
(220, 'P00220', 'WSI-VENTURI-18C-Smart Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '63500.00', '63500.00', '0.00', '63500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 22:00:42', 'Admin', '2019-12-17 12:16:15', 1);
INSERT INTO `tbl_product` (`Product_SlNo`, `Product_Code`, `Product_Name`, `ProductCategory_ID`, `color`, `brand`, `size`, `vat`, `Product_ReOrederLevel`, `Product_Purchase_Rate`, `Product_SellingPrice`, `Product_MinimumSellingPrice`, `Product_WholesaleRate`, `one_cartun_equal`, `is_service`, `Unit_ID`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Product_branchid`) VALUES
(221, 'P00221', 'WSN-RIVERINE-24B Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '56900.00', '56900.00', '0.00', '56900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-15 22:01:00', 'Admin', '2019-12-17 12:15:18', 1),
(222, 'P00222', 'WSN-VENTURI-24B Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '56900.00', '56900.00', '0.00', '56900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:47:36', 'Admin', '2019-12-17 12:14:12', 1),
(223, 'P00223', 'WSI-RIVERINE-24C Wlton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '74900.00', '74900.00', '0.00', '74900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:48:43', 'Admin', '2019-12-17 12:10:26', 1),
(224, 'P00224', 'WSI-VENTURI-24C Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '74900.00', '74900.00', '0.00', '74900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:50:54', 'Admin', '2019-12-17 12:09:09', 1),
(225, 'P00225', 'WSI-RIVERINE-24C-Smart Walton Air-Conditioner', 23, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:51:12', 'Admin', '2019-12-16 13:42:24', 1),
(226, 'P00226', 'WSI-VENTURI-24C-Smart Walton Air-Conditioner', 23, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:51:34', 'Admin', '2019-12-16 13:42:33', 1),
(227, 'P00227', 'WFN-42K-RXXXD-Ceiling Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '141000.00', '141000.00', '0.00', '141000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:52:39', 'Admin', '2019-12-17 12:36:30', 1),
(228, 'P00228', 'WCN-42K-0101-RXXXD-Cassette WaltonAir-Conditioner', 23, 0, 0, 'na', 0, 0, '141000.00', '141000.00', '0.00', '141000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:52:55', 'Admin', '2019-12-17 12:35:20', 1),
(229, 'P00229', 'WFN-48K-RXXXD-Ceiling Type Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '141000.00', '141000.00', '0.00', '141000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:53:11', 'Admin', '2019-12-17 12:33:31', 1),
(230, 'P00230', 'WFN-52K-RXXXE-Ceiling Type Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '159000.00', '159000.00', '0.00', '159000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:53:28', 'Admin', '2019-12-17 12:32:46', 1),
(231, 'P00231', 'WCN-52K-0101-RXXXE-Cassette Type Walton Air-Conditioner', 1, 0, 0, 'na', 0, 0, '159000.00', '159000.00', '0.00', '159000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:53:48', 'Admin', '2019-12-17 12:31:21', 1),
(232, 'P00232', 'WCN-60K-RXXXE-Cassette Type Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '159000.00', '159000.00', '0.00', '159000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:54:05', 'Admin', '2019-12-17 12:30:30', 1),
(233, 'P00233', 'WFN-60K-RXXXE-Ceiling Type Walton Air-Conditioner', 23, 0, 0, 'na', 0, 0, '159000.00', '159000.00', '0.00', '159000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:54:26', 'Admin', '2019-12-17 12:25:42', 1),
(234, 'P00234', 'Venture & Riverine Walton Golden Color', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:54:49', '', '', 1),
(235, 'P00235', 'WEA-K30T Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '16000.00', '16000.00', '0.00', '16000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:55:07', 'Abdul Mobin Hero', '2019-12-22 16:17:01', 1),
(236, 'P00236', 'WEA-S100 Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '14000.00', '14000.00', '0.00', '14000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:55:25', 'Abdul Mobin Hero', '2019-12-22 16:16:41', 1),
(237, 'P00237', 'WEA-W18R Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '14000.00', '14000.00', '0.00', '14000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:55:51', 'Abdul Mobin Hero', '2019-12-22 16:16:12', 1),
(238, 'P00238', 'WEA-J120C Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '12000.00', '12000.00', '0.00', '12000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:56:19', 'Abdul Mobin Hero', '2019-12-22 16:13:58', 1),
(239, 'P00239', 'WEA-D198R Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '10000.00', '10000.00', '0.00', '10000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:56:58', 'Abdul Mobin Hero', '2019-12-22 16:13:23', 1),
(240, 'P00240', 'WRA-1181 Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '7900.00', '7900.00', '0.00', '7900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:58:10', 'Abdul Mobin Hero', '2019-12-22 16:12:22', 1),
(241, 'P00241', 'WEA-B128R Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '7800.00', '7800.00', '0.00', '7800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:58:36', 'Abdul Mobin Hero', '2019-12-22 15:34:14', 1),
(242, 'P00242', 'WAC-EC80-MTC Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '7800.00', '7800.00', '0.00', '7800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:58:57', 'Abdul Mobin Hero', '2019-12-22 15:32:15', 1),
(243, 'P00243', 'WEA-V28R Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '6500.00', '6500.00', '0.00', '6500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:59:12', 'Abdul Mobin Hero', '2019-12-22 15:29:44', 1),
(244, 'P00244', 'WEA-B168M Walton Air-Cooler', 26, 0, 0, 'na', 0, 0, '5500.00', '5500.00', '0.00', '5500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:59:32', 'Abdul Mobin Hero', '2019-12-22 15:26:21', 1),
(245, 'P00245', 'WRH-PTC202-Walton Room Heatar', 27, 0, 0, 'na', 0, 0, '3500.00', '3500.00', '0.00', '3500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 09:59:49', 'Abdul Mobin Hero', '2019-12-22 16:22:34', 1),
(246, 'P00246', 'WRH-PTC004-Walton Room Heatar', 27, 0, 0, 'na', 0, 0, '2800.00', '2800.00', '0.00', '2800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:00:06', 'Abdul Mobin Hero', '2019-12-22 16:21:49', 1),
(247, 'P00247', 'WRH-PTC003-Walton Room', 27, 0, 0, 'na', 0, 0, '2750.00', '2750.00', '0.00', '2750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:00:21', 'Admin', '2019-12-23 19:50:15', 1),
(248, 'P00248', 'WRH-PTC002-Walton Room Heatar', 27, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:00:38', 'Abdul Mobin Hero', '2019-12-22 16:24:07', 1),
(249, 'P00249', 'WRH-PTC001-Walton Room Heatar', 27, 0, 0, 'na', 0, 0, '2450.00', '2450.00', '0.00', '2450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:00:53', 'Abdul Mobin Hero', '2019-12-22 16:20:18', 1),
(250, 'P00250', 'WRH-PTC009-Walton Room Heatar', 27, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:01:16', 'Abdul Mobin Hero', '2019-12-22 16:19:47', 1),
(251, 'P00251', 'WRm-FH01-Walton Room Heatar', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:01:30', '', '', 1),
(252, 'P00252', 'WRH-PTC007-Walton Room Heatar', 27, 0, 0, 'na', 0, 0, '1490.00', '1490.00', '0.00', '1490.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:01:46', 'Abdul Mobin Hero', '2019-12-22 16:19:07', 1),
(253, 'P00253', 'WWM-AFM90-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '45500.00', '45500.00', '0.00', '45500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:01:58', 'Abdul Mobin Hero', '2019-12-21 17:09:14', 1),
(254, 'P00254', 'WWM-S80F Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '45000.00', '45000.00', '0.00', '45000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:02:14', 'Abdul Mobin Hero', '2019-12-21 17:08:10', 1),
(255, 'P00255', 'WWM-AFM70-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '35000.00', '35000.00', '0.00', '35000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:02:32', 'Abdul Mobin Hero', '2019-12-20 13:01:41', 1),
(256, 'P00256', 'WWM-S70F Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '34000.00', '34000.00', '0.00', '34000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:03:29', 'Abdul Mobin Hero', '2019-12-21 17:06:44', 1),
(257, 'P00257', 'WWM-S60F Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '29500.00', '29500.00', '0.00', '29500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:04:10', 'Abdul Mobin Hero', '2019-12-21 17:06:08', 1),
(258, 'P00258', 'WWM-K125 Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '29500.00', '29500.00', '0.00', '29500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:04:43', 'Abdul Mobin Hero', '2019-12-21 17:04:03', 1),
(259, 'P00259', 'WWM-AFM60-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '28000.00', '28000.00', '0.00', '28000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:05:13', 'Abdul Mobin Hero', '2019-12-20 13:00:55', 1),
(260, 'P00260', 'WWM-Q80(HIL) Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '25500.00', '25500.00', '0.00', '25500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:05:42', 'Abdul Mobin Hero', '2019-12-21 17:03:17', 1),
(261, 'P00261', 'WWM-Q70(HIL) Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '24500.00', '24500.00', '0.00', '24500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:06:18', 'Abdul Mobin Hero', '2019-12-21 17:02:29', 1),
(262, 'P00262', 'WWM-X70 Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '23500.00', '23500.00', '0.00', '23500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:08:33', 'Abdul Mobin Hero', '2019-12-21 17:01:52', 1),
(263, 'P00263', 'WWM-X75 Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '22500.00', '22500.00', '0.00', '22500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:09:04', 'Abdul Mobin Hero', '2019-12-21 17:00:48', 1),
(264, 'P00264', 'WWM-Q60-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '22000.00', '22000.00', '0.00', '22000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:09:38', 'Abdul Mobin Hero', '2019-12-20 12:54:39', 1),
(265, 'P00265', 'WWM-X75 -Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '22500.00', '22500.00', '0.00', '22500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:10:04', 'Abdul Mobin Hero', '2019-12-21 16:59:43', 1),
(266, 'P00266', 'WWM-TU95S-MTC Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '14999.00', '14999.00', '0.00', '14999.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:10:32', 'Abdul Mobin Hero', '2019-12-21 16:59:02', 1),
(267, 'P00267', 'WWM-SK65S Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '14000.00', '14000.00', '0.00', '14000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:10:56', 'Abdul Mobin Hero', '2019-12-21 16:58:15', 1),
(268, 'P00268', 'WWM-KS90S-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '14000.00', '14000.00', '0.00', '14000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:11:18', 'Abdul Mobin Hero', '2019-12-20 13:04:08', 1),
(269, 'P00269', 'WWM-STP80-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '13500.00', '13500.00', '0.00', '13500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:11:40', 'Abdul Mobin Hero', '2019-12-21 16:57:40', 1),
(270, 'P00270', 'WWM-TU75S-HIL Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '13000.00', '13000.00', '0.00', '13000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:12:01', 'Abdul Mobin Hero', '2019-12-21 16:56:55', 1),
(271, 'P00271', 'WWM-KS60S-MTC Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '10000.00', '10000.00', '0.00', '10000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:12:23', 'Abdul Mobin Hero', '2019-12-21 16:56:18', 1),
(272, 'P00272', 'WWM-SWP60 Walton Washing Machine', 24, 0, 0, 'na', 0, 0, '7500.00', '7500.00', '0.00', '7500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:12:45', 'Abdul Mobin Hero', '2019-12-21 16:55:39', 1),
(273, 'P00273', 'WSM-AK01  Walton Sandwich Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:13:41', '', '', 1),
(274, 'P00274', 'Proton-900 Walton Generator', 25, 0, 0, 'na', 0, 0, '15000.00', '15000.00', '0.00', '15000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:14:27', 'Abdul Mobin Hero', '2019-12-22 15:17:52', 1),
(275, 'P00275', 'Optima 1000i(1KW)-Inverte Walton Generator', 25, 0, 0, 'na', 0, 0, '29900.00', '29900.00', '0.00', '29900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:15:12', 'Abdul Mobin Hero', '2019-12-22 15:16:52', 1),
(276, 'P00276', 'Zoom-1200-Gasoline Walton Generator', 25, 0, 0, 'na', 0, 0, '17100.00', '17100.00', '0.00', '17100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:15:47', 'Abdul Mobin Hero', '2019-12-22 15:16:08', 1),
(277, 'P00277', 'Impulse-1200 Walton Generator', 25, 0, 0, 'na', 0, 0, '17500.00', '17500.00', '0.00', '17500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:16:19', 'Abdul Mobin Hero', '2019-12-22 15:15:22', 1),
(278, 'P00278', 'Smart Power Plus-1500 Walton Generator', 25, 0, 0, 'na', 0, 0, '23000.00', '23000.00', '0.00', '23000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:17:21', 'Abdul Mobin Hero', '2019-12-22 15:14:25', 1),
(279, 'P00279', 'Smart Power Plus-1500E Walton Generator', 25, 0, 0, 'na', 0, 0, '28000.00', '28000.00', '0.00', '28000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:18:32', 'Abdul Mobin Hero', '2019-12-22 15:13:32', 1),
(280, 'P00280', 'Excel-2200-DM Walton Generator', 25, 0, 0, 'na', 0, 0, '22000.00', '22000.00', '0.00', '22000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:19:22', 'Abdul Mobin Hero', '2019-12-22 15:12:43', 1),
(281, 'P00281', 'Excel-2200E-DM Walton Generator', 25, 0, 0, 'na', 0, 0, '28000.00', '28000.00', '0.00', '28000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:20:06', 'Abdul Mobin Hero', '2019-12-22 15:11:58', 1),
(282, 'P00282', 'Excel Smart-2200 Walton Generator', 25, 0, 0, 'na', 0, 0, '25000.00', '25000.00', '0.00', '25000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:20:36', 'Abdul Mobin Hero', '2019-12-22 15:08:33', 1),
(283, 'P00283', 'Power Max-3600  Walton Generator', 25, 0, 0, 'na', 0, 0, '39000.00', '39000.00', '0.00', '39000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:21:06', 'Abdul Mobin Hero', '2019-12-22 15:06:42', 1),
(284, 'P00284', 'Power Max-3600 Walton Generator', 25, 0, 0, 'na', 0, 0, '39000.00', '39000.00', '0.00', '39000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:21:45', 'Abdul Mobin Hero', '2019-12-22 15:06:21', 1),
(285, 'P00285', 'Power Max-3600E  Walton Generator', 25, 0, 0, 'na', 0, 0, '47000.00', '47000.00', '0.00', '47000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:22:26', 'Abdul Mobin Hero', '2019-12-22 15:05:24', 1),
(286, 'P00286', 'Sparks-4500 Walton Generator', 25, 0, 0, 'na', 0, 0, '45000.00', '45000.00', '0.00', '45000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:23:05', 'Abdul Mobin Hero', '2019-12-22 15:04:49', 1),
(287, 'P00287', 'Sparks-4500E  Walton Generator', 25, 0, 0, 'na', 0, 0, '49000.00', '49000.00', '0.00', '49000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:23:33', 'Abdul Mobin Hero', '2019-12-22 15:04:23', 1),
(288, 'P00288', 'Silent Katrina-5500E-Diesel Walton Generator', 25, 0, 0, 'na', 0, 0, '90000.00', '90000.00', '0.00', '90000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:24:02', 'Abdul Mobin Hero', '2019-12-22 15:03:11', 1),
(289, 'P00289', 'Superia-6000 Walton Generator', 25, 0, 0, 'na', 0, 0, '43500.00', '43500.00', '0.00', '43500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:24:29', 'Abdul Mobin Hero', '2019-12-22 15:02:33', 1),
(290, 'P00290', 'Superia-6000E Walton Generator', 25, 0, 0, 'na', 0, 0, '51000.00', '51000.00', '0.00', '51000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:24:55', 'Abdul Mobin Hero', '2019-12-22 15:01:49', 1),
(291, 'P00291', 'Igniter-5500E-Gasoline Walton Generator', 25, 0, 0, 'na', 0, 0, '50000.00', '50000.00', '0.00', '50000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:25:26', 'Abdul Mobin Hero', '2019-12-22 15:01:12', 1),
(292, 'P00292', 'Megatron-7000E(6 KW) Walton Generator', 25, 0, 0, 'na', 0, 0, '55000.00', '55000.00', '0.00', '55000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:26:07', 'Abdul Mobin Hero', '2019-12-22 14:59:58', 1),
(293, 'P00293', 'Power Craft-8000E(7.5 KE) Walton Generator', 25, 0, 0, 'na', 0, 0, '54000.00', '54000.00', '0.00', '54000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:26:38', 'Abdul Mobin Hero', '2019-12-22 14:59:26', 1),
(294, 'P00294', 'Power Carft-8000E  Walton Generator', 25, 0, 0, 'na', 0, 0, '58000.00', '58000.00', '0.00', '58000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:27:03', 'Abdul Mobin Hero', '2019-12-22 14:58:59', 1),
(295, 'P00295', 'Booster-8000E Walton Generator', 25, 0, 0, 'na', 0, 0, '60000.00', '60000.00', '0.00', '60000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:28:17', 'Abdul Mobin Hero', '2019-12-22 14:58:12', 1),
(296, 'P00296', 'WGS-PCHB2-HIL Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '7500.00', '7500.00', '0.00', '7500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:38:02', 'Abdul Mobin Hero', '2019-12-22 16:27:16', 1),
(297, 'P00297', 'WGS-PCHB1-HIL Gas Stove (NG & LPG) ', 31, 0, 0, 'na', 0, 0, '7000.00', '7000.00', '0.00', '7000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:38:57', 'Abdul Mobin Hero', '2019-12-22 16:28:11', 1),
(298, 'P00298', 'WGS-AT299(Glass Top) Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '5900.00', '5900.00', '0.00', '5900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:39:50', 'Abdul Mobin Hero', '2019-12-22 16:27:57', 1),
(299, 'P00299', 'WGS-3GNS1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '4300.00', '4300.00', '0.00', '4300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:40:37', 'Abdul Mobin Hero', '2019-12-20 14:53:16', 1),
(300, 'P00300', 'WGS-GNSB1 (MTC) Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '4100.00', '4100.00', '0.00', '4100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:41:07', 'Admin', '2019-12-16 16:45:26', 1),
(301, 'P00301', 'WGS-GS1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '4000.00', '4000.00', '0.00', '4000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:41:45', 'Abdul Mobin Hero', '2019-12-22 16:27:39', 1),
(302, 'P00302', 'WGS-GS2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3950.00', '3950.00', '0.00', '3950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:43:23', 'Abdul Mobin Hero', '2019-12-22 16:27:29', 1),
(303, 'P00303', 'WGS-GNS1 Gas Stove  (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3990.00', '3990.00', '0.00', '3990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:43:59', 'Admin', '2019-12-16 11:30:05', 1),
(304, 'P00304', 'WGS-GNS2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3850.00', '3850.00', '0.00', '3850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:44:29', 'Admin', '2019-12-16 11:31:44', 1),
(305, 'P00305', 'WGS-GSC1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3550.00', '3550.00', '0.00', '3550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:44:59', 'Admin', '2019-12-16 17:50:00', 1),
(306, 'P00306', 'WGS-GSC2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3500.00', '3500.00', '0.00', '3500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:45:26', 'Admin', '2019-12-16 11:35:34', 1),
(307, 'P00307', 'WGS-NSB1501 (MTC) Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3500.00', '3500.00', '0.00', '3500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:45:51', 'Admin', '2019-12-16 11:35:20', 1),
(308, 'P00308', 'WGS-GHT1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3300.00', '3300.00', '0.00', '3300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:46:23', 'Admin', '2019-12-16 11:37:14', 1),
(309, 'P00309', 'WGS-GH2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3300.00', '3300.00', '0.00', '3300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:47:09', 'Admin', '2019-12-16 11:38:35', 1),
(310, 'P00310', 'WGS-GSHC1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3200.00', '3200.00', '0.00', '3200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:47:36', 'Admin', '2019-12-16 11:59:26', 1),
(311, 'P00311', 'WGS-NSC1501-MTC Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3100.00', '3100.00', '0.00', '3100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:48:04', 'Admin', '2019-12-16 12:01:18', 1),
(312, 'P00312', 'WGS-DSB2-Stainless Steel Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3000.00', '3000.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:48:41', 'Admin', '2019-12-16 12:04:53', 1),
(313, 'P00313', 'WGS-DSB1-Stainless Steel Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3000.00', '3000.00', '0.00', '3000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:49:05', 'Admin', '2019-12-16 12:06:04', 1),
(314, 'P00314', 'WGS-DSC1-Stainless Steel Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2400.00', '2400.00', '0.00', '2400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:49:30', 'Admin', '2019-12-16 12:07:44', 1),
(315, 'P00315', 'WGS-SGNS1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2200.00', '2200.00', '0.00', '2200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:49:57', 'Admin', '2019-12-16 12:11:03', 1),
(316, 'P00316', 'WGS-DSH2-Stainless Steel Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:50:22', 'Admin', '2019-12-16 12:11:54', 1),
(317, 'P00317', 'WGS-SGH2-Stainless Steel (MTC) Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:50:51', 'Admin', '2019-12-16 12:12:59', 1),
(318, 'P00318', 'WGS-SGH1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2050.00', '2050.00', '0.00', '2050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:51:16', 'Admin', '2019-12-16 12:14:14', 1),
(319, 'P00319', 'WGS-SGC1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2000.00', '2000.00', '0.00', '2000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:51:34', 'Admin', '2019-12-16 12:16:06', 1),
(320, 'P00320', 'WGS-DSH1-Stainless Steel Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2000.00', '2000.00', '0.00', '2000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:51:49', 'Admin', '2019-12-16 12:17:07', 1),
(321, 'P00321', 'WGS-SB1701S-LPG (MTC) Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1990.00', '1990.00', '0.00', '1990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:52:04', 'Admin', '2019-12-16 12:18:30', 1),
(322, 'P00322', 'WGS-SC1701S-LPG (MTC) Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1800.00', '1800.00', '0.00', '1800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:54:00', 'Admin', '2019-12-16 12:20:36', 1),
(323, 'P00323', 'WGS-AT150-LPG  Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1980.00', '1980.00', '0.00', '1980.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:54:32', 'Admin', '2019-12-16 12:21:33', 1),
(324, 'P00324', 'WGS-AT100-LPG-Cast Iron Burner Cover  Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1750.00', '1750.00', '0.00', '7510.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:54:49', 'Admin', '2019-12-16 12:22:38', 1),
(325, 'P00325', 'WGS-SSB2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1600.00', '1600.00', '0.00', '1600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:55:28', 'Admin', '2019-12-16 12:24:56', 1),
(326, 'P00326', 'WGS-SSB1-LPG Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1600.00', '1600.00', '0.00', '1600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:55:46', 'Admin', '2019-12-16 12:26:03', 1),
(327, 'P00327', 'WGS-SSC2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:57:10', 'Admin', '2019-12-16 12:26:42', 1),
(328, 'P00328', 'WGS-SSC1-LPG Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:57:29', 'Admin', '2019-12-16 12:29:41', 1),
(329, 'P00329', 'WGS-SCE1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1350.00', '1350.00', '0.00', '1350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:57:47', 'Admin', '2019-12-16 12:30:39', 1),
(330, 'P00330', 'WGS-SSH2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1200.00', '1200.00', '0.00', '1200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:58:30', 'Admin', '2019-12-16 12:31:12', 1),
(331, 'P00331', 'WGS-SSH1 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '1100.00', '1100.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:58:53', 'Abdul Mobin Hero', '2019-12-20 14:52:14', 1),
(332, 'P00332', 'WMB-H05 Mosquito Bat', 41, 0, 0, 'na', 0, 0, '450.00', '450.00', '0.00', '450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:59:18', 'Admin', '2019-12-16 12:38:44', 1),
(333, 'P00333', 'WMB-K01 Mosquito Bat', 41, 0, 0, 'na', 0, 0, '590.00', '590.00', '0.00', '590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 10:59:35', 'Admin', '2019-12-16 19:17:16', 1),
(334, 'P00334', 'WMB-K03 Mosquito Bat', 41, 0, 0, 'na', 0, 0, '640.00', '640.00', '0.00', '640.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:00:04', 'Admin', '2019-12-16 12:41:38', 1),
(335, 'P00335', 'WD4-W55E3000AS-Smart', 22, 0, 0, 'na', 0, 0, '69900.00', '69900.00', '0.00', '69900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:01:16', 'Admin', '2019-12-16 19:39:30', 1),
(336, 'P00336', 'Thunder-8500E Walton Generator', 25, 0, 0, 'na', 0, 0, '65000.00', '65000.00', '0.00', '65000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:05:03', 'Abdul Mobin Hero', '2019-12-22 14:57:05', 1),
(337, 'P00337', 'Robust D6500E(6.5 KW)-Di Walton Generator', 25, 0, 0, 'na', 0, 0, '99000.00', '99000.00', '0.00', '99000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:05:23', 'Abdul Mobin Hero', '2019-12-22 14:56:13', 1),
(338, 'P00338', 'WMWO-M28EC3-Grill Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '19500.00', '19500.00', '0.00', '19500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:08:54', 'Abdul Mobin Hero', '2019-12-22 16:41:55', 1),
(339, 'P00339', 'WMWO-M30AS3-HIL Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '16000.00', '16000.00', '0.00', '16000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:09:16', 'Abdul Mobin Hero', '2019-12-22 16:41:31', 1),
(340, 'P00340', 'WG-30ESLR Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '16500.00', '16500.00', '0.00', '16500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:09:37', 'Abdul Mobin Hero', '2019-12-22 16:40:47', 1),
(341, 'P00341', 'WMWO-M26EBL-Grill Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '13900.00', '13900.00', '0.00', '13900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:09:59', 'Abdul Mobin Hero', '2019-12-22 16:40:17', 1),
(342, 'P00342', 'WMWO-M30AHY-Grill Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '13500.00', '13500.00', '0.00', '13500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:10:18', 'Abdul Mobin Hero', '2019-12-22 16:39:25', 1),
(343, 'P00343', 'WMWO-M28EGN Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '14000.00', '14000.00', '0.00', '14000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:10:39', 'Abdul Mobin Hero', '2019-12-22 16:39:01', 1),
(344, 'P00344', 'WMWO-G25G3 Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '13500.00', '13500.00', '0.00', '13500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:10:58', 'Abdul Mobin Hero', '2019-12-22 16:38:19', 1),
(345, 'P00345', 'WMWO-X25CP Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '13000.00', '13000.00', '0.00', '13000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:11:26', 'Abdul Mobin Hero', '2019-12-22 16:37:53', 1),
(346, 'P00346', 'WG23-CGD Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '12500.00', '12500.00', '0.00', '12500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:11:48', 'Abdul Mobin Hero', '2019-12-22 16:36:56', 1),
(347, 'P00347', 'WMWO-G23ZW Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '12000.00', '12000.00', '0.00', '12000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:12:16', 'Abdul Mobin Hero', '2019-12-22 16:36:28', 1),
(348, 'P00348', 'WMWO-M23AKV-Grill Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '10700.00', '10700.00', '0.00', '10700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:12:47', 'Abdul Mobin Hero', '2019-12-22 16:35:43', 1),
(349, 'P00349', 'WMWO-G20XC Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '10000.00', '10000.00', '0.00', '10000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:13:13', 'Abdul Mobin Hero', '2019-12-22 16:35:13', 1),
(350, 'P00350', 'WMWO-25ETX Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '10000.00', '10000.00', '0.00', '10000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:13:43', 'Abdul Mobin Hero', '2019-12-22 16:34:37', 1),
(351, 'P00351', 'WMWO-W23MX Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '9990.00', '9990.00', '0.00', '9990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:14:12', 'Abdul Mobin Hero', '2019-12-22 16:34:00', 1),
(352, 'P00352', 'WMWO-G20MXC Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '9500.00', '9500.00', '0.00', '9500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:14:40', 'Abdul Mobin Hero', '2019-12-22 16:32:34', 1),
(353, 'P00353', 'WG20-GL Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '8650.00', '8650.00', '0.00', '8650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:15:10', 'Abdul Mobin Hero', '2019-12-22 16:31:52', 1),
(354, 'P00354', 'WG17AL-DI Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '8100.00', '8100.00', '0.00', '8100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:15:43', 'Abdul Mobin Hero', '2019-12-22 16:31:10', 1),
(355, 'P00355', 'WMWO-X20MXP Walton Microwave Oven', 30, 0, 0, 'na', 0, 0, '8000.00', '8000.00', '0.00', '8000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:16:09', 'Abdul Mobin Hero', '2019-12-22 16:30:24', 1),
(356, 'P00356', 'WEO-HL28B(28Lt) Walton Electric Oven', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:16:28', '', '', 1),
(357, 'P00357', 'WEO-TY28L(28Lt) Walton Electric Oven', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:16:45', '', '', 1),
(358, 'P00358', 'WEO-GR26CGL(26Lt) Walton Electric Oven', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:17:05', '', '', 1),
(359, 'P00359', 'WEO-HL23RL Walton Electric Oven', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:17:22', '', '', 1),
(360, 'P00360', 'WEO-TY23L(23Lt) Walton Electric Oven', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:17:44', '', '', 1),
(361, 'P00361', 'WIR-SSI 01(Stand Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '6800.00', '6800.00', '0.00', '6800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:18:01', 'Abdul Mobin Hero', '2019-12-21 16:00:49', 1),
(362, 'P00362', 'WIR-SC01(Cordless Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1800.00', '1800.00', '0.00', '1800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:18:20', 'Abdul Mobin Hero', '2019-12-21 16:00:13', 1),
(363, 'P00363', 'WIR-S07(Steam) Walton Steam Iron', 34, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:18:55', 'Abdul Mobin Hero', '2019-12-21 15:59:42', 1),
(364, 'P00364', 'WIR-S08(Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1550.00', '1550.00', '0.00', '1550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:19:20', 'Abdul Mobin Hero', '2019-12-21 15:59:17', 1),
(365, 'P00365', 'WIR-SC02(Cordless Steam)  Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1400.00', '1400.00', '0.00', '1400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:19:40', 'Abdul Mobin Hero', '2019-12-21 15:58:46', 1),
(366, 'P00366', 'WIR-S02(Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1380.00', '1380.00', '0.00', '1380.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:20:15', 'Abdul Mobin Hero', '2019-12-21 11:22:43', 1),
(367, 'P00367', 'WIR-HD03-Heavy  Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:20:38', 'Abdul Mobin Hero', '2019-12-21 11:21:09', 1),
(368, 'P00368', 'WIR-S05(Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1320.00', '1320.00', '0.00', '1320.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:20:59', 'Abdul Mobin Hero', '2019-12-21 11:09:50', 1),
(369, 'P00369', 'WIR-S01(Steam)  Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1220.00', '1220.00', '0.00', '1220.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:21:15', 'Abdul Mobin Hero', '2019-12-21 11:09:37', 1),
(370, 'P00370', 'WIR-S06(Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1220.00', '1220.00', '0.00', '1220.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:21:29', 'Abdul Mobin Hero', '2019-12-21 11:09:16', 1),
(371, 'P00371', 'WIR-S04(Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1220.00', '1220.00', '0.00', '1220.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:21:51', 'Abdul Mobin Hero', '2019-12-21 11:08:37', 1),
(372, 'P00372', 'WIR-S03(Steam) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1050.00', '1050.00', '0.00', '1050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:22:07', 'Abdul Mobin Hero', '2019-12-21 11:08:19', 1),
(373, 'P00373', 'WIR-HD01(Dry)-Heavy Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1290.00', '1290.00', '0.00', '1290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:22:28', 'Abdul Mobin Hero', '2019-12-21 11:08:02', 1),
(374, 'P00374', 'WIR-HD02(Dri)-Heavy Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1320.00', '1320.00', '0.00', '1320.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:23:29', 'Abdul Mobin Hero', '2019-12-21 11:07:42', 1),
(375, 'P00375', 'WIR-S10 Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1100.00', '1100.00', '0.00', '1100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:23:50', 'Abdul Mobin Hero', '2019-12-21 11:07:29', 1),
(376, 'P00376', 'WIR-D08(Dry)  Walton  iron', 34, 0, 0, 'na', 0, 0, '1150.00', '1150.00', '0.00', '1150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:24:05', 'Abdul Mobin Hero', '2019-12-21 11:07:02', 1),
(377, 'P00377', 'WIR-D07(Dry)  Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1100.00', '1100.00', '0.00', '1100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:24:23', 'Abdul Mobin Hero', '2019-12-21 11:06:52', 1),
(378, 'P00378', 'WIR-D06(Dry) Walton Steam iron', 34, 0, 0, 'na', 0, 0, '1000.00', '1000.00', '0.00', '1000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:24:47', 'Abdul Mobin Hero', '2019-12-21 11:20:39', 1),
(379, 'P00379', 'WIR-D03 (Dry)  Walton iron', 34, 0, 0, 'na', 0, 0, '860.00', '860.00', '0.00', '860.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:25:06', 'Abdul Mobin Hero', '2019-12-21 11:20:17', 1),
(380, 'P00380', 'WIR-S09(Steam)-HIL Walton iron', 34, 0, 0, 'na', 0, 0, '800.00', '800.00', '0.00', '800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:25:25', 'Abdul Mobin Hero', '2019-12-21 11:19:22', 1),
(381, 'P00381', 'WIR-D04(Dry)   Walton iron', 34, 0, 0, 'na', 0, 0, '780.00', '780.00', '0.00', '780.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:25:47', 'Abdul Mobin Hero', '2019-12-21 11:19:02', 1),
(382, 'P00382', 'WIR-D01A(Dry)-MTC  Walton iron', 34, 0, 0, 'na', 0, 0, '750.00', '750.00', '0.00', '750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:26:07', 'Abdul Mobin Hero', '2019-12-21 11:18:28', 1),
(383, 'P00383', 'WIR-D05(Dry)-MTC Walton iron', 34, 0, 0, 'na', 0, 0, '730.00', '730.00', '0.00', '730.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:26:21', 'Abdul Mobin Hero', '2019-12-21 11:17:57', 1),
(384, 'P00384', 'WIR-SC03  Steam Iron  WALTON-D05(Dry)-MTC Walton iron', 34, 0, 0, 'na', 0, 0, '1050.00', '1050.00', '0.00', '1050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:26:58', 'Abdul Mobin Hero', '2019-12-21 11:13:47', 1),
(385, 'P00385', 'WIR-S03 Steam Iron WALTON', 34, 0, 0, 'na', 0, 0, '1050.00', '1050.00', '0.00', '1050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:27:16', 'Abdul Mobin Hero', '2019-12-21 11:10:42', 1),
(386, 'P00386', 'WELB-RB02 Electric Lunch Box', 35, 0, 0, 'na', 0, 0, '590.00', '590.00', '0.00', '590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:27:32', 'Abdul Mobin Hero', '2019-12-22 17:13:59', 1),
(387, 'P00387', 'WELB-VB10 Electric Lunch Box', 1, 0, 0, 'na', 0, 0, '600.00', '600.00', '0.00', '600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:27:49', 'Admin', '2019-12-16 17:04:57', 1),
(388, 'P00388', 'WELB-V121 Electric Lunch Box', 35, 0, 0, 'na', 0, 0, '750.00', '750.00', '0.00', '750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:28:14', 'Abdul Mobin Hero', '2019-12-22 17:12:47', 1),
(389, 'P00389', 'WELB-V959 Electric Lunch Box', 35, 0, 0, 'na', 0, 0, '900.00', '900.00', '0.00', '900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:28:31', 'Abdul Mobin Hero', '2019-12-22 17:12:03', 1),
(390, 'P00390', 'RACY-S2200  Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '4200.00', '4200.00', '0.00', '4200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:29:11', 'Abdul Mobin Hero', '2019-12-21 17:13:16', 1),
(391, 'P00391', 'WVS-2000SD  Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '4000.00', '4000.00', '0.00', '4000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:29:32', 'Abdul Mobin Hero', '2019-12-20 12:35:38', 1),
(392, 'P00392', 'Supreme-2100JV80V   Auto Voltage Stabilizer', 1, 0, 0, 'na', 0, 0, '3550.00', '3550.00', '0.00', '3550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:29:51', 'Admin', '2019-12-16 16:50:52', 1),
(393, 'P00393', 'Supreme-2100JV   Auto Voltage Stabilizer', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:30:09', '', '', 1),
(394, 'P00394', 'WVS-K2000HDR Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '3300.00', '3300.00', '0.00', '3300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:30:29', 'Abdul Mobin Hero', '2019-12-20 12:33:59', 1),
(395, 'P00395', 'WVS-1000HSD  Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '3300.00', '3300.00', '0.00', '3300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:30:49', 'Abdul Mobin Hero', '2019-12-20 12:33:22', 1),
(396, 'P00396', 'WVS-1000SDR80V  Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '3200.00', '3200.00', '0.00', '3200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:31:03', 'Abdul Mobin Hero', '2019-12-20 12:32:52', 1),
(397, 'P00397', 'WVS-K1000HDR /1000LM80V  Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '3000.00', '3000.00', '0.00', '3000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:31:20', 'Abdul Mobin Hero', '2019-12-20 12:32:36', 1),
(398, 'P00398', 'WVS-1000SD   Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '2950.00', '3290.00', '0.00', '3290.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:31:39', 'Admin', '2019-12-16 19:09:32', 1),
(399, 'P00399', 'WVS-600SD  Auto Voltage Stabilizer', 36, 0, 0, 'na', 0, 0, '2600.00', '2600.00', '0.00', '2600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:32:12', 'Abdul Mobin Hero', '2019-12-20 12:29:20', 1),
(400, 'P00400', 'WVP-SG15  Automatic Voltage Protector', 37, 0, 0, 'na', 0, 0, '1000.00', '1000.00', '0.00', '1000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:32:35', 'Abdul Mobin Hero', '2019-12-22 17:15:38', 1),
(401, 'P00401', 'WVP-JV15 Automatic Voltage Protector', 37, 0, 0, 'na', 0, 0, '1050.00', '1050.00', '0.00', '1050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:32:48', 'Abdul Mobin Hero', '2019-12-22 17:15:24', 1),
(402, 'P00402', 'WVP-JV200  Automatic Voltage Protector', 37, 0, 0, 'na', 0, 0, '1500.00', '1500.00', '0.00', '1500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:33:05', 'Abdul Mobin Hero', '2019-12-22 17:15:04', 1),
(403, 'P00403', 'M STV', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:33:20', '', '', 1),
(404, 'P00404', 'WAF-LF786  Air-Fryer', 38, 0, 0, 'na', 0, 0, '6550.00', '6550.00', '0.00', '6550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:33:52', 'Abdul Mobin Hero', '2019-12-22 17:16:49', 1),
(405, 'P00405', 'WRC-C322-3.2Lt(Double Pot) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '3550.00', '3550.00', '0.00', '3550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:34:20', 'Abdul Mobin Hero', '2019-12-21 16:52:24', 1),
(406, 'P00406', 'WRC-C282-2.8Lt(Al2Pot) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2850.00', '2850.00', '0.00', '2850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:35:08', 'Abdul Mobin Hero', '2019-12-21 16:51:36', 1),
(407, 'P00407', 'WRC-C281(2.8L) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '3200.00', '3200.00', '0.00', '3200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:35:44', 'Abdul Mobin Hero', '2019-12-21 16:50:19', 1),
(408, 'P00408', 'WRC-C320-3.2Lt(SSPot)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2950.00', '2950.00', '0.00', '2950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:36:31', 'Abdul Mobin Hero', '2019-12-21 16:49:44', 1),
(409, 'P00409', 'WRC-D321(3.2Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2990.00', '2990.00', '0.00', '2990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:37:03', 'Abdul Mobin Hero', '2019-12-21 16:48:55', 1),
(410, 'P00410', 'WRC-D320(3.2Lt) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2950.00', '2950.00', '0.00', '2950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:37:29', 'Abdul Mobin Hero', '2019-12-21 16:48:13', 1),
(411, 'P00411', 'WRC-D280(2.8Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2880.00', '2880.00', '0.00', '2880.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:37:58', 'Admin', '2019-12-16 18:16:29', 1),
(412, 'P00412', 'WRC-C280(2.8Lt) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2800.00', '2800.00', '0.00', '2800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:38:48', 'Abdul Mobin Hero', '2019-12-21 16:47:39', 1),
(413, 'P00413', 'WRC-8T28(MTC)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2750.00', '2750.00', '0.00', '2750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:39:19', 'Abdul Mobin Hero', '2019-12-21 16:46:23', 1),
(414, 'P00414', 'WGS-GSHC2 Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '3250.00', '3250.00', '0.00', '3250.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 11:39:35', 'Admin', '2019-12-16 11:40:45', 1),
(415, 'P00415', 'WRC-SGA280-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2750.00', '2750.00', '0.00', '2750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:39:53', 'Admin', '2019-12-16 16:52:23', 1),
(416, 'P00416', 'WRC-M320(3.2Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2600.00', '2600.00', '0.00', '2600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:40:23', 'Abdul Mobin Hero', '2019-12-21 16:45:43', 1),
(417, 'P00417', 'WRC-T280(2.8Lt)   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2580.00', '2580.00', '0.00', '2580.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:40:55', 'Abdul Mobin Hero', '2019-12-21 16:45:10', 1),
(418, 'P00418', 'WRC-D250(2.5Lt) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2550.00', '2550.00', '0.00', '2550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:42:24', 'Abdul Mobin Hero', '2019-12-21 16:44:33', 1),
(419, 'P00419', 'WRC-TP28A(MTC)   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2550.00', '2550.00', '0.00', '2550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:42:47', 'Abdul Mobin Hero', '2019-12-21 16:43:54', 1),
(420, 'P00420', 'WRC-SGA220-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:43:16', 'Abdul Mobin Hero', '2019-12-20 15:04:21', 1),
(421, 'P00421', 'WRC-MS320-HIL WRC-MS320-HIL Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:43:50', 'Abdul Mobin Hero', '2019-12-21 16:43:01', 1),
(422, 'P00422', 'WRC-C220(2.2Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2490.00', '2490.00', '0.00', '2490.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:44:13', 'Abdul Mobin Hero', '2019-12-21 16:42:26', 1),
(423, 'P00423', 'WRC-TP22A(MTC)   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2400.00', '2400.00', '0.00', '2400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:44:42', 'Abdul Mobin Hero', '2019-12-21 16:41:50', 1),
(424, 'P00424', 'WRC-C182(MTC)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2400.00', '2400.00', '0.00', '2400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:45:33', 'Abdul Mobin Hero', '2019-12-21 16:41:08', 1),
(425, 'P00425', 'WRC-T225 Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2380.00', '2380.00', '0.00', '2380.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:46:11', 'Abdul Mobin Hero', '2019-12-21 16:40:34', 1),
(426, 'P00426', 'WRC-D220(2.2Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2380.00', '2380.00', '0.00', '2380.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:46:40', 'Abdul Mobin Hero', '2019-12-21 16:40:03', 1),
(427, 'P00427', 'WRC-M280(2.8L) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2300.00', '2300.00', '0.00', '2300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:58:27', 'Abdul Mobin Hero', '2019-12-21 16:39:32', 1),
(428, 'P00428', 'WRC-T222((2.2L))  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2220.00', '2220.00', '0.00', '2220.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:59:11', 'Abdul Mobin Hero', '2019-12-21 16:38:47', 1),
(429, 'P00429', 'WRC-MS280-HIL   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2200.00', '2200.00', '0.00', '2200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 11:59:41', 'Admin', '2019-12-16 15:24:54', 1),
(430, 'P00430', 'WRC-T220(2.2Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2180.00', '2180.00', '0.00', '2180.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:00:08', 'Abdul Mobin Hero', '2019-12-21 16:37:29', 1),
(431, 'P00431', 'WRC-C182(1.8L)Double Pot Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:00:43', 'Abdul Mobin Hero', '2019-12-21 16:36:50', 1),
(432, 'P00432', 'WRC-SGA180-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2200.00', '2200.00', '0.00', '2200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:01:06', 'Admin', '2019-12-16 15:21:35', 1),
(433, 'P00433', 'WRC-M250(2.5Lt)   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1990.00', '1990.00', '0.00', '1990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:01:39', 'Admin', '2019-12-16 15:20:48', 1),
(434, 'P00434', 'WRC-MS220(HIL)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:02:08', 'Admin', '2019-12-16 15:17:48', 1),
(435, 'P00435', 'WRC-M220(2.2Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1850.00', '1850.00', '0.00', '1850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:02:45', 'Admin', '2019-12-16 15:19:58', 1),
(436, 'P00436', 'WRC-C181(1.8Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1780.00', '1780.00', '0.00', '1780.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:03:08', 'Admin', '2019-12-16 15:20:22', 1),
(437, 'P00437', 'WRC-MS180(HIL)   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1850.00', '1850.00', '0.00', '1850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:03:37', 'Admin', '2019-12-16 16:55:34', 1),
(438, 'P00438', 'WRC-M182(1.8L)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1750.00', '1750.00', '0.00', '1750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:04:03', 'Abdul Mobin Hero', '2019-12-21 16:36:01', 1),
(439, 'P00439', 'WRC-M180(1.8Lt) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1720.00', '1720.00', '0.00', '1720.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:04:31', 'Abdul Mobin Hero', '2019-12-21 16:34:40', 1),
(440, 'P00440', 'WRC-M181(1.8Lt) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1650.00', '1650.00', '0.00', '1650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:05:13', 'Abdul Mobin Hero', '2019-12-21 16:35:05', 1),
(441, 'P00441', 'WRC-P103  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1500.00', '1500.00', '0.00', '1500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:05:36', 'Admin', '2019-12-16 14:18:25', 1),
(442, 'P00442', 'WRC-P105(MTC)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1600.00', '1600.00', '0.00', '1600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:06:05', 'Admin', '2019-12-16 14:17:46', 1),
(443, 'P00443', 'WRC-P100(1.0Lt)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1480.00', '1480.00', '0.00', '1480.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:06:27', 'Admin', '2019-12-16 14:16:25', 1),
(444, 'P00444', 'WRC-P105(1.0L) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '1300.00', '1300.00', '0.00', '1300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:06:48', 'Admin', '2019-12-16 14:17:14', 1);
INSERT INTO `tbl_product` (`Product_SlNo`, `Product_Code`, `Product_Name`, `ProductCategory_ID`, `color`, `brand`, `size`, `vat`, `Product_ReOrederLevel`, `Product_Purchase_Rate`, `Product_SellingPrice`, `Product_MinimumSellingPrice`, `Product_WholesaleRate`, `one_cartun_equal`, `is_service`, `Unit_ID`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Product_branchid`) VALUES
(445, 'P00445', 'WRC-CGA180-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:07:11', 'Admin', '2019-12-16 17:16:29', 1),
(446, 'P00446', 'WRC-CGA220-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2400.00', '2400.00', '0.00', '2400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:07:36', 'Admin', '2019-12-16 18:19:26', 1),
(447, 'P00447', 'WRC-CGA280-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:07:59', 'Abdul Mobin Hero', '2019-12-20 15:02:41', 1),
(448, 'P00448', 'WRC-CSS180-HIL   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2250.00', '2250.00', '0.00', '2250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:08:27', 'Abdul Mobin Hero', '2019-12-21 16:32:05', 1),
(449, 'P00449', 'WRC-CSS220-HIL   Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2700.00', '2640.00', '0.00', '2640.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:09:19', 'Abdul Mobin Hero', '2019-12-21 16:31:33', 1),
(450, 'P00450', ' Gas Stove (NG & LPG)', 31, 0, 0, 'na', 0, 0, '2450.00', '2450.00', '0.00', '2450.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 12:09:32', 'Admin', '2019-12-22 13:17:14', 1),
(451, 'P00451', 'WRC-CSS280-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '3050.00', '3050.00', '0.00', '3050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:09:49', 'Admin', '2019-12-16 16:56:52', 1),
(452, 'P00452', 'WRC-CSS28D-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '3200.00', '3200.00', '0.00', '3200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:10:20', 'Abdul Mobin Hero', '2019-12-21 16:29:25', 1),
(453, 'P00453', 'WRC-CSS22D-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2600.00', '2600.00', '0.00', '2600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:10:49', 'Abdul Mobin Hero', '2019-12-21 16:31:01', 1),
(454, 'P00454', 'WRC-CGA28D-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2800.00', '2800.00', '0.00', '2800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:11:25', 'Abdul Mobin Hero', '2019-12-21 16:27:55', 1),
(455, 'P00455', 'WRC-CGA22D-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2600.00', '2600.00', '0.00', '2600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:11:58', 'Abdul Mobin Hero', '2019-12-21 16:27:28', 1),
(456, 'P00456', 'WRC-CSS18D-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:12:23', 'Abdul Mobin Hero', '2019-12-21 16:26:53', 1),
(457, 'P00457', 'WRC-CGA18D-HIL  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2200.00', '2200.00', '0.00', '2200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:12:47', 'Abdul Mobin Hero', '2019-12-21 16:26:25', 1),
(458, 'P00458', 'WRC-SGA180(MTC)  Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2200.00', '2200.00', '0.00', '2200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:13:26', 'Abdul Mobin Hero', '2019-12-20 15:05:12', 1),
(459, 'P00459', 'WRC-SGA220(MTC) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:13:54', 'Admin', '2019-12-16 17:50:51', 1),
(460, 'P00460', 'WRC-SGA280(MTC) Walton Rice Cooker', 32, 0, 0, 'na', 0, 0, '2750.00', '2750.00', '0.00', '2750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:14:38', 'Abdul Mobin Hero', '2019-12-21 16:24:35', 1),
(461, 'P00461', 'WB-LB01(SS3in1)Mixer Grinder  Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:15:13', '', '', 1),
(462, 'P00462', 'WB-MG03(1.5L)SS-Mixer Grinder Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:15:42', '', '', 1),
(463, 'P00463', 'WBL-VK01-Mixer Grinder-HIL   Walton Blender', 39, 0, 0, 'na', 0, 0, '3850.00', '3850.00', '0.00', '3850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:16:11', 'Admin', '2019-12-16 16:39:04', 1),
(464, 'P00464', 'WBL-10GX65-Mixer  Grinder-HIL  Walton Blender', 39, 0, 0, 'na', 0, 0, '3500.00', '3500.00', '0.00', '3500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:16:45', 'Admin', '2019-12-16 17:00:44', 1),
(465, 'P00465', 'WBL-JYL22-HIL Walton Blender', 39, 0, 0, 'na', 0, 0, '3280.00', '3280.00', '0.00', '3280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:17:28', 'Admin', '2019-12-16 17:52:35', 1),
(466, 'P00466', 'WB-JYL22(Meat Chopper)1.2Lt  Walton Blender', 1, 0, 0, 'na', 0, 0, '3280.00', '3280.00', '0.00', '3280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:18:32', 'Admin', '2019-12-16 16:41:06', 1),
(467, 'P00467', 'WB-Q409(2in1,1.50Lt)  Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:19:05', '', '', 1),
(468, 'P00468', 'WB-JYL19A(3in1)  Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:19:36', '', '', 1),
(469, 'P00469', 'WB-JYL16 (3in1,1.2L)  Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:20:03', '', '', 1),
(470, 'P00470', 'WB-ME-1709  Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:20:30', '', '', 1),
(471, 'P00471', 'WB-AM930(3in1,1.50Lt)  Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:20:55', '', '', 1),
(472, 'P00472', 'WBL-13MC40-HIL Walton Blender', 39, 0, 0, 'na', 0, 0, '2550.00', '2550.00', '0.00', '2550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:21:24', 'Admin', '2019-12-18 12:00:16', 1),
(473, 'P00473', 'WBL-13PC40P(MTC)  Walton Blender', 39, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:21:53', 'Admin', '2019-12-18 11:59:40', 1),
(474, 'P00474', 'WBL-15GC40(MTC)  Walton Blender', 39, 0, 0, 'na', 0, 0, '2450.00', '2450.00', '0.00', '2450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:22:24', 'Admin', '2019-12-18 11:58:50', 1),
(475, 'P00475', 'WBL-13MX35-HIL Walton Blender', 39, 0, 0, 'na', 0, 0, '2300.00', '2300.00', '0.00', '2300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:22:48', 'Admin', '2019-12-18 11:57:32', 1),
(476, 'P00476', 'WBL-15PC40(MTC) Walton Blender', 39, 0, 0, 'na', 0, 0, '2450.00', '2450.00', '0.00', '2450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:23:11', 'Admin', '2019-12-18 11:55:56', 1),
(477, 'P00477', 'WB-EP301(3in1,1.50Lt)  Walton Blender', 39, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:23:36', 'Admin', '2019-12-16 19:48:13', 1),
(478, 'P00478', 'WB-LB800(1.5L)-3in1  Walton Blender', 39, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:24:04', 'Admin', '2019-12-16 19:48:36', 1),
(479, 'P00479', 'WB-AM630(3in1,1.00Lt) Walton Blender', 39, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:24:28', 'Admin', '2019-12-16 19:48:48', 1),
(480, 'P00480', 'WBL-15G35(MTC)  Walton Blender', 39, 0, 0, 'na', 0, 0, '2150.00', '2150.00', '0.00', '2150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:24:52', 'Admin', '2019-12-18 11:55:00', 1),
(481, 'P00481', 'WBL-13PC40-HIL   Walton Blender', 39, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:25:28', 'Admin', '2019-12-18 11:54:12', 1),
(482, 'P00482', 'WB-LB700(3in1,1.50Lt)   Walton Blender', 39, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:25:51', 'Admin', '2019-12-16 19:47:56', 1),
(483, 'P00483', 'WBL-15PX35  Walton Blender', 39, 0, 0, 'na', 0, 0, '2000.00', '2000.00', '0.00', '2000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:26:20', 'Admin', '2019-12-18 11:53:25', 1),
(484, 'P00484', 'WBL-13EC25-HIL  Walton Blender', 39, 0, 0, 'na', 0, 0, '1850.00', '1850.00', '0.00', '1850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:26:45', 'Admin', '2019-12-16 17:02:37', 1),
(485, 'P00485', 'WB-PN20(0.6L-Double Jar)   Walton Blender', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:27:14', '', '', 1),
(486, 'P00486', 'WBL-13EX25-HIL   Walton Blender', 39, 0, 0, 'na', 0, 0, '1650.00', '1650.00', '0.00', '1650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:27:46', 'Admin', '2019-12-16 17:55:17', 1),
(487, 'P00487', 'WBL-13CC25-HIL   Walton Blender', 39, 0, 0, 'na', 0, 0, '1650.00', '1650.00', '0.00', '1650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:28:42', 'Admin', '2019-12-16 16:42:57', 1),
(488, 'P00488', 'WBL-13CX25-HIL  Walton Blender', 39, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:29:10', 'Admin', '2019-12-16 17:04:21', 1),
(489, 'P00489', 'WBL-15GM65-Mixer Grider  Walton Blender', 39, 0, 0, 'na', 0, 0, '3600.00', '3600.00', '0.00', '3600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:29:40', 'Admin', '2019-12-18 11:52:09', 1),
(490, 'P00490', 'BL-10GX65-Mixer Grider  Walton Blender', 39, 0, 0, 'na', 0, 0, '3500.00', '3500.00', '0.00', '3500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:30:10', 'Abdul Mobin Hero', '2019-12-20 15:00:50', 1),
(491, 'P00491', 'WK-DW155(1.5L)Double layer Walton  Electric Kettle', 113, 0, 0, 'na', 0, 0, '1900.00', '1900.00', '0.00', '1900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:30:38', 'Abdul Mobin Hero', '2019-12-21 10:58:57', 1),
(492, 'P00492', 'WK-DW175(Double Wall) Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1800.00', '1800.00', '0.00', '1800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:31:08', 'Admin', '2019-12-16 19:49:13', 1),
(493, 'P00493', 'WK-DW171(Double Wall) Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1590.00', '1590.00', '0.00', '1590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:31:40', 'Abdul Mobin Hero', '2019-12-21 10:58:20', 1),
(494, 'P00494', 'WK-DW170(Double Wall) Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1530.00', '1530.00', '0.00', '1530.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:32:02', 'Abdul Mobin Hero', '2019-12-21 10:58:00', 1),
(495, 'P00495', 'WK-DW150(Double Wall) Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1500.00', '1500.00', '0.00', '1500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:32:25', 'Abdul Mobin Hero', '2019-12-20 12:39:03', 1),
(496, 'P00496', 'WK-DW200(2L)Double  Wall  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1490.00', '1490.00', '0.00', '1490.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:33:03', 'Abdul Mobin Hero', '2019-12-21 10:57:21', 1),
(497, 'P00497', 'WK-DW201(2.0L)Double Wall Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1650.00', '1650.00', '0.00', '1650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:33:28', 'Abdul Mobin Hero', '2019-12-21 10:56:56', 1),
(498, 'P00498', 'WK-GLDW170  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:33:58', 'Admin', '2019-12-16 19:51:10', 1),
(499, 'P00499', 'WK-DW173(Double  Wall)  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1350.00', '1350.00', '0.00', '1350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:34:18', 'Abdul Mobin Hero', '2019-12-21 11:03:39', 1),
(500, 'P00500', 'WK-DW151(1.5L)Double Wall  Wall Walton Electric', 113, 0, 0, 'na', 0, 0, '12502.00', '1250.00', '0.00', '1250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:34:41', 'Abdul Mobin Hero', '2019-12-21 11:03:07', 1),
(501, 'P00501', 'WK-DLP100  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1250.00', '1250.00', '0.00', '1250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:35:04', 'Abdul Mobin Hero', '2019-12-20 15:09:02', 1),
(502, 'P00502', 'WK-SS1202(1.2L)Double Wall  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1280.00', '1280.00', '0.00', '1280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:35:35', 'Abdul Mobin Hero', '2019-12-21 11:02:31', 1),
(503, 'P00503', 'WK-LJSS170C  Wall Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1025.00', '1025.00', '0.00', '1025.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:36:05', 'Abdul Mobin Hero', '2019-12-20 15:07:04', 1),
(504, 'P00504', 'WK-SS1202(1.2L)Double Wall Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1280.00', '1280.00', '0.00', '1280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:36:30', 'Abdul Mobin Hero', '2019-12-21 11:01:53', 1),
(505, 'P00505', 'WK-LJSS170  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '990.00', '990.00', '0.00', '990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:36:56', 'Admin', '2019-12-16 19:53:59', 1),
(506, 'P00506', 'WK-P1703(1.7L)  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '980.00', '980.00', '0.00', '980.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:37:21', 'Abdul Mobin Hero', '2019-12-21 11:00:50', 1),
(507, 'P00507', 'WK-HQDW150  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '1050.00', '1050.00', '0.00', '1050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:37:53', 'Admin', '2019-12-16 19:54:21', 1),
(508, 'P00508', 'WK-LJSS150C    Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '940.00', '940.00', '0.00', '940.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:38:40', 'Abdul Mobin Hero', '2019-12-20 13:08:56', 1),
(509, 'P00509', 'WK-LJSS150(1.5L)   Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '940.00', '940.00', '0.00', '940.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:39:04', 'Admin', '2019-12-16 19:54:29', 1),
(510, 'P00510', 'WK-P1001(1.0L)  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:39:31', 'Admin', '2019-12-16 19:54:36', 1),
(511, 'P00511', 'WK-LJSS120   Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '875.00', '875.00', '0.00', '875.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:39:54', 'Admin', '2019-12-16 19:54:46', 1),
(512, 'P00512', 'WK-P0801(0.8L)  Walton Electric Kettle', 113, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:40:22', 'Admin', '2019-12-16 19:21:09', 1),
(513, 'P00513', 'WMB-K02 Mosquito Bat', 41, 0, 0, 'na', 0, 0, '550.00', '550.00', '0.00', '500.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 12:40:38', '', '', 1),
(514, 'P00514', 'WCW-FS2001 ', 1, 0, 0, 'na', 0, 0, '740.00', '740.00', '0.00', '740.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:41:02', 'Admin', '2019-12-16 16:41:40', 1),
(515, 'P00515', 'WEF-HM09(Frying  Pan-Electric)  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:41:27', 'Admin', '2019-12-16 19:55:16', 1),
(516, 'P00516', 'WCW-F2202(22cm)   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:41:51', 'Admin', '2019-12-16 19:55:25', 1),
(517, 'P00517', 'WCW-TPS2601-Ruti Tawa Pan 26CM  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '780.00', '780.00', '0.00', '780.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:42:23', 'Abdul Mobin Hero', '2019-12-20 15:19:12', 1),
(518, 'P00518', 'WCW-FS2201   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '840.00', '840.00', '0.00', '840.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:42:46', 'Admin', '2019-12-16 19:55:42', 1),
(519, 'P00519', 'WCW-TPS2801-Ruti Tawa Pan 28CM   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:43:09', 'Admin', '2019-12-16 19:55:50', 1),
(520, 'P00520', 'WCW-FS2201 (induction)   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:43:37', 'Admin', '2019-12-16 19:55:59', 1),
(521, 'P00521', 'WCW-F2002 Glass Lid(20cm)  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:44:10', 'Admin', '2019-12-16 19:56:07', 1),
(522, 'P00522', 'WCW-FSL2201   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:44:36', 'Admin', '2019-12-16 19:56:20', 1),
(523, 'P00523', 'WB-ME-1709   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:45:15', 'Admin', '2019-12-16 19:56:29', 1),
(524, 'P00524', 'WCW-F2201-Glass Lid (22cm)  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:45:46', 'Admin', '2019-12-16 19:56:38', 1),
(525, 'P00525', 'WCW-FS2401 (Induction)  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:46:11', 'Admin', '2019-12-16 19:56:50', 1),
(526, 'P00526', 'WCW-T2601Without Indu.base (26cm)  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '980.00', '980.00', '0.00', '980.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:47:07', 'Abdul Mobin Hero', '2019-12-20 15:18:31', 1),
(527, 'P00527', 'WCW-FS2601-Fry Pan  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:47:40', 'Admin', '2019-12-16 19:57:05', 1),
(528, 'P00528', 'WCW-FSL2201  (induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:48:19', '', '', 1),
(529, 'P00529', 'WCW-F2404(24cm)   Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '1000.00', '1000.00', '0.00', '1000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:48:49', 'Abdul Mobin Hero', '2019-12-20 15:14:38', 1),
(530, 'P00530', 'WCW-FSL2401-Fry Pan with Lid  Walton Kitchen Cookware', 40, 0, 0, 'na', 0, 0, '1000.00', '1000.00', '0.00', '1000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:49:11', 'Admin', '2019-12-16 19:57:32', 1),
(531, 'P00531', 'WCW-F2403-Glass Lid (24cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1020.00', '1020.00', '0.00', '1020.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:49:33', 'Abdul Mobin Hero', '2019-12-20 15:13:55', 1),
(532, 'P00532', 'WCW-FS2601 (induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:49:50', '', '', 1),
(533, 'P00533', 'WCW-F2605(26cm) Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1080.00', '1080.00', '0.00', '1080.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:50:15', 'Abdul Mobin Hero', '2019-12-20 15:17:41', 1),
(534, 'P00534', 'WCW-FS2801-Fry Pan Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:50:42', '', '', 1),
(535, 'P00535', 'WCW-FSL2601-Fry Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:51:00', '', '', 1),
(536, 'P00536', 'WCW-CSL2001-Casserole Pan with Lid   Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:51:14', '', '', 1),
(537, 'P00537', 'WCW-FSL2401  (Induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'd', 'Abdul Mobin Hero', '2019-12-16 12:51:33', '', '', 1),
(538, 'P00538', 'WCW-FS2801 (induction) Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1150.00', '1150.00', '0.00', '1150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:51:53', 'Admin', '2019-12-16 12:54:13', 1),
(539, 'P00539', 'WCW-FSL2601  (induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:52:11', '', '', 1),
(540, 'P00540', 'WCW-WSL2401-Wok Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:52:28', '', '', 1),
(541, 'P00541', 'WCW-S2001 Glass Lid(20cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:52:47', '', '', 1),
(542, 'P00542', 'WCW-F2604-Glass Lid (26cm)', 1, 0, 0, 'na', 0, 0, '1300.00', '1300.00', '0.00', '1300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:53:04', 'Abdul Mobin Hero', '2019-12-20 15:16:48', 1),
(543, 'P00543', 'WCW-WSL2601-Wok Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:53:26', '', '', 1),
(544, 'P00544', 'WCW-FSL2801  (induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:53:49', '', '', 1),
(545, 'P00545', 'WCW-WSL2601  (induction)   Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1380.00', '1380.00', '0.00', '1380.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:54:06', 'Admin', '2019-12-16 12:55:14', 1),
(546, 'P00546', 'WCW-CSL2401-Casserole Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1420.00', '1420.00', '0.00', '1420.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:54:36', 'Admin', '2019-12-16 12:56:10', 1),
(547, 'P00547', 'WCW-F2804-Glass Lid (28cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:54:58', 'Admin', '2019-12-16 12:57:53', 1),
(548, 'P00548', 'WCW-WSL2801-Wok Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:55:17', '', '', 1),
(549, 'P00549', 'WCW-F3002-Glass Lid (30cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:55:33', '', '', 1),
(550, 'P00550', 'WCW-CSL2601-Casserole Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:55:53', '', '', 1),
(551, 'P00551', 'WCW-CSL2601  (induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:56:21', '', '', 1),
(552, 'P00552', 'WCW-WSL3001-Wok Pan with Lid', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:56:45', '', '', 1),
(553, 'P00553', 'WCW-WSL3001  (induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:56:59', '', '', 1),
(554, 'P00554', 'WCW-W2801 Glass Lid(28cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1720.00', '1720.00', '0.00', '1720.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:57:16', 'Admin', '2019-12-16 12:58:58', 1),
(555, 'P00555', 'WCW-CSL2801-Casserole Pan', 1, 0, 0, 'na', 0, 0, '1750.00', '1750.00', '0.00', '1750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:57:48', 'Admin', '2019-12-16 14:27:23', 1),
(556, 'P00556', 'WCW-CSL2801-Casserole Pan with Lid  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:58:15', '', '', 1),
(557, 'P00557', 'WCW-C2602-With Glass Lid(26cm)   Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1800.00', '1800.00', '0.00', '1800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:58:30', 'Abdul Mobin Hero', '2019-12-20 15:15:46', 1),
(558, 'P00558', 'WCW-CSL2801(induction) Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:58:44', '', '', 1),
(559, 'P00559', 'WCW-SF240 Glass Lid(24cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '2000.00', '2000.00', '0.00', '2000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:58:59', 'Abdul Mobin Hero', '2019-12-20 15:12:20', 1),
(560, 'P00560', 'WCW-CSL2001(Induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:59:18', '', '', 1),
(561, 'P00561', 'WCW-CSL2401(Induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:59:34', '', '', 1),
(562, 'P00562', 'WCW-FS2401(Induction) Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 12:59:56', '', '', 1),
(563, 'P00563', 'WCW-WSL2401(Induction)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:00:17', '', '', 1),
(564, 'P00564', 'WCW-COM80   Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:00:43', '', '', 1),
(565, 'P00565', 'WCW-W3003 Glass Lid(30cm)  Walton Kitchen Cookware', 1, 0, 0, 'na', 0, 0, '1920.00', '1920.00', '0.00', '1920.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:01:09', 'Admin', '2019-12-16 13:02:48', 1),
(566, 'P00566', 'WMIX-KF13 Walton Stand Mixer', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:01:34', '', '', 1),
(567, 'P00567', 'WMB-H05  Walton Mosquito Bat', 41, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:02:14', 'Admin', '2019-12-16 19:17:04', 1),
(568, 'P00568', 'WMB-K01 Walton Mosquito Bat', 41, 0, 0, 'na', 0, 0, '590.00', '590.00', '0.00', '590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:02:42', 'Admin', '2019-12-16 19:16:56', 1),
(569, 'P00569', 'WMB-K02  Walton Mosquito Bat', 41, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:03:04', 'Admin', '2019-12-16 19:15:41', 1),
(570, 'P00570', 'WMB-K03  Walton Mosquito Bat', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:03:17', '', '', 1),
(571, 'P00571', 'WMB-K04  Walton Electric Kettle', 1, 0, 0, 'na', 0, 0, '750.00', '750.00', '0.00', '750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:03:37', 'Admin', '2019-12-16 13:04:29', 1),
(572, 'P00572', 'WK-DW175 Double Wall Walton  Electric Kettle', 113, 0, 0, 'na', 0, 0, '1800.00', '1800.00', '0.00', '1800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:04:00', 'Abdul Mobin Hero', '2019-12-20 15:07:47', 1),
(573, 'P00573', 'WRL-L77-Two Color Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:04:15', 'Admin', '2019-12-16 13:05:13', 1),
(574, 'P00574', 'WRL-L99 Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:04:32', '', '', 1),
(575, 'P00575', 'WRL-MT50(Metal Torch) Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:04:47', '', '', 1),
(576, 'P00576', 'WRL-L88 Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '1050.00', '1050.00', '0.00', '1050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:05:10', 'Admin', '2019-12-16 13:05:50', 1),
(577, 'P00577', 'WRL-L98  Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:05:28', '', '', 1),
(578, 'P00578', 'WRL-L104 Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '850.00', '850.00', '0.00', '850.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:05:45', 'Admin', '2019-12-16 13:06:29', 1),
(579, 'P00579', 'WRL-L69  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:06:04', '', '', 1),
(580, 'P00580', 'WRL-L55  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '800.00', '800.00', '0.00', '800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:06:20', 'Admin', '2019-12-16 13:08:20', 1),
(581, 'P00581', 'WRL-L95B  Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:06:47', '', '', 1),
(582, 'P00582', 'WRL-DL07 Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:07:04', '', '', 1),
(583, 'P00583', 'WRL-L66-Two Color Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:07:17', '', '', 1),
(584, 'P00584', 'WRL-LT100 Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:07:35', '', '', 1),
(585, 'P00585', 'WRL-L44 Walton Rechargeble Portable Lamp & Torch', 114, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:07:51', 'Admin', '2019-12-16 19:59:30', 1),
(586, 'P00586', 'WRL-L95S Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:08:08', '', '', 1),
(587, 'P00587', 'WRL-L16C Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '420.00', '420.00', '0.00', '420.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:08:23', 'Admin', '2019-12-16 13:09:00', 1),
(588, 'P00588', 'WRL-HT01(Head Torch)  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '410.00', '410.00', '0.00', '410.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:08:38', 'Admin', '2019-12-16 13:09:37', 1),
(589, 'P00589', 'WRL-T80(Torch)  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '330.00', '330.00', '0.00', '330.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:09:10', 'Admin', '2019-12-16 13:10:30', 1),
(590, 'P00590', 'WRL-L30  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:09:42', '', '', 1),
(591, 'P00591', 'WRL-L18  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:10:15', '', '', 1),
(592, 'P00592', 'WRL-LT101  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '320.00', '320.00', '0.00', '320.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:10:29', 'Admin', '2019-12-16 13:11:12', 1),
(593, 'P00593', 'WRL-T50(Torch)   Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:10:45', '', '', 1),
(594, 'P00594', 'WRL-T40(Torch)  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:10:57', '', '', 1),
(595, 'P00595', 'WRL-L20  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:11:12', 'Admin', '2019-12-16 13:12:16', 1),
(596, 'P00596', 'WRL-T20(Torch)9”length Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:11:33', '', '', 1),
(597, 'P00597', 'WRL-T103 Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:11:52', '', '', 1),
(598, 'P00598', 'WRL-L10  Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:12:10', '', '', 1),
(599, 'P00599', 'WRL-T10(Torch) Walton Rechargeble Portable Lamp & Torch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:12:28', '', '', 1),
(600, 'P00600', 'WCC-WK50(5.0L) Walton Multi Curry Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:12:43', '', '', 1),
(601, 'P00601', 'WCC-WK30(3.0L)  Walton Multi Curry Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:13:02', '', '', 1),
(602, 'P00602', 'Grace-Shaver Walton Electric Trimmer & Shaver', 1, 0, 0, 'na', 0, 0, '2300.00', '2300.00', '0.00', '2300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:13:19', 'Abdul Mobin Hero', '2019-12-20 12:51:03', 1),
(603, 'P00603', 'Stark Walton Electric Trimmer & Shaver', 43, 0, 0, 'na', 0, 0, '1350.00', '1350.00', '0.00', '1350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:13:49', 'Abdul Mobin Hero', '2019-12-21 17:15:16', 1),
(604, 'P00604', 'Sleek Walton Electric Trimmer & Shaver', 43, 0, 0, 'na', 0, 0, '1020.00', '1020.00', '0.00', '1020.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:14:08', 'Abdul Mobin Hero', '2019-12-21 16:17:18', 1),
(605, 'P00605', 'Shaver  Walton Electric Trimmer & Shaver', 43, 0, 0, 'na', 0, 0, '1140.00', '1140.00', '0.00', '1140.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:14:37', 'Abdul Mobin Hero', '2019-12-21 16:16:07', 1),
(606, 'P00606', 'Knight Walton Electric Trimmer & Shaver', 43, 0, 0, 'na', 0, 0, '890.00', '890.00', '0.00', '890.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:14:59', 'Abdul Mobin Hero', '2019-12-21 16:15:47', 1),
(607, 'P00607', 'WHD-P05 Walton Hair Dryer', 44, 0, 0, 'na', 0, 0, '990.00', '990.00', '0.00', '990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:15:16', 'Admin', '2019-12-22 09:29:29', 1),
(608, 'P00608', 'WHS-TL01 Walton Hair Straightener', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:15:38', '', '', 1),
(609, 'P00609', 'WHSC-SZ19T(Curler) Walton Hair Straightener', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:15:57', '', '', 1),
(610, 'P00610', 'ELITE-HP01 Walton Hair Clipper', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:16:25', '', '', 1),
(611, 'P00611', 'ELITE-HP02  Walton Hair Clipper', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:16:40', '', '', 1),
(612, 'P00612', 'ELITE-HP03  Walton Hair Clipper', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:16:52', '', '', 1),
(613, 'P00613', 'WEPC-YB05(5Kg) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:17:07', '', '', 1),
(614, 'P00614', 'WEPC-K06A7 Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:17:25', '', '', 1),
(615, 'P00615', 'WEPC-K05A10 Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:17:41', '', '', 1),
(616, 'P00616', 'WMPC-P6D5L-Manual Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:17:59', '', '', 1),
(617, 'P00617', 'WMPC-P05L-Manual Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '2300.00', '2300.00', '0.00', '2300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:18:30', 'Abdul Mobin Hero', '2019-12-20 12:40:01', 1),
(618, 'P00618', 'WMPC-LR07(7Lt)-Manual Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:18:46', '', '', 1),
(619, 'P00619', 'WMPC-P03L(Manual) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:19:05', '', '', 1),
(620, 'P00620', 'WMPC-LR05(5.Lt)-Manual Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:19:25', '', '', 1),
(621, 'P00621', 'WPC-MS55-Manual(MTC) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:19:38', '', '', 1),
(622, 'P00622', 'WPC-MO55-Oval(MTC) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:19:54', '', '', 1),
(623, 'P00623', 'WPC-MO45-Oval(MTC) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:20:11', '', '', 1),
(624, 'P00624', 'WPC-MS45-Manual(MTC) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:20:29', '', '', 1),
(625, 'P00625', 'WPC-MO35-Oval(MTC) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:21:00', '', '', 1),
(626, 'P00626', 'WPC-MS35-Manual(MTC) Walton Pressure Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:22:09', '', '', 1),
(627, 'P00627', 'WWP-RO13L Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '17000.00', '17000.00', '0.00', '17000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:22:30', 'Abdul Mobin Hero', '2019-12-21 17:29:24', 1),
(628, 'P00628', 'WWP-RO11L Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '16000.00', '16000.00', '0.00', '16000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:22:48', 'Abdul Mobin Hero', '2019-12-21 17:28:47', 1),
(629, 'P00629', 'WWP-RO12L Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '9000.00', '9000.00', '0.00', '9000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:23:05', 'Abdul Mobin Hero', '2019-12-21 17:28:02', 1),
(630, 'P00630', 'WWP-UF20L Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '3500.00', '3500.00', '0.00', '3500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:23:23', 'Admin', '2019-12-16 17:10:04', 1),
(631, 'P00631', 'WWP-F12M Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:23:44', 'Abdul Mobin Hero', '2019-12-21 17:27:23', 1),
(632, 'P00632', 'WWP-SM28L Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '2300.00', '2300.00', '0.00', '2300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:24:17', 'Abdul Mobin Hero', '2019-12-21 17:26:22', 1),
(633, 'P00633', 'WWP-SH28L(28L) Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:24:41', 'Admin', '2019-12-16 18:14:25', 1),
(634, 'P00634', 'WWP-SF17 Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '2050.00', '2050.00', '0.00', '2050.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:24:55', 'Abdul Mobin Hero', '2019-12-21 17:25:35', 1),
(635, 'P00635', 'WWP-SH24L(24L) Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '2000.00', '2000.00', '0.00', '2000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:25:19', 'Abdul Mobin Hero', '2019-12-21 17:24:51', 1),
(636, 'P00636', 'WWP-UF Filter-Filtration Cartridge Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '800.00', '800.00', '0.00', '800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:25:37', 'Abdul Mobin Hero', '2019-12-20 13:11:25', 1),
(637, 'P00637', 'WWP-Multifil Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '280.00', '280.00', '0.00', '280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:25:59', 'Abdul Mobin Hero', '2019-12-21 17:22:55', 1),
(638, 'P00638', 'WWP-Cerafil Walton Water Purifier', 51, 0, 0, 'na', 0, 0, '160.00', '160.00', '0.00', '160.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:26:21', 'Abdul Mobin Hero', '2019-12-21 17:22:05', 1),
(639, 'P00639', 'WWP-WT05C(0.5 HP) WaltonWater Pump', 52, 0, 0, 'na', 0, 0, '2900.00', '2900.00', '0.00', '2900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:26:43', 'Abdul Mobin Hero', '2019-12-21 17:20:38', 1),
(640, 'P00640', 'WWP-LX-JSW-10M (1HP) WaltonWater Pump', 52, 0, 0, 'na', 0, 0, '5500.00', '5500.00', '0.00', '5500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:26:59', 'Abdul Mobin Hero', '2019-12-21 17:20:01', 1),
(641, 'P00641', 'WWP-WT10J(1HP) WaltonWater Pump', 52, 0, 0, 'na', 0, 0, '5900.00', '5900.00', '0.00', '5900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:27:15', 'Abdul Mobin Hero', '2019-12-21 17:19:22', 1),
(642, 'P00642', 'WWP-LX-JSW100 WaltonWater Pump', 52, 0, 0, 'na', 0, 0, '6100.00', '6100.00', '0.00', '6100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:27:29', 'Abdul Mobin Hero', '2019-12-21 17:18:36', 1),
(643, 'P00643', 'WWD-TC05(Comp.Cooling) Walton Water Dispenser', 53, 0, 0, 'na', 0, 0, '12500.00', '12500.00', '0.00', '12500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:27:51', 'Admin', '2019-12-16 16:49:59', 1),
(644, 'P00644', 'WWD-ZC02(Comp.Cooling) Walton Water Dispenser', 53, 0, 0, 'na', 0, 0, '10500.00', '10500.00', '0.00', '10500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:28:14', 'Abdul Mobin Hero', '2019-12-21 17:33:50', 1),
(645, 'P00645', 'WWD-QC01(Com.Co.) Walton Water Dispenser', 53, 0, 0, 'na', 0, 0, '9150.00', '9150.00', '0.00', '9150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:28:31', 'Abdul Mobin Hero', '2019-12-21 17:32:47', 1),
(646, 'P00646', 'WWD-ME03(Electric Cooling) Walton Water Dispenser', 53, 0, 0, 'na', 0, 0, '7000.00', '7000.00', '0.00', '7000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:28:53', 'Admin', '2019-12-16 17:10:51', 1),
(647, 'P00647', 'WWD-QE01 Walton Water Dispenser', 53, 0, 0, 'na', 0, 0, '5700.00', '5700.00', '0.00', '5700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:29:11', 'Abdul Mobin Hero', '2019-12-21 17:32:07', 1),
(648, 'P00648', 'WWD-SE04(Electric Cooling) Walton Water Dispenser', 53, 0, 0, 'na', 0, 0, '4200.00', '4200.00', '0.00', '4200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:29:25', 'Admin', '2019-12-16 18:15:49', 1),
(649, 'P00649', 'WWH-MVH50L Walton Water Heater', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:29:46', '', '', 1),
(650, 'P00650', 'WWH-WH35L(Geyser) Walton Water Heater', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:30:03', '', '', 1),
(651, 'P00651', 'WIWH-M45S5 Walton Water Heater', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:30:24', '', '', 1),
(652, 'P00652', 'WIWH-M35J Walton Water Heater', 1, 0, 0, 'na', 0, 0, '4150.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:30:50', '', '', 1),
(653, 'P00653', 'WCM-AK03 Walton Cake Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:31:12', '', '', 1),
(654, 'P00654', 'WCM-AK01 Walton Cake Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:31:28', '', '', 1),
(655, 'P00655', 'WCM-AK04(Waffle Maker) Walton Cake Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:32:21', '', '', 1),
(656, 'P00656', 'WCM-AK05(Waffle Bowl Maker) Walton Cake Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:32:48', '', '', 1),
(657, 'P00657', 'WS-AE565 Walton Sewing Machine', 48, 0, 0, 'na', 0, 0, '9000.00', '9000.00', '0.00', '9000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:33:08', 'Abdul Mobin Hero', '2019-12-21 16:03:47', 1),
(658, 'P00658', 'WS-AE588 Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:33:48', '', '', 1),
(659, 'P00659', 'WS-FY520(Gift) Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:34:16', '', '', 1),
(660, 'P00660', 'WS-HS202(Mini) Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:34:36', '', '', 1),
(661, 'P00661', 'Stand Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:35:05', '', '', 1),
(662, 'P00662', 'Top Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:35:27', '', '', 1),
(663, 'P00663', 'Cover Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:35:50', '', '', 1),
(664, 'P00664', 'Box Walton Sewing Machine', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:36:05', '', '', 1),
(665, 'P00665', 'WSM-AK01(A)  WaltonDonut Plate-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:36:20', '', '', 1),
(666, 'P00666', 'WSM-AK01(A)  WWS-G03 Walton Body Weight Scale Plate-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:36:58', '', '', 1),
(667, 'P00667', 'WPCS-DS810 Walton Price Computing Weight Scale', 56, 0, 0, 'na', 0, 0, '2650.00', '2650.00', '0.00', '2650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:37:22', 'Abdul Mobin Hero', '2019-12-21 17:41:46', 1),
(668, 'P00668', 'WPCS-DD03 Walton Price Computing Weight Scale', 56, 0, 0, 'na', 0, 0, '2670.00', '2670.00', '0.00', '2670.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:37:41', 'Abdul Mobin Hero', '2019-12-21 17:41:30', 1),
(669, 'P00669', 'WPCS-DS968 Walton Price Computing Weight Scale', 56, 0, 0, 'na', 0, 0, '2700.00', '2700.00', '0.00', '2700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:37:57', 'Abdul Mobin Hero', '2019-12-21 17:40:55', 1),
(670, 'P00670', 'WPCS-DS800 WALTON Price Computing Weight Scale', 56, 0, 0, 'na', 0, 0, '2650.00', '2650.00', '0.00', '2650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:38:15', 'Abdul Mobin Hero', '2019-12-21 17:41:15', 1),
(671, 'P00671', 'WT-EB01 Walton Toaster', 57, 0, 0, 'na', 0, 0, '1600.00', '1600.00', '0.00', '1600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:38:31', 'Abdul Mobin Hero', '2019-12-21 16:08:01', 1),
(672, 'P00672', 'WT-368N/ WT371N Walton Toaster', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:38:51', '', '', 1),
(673, 'P00673', 'WSM-AK01  Walton Sandwich Maker -', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:39:12', '', '', 1),
(674, 'P00674', 'WVC-2014 Walton Vegetable(Salad)Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:39:38', '', '', 1),
(675, 'P00675', 'WDCM-S19L Walton Coffee Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:40:02', '', '', 1),
(676, 'P00676', 'WDCM-G15L Walton Coffee Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:40:17', '', '', 1),
(677, 'P00677', 'WSSL-W60 Walton Solar Street Light', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:40:32', '', '', 1),
(678, 'P00678', 'WMIX-E200 Walton Hand Mixer', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:41:02', '', '', 1),
(679, 'P00679', 'WI-F15 With Fry Pan Walton Induction Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:41:23', '', '', 1),
(680, 'P00680', 'WI-S35(Full Touch 1SS pot) Walton Induction Cooker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:41:42', '', '', 1),
(681, 'P00681', 'WRM-SW493 Walton Ruti Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:42:00', '', '', 1);
INSERT INTO `tbl_product` (`Product_SlNo`, `Product_Code`, `Product_Name`, `ProductCategory_ID`, `color`, `brand`, `size`, `vat`, `Product_ReOrederLevel`, `Product_Purchase_Rate`, `Product_SellingPrice`, `Product_MinimumSellingPrice`, `Product_WholesaleRate`, `one_cartun_equal`, `is_service`, `Unit_ID`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Product_branchid`) VALUES
(682, 'P00682', 'WRM-SW293 Walton Ruti Maker', 64, 0, 0, 'na', 0, 0, '2400.00', '2400.00', '0.00', '2400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:42:22', 'Abdul Mobin Hero', '2019-12-21 16:02:22', 1),
(683, 'P00683', 'WRM-CS193 Walton Ruti Maker', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:42:39', '', '', 1),
(684, 'P00684', 'WVF-SXP20 Walton Vacuum Flask', 65, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:43:00', 'Admin', '2019-12-17 09:45:38', 1),
(685, 'P00685', 'WVF-SXP15 Walton Vacuum Flask', 65, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:43:20', 'Admin', '2019-12-17 09:45:20', 1),
(686, 'P00686', 'WVF-SXP10 Walton Vacuum Flask', 65, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:44:03', 'Admin', '2019-12-17 09:45:30', 1),
(687, 'P00687', 'WVF-W500JE84 Walton Vacuum Flask', 65, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:44:23', 'Admin', '2019-12-17 09:45:03', 1),
(688, 'P00688', 'WVF-W350JE84 Walton Vacuum Flask', 65, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:44:47', 'Admin', '2019-12-17 09:44:55', 1),
(689, 'P00689', 'WAVC-LS06 Walton Vacuum Cleaner', 1, 0, 0, 'na', 0, 0, '3300.00', '3300.00', '0.00', '3300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:45:11', 'Admin', '2019-12-16 19:18:50', 1),
(690, 'P00690', 'WAVC-F153 Walton Vacuum Cleaner', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:45:30', '', '', 1),
(691, 'P00691', 'WMOP-ZT25 Walton MOP', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:45:58', '', '', 1),
(692, 'P00692', 'WMOP-BTM30 Walton MOP', 1, 0, 0, 'na', 0, 0, '1350.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:46:15', '', '', 1),
(693, 'P00693', 'Road Master-W6DZM100-12V 40AH Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:46:36', '', '', 1),
(694, 'P00694', 'Power Master-W6DZM95 12V Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:46:55', '', '', 1),
(695, 'P00695', 'Road Master-W6DZM80 Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:48:49', '', '', 1),
(696, 'P00696', 'Power Master-W6DZM75 12V Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:49:13', '', '', 1),
(697, 'P00697', 'Power Master-W6DZM120 12V4.5Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:49:32', '', '', 1),
(698, 'P00698', 'Power Master-12 V 75 AH Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:49:51', '', '', 1),
(699, 'P00699', 'WB1275-12V 7.5Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:50:08', '', '', 1),
(700, 'P00700', 'WB1245-12V 4.5Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:50:25', '', '', 1),
(701, 'P00701', 'WB670-6V 7.0Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:50:51', '', '', 1),
(702, 'P00702', 'Power Master-WB670  6V7.0Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:51:06', '', '', 1),
(703, 'P00703', 'WB6450-6V4.5Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:51:22', '', '', 1),
(704, 'P00704', 'Power Master-WB6450B-6V4.5Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:51:39', '', '', 1),
(705, 'P00705', 'Power Master-WB6450C-6V4.5Ah(Clip Type) Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:51:56', '', '', 1),
(706, 'P00706', 'WB440 4V 4Ah Walton Sealed Lead Acid Recharge Battery', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:52:10', '', '', 1),
(707, 'P00707', 'WCF5602-1400mm(Re.Control) walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '3900.00', '3900.00', '0.00', '3900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:52:29', 'Abdul Mobin Hero', '2019-12-21 18:15:25', 1),
(708, 'P00708', 'WCF5604 WR-Pink walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2940.00', '2940.00', '0.00', '2940.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:52:57', 'Abdul Mobin Hero', '2019-12-21 18:13:11', 1),
(709, 'P00709', 'WCF5604 WR-Indigo walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2840.00', '2840.00', '0.00', '2840.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:53:20', 'Abdul Mobin Hero', '2019-12-21 18:11:47', 1),
(710, 'P00710', 'WCF5604 WR White / Off White walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2800.00', '2800.00', '0.00', '2800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:54:38', 'Abdul Mobin Hero', '2019-12-21 18:11:14', 1),
(711, 'P00711', 'WCF 5603 WR Indigo walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2940.00', '2940.00', '0.00', '2940.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:54:56', 'Abdul Mobin Hero', '2019-12-21 18:10:19', 1),
(712, 'P00712', 'WCF 5603 WR White / Off White walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2900.00', '2900.00', '0.00', '2900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:55:09', 'Abdul Mobin Hero', '2019-12-21 18:09:20', 1),
(713, 'P00713', 'WCF 5603 WR Pink walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2940.00', '2940.00', '0.00', '2940.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:55:21', 'Abdul Mobin Hero', '2019-12-21 18:08:26', 1),
(714, 'P00714', 'WCF5601 WR Indigo walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2750.00', '2750.00', '0.00', '2750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:55:56', 'Abdul Mobin Hero', '2019-12-21 18:07:29', 1),
(715, 'P00715', 'WCF5601 WR White / Off White walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2700.00', '2700.00', '0.00', '2700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:56:10', 'Abdul Mobin Hero', '2019-12-21 18:06:52', 1),
(716, 'P00716', 'WCF5601 WRWCF5601EM walton Ceiling FanWhite / Off White walton Ceiling Fan', 68, 0, 0, 'na', 0, 0, '2700.00', '2700.00', '0.00', '2700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:56:55', 'Abdul Mobin Hero', '2019-12-21 18:05:58', 1),
(717, 'P00717', 'W16OA-RMC(Remote Type)Any Color Walton Wall Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:57:14', '', '', 1),
(718, 'P00718', 'W16OA-RGC(Pull Type)Any Color Walton Wall Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:57:31', '', '', 1),
(719, 'P00719', 'WTF16B-PBC-400 mm Cream White Walton Table Fan', 70, 0, 0, 'na', 0, 0, '2090.00', '2090.00', '0.00', '2090.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:57:48', 'Abdul Mobin Hero', '2019-12-21 10:44:52', 1),
(720, 'P00720', 'WTF16A-PBC-Sky Blue/Cream White(Push Butto) Walton Table Fan', 70, 0, 0, 'na', 0, 0, '2400.00', '2400.00', '0.00', '2400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:58:06', 'Abdul Mobin Hero', '2019-12-21 10:43:57', 1),
(721, 'P00721', 'WTF16A-RMC(Remote Type) Walton Table Fan', 70, 0, 0, 'na', 0, 0, '2800.00', '2800.00', '0.00', '2800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 13:58:34', 'Abdul Mobin Hero', '2019-12-21 10:43:06', 1),
(722, 'P00722', 'W17OA-EM-MS(Stand White-Base White)  Walton Rechargeable Table Fan', 72, 0, 0, 'na', 0, 0, '3690.00', '3690.00', '0.00', '3960.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:00:05', 'Abdul Mobin Hero', '2019-12-21 10:38:24', 1),
(723, 'P00723', 'W17OA-MS-17\"  Walton Rechargeable Fan', 72, 0, 0, 'na', 0, 0, '4100.00', '4100.00', '0.00', '4100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:00:33', 'Abdul Mobin Hero', '2019-12-21 10:40:25', 1),
(724, 'P00724', 'W17OA-AS-17\" Walton Rechargeable Fan', 72, 0, 0, 'na', 0, 0, '4200.00', '4200.00', '0.00', '4200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:00:52', 'Abdul Mobin Hero', '2019-12-21 10:41:23', 1),
(725, 'P00725', 'WPF-16OB-PBC(Pink/Purple/Sky Blue/Dark Blue) Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:01:09', '', '', 1),
(726, 'P00726', 'WPF-16OB-RMC(Pink/Purple/(Sky Blue/Dark Blue) Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:01:25', '', '', 1),
(727, 'P00727', 'WPF-16OA-PBC-Cream White Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:01:56', '', '', 1),
(728, 'P00728', 'WPF-16OA-PBC-Pink Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:02:13', '', '', 1),
(729, 'P00729', 'WPF24A-PBC(Tripod) Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:02:40', '', '', 1),
(730, 'P00730', 'WPF24A-PBC Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:02:58', '', '', 1),
(731, 'P00731', 'WPF-24B-PBC (Black/Gray) Walton Pedestal Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:03:19', '', '', 1),
(732, 'P00732', 'WEF 1001-10\" Walton Exhaust Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:03:35', '', '', 1),
(733, 'P00733', 'WEF 0801-8\" Walton Exhaust Fan', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:03:48', '', '', 1),
(734, 'P00734', 'WGS-01Gang Switch Walton Pearl White (W1 Series)', 31, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:04:05', 'Admin', '2019-12-16 19:07:36', 1),
(735, 'P00735', 'WGS-02Gang Switch Walton Pearl White (W1 Series)', 31, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:04:25', 'Admin', '2019-12-16 19:07:52', 1),
(736, 'P00736', 'WGS-03Gang Switch Walton Pearl White (W1 Series)', 31, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:04:42', 'Admin', '2019-12-16 19:08:01', 1),
(737, 'P00737', 'WGS-04Gang Switch Walton Pearl White (W1 Series)', 31, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:04:58', 'Admin', '2019-12-16 19:08:11', 1),
(738, 'P00738', 'WGS-05Gang Switch Walton Pearl White (W1 Series)', 31, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:05:23', 'Admin', '2019-12-16 19:08:19', 1),
(739, 'P00739', 'W3PS-01-3Pin Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:05:46', '', '', 1),
(740, 'P00740', 'WU3P-01-USB Power Supply Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:06:00', '', '', 1),
(741, 'P00741', 'WRRCS-02(Remote for Remote Control Switch) Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:06:46', '', '', 1),
(742, 'P00742', 'WRRCS-03(Remote for Remote Control Switch) Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:07:01', '', '', 1),
(743, 'P00743', 'WRCS-01-Remote Con.Sw Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:07:25', '', '', 1),
(744, 'P00744', 'WRCSPW-02-Remote Con.Switch Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:08:05', '', '', 1),
(745, 'P00745', 'WRCSRF.01-Remote Cont. Switch(RF) Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:08:18', '', '', 1),
(746, 'P00746', 'W1BP-Blank Plate Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:08:34', '', '', 1),
(747, 'P00747', 'WCB-01-Calling Bell Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:08:47', '', '', 1),
(748, 'P00748', 'W1TVS-TV Socket W1TS3', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:09:18', 'Admin', '2019-12-16 14:26:51', 1),
(749, 'P00749', 'W1DS6-Date Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:09:40', '', '', 1),
(750, 'P00750', 'WRCFSR.01-RMC Fan Speed Regulator Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:09:56', '', '', 1),
(751, 'P00751', 'W1MSN13-Multi Socket Walton Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:10:47', 'Admin', '2019-12-16 14:23:39', 1),
(752, 'P00752', 'W12USBMSPW-2 USB Charger & Multi Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:11:09', '', '', 1),
(753, 'P00753', 'W1MS13-Multi Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:11:23', '', '', 1),
(754, 'P00754', 'W1GTS13-13A G-Type Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:11:44', '', '', 1),
(755, 'P00755', 'W13PRSN15-15A 3Pin Round Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:12:00', '', '', 1),
(756, 'P00756', 'W13PRS15-3Pin Round Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:12:12', '', '', 1),
(757, 'P00757', 'W12PSPW10-2Pin Socket Walton Pearl White (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:12:33', '', '', 1),
(758, 'P00758', 'W12W11GSMB/ W11GS10', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:13:16', 'Admin', '2019-12-16 14:26:07', 1),
(759, 'P00759', 'W12GSMB/ W12GS10.1-2Gang Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:13:33', '', '', 1),
(760, 'P00760', 'W13GSMB/ W13GS10.1-3Gang Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:13:47', '', '', 1),
(761, 'P00761', 'W14GSMB/ W14GS10.1-4Gang Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:14:08', '', '', 1),
(762, 'P00762', 'W15GSMB/ W15GS10.1-5Gang Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:14:29', '', '', 1),
(763, 'P00763', 'W1CBSMB/ W1CBS10.1-Calling Bell Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:15:28', '', '', 1),
(764, 'P00764', 'WRCSMB / WRCSC-Remote Cont.Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:15:48', '', '', 1),
(765, 'P00765', 'W1FRMB / W1FR250-Fan Regulator Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:16:03', '', '', 1),
(766, 'P00766', 'W13PUSMB / W13PUS13-3Pin Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:16:26', '', '', 1),
(767, 'P00767', 'W13PSUSBMB /W13PSUSB13-3Pin USB Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:16:39', '', '', 1),
(768, 'P00768', 'W1TVSMB / W1TVSC-TV Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:16:55', '', '', 1),
(769, 'P00769', 'W1TSMB3 / W1TSC3-Telephone Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:17:10', '', '', 1),
(770, 'P00770', 'W1DSMB6 / W1DSC6-Data Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:17:22', '', '', 1),
(771, 'P00771', 'W12PS10-2Pin Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:17:39', '', '', 1),
(772, 'P00772', 'W1MSMB13 / W1MSC13-Multi Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:18:02', '', '', 1),
(773, 'P00773', 'W13PRSC15-3Pin Round Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:18:18', '', '', 1),
(774, 'P00774', 'W1MSCN13-Multi Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:18:30', '', '', 1),
(775, 'P00775', 'W12USBMSCN-2USB Charger & Multi Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:18:47', '', '', 1),
(776, 'P00776', 'W1BPC-Blank Plate Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:19:02', '', '', 1),
(777, 'P00777', 'W12USBMSPW-2USB Charger & Multi Socket Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:19:17', '', '', 1),
(778, 'P00778', 'WRCS-02-Remote Control Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:19:31', '', '', 1),
(779, 'P00779', 'WRCSPW-03-Remote Control Switch Walton Metallic Black/Silver/Gold (W1 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:19:45', '', '', 1),
(780, 'P00780', 'WCF-PR01(Piano Type) WaltonFan Regulator(10 Pes Carton)', 86, 0, 0, 'na', 0, 0, '150.00', '150.00', '0.00', '150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:20:06', 'Abdul Mobin Hero', '2019-12-21 18:02:23', 1),
(781, 'P00781', 'WCF-CR 01(Capacitive Fan Regulator) WaltonFan Regulator(10 Pes Carton)', 86, 0, 0, 'na', 0, 0, '350.00', '350.00', '0.00', '350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:20:37', 'Abdul Mobin Hero', '2019-12-21 18:01:40', 1),
(782, 'P00782', 'WFR-01 WaltonFan Regulator(10 Pes Carton)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:20:54', '', '', 1),
(783, 'P00783', 'A8CBSRPW16.1-Calling Bell Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:21:20', '', '', 1),
(784, 'P00784', 'A81GSRPW16.1-1Gang Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:21:38', '', '', 1),
(785, 'P00785', 'A82GSRPW16.1-2Gang Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:21:57', '', '', 1),
(786, 'P00786', 'A83GSRPW10.1-3Gang Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:22:14', '', '', 1),
(787, 'P00787', 'A84GSRPW10.1-4Gang Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:22:29', '', '', 1),
(788, 'P00788', 'A83PUPW13-3Pin Socket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:22:41', '', '', 1),
(789, 'P00789', 'A83PUSPW13-3Pin Socket & Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:23:08', '', '', 1),
(790, 'P00790', 'A8MSUPW13-Multi Socket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:23:21', '', '', 1),
(791, 'P00791', 'A8TSPW3-Telephone Socket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:23:36', '', '', 1),
(792, 'P00792', 'A8TVSPW-TV Socket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:23:50', '', '', 1),
(793, 'P00793', 'A8DSPW5-Date Socket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:24:07', '', '', 1),
(794, 'P00794', 'A8FRPW250-Fan Regulator Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:24:26', '', '', 1),
(795, 'P00795', 'A8LDPW250-Light Dimmer Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:24:39', '', '', 1),
(796, 'P00796', 'A81GSRPW16.2-1Gang-2Way Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:24:55', '', '', 1),
(797, 'P00797', 'A82GSRPW16.2-2Gang-2Way Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:25:44', '', '', 1),
(798, 'P00798', 'A83GSRPW10.2-3Gang-2Way Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:25:59', '', '', 1),
(799, 'P00799', 'A84GSRPW10.2-4Gang-2Way Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:26:15', '', '', 1),
(800, 'P00800', 'A8BPPW-Blank Plate Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:26:29', '', '', 1),
(801, 'P00801', 'A82PSPW10-2 Pin Socket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:26:48', '', '', 1),
(802, 'P00802', 'A82PSSPW10-2 Pin Socket with Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:27:05', '', '', 1),
(803, 'P00803', 'A8USBSPW16-2USB Charger & Switch Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:27:22', '', '', 1),
(804, 'P00804', 'A8USB3PSU13-2USB Charger & 3Pin Scoket Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:27:38', '', '', 1),
(805, 'P00805', 'A8FRSPW400-Fan Regulator Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:27:54', '', '', 1),
(806, 'P00806', 'A8FRSPW100-Fan Regulator(Step) Walton Pearl White (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:28:07', '', '', 1),
(807, 'P00807', 'A8CBSR16.1-Calling Bell Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:28:23', '', '', 1),
(808, 'P00808', 'A81GSR16.1-1Gang Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 14:28:38', '', '', 1),
(809, 'P00809', 'A82GSR16.1-2Gang Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:45:24', '', '', 1),
(810, 'P00810', 'A83GSR10.1-3Gang Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:45:51', '', '', 1),
(811, 'P00811', 'A84GSR10.1-4Gang Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:46:25', '', '', 1),
(812, 'P00812', 'A81GSR16.2-1Gang-2way Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:46:55', '', '', 1),
(813, 'P00813', 'A82GSR16.2-2Gang-2way Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:47:16', '', '', 1),
(814, 'P00814', 'A83GSR10.2-3Gang-2way Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:47:42', '', '', 1),
(815, 'P00815', 'A84GSR10.2-4Gang-2way Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:48:24', '', '', 1),
(816, 'P00816', 'A83PU13-3Pin Socket Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:48:41', '', '', 1),
(817, 'P00817', 'A83PUS13-3Pin Socket & Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:48:58', '', '', 1),
(818, 'P00818', 'A8MSU13-Multi Socket Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:49:12', '', '', 1),
(819, 'P00819', 'A8TS3-Telephone Socket Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:49:39', '', '', 1),
(820, 'P00820', 'A82PS10-2 Pin Socket Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:50:00', '', '', 1),
(821, 'P00821', 'A8TVS-TV Socket Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:51:29', '', '', 1),
(822, 'P00822', 'A8DS5-Data Socket Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:51:52', '', '', 1),
(823, 'P00823', 'A8FR250-Fan Regulator Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:52:10', '', '', 1),
(824, 'P00824', 'A8LD250-Light Dimmer Switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:52:26', '', '', 1),
(825, 'P00825', 'A8BP-Blank Plate Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:52:46', '', '', 1),
(826, 'P00826', 'A82PSS10-2 Pin Socket with switch Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:53:09', '', '', 1),
(827, 'P00827', 'A8FRS400-Fan Regulator Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:53:26', '', '', 1),
(828, 'P00828', 'A8FRS100-Fan Regulator(Step) Walton Metallic Silver / Black / Gold (A8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:53:52', '', '', 1),
(829, 'P00829', 'RCBSPW16.1B Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:54:13', '', '', 1),
(830, 'P00830', 'R1GSPW16.1B Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:54:32', '', '', 1),
(831, 'P00831', 'R2GSPW16.1B Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:54:51', '', '', 1),
(832, 'P00832', 'R3GSPW10.1 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:55:31', '', '', 1),
(833, 'P00833', 'R4GSPW10.1 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:56:20', '', '', 1),
(834, 'P00834', 'R1GSPW16.2B Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:56:35', '', '', 1),
(835, 'P00835', 'R3PUSPW13 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:57:22', '', '', 1),
(836, 'P00836', 'RMSUPW13 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:57:52', '', '', 1),
(837, 'P00837', 'RTSPW3 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:58:26', '', '', 1),
(838, 'P00838', 'RTVSPW Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:58:53', '', '', 1),
(839, 'P00839', 'RDSPW5 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:59:19', '', '', 1),
(840, 'P00840', 'RFRSPW400 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 15:59:44', '', '', 1),
(841, 'P00841', 'RFRSPW100 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:00:03', '', '', 1),
(842, 'P00842', 'RBPPW Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:00:27', '', '', 1),
(843, 'P00843', 'RUSBSPW16 Pearl White Walton Royal Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:00:48', '', '', 1),
(844, 'P00844', 'WJB-01(Single Gang) Walton Junction Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:01:08', '', '', 1),
(845, 'P00845', 'SV2MJBG-2M Junction Box Walton Junction Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:01:28', '', '', 1),
(846, 'P00846', 'SV3MJBG-3M Junction Box Walton Junction Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:01:46', '', '', 1),
(847, 'P00847', 'SV4MJBG-4M Junction Box Walton Junction Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:03:56', '', '', 1),
(848, 'P00848', 'WDB-8WTP-63A walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:07:00', '', '', 1),
(849, 'P00849', 'WDB-5TP-15W walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:07:15', '', '', 1),
(850, 'P00850', 'WDB-PR-4TP-12W-4TP walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:07:33', '', '', 1),
(851, 'P00851', 'WDB-4TP-12W walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:08:19', '', '', 1),
(852, 'P00852', 'WDB-PR-3TP-9W-3TP walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:08:45', '', '', 1),
(853, 'P00853', 'WDB-PR-2TP-6W-2TP walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:09:07', '', '', 1),
(854, 'P00854', 'WDB-3TP-9W walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:09:25', '', '', 1),
(855, 'P00855', 'WDB-2TP-6W walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:09:36', '', '', 1),
(856, 'P00856', 'TP-3W63C walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:09:49', '', '', 1),
(857, 'P00857', 'SP-1W32C walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:10:03', '', '', 1),
(858, 'P00858', 'WDB-DP-2W walton Electric Distribution Box', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:10:18', '', '', 1),
(859, 'P00859', 'PRIME-TP-3W63C walton Electric Distribution Box', 79, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:10:34', 'Admin', '2019-12-16 20:04:12', 1),
(860, 'P00860', 'PRIME-SP-1W32C walton Electric Distribution Box', 79, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:10:57', 'Admin', '2019-12-16 20:03:58', 1),
(861, 'P00861', 'WDPSPWM20-HIL Walton DP Switch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:11:25', '', '', 1),
(862, 'P00862', 'WDPSPWM45 Walton DP Switch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:11:45', '', '', 1),
(863, 'P00863', 'WDPSM20 Metallic Walton DP Switch0', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:12:02', '', '', 1),
(864, 'P00864', 'WDPSM45 Metallic Walton DP Switch', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:12:29', '', '', 1),
(865, 'P00865', 'WVT-Z01  Walton Voltage Tester', 83, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:13:07', 'Admin', '2019-12-16 20:03:38', 1),
(866, 'P00866', 'WVT-W01 Walton Voltage Tester', 83, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:13:31', 'Admin', '2019-12-16 20:04:41', 1),
(867, 'P00867', 'WLED-T8FX-4F-Tube Light Fixture walton Tube Light-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:13:44', '', '', 1),
(868, 'P00868', 'W2PP10-2 Pin Plug Walton Holder(12 Pes Carton)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:14:08', '', '', 1),
(869, 'P00869', 'WTH-01(Thread) / WPBH-01(Pin) Walton Holder(12 Pes Carton)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:14:29', '', '', 1),
(870, 'P00870', 'E41GSRPW16.1-1Gang Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:14:48', '', '', 1),
(871, 'P00871', 'E42GSRPW16.1-2Gang Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:15:14', '', '', 1),
(872, 'P00872', 'E42PSPW10-2 Pin Socket Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:15:31', '', '', 1),
(873, 'P00873', 'E43GSRPW10.1-3Gang Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:15:51', '', '', 1),
(874, 'P00874', 'E44GSRPW10.1-4Gang Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:16:09', '', '', 1),
(875, 'P00875', 'E43PUPW13-3 Pin Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:17:05', '', '', 1),
(876, 'P00876', 'E43PUSPW13-3 Pin Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:17:31', '', '', 1),
(877, 'P00877', 'E4MSUPW13-Multi Socket Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:17:52', '', '', 1),
(878, 'P00878', 'E4CBSRPW16.1-Calling Bell Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:18:36', '', '', 1),
(879, 'P00879', 'E4TSPW3-Telephone Socket Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:18:52', '', '', 1),
(880, 'P00880', 'E4TVSPW-TV Socket Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:19:08', '', '', 1),
(881, 'P00881', 'E4DSPW5-Data Socket Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:19:28', '', '', 1),
(882, 'P00882', 'E4FRPW250-Fan Regulator Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:19:50', '', '', 1),
(883, 'P00883', 'E4LDPW250-Light Dimmer Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:20:09', '', '', 1),
(884, 'P00884', 'E41GSRPW16.2-1Gang-2Way Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:20:25', '', '', 1),
(885, 'P00885', 'E42GSRPW16.2-2Gang-2Way Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:20:47', '', '', 1),
(886, 'P00886', 'E43GSRPW10.2-3Gang-2Way Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:21:03', '', '', 1),
(887, 'P00887', 'E44GSRPW10.2-4Gang-2Way Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:21:17', '', '', 1),
(888, 'P00888', 'E4BPPW-Blank Plate Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:21:49', '', '', 1),
(889, 'P00889', 'E42PSSPW10- 2Pin Socket with switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:22:08', '', '', 1),
(890, 'P00890', 'E4USB3PSU13-2USB Charger with 3Pin Socket Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:22:26', '', '', 1),
(891, 'P00891', 'E4USBSPW16-2USB Charger with Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:22:44', '', '', 1),
(892, 'P00892', 'E4MSSPWP.01-Motion Sensor(PIR) Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:23:05', '', '', 1),
(893, 'P00893', 'E4MSSPWM.01White-Motion Sensor(Micro Wave) Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:23:31', '', '', 1),
(894, 'P00894', 'E4LCSPW.01-Light Control Switch Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:23:54', '', '', 1),
(895, 'P00895', 'E4FRSPW400-Fan Regulator Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:24:37', '', '', 1),
(896, 'P00896', 'E4FRSPW100-Fan Regulator(Step) Walton Pearl White (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:24:56', '', '', 1),
(897, 'P00897', 'E4CBSR16.1-Calling Bell Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:25:14', '', '', 1),
(898, 'P00898', 'E41GSR16.1-1Gang Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:25:35', '', '', 1),
(899, 'P00899', 'E42PS10-2  Pin Socket Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:26:07', '', '', 1),
(900, 'P00900', 'E42GSR16.1-2Gang Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:26:23', '', '', 1),
(901, 'P00901', 'E43GSR10.1-3Gang Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:26:46', '', '', 1),
(902, 'P00902', 'E44GSR10.1-4Gang Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:27:21', '', '', 1),
(903, 'P00903', 'E41GSR16.2-1Gang-2way Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:27:37', '', '', 1),
(904, 'P00904', 'E42GSR16.2-2Gang-2way Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:27:49', '', '', 1),
(905, 'P00905', 'E43GSR10.2-3Gang-2way Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:28:11', '', '', 1),
(906, 'P00906', 'E44GSR10.2-4Gang-2way Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:28:30', '', '', 1),
(907, 'P00907', 'E43PU13-3Pin Socket Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:28:43', '', '', 1),
(908, 'P00908', 'E43PUS13-3Pin Socket & Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:28:56', '', '', 1),
(909, 'P00909', 'E4MSU13-Multi Socket Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:29:16', '', '', 1),
(910, 'P00910', 'E4TS3-Telephone Socket Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:29:29', '', '', 1),
(911, 'P00911', 'E4TVS-TV  Socket Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:29:49', '', '', 1),
(912, 'P00912', 'E4DS5-Data Socket Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:30:04', '', '', 1),
(913, 'P00913', 'E4FR250-Fan Regulator Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:30:21', '', '', 1),
(914, 'P00914', 'E4LD250-Light Dimmer Switch Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:30:50', '', '', 1),
(915, 'P00915', 'E4BP-Blank  Plate Walton Metallic Silver / Black /Gold (E4 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:31:23', '', '', 1),
(916, 'P00916', 'S31GSRMB16.1-1 Gang Switch (S3)-10 Pes Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:31:46', '', '', 1),
(917, 'P00917', 'V81GSRMB16.1-1 Gang Switch (V8)-10 Pes Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:32:13', '', '', 1);
INSERT INTO `tbl_product` (`Product_SlNo`, `Product_Code`, `Product_Name`, `ProductCategory_ID`, `color`, `brand`, `size`, `vat`, `Product_ReOrederLevel`, `Product_Purchase_Rate`, `Product_SellingPrice`, `Product_MinimumSellingPrice`, `Product_WholesaleRate`, `one_cartun_equal`, `is_service`, `Unit_ID`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Product_branchid`) VALUES
(918, 'P00918', 'SVSSRMB16.1-Single Switch Module (1way) Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:32:34', '', '', 1),
(919, 'P00919', 'SVDSRMB16.1-Double Switch Module (1way) Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:34:17', '', '', 1),
(920, 'P00920', 'SV3PUMB10-3 Pin Socket Module (Universal) Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:35:18', '', '', 1),
(921, 'P00921', 'SVTVSMB-TV-Socket Module-20 Pes Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:36:14', '', '', 1),
(922, 'P00922', 'SVTSMB3-Telephone Socket Module-20 Pes Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:36:28', '', '', 1),
(923, 'P00923', 'SVDSMB6-Data Socket Module-20 Pes Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:36:43', '', '', 1),
(924, 'P00924', 'SVBMMB-Blank Module- 20 Pes Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:36:59', '', '', 1),
(925, 'P00925', 'S3CBSRMB16.1-Calling Bell Switch(S3) Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:37:14', '', '', 1),
(926, 'P00926', 'V8CBSRMB16.1-Calling Bell Switch(V8) Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:37:29', '', '', 1),
(927, 'P00927', 'SVFRPW-250-Module(PW)Fan Regulator Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:37:44', '', '', 1),
(928, 'P00928', 'SVFRMB-250-Module(MB)Fan Regulator Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:38:00', '', '', 1),
(929, 'P00929', 'SVLDMB250-Module-(MB)-Light Dimmer Walton Metallic Black(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:38:13', '', '', 1),
(930, 'P00930', 'P1CBS6-Calling Bell-HIL  Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Ma', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:38:28', '', '', 1),
(931, 'P00931', 'P1S6.1-1 Way Single-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Mar', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:38:52', '', '', 1),
(932, 'P00932', 'P1S6.2-2 Way Single-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Mar', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:40:11', '', '', 1),
(933, 'P00933', 'P1S2P6-2Pin Socket-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Maro', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:40:33', '', '', 1),
(934, 'P00934', 'WCW-F2001(20cm)', 40, 0, 0, 'na', 0, 0, '720.00', '720.00', '0.00', '720.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:40:41', '', '', 2),
(935, 'P00935', 'P1F6-Fuse-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Maroon / Choc', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:40:50', '', '', 1),
(936, 'P00936', 'P1I-Indicator-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Maroon /', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:41:10', '', '', 1),
(937, 'P00937', 'P1FR250-Fan Regulator-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / M', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:41:28', '', '', 1),
(938, 'P00938', 'P1FRN250-Fan Regulator-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green /', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:41:47', '', '', 1),
(939, 'P00939', 'P1TVS-TV Socket-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Maroon', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:42:04', '', '', 1),
(940, 'P00940', 'WEF-HM09(Frying Pan-Electric)', 1, 0, 0, 'na', 0, 0, '750.00', '750.00', '0.00', '750.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:42:11', '', '', 2),
(941, 'P00941', 'P1TS3-Telephone Socket-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green /', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:42:27', '', '', 1),
(942, 'P00942', 'WCW-FSL2201 ', 1, 0, 0, 'na', 0, 0, '900.00', '900.00', '0.00', '900.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:42:40', 'Admin', '2019-12-16 16:46:47', 2),
(943, 'P00943', 'P1DS5-Data Socket-HIL Walton Piano Series Switch Socket-Golden/Black/Sky/Blue/Stylish (Green / Maroo', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:43:04', '', '', 1),
(944, 'P00944', 'WCW-TPS2601-Ruti Tawa Pan 26CM', 1, 0, 0, 'na', 0, 0, '780.00', '780.00', '0.00', '780.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:43:05', '', '', 2),
(945, 'P00945', 'S31GSWWR16.1-1Gang Switch-S3 Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:43:19', '', '', 1),
(946, 'P00946', 'WCW-MSL1801 ', 1, 0, 0, 'na', 0, 0, '850.00', '850.00', '0.00', '850.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:43:32', '', '', 2),
(947, 'P00947', 'V81GSWWR16.1-1 Gang Switch-V8 Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:43:35', '', '', 1),
(948, 'P00948', 'S3CBSWWR16.1-Calling Bell Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:43:50', '', '', 1),
(949, 'P00949', 'WCW-FS2201 (induction)', 1, 0, 0, 'na', 0, 0, '870.00', '870.00', '0.00', '870.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:43:56', 'Admin', '2019-12-16 16:45:05', 2),
(950, 'P00950', 'V8CBSWWR16.1-Calling Bell Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:44:10', '', '', 1),
(951, 'P00951', 'SVSSWWR16.1-Single Switch Walton Switch Socket(S3 & V8 Series)', 91, 0, 0, 'na', 0, 0, '59.00', '59.00', '0.00', '59.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:44:29', 'Abdul Mobin Hero', '2019-12-21 10:53:32', 1),
(952, 'P00952', 'SVDSWWR16.1-Double Switch Walton Switch Socket(S3 & V8 Series)', 93, 0, 0, 'na', 0, 0, '125.00', '125.00', '0.00', '125.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:44:45', 'Abdul Mobin Hero', '2019-12-21 10:51:44', 1),
(953, 'P00953', 'SV3PUWW10-3 Pin Socket Walton Switch Socket(S3 & V8 Series)', 91, 0, 0, 'na', 0, 0, '85.00', '85.00', '0.00', '85.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:45:05', 'Abdul Mobin Hero', '2019-12-21 10:49:49', 1),
(954, 'P00954', 'SVTVSW-TV Socket Walton Switch Socket(S3 & V8 Series)', 76, 0, 0, 'na', 0, 0, '140.00', '140.00', '0.00', '140.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:45:23', 'Abdul Mobin Hero', '2019-12-21 10:48:20', 1),
(955, 'P00955', 'WCW-F2002 Glass Lid(20cm) ', 1, 0, 0, 'na', 0, 0, '880.00', '880.00', '0.00', '880.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:45:41', '', '', 2),
(956, 'P00956', 'SVTSWW3-Telephone Socket Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:45:46', '', '', 1),
(957, 'P00957', 'SVDSWW6-Data Socket Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:46:01', '', '', 1),
(958, 'P00958', 'SVBMW-Blank Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:46:14', '', '', 1),
(959, 'P00959', 'SVLDPW250-(PW)-Light Dimmer Walton Switch Socket(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:46:30', '', '', 1),
(960, 'P00960', 'S32MCPWW-2M Cover Plate-S3 Walton Cover Plate(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:46:53', '', '', 1),
(961, 'P00961', 'V82MCPWW-2M Cover Plate-V8 Walton Cover Plate(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:47:10', '', '', 1),
(962, 'P00962', 'WCW-MSL1801 (Induction) ', 1, 0, 0, 'na', 0, 0, '900.00', '900.00', '0.00', '900.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:47:23', '', '', 2),
(963, 'P00963', 'S33MCPWW-3M Cover Plate-S3 Walton Cover Plate(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:47:39', '', '', 1),
(964, 'P00964', 'WCW-F2201-Glass Lid (22cm)', 1, 0, 0, 'na', 0, 0, '930.00', '930.00', '0.00', '930.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:47:50', '', '', 2),
(965, 'P00965', 'V83MCPWW-3M Cover Plate-V8 Walton Cover Plate(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:48:00', '', '', 1),
(966, 'P00966', 'S34MCPWW-4M Cover Plate-S3 Walton Cover Plate(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:48:18', '', '', 1),
(967, 'P00967', 'WCW-FS2401 (Induction)', 1, 0, 0, 'na', 0, 0, '940.00', '940.00', '0.00', '940.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:48:19', '', '', 2),
(968, 'P00968', 'V84MCPDWW-4M Cover Plate-V8 Walton Cover Plate(S3 & V8 Series)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:48:38', '', '', 1),
(969, 'P00969', 'WCW-T2601Without Indu.base (26cm) ', 1, 0, 0, 'na', 0, 0, '980.00', '980.00', '0.00', '980.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:48:47', '', '', 2),
(970, 'P00970', 'SVSSWWR16.2-2Way Walton S3V8 Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:48:56', '', '', 1),
(971, 'P00971', 'WCW-FS2601-Fry Pan', 1, 0, 0, 'na', 0, 0, '980.00', '980.00', '0.00', '980.00', '', 'false', 1, 'a', 'Admin', '2019-12-16 16:49:09', '', '', 2),
(972, 'P00972', 'SVDSWWR16.2-2Way Walton S3V8 Series-Pearl White', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:49:11', '', '', 1),
(973, 'P00973', 'S32MCPMB-2M Cover Plate-S3-10 Pes Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:49:58', '', '', 1),
(974, 'P00974', 'V82MCPMB-2M Cover Plate-V8-10 Pes Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:50:16', '', '', 1),
(975, 'P00975', 'S33MCPMB-3M Cover Plate-S3-10 Pes Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:50:42', '', '', 1),
(976, 'P00976', 'V83MCPMB-3M Cover Plate-V8-10 Pes Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:51:07', '', '', 1),
(977, 'P00977', 'S34MCPMB-4M Cover Plate-S3-10 Pes Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:51:25', '', '', 1),
(978, 'P00978', 'V84MCPMB-4M Cover Plate-V8-10 Pes Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:52:02', '', '', 1),
(979, 'P00979', 'SVSSRMB16.2-2Way Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:52:18', '', '', 1),
(980, 'P00980', 'SVDSRMB16.2-2Way Walton Cover Plate(S3 & V8 Series)Metallic Black', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:52:38', '', '', 1),
(981, 'P00981', 'WCLR01-Ceiling Rose Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:52:58', '', '', 1),
(982, 'P00982', 'W1HPB-1H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:53:16', '', '', 1),
(983, 'P00983', 'W2HPB-2H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:53:36', '', '', 1),
(984, 'P00984', 'W3HPB-3H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:54:00', '', '', 1),
(985, 'P00985', 'W4HPB-4H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:54:13', '', '', 1),
(986, 'P00986', 'W6HPB-6H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:54:27', '', '', 1),
(987, 'P00987', 'W8HPB-8H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:54:41', '', '', 1),
(988, 'P00988', 'WHBP-01-Holder Back Plate Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:54:54', '', '', 1),
(989, 'P00989', 'WHBP-02-Holder Back Plate Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:55:07', '', '', 1),
(990, 'P00990', 'W68HPB-6x8 Hole Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:55:31', '', '', 1),
(991, 'P00991', 'W810HPB-8x10 Hole Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:55:57', '', '', 1),
(992, 'P00992', 'W1GOB-1 Gang Outer Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:56:14', '', '', 1),
(993, 'P00993', 'W2GOB-2 Gang Outer Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:56:29', '', '', 1),
(994, 'P00994', 'W3GOB-3 Gang Outer Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:56:43', '', '', 1),
(995, 'P00995', 'W2MOB-2M Outer Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:57:01', '', '', 1),
(996, 'P00996', 'W3MOB-3M Outer Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:57:26', '', '', 1),
(997, 'P00997', 'W4MOB-4M Outer Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:57:48', '', '', 1),
(998, 'P00998', 'WDHB22-Decorative Holder Pin Type Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:58:17', '', '', 1),
(999, 'P00999', 'WDHE27-Decorative Holder-Thread Type Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:58:35', '', '', 1),
(1000, 'P01000', 'WBHB22-Batten Holder-Pin Type Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:58:57', '', '', 1),
(1001, 'P01001', 'WBHE27-Batten Holder-Thread Type Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:59:14', '', '', 1),
(1002, 'P01002', 'WRBHB22-Round Batten Holder-Pin Type Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:59:34', '', '', 1),
(1003, 'P01003', 'WRBHE27-Round Batten Holder-Thread Type Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 16:59:53', '', '', 1),
(1004, 'P01004', 'W2PP10-2 Pin Plug Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:01:13', '', '', 1),
(1005, 'P01005', 'W2PP6-6A 2Pin Plug Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:01:29', '', '', 1),
(1006, 'P01006', 'WTA-01-Travel Adapter Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:01:42', '', '', 1),
(1007, 'P01007', 'W5HPB-5H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:01:56', '', '', 1),
(1008, 'P01008', 'W7HPB-7H Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:02:12', '', '', 1),
(1009, 'P01009', 'W33HB-Holder Board Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:02:27', '', '', 1),
(1010, 'P01010', 'W64HB-Holder Board Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:02:41', '', '', 1),
(1011, 'P01011', 'W33HP-Holder Plate Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:02:53', '', '', 1),
(1012, 'P01012', 'W64HP-Holder Plate Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:03:06', '', '', 1),
(1013, 'P01013', 'W68PHBM02-6x8 Hole Piano Box Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:03:22', '', '', 1),
(1014, 'P01014', 'W68PB-6x8 Plain Board Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:03:35', '', '', 1),
(1015, 'P01015', 'WPHB22-Pendant Holder Walton Switch Socket-Accessories', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:03:53', '', '', 1),
(1016, 'P01016', 'WESU2P3E-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:04:09', '', '', 1),
(1017, 'P01017', 'WESU3P3E-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:04:24', '', '', 1),
(1018, 'P01018', 'WESU2P3E(Comb.) Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:04:39', '', '', 1),
(1019, 'P01019', 'WES3P4E5-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:04:58', '', '', 1),
(1020, 'P01020', 'WES3P4M5-Sky Blue Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:05:15', '', '', 1),
(1021, 'P01021', 'WES3P4H5-Black  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:07:26', '', '', 1),
(1022, 'P01022', 'WES2P4E5-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:07:52', '', '', 1),
(1023, 'P01023', 'WES2P4M5-Sky Blue', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:08:05', '', '', 1),
(1024, 'P01024', 'WES2P4H5-Black Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:08:26', '', '', 1),
(1025, 'P01025', 'WES3P4E-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:08:45', '', '', 1),
(1026, 'P01026', 'WES3P4M-Sky Blue  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:09:12', '', '', 1),
(1027, 'P01027', 'WES3P4H-Black Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:09:39', '', '', 1),
(1028, 'P01028', 'WES2P4E- White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:09:57', '', '', 1),
(1029, 'P01029', 'WES2P4M-Sky Blue Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:10:20', '', '', 1),
(1030, 'P01030', 'WES2P4H-Black Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:10:41', '', '', 1),
(1031, 'P01031', 'WESU2P3E5(Comb.)  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:10:57', '', '', 1),
(1032, 'P01032', 'WESU2P3E5 Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:11:16', '', '', 1),
(1033, 'P01033', 'WESU2P3M5  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:11:36', '', '', 1),
(1034, 'P01034', 'WESU2P3H5  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:11:56', '', '', 1),
(1035, 'P01035', 'WESU3P3E5 (Comb.)  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:12:19', '', '', 1),
(1036, 'P01036', 'WESU3P3E5 Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:12:56', '', '', 1),
(1037, 'P01037', 'WESU3P3M5 Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:13:13', '', '', 1),
(1038, 'P01038', 'WESU3P3H5 Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:13:29', '', '', 1),
(1039, 'P01039', 'WES2P4E3M-02 -Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:13:56', '', '', 1),
(1040, 'P01040', 'WES2P4H3M-02 Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:15:25', '', '', 1),
(1041, 'P01041', 'WES3P4E3M-02- Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:15:39', '', '', 1),
(1042, 'P01042', 'WES3P4H3M-02- Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:15:55', '', '', 1),
(1043, 'P01043', 'WES2P4E5M-02 -Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:16:30', '', '', 1),
(1044, 'P01044', 'WES2P4H5M-02-Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:16:51', '', '', 1),
(1045, 'P01045', 'WES3P4E5M-02-Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:17:12', '', '', 1),
(1046, 'P01046', 'WES3P4H5M-02- Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:17:33', '', '', 1),
(1047, 'P01047', 'WESU3P3M-Sky Blue Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:17:48', '', '', 1),
(1048, 'P01048', 'WESU3P3H-Black-Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:18:20', '', '', 1),
(1049, 'P01049', 'WESU2P3M-Sky Blue-Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:18:37', '', '', 1),
(1050, 'P01050', 'WESU2P3H-Black-Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:18:52', '', '', 1),
(1051, 'P01051', 'WES2P4E1.5-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:19:05', '', '', 1),
(1052, 'P01052', 'WES3P4E1.5-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:19:20', '', '', 1),
(1053, 'P01053', 'WES2P4M1.5-Sky Blue  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:19:36', '', '', 1),
(1054, 'P01054', 'WES3P4M1.5-Sky Bllue  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:19:50', '', '', 1),
(1055, 'P01055', 'WES2P4H1.5-Black  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:20:03', '', '', 1),
(1056, 'P01056', 'WES3P4H1.5-Black  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:20:24', '', '', 1),
(1057, 'P01057', 'WESU2PE1.5-White  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:20:52', '', '', 1),
(1058, 'P01058', 'WESU3P3E1.5-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:21:15', '', '', 1),
(1059, 'P01059', 'WESU2P3M1.5-Sky Blue  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:21:34', '', '', 1),
(1060, 'P01060', 'WESU3P3M1.5-Sky Blue   Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:21:53', '', '', 1),
(1061, 'P01061', 'WESU2P3H1.5-Black   Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:22:10', '', '', 1),
(1062, 'P01062', 'WESU3P3H1.5-Black Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:22:25', '', '', 1),
(1063, 'P01063', 'WESU2P3E1.5-(Com.)  Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:22:46', '', '', 1),
(1064, 'P01064', 'WESU3P3E1.5-(Com.)   Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:23:05', '', '', 1),
(1065, 'P01065', 'WLED-H5WE27 / WLED-H5WB22 Walton LED Light', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:23:21', '', '', 1),
(1066, 'P01066', 'WLED-H5WE27A / WLED-H5WB22A Walton LED Light', 1, 0, 0, 'na', 0, 0, '260.00', '260.00', '0.00', '260.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:23:55', 'Abdul Mobin Hero', '2019-12-18 20:57:33', 1),
(1067, 'P01067', 'WLED-H7WE27 / WLED-H7WB22 Walton LED Light', 1, 0, 0, 'na', 0, 0, '325.00', '325.00', '0.00', '325.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:24:18', 'Abdul Mobin Hero', '2019-12-18 20:57:17', 1),
(1068, 'P01068', 'WLED-H9WE27 / WLED-H9WB22 Walton LED Light', 1, 0, 0, 'na', 0, 0, '425.00', '425.00', '0.00', '425.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:24:37', 'Abdul Mobin Hero', '2019-12-18 20:56:46', 1),
(1069, 'P01069', 'WLED-H12WE27 / WLED-12WB22 Walton LED Light', 1, 0, 0, 'na', 0, 0, '490.00', '490.00', '0.00', '490.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:24:54', 'Abdul Mobin Hero', '2019-12-18 20:56:14', 1),
(1070, 'P01070', 'WLED-F3WB22 / R3WB22/ F3WE27 / R3WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '165.00', '165.00', '0.00', '165.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:25:31', 'Abdul Mobin Hero', '2019-12-18 20:55:41', 1),
(1071, 'P01071', 'WLED-F5WB22 / R5WB22/ F5WE27/ R5WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '190.00', '190.00', '0.00', '190.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:25:48', 'Abdul Mobin Hero', '2019-12-18 20:55:01', 1),
(1072, 'P01072', 'WLED-F6WB22 / R6WB22/F6WE27 / R6WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '210.00', '210.00', '0.00', '210.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:26:29', 'Abdul Mobin Hero', '2019-12-18 20:53:09', 1),
(1073, 'P01073', 'WLED-F7WB22 / R7WB22/F7WE27 / R7WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '225.00', '225.00', '0.00', '225.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:26:45', 'Abdul Mobin Hero', '2019-12-18 20:50:49', 1),
(1074, 'P01074', 'WLED-ECO-WARM-R9WB22/ WARM R9WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '230.00', '230.00', '0.00', '230.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:26:59', 'Abdul Mobin Hero', '2019-12-18 20:48:15', 1),
(1075, 'P01075', 'WLED-ECO-WARM-12WB22/ WARM-12WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '295.00', '295.00', '0.00', '295.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:27:19', 'Abdul Mobin Hero', '2019-12-18 20:47:00', 1),
(1076, 'P01076', 'WLED-ECO-R7WB22/ WLED-ECO-R7WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '215.00', '215.00', '0.00', '215.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:27:47', 'Abdul Mobin Hero', '2019-12-18 20:44:23', 1),
(1077, 'P01077', 'WLED-ECO-R9WB22 / WLED-ECO-R9WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '225.00', '225.00', '0.00', '225.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:28:01', 'Abdul Mobin Hero', '2019-12-18 20:44:09', 1),
(1078, 'P01078', 'WLED-ECO-R12WB22 /WLED-ECO-R12WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '260.00', '260.00', '0.00', '260.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:28:18', 'Abdul Mobin Hero', '2019-12-18 20:43:16', 1),
(1079, 'P01079', 'WLED-EXC-OM-9WB22/ EXC-OM-9WE27 Walton LED Light', 100, 0, 0, 'na', 0, 0, '325.00', '325.00', '0.00', '325.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:28:31', 'Abdul Mobin Hero', '2019-12-18 20:42:16', 1),
(1080, 'P01080', 'WLED-EXC-OM-12WB22/ EXC-OM-12WE27 Walton LED Light', 1, 0, 0, 'na', 0, 0, '395.00', '395.00', '0.00', '395.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:28:46', 'Abdul Mobin Hero', '2019-12-18 20:41:42', 1),
(1081, 'P01081', 'WLED-PR5WB22/ PR5WE27-Premium-5W Walton LED Light', 1, 0, 0, 'na', 0, 0, '200.00', '200.00', '0.00', '200.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:29:02', 'Abdul Mobin Hero', '2019-12-18 20:40:36', 1),
(1082, 'P01082', 'WLED-PR7WB22/ PR7WE27-Premium-7W Walton LED Light', 1, 0, 0, 'na', 0, 0, '230.00', '230.00', '0.00', '230.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:29:17', 'Abdul Mobin Hero', '2019-12-18 20:39:59', 1),
(1083, 'P01083', 'WLED-PR9WB22 /PR9WE27-Premium-9W Walton LED Light', 1, 0, 0, 'na', 0, 0, '240.00', '240.00', '0.00', '240.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:29:34', 'Abdul Mobin Hero', '2019-12-18 20:39:21', 1),
(1084, 'P01084', 'WLED-PR11WB22/ PR11WE27-Premium-11W Walton LED Light', 1, 0, 0, 'na', 0, 0, '280.00', '280.00', '0.00', '280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:29:54', 'Abdul Mobin Hero', '2019-12-18 20:38:38', 1),
(1085, 'P01085', 'WLED-PR12WB22 /PR12WE27-Premium-12W Walton LED Light', 1, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:30:17', 'Abdul Mobin Hero', '2019-12-18 20:37:24', 1),
(1086, 'P01086', 'WLED-PR13WB22 /PR13WE27-Premium-13W Walton LED Light', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:30:35', 'Abdul Mobin Hero', '2019-12-18 20:31:15', 1),
(1087, 'P01087', 'WLED-PR-WR11WB22-11W Walton LED Light', 1, 0, 0, 'na', 0, 0, '285.00', '285.00', '0.00', '285.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:30:58', 'Abdul Mobin Hero', '2019-12-18 20:30:26', 1),
(1088, 'P01088', 'WLED-WR11WE27-Premium-11W Warm Walton LED Light', 1, 0, 0, 'na', 0, 0, '285.00', '285.00', '0.00', '285.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:31:30', 'Abdul Mobin Hero', '2019-12-18 20:30:12', 1),
(1089, 'P01089', 'WLED-PR-WR12WB22-12W Walton LED Light', 1, 0, 0, 'na', 0, 0, '295.00', '295.00', '0.00', '295.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:31:53', 'Abdul Mobin Hero', '2019-12-18 20:29:37', 1),
(1090, 'P01090', 'WLED-WR12WE2-Premium-12W Warm Walton LED Light', 1, 0, 0, 'na', 0, 0, '295.00', '295.00', '0.00', '295.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:32:09', 'Abdul Mobin Hero', '2019-12-18 20:29:20', 1),
(1091, 'P01091', 'WLED-PR-WR13WB22-13W Walton LED Light', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:32:25', 'Abdul Mobin Hero', '2019-12-18 20:28:57', 1),
(1092, 'P01092', 'WLED-WR13WE27-Premium-13W Warm Walton LED Light', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:32:45', 'Abdul Mobin Hero', '2019-12-18 20:28:42', 1),
(1093, 'P01093', 'WLED-PR--Premium-13W Warm Walton LED Light', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:33:22', 'Abdul Mobin Hero', '2019-12-18 20:26:34', 1),
(1094, 'P01094', 'WLED-UL3WB22/ WLED-UL3WE27-HIL Walton LED Light', 1, 0, 0, 'na', 0, 0, '140.00', '140.00', '0.00', '140.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:33:45', 'Abdul Mobin Hero', '2019-12-18 20:24:55', 1),
(1095, 'P01095', 'WLED-UL5WB22/WLED-UL5WE27-HIL Walton LED Light', 1, 0, 0, 'na', 0, 0, '160.00', '160.00', '0.00', '160.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:34:03', 'Abdul Mobin Hero', '2019-12-18 20:23:52', 1),
(1096, 'P01096', 'WLED-UL7WB22/ UL7WE27-Premium-7W-Ultra Walton LED Light', 1, 0, 0, 'na', 0, 0, '160.00', '160.00', '0.00', '160.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:34:25', 'Abdul Mobin Hero', '2019-12-18 20:21:43', 1),
(1097, 'P01097', 'WLED-UL9WB22/ UL9WE27-Premium-9W-Ultra Walton LED Light', 1, 0, 0, 'na', 0, 0, '225.00', '225.00', '0.00', '225.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:35:37', 'Admin', '2019-12-18 12:14:27', 1),
(1098, 'P01098', 'WLED-UL12WB22/ UL12WE27-Premium-12W-Ultra Walton LED Light', 1, 0, 0, 'na', 0, 0, '255.00', '255.00', '0.00', '255.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:35:53', 'Admin', '2019-12-18 12:14:03', 1),
(1099, 'P01099', 'WLED-UL15WB22/WLED-UL15WE27-15W Walton LED Light', 1, 0, 0, 'na', 0, 0, '280.00', '280.00', '0.00', '280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:36:13', 'Admin', '2019-12-18 12:13:04', 1),
(1100, 'P01100', 'WLED-UL18WB22/WLED-UL18WE27-18W Walton LED Light', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:36:47', 'Admin', '2019-12-18 12:12:42', 1),
(1101, 'P01101', 'WLED-HP14WB22/ WLED-HP14WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '300.00', '300.00', '0.00', '300.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:37:08', 'Admin', '2019-12-18 12:08:59', 1),
(1102, 'P01102', 'WLED-HP15WB22/ HP15WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '325.00', '325.00', '0.00', '325.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:37:26', 'Admin', '2019-12-18 12:08:27', 1),
(1103, 'P01103', 'WLED-GL18WB22/WLED-GL18WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '490.00', '490.00', '0.00', '490.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:37:40', 'Admin', '2019-12-18 12:07:41', 1),
(1104, 'P01104', 'WLED-HP20WB22/ HP20WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '390.00', '390.00', '0.00', '390.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:37:56', 'Admin', '2019-12-18 12:05:48', 1),
(1105, 'P01105', 'WLED-HP30WB22/ HP30WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '595.00', '595.00', '0.00', '595.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:38:15', 'Admin', '2019-12-18 12:06:04', 1),
(1106, 'P01106', 'WLED-HP40WB22/ HP40WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '760.00', '760.00', '0.00', '760.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:38:30', 'Abdul Mobin Hero', '2019-12-18 20:20:39', 1),
(1107, 'P01107', 'WLED-HP-WR30WB22/ WR30WE27-Warm Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '595.00', '595.00', '0.00', '595.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:39:02', 'Abdul Mobin Hero', '2019-12-18 20:20:16', 1),
(1108, 'P01108', 'WLED-HP-WR40WE27-Warm Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '760.00', '760.00', '0.00', '760.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:39:51', 'Abdul Mobin Hero', '2019-12-18 20:18:44', 1),
(1109, 'P01109', 'WLED-HP50WB22/ HP50WE27-Prime Series Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '1060.00', '1060.00', '0.00', '1060.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:40:07', 'Abdul Mobin Hero', '2019-12-18 20:17:18', 1),
(1110, 'P01110', 'WLED-HP-WR50WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '1060.00', '1060.00', '0.00', '1060.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:40:28', 'Abdul Mobin Hero', '2019-12-18 20:16:11', 1),
(1111, 'P01111', 'WLED-HP3WB22/WLED-HP3WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '595.00', '595.00', '0.00', '595.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:40:51', 'Abdul Mobin Hero', '2019-12-18 20:14:44', 1),
(1112, 'P01112', 'WLED-HP5WB22/WLED-HP5WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '160.00', '160.00', '0.00', '160.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:41:15', 'Abdul Mobin Hero', '2019-12-18 20:13:43', 1),
(1113, 'P01113', 'WLED-HP7WB22/WLED-HP7WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '225.00', '225.00', '0.00', '225.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:43:05', 'Abdul Mobin Hero', '2019-12-18 20:13:07', 1),
(1114, 'P01114', 'WLED-HP9WB22/WLED-HP9WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '235.00', '235.00', '0.00', '235.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:43:26', 'Abdul Mobin Hero', '2019-12-18 20:12:25', 1),
(1115, 'P01115', 'WLED-HP12WB22/WLED-HP12WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '275.00', '275.00', '0.00', '275.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:43:52', 'Abdul Mobin Hero', '2019-12-18 20:11:12', 1),
(1116, 'P01116', 'WLED-HP60WE27/ WLED-HP-WR60WE27 Walton High Power Led Light', 1, 0, 0, 'na', 0, 0, '1150.00', '1150.00', '0.00', '1150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:45:05', 'Abdul Mobin Hero', '2019-12-18 20:09:58', 1),
(1117, 'P01117', 'WLED-T5Tube-60WMB-8W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '410.00', '410.00', '0.00', '410.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:45:38', 'Abdul Mobin Hero', '2019-12-18 20:08:45', 1),
(1118, 'P01118', 'WLED-T5Tube-60WMB-10W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '420.00', '420.00', '0.00', '420.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:46:20', 'Abdul Mobin Hero', '2019-12-18 20:08:10', 1),
(1119, 'P01119', 'WLED-T5NANO-1F-10W-(Nano) Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '280.00', '280.00', '0.00', '280.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:46:48', 'Abdul Mobin Hero', '2019-12-18 20:07:35', 1),
(1120, 'P01120', 'WLED-T5NANO-2F-20W-(Nano) Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '400.00', '400.00', '0.00', '400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:47:18', 'Abdul Mobin Hero', '2019-12-18 20:07:07', 1),
(1121, 'P01121', 'WLED-T5Tube-120WMB-16W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '640.00', '640.00', '0.00', '640.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:47:47', 'Abdul Mobin Hero', '2019-12-18 20:06:08', 1),
(1122, 'P01122', 'WLED-T5Tube-120WMB-18W Waltion Wall Mounted Tube Light1', 1, 0, 0, 'na', 0, 0, '650.00', '650.00', '0.00', '650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:48:39', 'Abdul Mobin Hero', '2019-12-18 20:05:11', 1),
(1123, 'P01123', 'WLED-T5Tube-120WMB-20W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '690.00', '690.00', '0.00', '690.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:49:05', 'Abdul Mobin Hero', '2019-12-18 20:04:48', 1),
(1124, 'P01124', 'WLED-T8Tube-60WMB-8W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '430.00', '430.00', '0.00', '430.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:49:52', 'Abdul Mobin Hero', '2019-12-18 20:03:40', 1),
(1125, 'P01125', 'WLED-T8Tube-60WMB-10W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '440.00', '440.00', '0.00', '440.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:50:15', 'Abdul Mobin Hero', '2019-12-18 20:03:25', 1),
(1126, 'P01126', 'WLED-T8Tube-120WMB-18W Waltion Wall Mounted Tube Light', 1, 0, 0, 'na', 0, 0, '650.00', '650.00', '0.00', '650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:50:46', 'Abdul Mobin Hero', '2019-12-18 20:02:32', 1),
(1127, 'P01127', 'WLED-T8Tube-60FMR-8W Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '420.00', '420.00', '0.00', '420.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:51:10', 'Abdul Mobin Hero', '2019-12-18 20:01:44', 1),
(1128, 'P01128', 'WlLED-T8Tube-60FMR-10W Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '440.00', '440.00', '0.00', '440.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:51:28', 'Abdul Mobin Hero', '2019-12-18 20:01:10', 1),
(1129, 'P01129', 'WLED-T8Tube-120FMR-16 Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '690.00', '690.00', '0.00', '690.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:51:53', 'Abdul Mobin Hero', '2019-12-18 20:00:42', 1),
(1130, 'P01130', 'WLED-T8Tube-120FMR-18W Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '700.00', '700.00', '0.00', '700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:52:16', 'Abdul Mobin Hero', '2019-12-18 19:59:50', 1),
(1131, 'P01131', 'WLED-T8Tube-120FMR-20W Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '725.00', '725.00', '0.00', '725.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:52:41', 'Abdul Mobin Hero', '2019-12-18 19:59:00', 1),
(1132, 'P01132', 'WLED-T8TUBE-E120FMR-20W(Economic Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '450.00', '450.00', '0.00', '450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:52:59', 'Abdul Mobin Hero', '2019-12-18 19:57:52', 1),
(1133, 'P01133', 'WLED-T8TUBE-UL4F20W-T8 Round Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '500.00', '500.00', '0.00', '500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:53:17', 'Abdul Mobin Hero', '2019-12-18 19:53:13', 1),
(1134, 'P01134', 'WLED-T5TUBE-UL4F20W-T5 Round Walton LED Tube Light', 1, 0, 0, 'na', 0, 0, '485.00', '485.00', '0.00', '485.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:53:35', 'Abdul Mobin Hero', '2019-12-18 19:52:54', 1),
(1135, 'P01135', 'WLED-T5BAT-10W  Walton T5 Batten Led Tube Light', 1, 0, 0, 'na', 0, 0, '320.00', '320.00', '0.00', '320.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:53:52', 'Abdul Mobin Hero', '2019-12-18 19:52:24', 1),
(1136, 'P01136', 'WLED-T5BAT-18W Walton T5 Batten Led Tube Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:54:13', '', '', 1),
(1137, 'P01137', 'WLED-T5BAT-20W  Walton T5 Batten Led Tube Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:55:00', '', '', 1),
(1138, 'P01138', 'WLED-CL-20W Walton Ceiling Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:55:24', '', '', 1),
(1139, 'P01139', 'WLED-ML-18W Walton Mirror Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:55:45', '', '', 1),
(1140, 'P01140', 'WLED-T8TUBE-COMP2F-9W  Walton Light-Round (Compact Light)', 1, 0, 0, 'na', 0, 2, '2.00', '2.00', '0.00', '2.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:56:12', '', '', 1),
(1141, 'P01141', 'WLED-T8TUBE-COMP4F-18W Walton Light-Round (Compact Light)', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:56:38', '', '', 1),
(1142, 'P01142', 'WLED-DTDL1F-9W walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:57:00', '', '', 1),
(1143, 'P01143', 'WLED-DTDL1F-18W walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:57:23', '', '', 1),
(1144, 'P01144', 'WLED-DTDL2F-18W walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 0, '650.00', '650.00', '0.00', '650.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:57:58', 'Admin', '2019-12-17 19:29:25', 1),
(1145, 'P01145', 'WLED-DTDL2F-18W- walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 0, '650.00', '950.00', '0.00', '950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:58:30', 'Admin', '2019-12-17 19:28:46', 1),
(1146, 'P01146', 'WLED-NANO-DTDL2F-36W (Nano) walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:58:55', '', '', 1),
(1147, 'P01147', 'WLED-NANO-DTDL1F-18W-36w(Nano) walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:59:21', '', '', 1),
(1148, 'P01148', 'WLED-DTDL-36W walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 17:59:45', '', '', 1),
(1149, 'P01149', 'WLED-DPL2F2-PR48W walton Double Tube Decorative Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:00:31', '', '', 1),
(1150, 'P01150', 'WLED-T8-STALIS-120-Led Single Walton LED Tube Industrial Shade(Without Carton)', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:00:55', '', '', 1),
(1151, 'P01151', 'WLED-T8-STALISWC-120(With Carton) Walton LED Tube Industrial Shade(Without Carton)', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:01:15', '', '', 1),
(1152, 'P01152', 'WLED-T8-DTALIS-120-Led Double Walton LED Tube Industrial Shade(Without Carton)', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:01:34', '', '', 1);
INSERT INTO `tbl_product` (`Product_SlNo`, `Product_Code`, `Product_Name`, `ProductCategory_ID`, `color`, `brand`, `size`, `vat`, `Product_ReOrederLevel`, `Product_Purchase_Rate`, `Product_SellingPrice`, `Product_MinimumSellingPrice`, `Product_WholesaleRate`, `one_cartun_equal`, `is_service`, `Unit_ID`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Product_branchid`) VALUES
(1153, 'P01153', 'WLED-T8-DTALISWC-120(With Carton) Walton LED Tube Industrial Shade(Without Carton)', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '1.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:01:51', '', '', 1),
(1154, 'P01154', 'WLED-ML-F-0.5WB22-HIL walton Moon Light', 1, 0, 0, 'na', 0, 1, '1.00', '1.00', '0.00', '2.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:02:08', '', '', 1),
(1155, 'P01155', 'WLED-ML-F-0.5WE27-HIL walton Moon Light', 1, 0, 0, 'na', 0, 2, '2.00', '2.00', '0.00', '2.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:02:33', '', '', 1),
(1156, 'P01156', 'WLED-EL7WB22 / WLED-EL7WE27 Walton Led Emergency Light', 1, 0, 0, 'na', 0, 0, '320.00', '320.00', '0.00', '320.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:03:02', 'Admin', '2019-12-17 19:23:48', 1),
(1157, 'P01157', 'WLED-EL9WB22 / WLED-EL9WE27 Walton Led Emergency Light', 1, 0, 0, 'na', 0, 0, '360.00', '360.00', '0.00', '360.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:03:28', 'Admin', '2019-12-17 19:23:24', 1),
(1158, 'P01158', 'WLED-EL12WB22 / WLED-EL12WE27 Walton Led Emergency Light', 1, 0, 0, 'na', 0, 0, '400.00', '400.00', '0.00', '400.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:03:49', 'Admin', '2019-12-17 19:22:19', 1),
(1159, 'P01159', 'WLED-EL-10WB22 / WLED-EL-10WE27-H Walton Led Emergency Light', 1, 0, 0, 'na', 0, 0, '550.00', '550.00', '0.00', '550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:05:01', 'Admin', '2019-12-17 19:20:45', 1),
(1160, 'P01160', 'WLED-PL-ECO-24W Economy-24W walton LED Panel Light-Economy', 1, 0, 0, 'na', 0, 1, '1350.00', '1350.00', '0.00', '1350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:05:24', 'Admin', '2019-12-17 19:18:53', 1),
(1161, 'P01161', 'WLED-PL-ECO-36W Economy-36W walton LED Panel Light-Economy', 1, 0, 0, 'na', 0, 1, '2950.00', '2950.00', '0.00', '2950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:05:52', 'Admin', '2019-12-17 19:17:50', 1),
(1162, 'P01162', 'WLED-PL-ECO-48W Economy-48W walton LED Panel Light-Economy', 1, 0, 0, 'na', 0, 1, '3350.00', '3350.00', '0.00', '3350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:06:14', 'Admin', '2019-12-17 19:17:15', 1),
(1163, 'P01163', 'WLED-PL2F1-ECO-36W walton LED Panel Light-Economy', 1, 0, 0, 'na', 0, 1, '2600.00', '2600.00', '0.00', '2600.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:06:42', 'Admin', '2019-12-17 19:16:28', 1),
(1164, 'P01164', 'WLED-PL-ECO-RFC-36W walton LED Panel Light-Economy1', 1, 0, 0, 'na', 0, 1, '5500.00', '5500.00', '0.00', '5500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:07:11', 'Admin', '2019-12-17 19:16:02', 1),
(1165, 'P01165', 'WLED-FL-PR-30W Walton Flood Light', 1, 0, 0, 'na', 0, 1, '2100.00', '2100.00', '0.00', '2100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:07:40', 'Admin', '2019-12-17 19:15:05', 1),
(1166, 'P01166', 'WLED-FL-PR-50W Walton Flood Light', 1, 0, 0, 'na', 0, 1, '2700.00', '2700.00', '0.00', '2700.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:08:08', 'Admin', '2019-12-17 19:13:15', 1),
(1167, 'P01167', 'WLED-FL-PR-80W Walton Flood Light', 1, 0, 0, 'na', 0, 1, '5800.00', '5800.00', '0.00', '5800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:08:31', 'Admin', '2019-12-17 19:12:49', 1),
(1168, 'P01168', 'WLED-FL-PR-100W Walton Flood Light', 1, 0, 0, 'na', 0, 1, '7000.00', '7000.00', '0.00', '7000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:08:53', 'Admin', '2019-12-17 19:12:06', 1),
(1169, 'P01169', 'WLED-FL-PR-150W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '9500.00', '9500.00', '0.00', '9500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:09:18', 'Admin', '2019-12-17 19:11:48', 1),
(1170, 'P01170', 'WLED-FL-PR-200W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '13500.00', '13500.00', '0.00', '13500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:09:40', 'Admin', '2019-12-17 19:11:28', 1),
(1171, 'P01171', 'WLED-FL-COB-50W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '2900.00', '2900.00', '0.00', '2900.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:10:13', 'Admin', '2019-12-17 19:10:37', 1),
(1172, 'P01172', 'WLED-FL-COB-100W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '6500.00', '6500.00', '0.00', '6500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:10:49', 'Admin', '2019-12-17 19:09:14', 1),
(1173, 'P01173', 'WLED-FL-COB-150W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '10500.00', '10500.00', '0.00', '10500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:11:14', 'Admin', '2019-12-17 19:08:41', 1),
(1174, 'P01174', 'WLED-FL-COB-200W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '13000.00', '13000.00', '0.00', '13000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:11:36', 'Admin', '2019-12-17 19:08:12', 1),
(1175, 'P01175', 'WLED-FL-SMD-20W  Walton Flood Light', 1, 0, 0, 'na', 0, 0, '1250.00', '1250.00', '0.00', '1250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:12:10', 'Admin', '2019-12-17 19:07:28', 1),
(1176, 'P01176', 'WLED-FL-SMD-30W  Walton Flood Light', 1, 0, 0, 'na', 0, 0, '1800.00', '1800.00', '0.00', '1800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:12:32', 'Admin', '2019-12-17 19:06:05', 1),
(1177, 'P01177', 'WLED-FL-SMD-50W  Walton Flood Light', 1, 0, 0, 'na', 0, 0, '2500.00', '2500.00', '0.00', '2500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:12:51', 'Admin', '2019-12-17 19:05:44', 1),
(1178, 'P01178', 'WLED-FL-SMD-100W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '4500.00', '4500.00', '0.00', '4500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:13:09', 'Admin', '2019-12-17 19:05:12', 1),
(1179, 'P01179', 'WLED-FL-SMD-150W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '9000.00', '9000.00', '0.00', '9000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:13:28', 'Admin', '2019-12-17 19:04:44', 1),
(1180, 'P01180', 'WLED-FL-SMD-200W Walton Flood Light', 1, 0, 0, 'na', 0, 0, '11000.00', '11000.00', '0.00', '11000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:13:48', 'Admin', '2019-12-17 19:03:55', 1),
(1181, 'P01181', 'WLED-DLS120-UL6W-Ultra walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '340.00', '340.00', '0.00', '340.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:14:07', 'Admin', '2019-12-17 19:01:57', 1),
(1182, 'P01182', 'WLED-DLR145-UL9W-Ultra walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '390.00', '390.00', '0.00', '390.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:14:32', 'Admin', '2019-12-17 19:01:26', 1),
(1183, 'P01183', 'WLED-DLR170-UL12W-Ultra walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '530.00', '530.00', '0.00', '530.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:15:04', 'Admin', '2019-12-17 19:00:28', 1),
(1184, 'P01184', 'WLED-DLR170(PR12W/ WR12W) walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '590.00', '590.00', '0.00', '590.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:15:51', 'Admin', '2019-12-17 18:59:27', 1),
(1185, 'P01185', 'WLED-DLS200-UL15W-Ultra walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '630.00', '630.00', '0.00', '630.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:16:11', 'Admin', '2019-12-17 18:59:07', 1),
(1186, 'P01186', 'WLED-DLR225-UL18W-Ultra walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '690.00', '690.00', '0.00', '690.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:16:38', 'Admin', '2019-12-17 18:57:16', 1),
(1187, 'P01187', 'WLED-DLS200(PR15W/ WR15W) walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '690.00', '690.00', '0.00', '690.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:17:24', 'Admin', '2019-12-17 18:56:58', 1),
(1188, 'P01188', 'WLED-DLR225(PR18W/ WR18W) walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '750.00', '750.00', '0.00', '750.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:18:37', 'Admin', '2019-12-17 18:55:27', 1),
(1189, 'P01189', 'WLED-DLR300(PR24W/ WR24W) walton LED Down Light/  WARM  Down Light', 1, 0, 0, 'na', 0, 0, '1125.00', '1125.00', '0.00', '1125.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:19:27', 'Admin', '2019-12-17 18:54:46', 1),
(1190, 'P01190', 'WLED-PL1F1-PR12W walton LED Panel Light', 1, 0, 0, 'na', 0, 0, '1450.00', '1450.00', '0.00', '1450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:20:35', 'Admin', '2019-12-17 18:53:48', 1),
(1191, 'P01191', 'WLED-PL1F1-PR24W walton LED Panel Light', 1, 0, 0, 'na', 0, 0, '1950.00', '1950.00', '0.00', '1950.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:20:55', 'Admin', '2019-12-17 18:53:03', 1),
(1192, 'P01192', 'WLED-PL2F2-PR36W walton LED Panel Light', 1, 0, 0, 'na', 0, 0, '3800.00', '3800.00', '0.00', '3800.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:21:16', 'Admin', '2019-12-17 17:50:57', 1),
(1193, 'P01193', 'WLED-PL2F2-PR48W walton LED Panel Light', 1, 0, 0, 'na', 0, 0, '4100.00', '4100.00', '0.00', '4100.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:21:35', 'Admin', '2019-12-17 17:49:39', 1),
(1194, 'P01194', 'WLED-SPLS120-UL6W-Ultra Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '350.00', '350.00', '0.00', '350.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:22:04', 'Admin', '2019-12-17 17:48:01', 1),
(1195, 'P01195', 'WLED-SPLR145-UL9W Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '390.00', '390.00', '0.00', '390.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:22:23', 'Admin', '2019-12-17 17:47:05', 1),
(1196, 'P01196', 'WLED-SPLR170-UL12W-Ultra Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '540.00', '540.00', '0.00', '540.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:22:40', 'Admin', '2019-12-17 17:43:33', 1),
(1197, 'P01197', 'WLED-SPLS200-UL15W-Ultra Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '670.00', '670.00', '0.00', '670.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:22:55', 'Admin', '2019-12-17 17:42:41', 1),
(1198, 'P01198', 'WLED-SPLR225-UL18W-Ultra Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '720.00', '720.00', '0.00', '720.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:23:36', 'Admin', '2019-12-17 17:41:33', 1),
(1199, 'P01199', 'WLED-SPL170-12W Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '620.00', '620.00', '0.00', '620.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:23:55', 'Admin', '2019-12-17 17:40:46', 1),
(1200, 'P01200', 'WLED-SPL200-15W Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '760.00', '760.00', '0.00', '760.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:24:21', 'Admin', '2019-12-17 17:39:59', 1),
(1201, 'P01201', 'WLED-SPL225-18W Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '825.00', '825.00', '0.00', '825.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:24:48', 'Admin', '2019-12-17 17:39:11', 1),
(1202, 'P01202', 'WLED-SPLR300-UL24W Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '1150.00', '1150.00', '0.00', '1150.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:25:15', 'Admin', '2019-12-17 17:37:40', 1),
(1203, 'P01203', 'WLED-SL-2G-12W-LED 2-Grid Walton Surface Panel Light', 1, 0, 0, 'na', 0, 0, '500.00', '500.00', '0.00', '500.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:25:35', 'Admin', '2019-12-17 17:36:13', 1),
(1204, 'P01204', 'TB-12WB22/WLED-TB-12WE27 walton T-Rotating Bulb', 1, 0, 0, 'na', 0, 0, '295.00', '295.00', '0.00', '295.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:25:50', 'Admin', '2019-12-17 17:44:12', 1),
(1205, 'P01205', 'Walton Laptop WP157U3G', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:26:09', 'Admin', '2019-12-17 17:34:42', 1),
(1206, 'P01206', 'Walton Laptop - WPR14N34GR', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:26:38', '', '', 1),
(1207, 'P01207', 'Walton (Gaming Keyboard) -  WKG009WB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:26:57', '', '', 1),
(1208, 'P01208', 'Walton  WKG007WB (Gaming Keyboard)', 113, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:27:16', 'Admin', '2019-12-16 19:20:28', 1),
(1209, 'P01209', 'Walton Wireless Router 300Mbps - WWR001N2', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:27:55', '', '', 1),
(1210, 'P01210', 'Walton   WMS005WN (Wired Optical Mouse)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:28:15', '', '', 1),
(1211, 'P01211', 'Walton Mouse WMS009WN', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:28:30', '', '', 1),
(1212, 'P01212', 'Walton Mouse WMS016WB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:28:47', '', '', 1),
(1213, 'P01213', 'Walton Micro SD Card- WSD01601 (16 GB)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:29:09', '', '', 1),
(1214, 'P01214', 'Walton Micro SD Card - WSD03201 (32 GB)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:29:50', '', '', 1),
(1215, 'P01215', 'WALTON pendrive - WU3016P027', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:30:09', '', '', 1),
(1216, 'P01216', 'WALTON Pendrive - WU3032P027', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:30:44', '', '', 1),
(1217, 'P01217', 'WALTON pendrive-WU2016P026', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:31:09', '', '', 1),
(1218, 'P01218', 'WALTON pendrive-WU2032P026', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:31:27', '', '', 1),
(1219, 'P01219', 'WALTON PENDRIVE (WO2016P012 )', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:31:44', '', '', 1),
(1220, 'P01220', 'WALTON Pendrive - WO2032P012', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:32:03', '', '', 1),
(1221, 'P01221', 'WALTON Pendrive-WU16P007', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:32:17', '', '', 1),
(1222, 'P01222', 'WALTON PENDRIVE (WU3016P011 )', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:32:36', '', '', 1),
(1223, 'P01223', 'WALTON pendrive - WU3016P027-', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:32:55', '', '', 1),
(1224, 'P01224', 'Walton Pendrive (WU3016P008)', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:33:09', '', '', 1),
(1225, 'P01225', 'WALTON PENDRIVE ( WU2016P013 )', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:33:24', '', '', 1),
(1226, 'P01226', '-WALTON pendrive-WU2032P026', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:33:42', '', '', 1),
(1227, 'P01227', 'WALTON Pendrive-WU2032P013', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:33:55', '', '', 1),
(1228, 'P01228', 'Walton Pendrive-WU2032P027-32GBWaltom Pendreb-WU2016P027-16GB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:34:42', '', '', 1),
(1229, 'P01229', 'Walton Earphone', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:35:05', '', '', 1),
(1230, 'P01230', 'WES2P4E-White Walton USB', 1, 0, 0, 'na', 0, 0, '0.00', '0.00', '0.00', '0.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:35:24', '', '', 1),
(1231, 'P01231', 'WGS-GSLH1 LPG Walton Glass Gas Stove', 31, 0, 0, 'na', 0, 0, '3000.00', '3000.00', '0.00', '3000.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:35:38', 'Admin', '2019-12-16 19:07:25', 1),
(1232, 'P01232', 'WGS-GSLS1 LPG Walton Glass Gas Stove', 31, 0, 0, 'na', 0, 0, '2990.00', '2990.00', '0.00', '2990.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:36:09', 'Admin', '2019-12-16 19:07:16', 1),
(1233, 'P01233', 'WGS-GSHC2 LPG Walton Glass Gas Stove', 31, 0, 0, 'na', 0, 0, '3250.00', '3250.00', '0.00', '3250.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:36:28', 'Admin', '2019-12-16 19:07:06', 1),
(1234, 'P01234', 'WGS-GSC1 LPG Walton Glass Gas Stove', 31, 0, 0, 'na', 0, 0, '3550.00', '3550.00', '0.00', '3550.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:36:46', 'Admin', '2019-12-16 19:06:46', 1),
(1235, 'P01235', 'WGS- DSC2 Doublr Burner  Walton Gas Stove', 31, 0, 0, 'na', 0, 0, '2450.00', '2450.00', '0.00', '2450.00', '', 'false', 1, 'a', 'Abdul Mobin Hero', '2019-12-16 18:37:56', 'Admin', '2019-12-16 19:06:36', 1),
(1236, 'P01236', 'OK-ODW15A ORIGIN Electric Kettle', 116, 0, 0, 'na', 0, 0, '990.00', '990.00', '0.00', '990.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:33:02', 'Admin', '2019-12-24 11:33:57', 1),
(1237, 'P01237', 'OIR-OD01 ORIGIN IRON ', 116, 0, 0, 'na', 0, 950, '950.00', '950.00', '0.00', '950.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:35:09', '', '', 1),
(1238, 'P01238', 'OMB-K01 ORIGIN MOSQUITO', 116, 0, 0, 'na', 0, 0, '430.00', '430.00', '0.00', '430.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:36:23', '', '', 1),
(1239, 'P01239', 'OVF-FJ30GM ORIGIN VACUUN FLASK', 116, 0, 0, 'na', 0, 0, '1500.00', '1500.00', '0.00', '1500.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:39:25', '', '', 1),
(1240, 'P01240', 'GV10GM ORIGIN VACUUN FLASK', 116, 0, 0, 'na', 0, 0, '690.00', '690.00', '0.00', '690.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:40:31', '', '', 1),
(1241, 'P01241', 'OD10GM ORIGIN VACUUN FLASK', 116, 0, 0, 'na', 0, 0, '100.00', '850.00', '0.00', '850.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:42:59', '', '', 1),
(1242, 'P01242', 'OVF-W350Y8 350ML ORIGIN VACUUN FLASK', 116, 0, 0, 'na', 0, 0, '470.00', '470.00', '0.00', '470.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:44:17', 'Admin', '2019-12-24 11:45:11', 1),
(1243, 'P01243', 'OVF-W500Y8 500ML ORIGIN VACUUN FLASK', 116, 0, 0, 'na', 0, 0, '520.00', '520.00', '0.00', '520.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:46:05', '', '', 1),
(1244, 'P01244', 'OIWH- AH30T2 ORIGIN INSTANT WATER HEATER ', 116, 0, 0, 'na', 0, 0, '2800.00', '2800.00', '0.00', '2800.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:48:21', 'Admin', '2019-12-24 11:50:39', 1),
(1245, 'P01245', 'OIWH- AH30T4 ORIGIN INSTANT WATER HEATER	', 116, 0, 0, 'na', 0, 0, '3300.00', '3300.00', '0.00', '3300.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:49:04', '', '', 1),
(1246, 'P01246', 'OGS-CBL1 LPG  GAS STOVE ORIGIN COMMERCIAL', 116, 0, 0, 'na', 0, 0, '2760.00', '2760.00', '0.00', '2760.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:52:58', '', '', 1),
(1247, 'P01247', 'OGS-CBS1 LPG GAS STOVE ORIGIN COMMERCIAL', 116, 0, 0, 'na', 0, 0, '2260.00', '2260.00', '0.00', '2260.00', '', 'false', 1, 'a', 'Admin', '2019-12-24 11:53:41', '', '', 1),
(1248, 'P01248', 'iphone 6', 2, 0, 0, 'na', 0, 1, '1000.00', '1500.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-25 11:07:36', '', '', 1),
(1249, 'P01249', 'iphone 7', 2, 0, 0, 'na', 0, 1, '1000.00', '1500.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-25 11:08:00', '', '', 1),
(1250, 'P01250', 'iphone1', 6, 0, 0, 'na', 0, 1, '1000.00', '1200.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-25 14:32:10', '', '', 1),
(1251, 'P01251', 'iphone2', 46, 0, 0, 'na', 0, 1, '1000.00', '1300.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-25 14:32:40', '', '', 1),
(1252, 'P01252', 'test1', 1, 0, 0, 'na', 0, 1, '1000.00', '1001.00', '0.00', '0.00', '', 'false', 1, 'a', 'Admin', '2019-12-25 20:16:49', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_productcategory`
--

DROP TABLE IF EXISTS `tbl_productcategory`;
CREATE TABLE IF NOT EXISTS `tbl_productcategory` (
  `ProductCategory_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `ProductCategory_Name` varchar(150) NOT NULL,
  `ProductCategory_Description` varchar(300) NOT NULL,
  `status` char(1) NOT NULL,
  `AddBy` varchar(50) NOT NULL,
  `AddTime` varchar(30) NOT NULL,
  `UpdateBy` varchar(50) NOT NULL,
  `UpdateTime` varchar(30) NOT NULL,
  `category_branchid` int(11) NOT NULL,
  PRIMARY KEY (`ProductCategory_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_productcategory`
--

INSERT INTO `tbl_productcategory` (`ProductCategory_SlNo`, `ProductCategory_Name`, `ProductCategory_Description`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `category_branchid`) VALUES
(1, 'Akash DTH', 'akash dth', 'a', 'Abdul Mobin Hero', '2019-12-15 17:31:37', 'Admin', '2019-12-21 16:40:09', 1),
(2, 'LED Panel Light', '', 'a', 'Admin', '2019-12-15 19:14:02', 'Admin', '2019-12-16 09:59:05', 1),
(3, 'LED Down Light/ WARM Down Light', '', 'a', 'Admin', '2019-12-15 19:14:57', 'Admin', '2019-12-16 09:59:26', 1),
(4, 'T-Rotating Bulb', '', 'a', 'Admin', '2019-12-15 19:16:07', 'Admin', '2019-12-16 09:58:24', 1),
(5, 'Flood Light', '', 'a', 'Admin', '2019-12-15 19:21:15', 'Admin', '2019-12-16 09:59:51', 1),
(6, 'Surface Panel Light ', '', 'a', 'Admin', '2019-12-15 19:22:11', 'Admin', '2019-12-16 09:58:42', 1),
(7, 'STB Combo With Singie LNB Akash Dth', '', 'a', 'Admin', '2019-12-15 19:59:07', '', '', 2),
(8, 'Cable Combo Pack 10 Meter Akash Dth', '', 'a', 'Admin', '2019-12-15 20:01:19', 'Admin', '2019-12-16 13:26:26', 2),
(9, 'Dish with assembly Combo Pack Akash Dth', '', 'a', 'Admin', '2019-12-15 20:03:44', '', '', 2),
(10, 'Connector Indoor / Outdoore Combo Pack Akash Dth ', '', 'a', 'Admin', '2019-12-15 20:05:51', 'Admin', '2019-12-15 20:33:53', 2),
(11, 'Dish with assembly Singie Pack Akash Dth', '', 'a', 'Admin', '2019-12-15 20:07:06', 'Admin', '2019-12-16 21:05:03', 2),
(12, 'LNB SINGLE Combo Pack Akash Dth', '', 'a', 'Admin', '2019-12-15 20:11:55', '', '', 2),
(13, 'Remot STB Combo Pack Akash Dth', '', 'a', 'Admin', '2019-12-15 20:13:49', '', '', 2),
(14, 'STB With Singie Akash Dth', '', 'a', 'Admin', '2019-12-15 20:15:07', '', '', 2),
(15, 'LNB (SINGLE) Akash Dth', '', 'a', 'Admin', '2019-12-15 20:16:01', 'Admin', '2019-12-15 20:21:04', 2),
(16, 'LNB (DUL) Akash Dth', '', 'a', 'Admin', '2019-12-15 20:21:55', '', '', 2),
(17, 'LNB (QUAD) Akash Dth', '', 'a', 'Admin', '2019-12-15 20:22:16', '', '', 2),
(18, 'Direct Cool Refrigerator', '', 'a', 'Admin', '2019-12-16 09:33:22', '', '', 1),
(19, 'Non Frost Refrigerator', '', 'a', 'Admin', '2019-12-16 09:33:37', '', '', 1),
(20, 'Freezer (Deep)', '', 'a', 'Admin', '2019-12-16 09:33:49', 'Admin', '2019-12-16 09:34:13', 1),
(21, 'Beverage Cooler Refrigerator  WALTON', '', 'a', 'Admin', '2019-12-16 09:34:46', 'Admin', '2019-12-21 16:36:31', 1),
(22, 'LED Television', '', 'a', 'Admin', '2019-12-16 09:35:08', '', '', 1),
(23, 'Air-Conditioner  WALTON', '', 'a', 'Admin', '2019-12-16 09:35:25', 'Admin', '2019-12-21 16:36:02', 1),
(24, 'Washing Machine', '', 'a', 'Admin', '2019-12-16 09:35:35', '', '', 1),
(25, 'Generator', '', 'a', 'Admin', '2019-12-16 09:35:47', '', '', 1),
(26, 'Air-Cooler  WALTON', '', 'a', 'Admin', '2019-12-16 09:35:59', 'Admin', '2019-12-21 16:35:22', 1),
(27, 'Room Heater', '', 'a', 'Admin', '2019-12-16 09:36:10', '', '', 1),
(28, 'Water Heater', '', 'a', 'Admin', '2019-12-16 09:36:20', '', '', 1),
(29, 'Air Purifier  WALTON', '', 'a', 'Admin', '2019-12-16 09:36:29', 'Admin', '2019-12-21 16:35:48', 1),
(30, 'Microwave Oven', '', 'a', 'Admin', '2019-12-16 09:36:41', '', '', 1),
(31, 'Gas Stove (NG & LPG) ', '', 'a', 'Admin', '2019-12-16 09:36:51', 'Admin', '2019-12-16 11:13:36', 1),
(32, 'Rice Cooker', '', 'a', 'Admin', '2019-12-16 09:37:00', '', '', 1),
(33, 'Electric Oven', '', 'a', 'Admin', '2019-12-16 09:37:10', '', '', 1),
(34, 'Iron', '', 'a', 'Admin', '2019-12-16 09:37:20', '', '', 1),
(35, 'Electric Lunch Box', '', 'a', 'Admin', '2019-12-16 09:37:32', '', '', 1),
(36, 'Auto Voltage Stabilizer WALTON', '', 'a', 'Admin', '2019-12-16 09:37:50', 'Admin', '2019-12-21 16:36:19', 1),
(37, 'Automatic Voltage Protector  WALTON', '', 'a', 'Admin', '2019-12-16 09:38:00', 'Admin', '2019-12-21 16:37:01', 1),
(38, 'Air-Fryer  WALTON', '', 'a', 'Admin', '2019-12-16 09:38:09', 'Admin', '2019-12-21 16:37:13', 1),
(39, 'Blender  WALTON', '', 'a', 'Admin', '2019-12-16 09:39:48', 'Admin', '2019-12-21 16:36:44', 1),
(40, 'Kitchen Cookware ', '', 'a', 'Admin', '2019-12-16 09:40:01', '', '', 1),
(41, 'Mosquito Bat', '', 'a', 'Admin', '2019-12-16 09:40:10', '', '', 1),
(42, 'Multi Curry Cooker ', '', 'a', 'Admin', '2019-12-16 09:40:20', '', '', 1),
(43, 'Electric Trimmer & Shaver', '', 'a', 'Admin', '2019-12-16 09:40:29', '', '', 1),
(44, 'Walton Hair Dryer', '', 'a', 'Admin', '2019-12-16 09:40:38', 'Admin', '2019-12-22 09:28:57', 1),
(45, 'Hair Straightener', '', 'a', 'Admin', '2019-12-16 09:40:47', '', '', 1),
(46, 'Hair Clipper', '', 'a', 'Admin', '2019-12-16 09:40:56', '', '', 1),
(47, 'Pressure Cooker', '', 'a', 'Admin', '2019-12-16 09:41:08', '', '', 1),
(48, 'Sewing Machine', '', 'a', 'Admin', '2019-12-16 09:41:19', '', '', 1),
(49, 'Sealed Lead Acid Recharge Battery', '', 'a', 'Admin', '2019-12-16 09:41:29', '', '', 1),
(50, 'Donut Plate-Accessories', '', 'a', 'Admin', '2019-12-16 09:41:40', '', '', 1),
(51, 'Water Purifier WALTON', '', 'a', 'Admin', '2019-12-16 09:41:49', 'Admin', '2019-12-21 16:39:08', 1),
(52, 'Water Pump', '', 'a', 'Admin', '2019-12-16 09:42:00', '', '', 1),
(53, 'Water Dispenser', '', 'a', 'Admin', '2019-12-16 09:42:09', '', '', 1),
(54, 'Cake Maker  WALTON', '', 'a', 'Admin', '2019-12-16 09:42:25', 'Admin', '2019-12-21 16:37:46', 1),
(55, 'Body Weight Scale  WALTON', '', 'a', 'Admin', '2019-12-16 09:43:04', 'Admin', '2019-12-21 16:38:20', 1),
(56, 'Price Computing Weight Scale', '', 'a', 'Admin', '2019-12-16 09:43:12', '', '', 1),
(57, 'Toaster', '', 'a', 'Admin', '2019-12-16 09:43:21', '', '', 1),
(58, 'Sandwich Maker ', '', 'a', 'Admin', '2019-12-16 09:43:31', '', '', 1),
(59, 'Vegetable(Salad)Maker  WALTON', '', 'a', 'Admin', '2019-12-16 09:43:48', 'Admin', '2019-12-21 16:35:37', 1),
(60, 'Coffee Maker  WALTON', '', 'a', 'Admin', '2019-12-16 09:48:20', 'Admin', '2019-12-21 16:38:44', 1),
(61, 'Solar Street Light', '', 'a', 'Admin', '2019-12-16 09:48:30', '', '', 1),
(62, 'Hand Mixer', '', 'a', 'Admin', '2019-12-16 09:48:41', '', '', 1),
(63, 'Induction Cooker', '', 'a', 'Admin', '2019-12-16 09:48:49', '', '', 1),
(64, 'Ruti Maker', '', 'a', 'Admin', '2019-12-16 09:48:59', '', '', 1),
(65, 'Vacuum Flask ', '', 'a', 'Admin', '2019-12-16 09:49:08', '', '', 1),
(66, 'Vacuum Cleaner', '', 'a', 'Admin', '2019-12-16 09:49:18', '', '', 1),
(67, 'MOP', '', 'a', 'Admin', '2019-12-16 09:49:30', '', '', 1),
(68, 'Ceiling Fan  WALTON', '', 'a', 'Admin', '2019-12-16 09:49:53', 'Admin', '2019-12-21 16:38:06', 1),
(69, 'Wall Fan', '', 'a', 'Admin', '2019-12-16 09:50:01', '', '', 1),
(70, 'Table Fan', '', 'a', 'Admin', '2019-12-16 09:50:10', '', '', 1),
(71, 'Rechargeable Table Fan', '', 'a', 'Admin', '2019-12-16 09:50:20', '', '', 1),
(72, 'Rechargeable Fan', '', 'a', 'Admin', '2019-12-16 09:50:34', '', '', 1),
(73, 'Pedestal Fan', '', 'a', 'Admin', '2019-12-16 09:50:44', '', '', 1),
(74, 'Exhaust Fan', '', 'a', 'Admin', '2019-12-16 09:50:52', '', '', 1),
(75, 'Pearl White (W1 Series)  WALTON', '', 'a', 'Admin', '2019-12-16 09:51:19', 'Admin', '2019-12-21 16:37:32', 1),
(76, 'Pearl White (A8 Series)', '', 'a', 'Admin', '2019-12-16 09:51:27', '', '', 1),
(77, 'Royal Series-Pearl White', '', 'a', 'Admin', '2019-12-16 09:51:36', '', '', 1),
(78, 'Junction Box', '', 'a', 'Admin', '2019-12-16 09:51:44', '', '', 1),
(79, 'Electric Distribution Box', '', 'a', 'Admin', '2019-12-16 09:51:52', '', '', 1),
(80, 'Metallic Silver / Black / Gold (A8 Series)', '', 'a', 'Admin', '2019-12-16 09:52:01', '', '', 1),
(81, 'Metallic Black/Silver/Gold (W1 Series)', '', 'a', 'Admin', '2019-12-16 09:52:10', '', '', 1),
(82, 'DP Switch', '', 'a', 'Admin', '2019-12-16 09:52:20', '', '', 1),
(83, 'Voltage Tester ', '', 'a', 'Admin', '2019-12-16 09:52:27', '', '', 1),
(84, 'Tube Light-Accessories', '', 'a', 'Admin', '2019-12-16 09:52:35', '', '', 1),
(85, 'Holder(12 Pes Carton)', '', 'a', 'Admin', '2019-12-16 09:52:43', '', '', 1),
(86, 'Fan Regulator(10 Pes Carton)', '', 'a', 'Admin', '2019-12-16 09:52:53', '', '', 1),
(87, 'Pearl White (E4 Series)', '', 'a', 'Admin', '2019-12-16 09:53:05', '', '', 1),
(88, 'Metallic Silver / Black /Gold (E4 Series)', '', 'a', 'Admin', '2019-12-16 09:53:15', '', '', 1),
(89, 'Metallic Black(S3 & V8 Series', '', 'a', 'Admin', '2019-12-16 09:53:26', '', '', 1),
(90, 'Piano Series Switch Socket-Golden/Black/Sky/', '', 'a', 'Admin', '2019-12-16 09:53:49', '', '', 1),
(91, 'Switch Socket(S3 & V8 Series)', '', 'a', 'Admin', '2019-12-16 09:54:11', '', '', 1),
(92, 'Cover Plate(S3 & V8 Series)', '', 'a', 'Admin', '2019-12-16 09:54:21', '', '', 1),
(93, 'S3V8 Series-Pearl White', '', 'a', 'Admin', '2019-12-16 09:54:30', '', '', 1),
(94, 'Cover Plate(S3 & V8 Series)Metallic Black', '', 'a', 'Admin', '2019-12-16 09:54:39', '', '', 1),
(95, 'Switch Socket-Accessories', '', 'a', 'Admin', '2019-12-16 09:54:49', '', '', 1),
(96, 'Circuit Breaker', '', 'a', 'Admin', '2019-12-16 09:55:09', '', '', 1),
(97, 'uPVC Fittings', '', 'a', 'Admin', '2019-12-16 09:55:20', '', '', 1),
(98, 'uPVC Pipe (Electric Conduit)', '', 'a', 'Admin', '2019-12-16 09:55:30', '', '', 1),
(99, 'PVC Tape Hardware and Accessories', '', 'a', 'Admin', '2019-12-16 09:55:42', '', '', 1),
(100, 'LED Light', '', 'a', 'Admin', '2019-12-16 09:55:53', '', '', 1),
(101, 'High Power Led Light', '', 'a', 'Admin', '2019-12-16 09:56:03', '', '', 1),
(102, 'Wall Mounted Tube Light', '', 'a', 'Admin', '2019-12-16 09:56:17', '', '', 1),
(103, 'LED Tube Light', '', 'a', 'Admin', '2019-12-16 09:56:25', '', '', 1),
(104, 'T5 Batten Led Tube Light', '', 'a', 'Admin', '2019-12-16 09:56:36', '', '', 1),
(105, 'Ceiling Light  WALTON', '', 'a', 'Admin', '2019-12-16 09:56:46', 'Admin', '2019-12-21 16:39:40', 1),
(106, 'Mirror Light', '', 'a', 'Admin', '2019-12-16 09:56:53', '', '', 1),
(107, 'Light-Round (Compact Light)', '', 'a', 'Admin', '2019-12-16 09:57:02', '', '', 1),
(108, 'Double Tube Decorative Light', '', 'a', 'Admin', '2019-12-16 09:57:15', '', '', 1),
(109, 'LED Tube Industrial Shade(Without Carton)', '', 'a', 'Admin', '2019-12-16 09:57:26', '', '', 1),
(110, 'Moon Light', '', 'a', 'Admin', '2019-12-16 09:57:37', '', '', 1),
(111, 'Led Emergency Light', '', 'a', 'Admin', '2019-12-16 09:57:51', '', '', 1),
(112, 'LED Panel Light-Economy ', '', 'a', 'Admin', '2019-12-16 10:00:08', '', '', 1),
(113, 'Electric Kettle', '', 'a', 'Admin', '2019-12-16 19:19:55', '', '', 1),
(114, 'Lamp & Torch', '', 'a', 'Admin', '2019-12-16 19:59:07', '', '', 1),
(115, 'Marcel Gas Stove', '', 'a', 'Admin', '2019-12-21 16:33:47', '', '', 1),
(116, 'ORIGIN  GROUP', '', 'a', 'Admin', '2019-12-24 11:27:20', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_serial_numbers`
--

DROP TABLE IF EXISTS `tbl_product_serial_numbers`;
CREATE TABLE IF NOT EXISTS `tbl_product_serial_numbers` (
  `ps_id` int(11) NOT NULL AUTO_INCREMENT,
  `ps_prod_id` int(11) NOT NULL DEFAULT '0',
  `ps_imei_number` varchar(100) DEFAULT NULL,
  `ps_purchase_inv` varchar(255) DEFAULT NULL,
  `ps_purchase_supp_id` int(11) NOT NULL DEFAULT '0',
  `ps_s_status` enum('yes','no') NOT NULL DEFAULT 'no',
  `ps_s_r_status` enum('yes','no') NOT NULL DEFAULT 'no',
  `ps_s_r_amount` double NOT NULL DEFAULT '0',
  `ps_s_discount` float NOT NULL DEFAULT '0',
  `ps_p_status` enum('yes','no') NOT NULL DEFAULT 'no',
  `ps_p_r_status` enum('yes','no') NOT NULL DEFAULT 'no',
  `ps_p_r_amount` double DEFAULT '0',
  `ps_sale_date` varchar(20) DEFAULT NULL,
  `ps_brunch_id` int(11) NOT NULL DEFAULT '0',
  `ps_add_by` int(11) NOT NULL DEFAULT '0',
  `ps_update_by` int(11) NOT NULL DEFAULT '0',
  `ps_status` enum('a','d') NOT NULL DEFAULT 'a',
  `sales_details_id` int(11) NOT NULL DEFAULT '0',
  `purchase_details_id` int(11) NOT NULL DEFAULT '0',
  `purchase_rate` float NOT NULL DEFAULT '0',
  `purchase_discount` float NOT NULL DEFAULT '0',
  `purchase_total` float NOT NULL DEFAULT '0',
  `purchase_date` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ps_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchasedetails`
--

DROP TABLE IF EXISTS `tbl_purchasedetails`;
CREATE TABLE IF NOT EXISTS `tbl_purchasedetails` (
  `PurchaseDetails_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `PurchaseMaster_IDNo` int(11) NOT NULL,
  `Product_IDNo` int(11) NOT NULL,
  `PurchaseDetails_TotalQuantity` int(11) NOT NULL,
  `PurchaseDetails_Rate` decimal(18,2) NOT NULL,
  `purchase_cost` decimal(18,2) NOT NULL,
  `PurchaseDetails_Discount` decimal(18,2) NOT NULL,
  `PurchaseDetails_TotalAmount` decimal(18,2) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `PurchaseDetails_branchID` int(11) NOT NULL,
  PRIMARY KEY (`PurchaseDetails_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchasemaster`
--

DROP TABLE IF EXISTS `tbl_purchasemaster`;
CREATE TABLE IF NOT EXISTS `tbl_purchasemaster` (
  `PurchaseMaster_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Supplier_SlNo` int(11) NOT NULL,
  `Employee_SlNo` int(11) NOT NULL,
  `PurchaseMaster_InvoiceNo` varchar(50) NOT NULL,
  `PurchaseMaster_OrderDate` date NOT NULL,
  `PurchaseMaster_PurchaseFor` varchar(50) NOT NULL,
  `PurchaseMaster_Description` longtext NOT NULL,
  `PurchaseMaster_TotalAmount` decimal(18,2) NOT NULL,
  `PurchaseMaster_DiscountAmount` decimal(18,2) NOT NULL,
  `PurchaseMaster_Tax` decimal(18,2) NOT NULL,
  `PurchaseMaster_Freight` decimal(18,2) NOT NULL,
  `PurchaseMaster_SubTotalAmount` decimal(18,2) NOT NULL,
  `PurchaseMaster_PaidAmount` decimal(18,2) NOT NULL,
  `PurchaseMaster_DueAmount` decimal(18,2) NOT NULL,
  `previous_due` float DEFAULT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `PurchaseMaster_BranchID` int(11) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`PurchaseMaster_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchasereturn`
--

DROP TABLE IF EXISTS `tbl_purchasereturn`;
CREATE TABLE IF NOT EXISTS `tbl_purchasereturn` (
  `PurchaseReturn_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `PurchaseMaster_InvoiceNo` varchar(50) NOT NULL,
  `Supplier_IDdNo` int(11) NOT NULL,
  `PurchaseReturn_ReturnDate` date NOT NULL,
  `PurchaseReturn_ReturnAmount` decimal(18,2) NOT NULL,
  `PurchaseReturn_Description` varchar(300) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `PurchaseReturn_brunchID` int(11) NOT NULL,
  PRIMARY KEY (`PurchaseReturn_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchasereturndetails`
--

DROP TABLE IF EXISTS `tbl_purchasereturndetails`;
CREATE TABLE IF NOT EXISTS `tbl_purchasereturndetails` (
  `PurchaseReturnDetails_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `PurchaseReturn_SlNo` int(11) NOT NULL,
  `PurchaseReturnDetailsProduct_SlNo` int(11) NOT NULL,
  `PurchaseReturnDetails_ReturnQuantity` int(11) NOT NULL,
  `PurchaseReturnDetails_ReturnAmount` decimal(18,2) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `PurchaseReturnDetails_brachid` int(11) NOT NULL,
  PRIMARY KEY (`PurchaseReturnDetails_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_quotaion_customer`
--

DROP TABLE IF EXISTS `tbl_quotaion_customer`;
CREATE TABLE IF NOT EXISTS `tbl_quotaion_customer` (
  `quotation_customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` char(50) NOT NULL,
  `contact_number` varchar(35) NOT NULL,
  `customer_address` text NOT NULL,
  `quation_customer_branchid` int(11) NOT NULL,
  PRIMARY KEY (`quotation_customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_quotation_details`
--

DROP TABLE IF EXISTS `tbl_quotation_details`;
CREATE TABLE IF NOT EXISTS `tbl_quotation_details` (
  `SaleDetails_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `SaleMaster_IDNo` int(11) NOT NULL,
  `Product_IDNo` int(11) NOT NULL,
  `SaleDetails_TotalQuantity` int(11) NOT NULL,
  `SaleDetails_Rate` decimal(18,2) NOT NULL,
  `SaleDetails_Discount` decimal(18,2) NOT NULL,
  `SaleDetails_Tax` decimal(18,2) NOT NULL,
  `SaleDetails_Freight` decimal(18,2) NOT NULL,
  `SaleDetails_TotalAmount` decimal(18,2) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `SaleDetails_BranchId` int(11) NOT NULL,
  PRIMARY KEY (`SaleDetails_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_quotation_master`
--

DROP TABLE IF EXISTS `tbl_quotation_master`;
CREATE TABLE IF NOT EXISTS `tbl_quotation_master` (
  `SaleMaster_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `SaleMaster_InvoiceNo` varchar(50) NOT NULL,
  `SaleMaster_customer_name` varchar(500) NOT NULL,
  `SaleMaster_customer_mobile` varchar(50) NOT NULL,
  `SaleMaster_customer_address` varchar(1000) NOT NULL,
  `SaleMaster_SaleDate` date NOT NULL,
  `SaleMaster_Description` longtext,
  `SaleMaster_TotalSaleAmount` decimal(18,2) NOT NULL,
  `SaleMaster_TotalDiscountAmount` decimal(18,2) NOT NULL,
  `SaleMaster_TaxAmount` decimal(18,2) NOT NULL,
  `SaleMaster_Freight` decimal(18,2) NOT NULL,
  `SaleMaster_SubTotalAmount` decimal(18,2) NOT NULL,
  `Status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `SaleMaster_branchid` int(11) NOT NULL,
  PRIMARY KEY (`SaleMaster_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_saledetails`
--

DROP TABLE IF EXISTS `tbl_saledetails`;
CREATE TABLE IF NOT EXISTS `tbl_saledetails` (
  `SaleDetails_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `SaleMaster_IDNo` int(11) NOT NULL,
  `Product_IDNo` int(11) NOT NULL,
  `SaleDetails_TotalQuantity` int(11) NOT NULL,
  `Purchase_Rate` decimal(18,2) DEFAULT NULL,
  `SaleDetails_Rate` decimal(18,2) NOT NULL,
  `SaleDetails_Discount` double NOT NULL DEFAULT '0',
  `Discount_amount` decimal(18,2) DEFAULT NULL,
  `SaleDetails_Tax` decimal(18,2) NOT NULL,
  `SaleDetails_TotalAmount` decimal(18,2) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `SaleDetails_BranchId` int(11) NOT NULL,
  PRIMARY KEY (`SaleDetails_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salereturn`
--

DROP TABLE IF EXISTS `tbl_salereturn`;
CREATE TABLE IF NOT EXISTS `tbl_salereturn` (
  `SaleReturn_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `SaleMaster_InvoiceNo` varchar(50) NOT NULL,
  `SaleReturn_ReturnDate` date NOT NULL,
  `SaleReturn_ReturnAmount` decimal(18,2) NOT NULL,
  `SaleReturn_Description` varchar(300) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `SaleReturn_brunchId` int(11) NOT NULL,
  PRIMARY KEY (`SaleReturn_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salereturndetails`
--

DROP TABLE IF EXISTS `tbl_salereturndetails`;
CREATE TABLE IF NOT EXISTS `tbl_salereturndetails` (
  `SaleReturnDetails_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `SaleReturn_IdNo` int(11) NOT NULL,
  `SaleReturnDetailsProduct_SlNo` int(11) NOT NULL,
  `SaleReturnDetails_ReturnQuantity` int(11) NOT NULL,
  `SaleReturnDetails_ReturnAmount` decimal(18,2) NOT NULL,
  `Status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `SaleReturnDetails_brunchID` int(11) NOT NULL,
  PRIMARY KEY (`SaleReturnDetails_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salesmaster`
--

DROP TABLE IF EXISTS `tbl_salesmaster`;
CREATE TABLE IF NOT EXISTS `tbl_salesmaster` (
  `SaleMaster_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `SaleMaster_InvoiceNo` varchar(50) NOT NULL,
  `SalseCustomer_IDNo` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `SaleMaster_SaleDate` date NOT NULL,
  `SaleMaster_Description` longtext,
  `SaleMaster_SaleType` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT 'Cash',
  `SaleMaster_TotalSaleAmount` decimal(18,2) NOT NULL,
  `SaleMaster_TotalDiscountAmount` decimal(18,2) NOT NULL,
  `SaleMaster_TaxAmount` decimal(18,2) NOT NULL,
  `SaleMaster_Freight` decimal(18,2) DEFAULT '0.00',
  `SaleMaster_SubTotalAmount` decimal(18,2) NOT NULL,
  `SaleMaster_PaidAmount` decimal(18,2) NOT NULL,
  `SaleMaster_DueAmount` decimal(18,2) NOT NULL,
  `SaleMaster_Previous_Due` double(18,2) DEFAULT NULL,
  `Status` char(1) NOT NULL DEFAULT 'a',
  `is_service` varchar(10) NOT NULL DEFAULT 'false',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `SaleMaster_branchid` int(11) NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`SaleMaster_SlNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_details`
--

DROP TABLE IF EXISTS `tbl_services_details`;
CREATE TABLE IF NOT EXISTS `tbl_services_details` (
  `s_d_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_d_imei` varchar(255) DEFAULT NULL,
  `sv_m_id` int(11) NOT NULL,
  `sv_d_product_id` int(11) NOT NULL,
  `sv_d_customer_name` varchar(255) DEFAULT NULL,
  `sv_d_customer_address` text,
  `sv_d_total` double NOT NULL,
  `sv_d_desc` text,
  PRIMARY KEY (`s_d_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_services_master`
--

DROP TABLE IF EXISTS `tbl_services_master`;
CREATE TABLE IF NOT EXISTS `tbl_services_master` (
  `sv_m_id` int(11) NOT NULL AUTO_INCREMENT,
  `sv_invoice` varchar(100) NOT NULL,
  `sv_emp_id` int(11) NOT NULL,
  `sv_date` varchar(20) NOT NULL,
  `sv_desc` text NOT NULL,
  `sv_total_sale_amount` double NOT NULL,
  `sv_sale_total_discount` double NOT NULL,
  `sv_sale_subtotal` double NOT NULL,
  `sv_paid_amount` double NOT NULL,
  `sv_sale_due` double NOT NULL,
  `sv_status` enum('yes','no') NOT NULL DEFAULT 'no',
  `sv_branch` int(11) DEFAULT NULL,
  `sv_vat_amount` double NOT NULL,
  `sv_transport_cost` double NOT NULL,
  PRIMARY KEY (`sv_m_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sms`
--

DROP TABLE IF EXISTS `tbl_sms`;
CREATE TABLE IF NOT EXISTS `tbl_sms` (
  `row_id` int(11) NOT NULL AUTO_INCREMENT,
  `number` varchar(30) NOT NULL,
  `sms_text` varchar(500) NOT NULL,
  `sent_by` int(11) NOT NULL,
  `sent_datetime` datetime NOT NULL,
  PRIMARY KEY (`row_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sms_settings`
--

DROP TABLE IF EXISTS `tbl_sms_settings`;
CREATE TABLE IF NOT EXISTS `tbl_sms_settings` (
  `sms_enabled` varchar(10) NOT NULL DEFAULT 'false',
  `api_key` varchar(500) NOT NULL,
  `url` varchar(1000) NOT NULL,
  `bulk_url` varchar(1000) NOT NULL,
  `sms_type` varchar(50) NOT NULL,
  `sender_id` varchar(200) NOT NULL,
  `sender_name` varchar(200) NOT NULL,
  `sender_phone` varchar(50) NOT NULL,
  `saved_by` int(11) DEFAULT NULL,
  `saved_datetime` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

DROP TABLE IF EXISTS `tbl_supplier`;
CREATE TABLE IF NOT EXISTS `tbl_supplier` (
  `Supplier_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Supplier_Code` varchar(50) NOT NULL,
  `Supplier_Name` varchar(150) NOT NULL,
  `Supplier_Type` varchar(50) NOT NULL,
  `Supplier_Phone` varchar(50) NOT NULL,
  `Supplier_Mobile` varchar(15) NOT NULL,
  `Supplier_Email` varchar(50) NOT NULL,
  `Supplier_OfficePhone` varchar(50) NOT NULL,
  `Supplier_Address` varchar(300) NOT NULL,
  `contact_person` varchar(250) DEFAULT NULL,
  `District_SlNo` int(11) NOT NULL,
  `Country_SlNo` int(11) NOT NULL,
  `Supplier_Web` varchar(150) NOT NULL,
  `previous_due` decimal(18,2) NOT NULL,
  `image_name` varchar(1000) DEFAULT NULL,
  `Status` char(1) NOT NULL DEFAULT 'a',
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `Supplier_brinchid` int(11) NOT NULL,
  PRIMARY KEY (`Supplier_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`Supplier_SlNo`, `Supplier_Code`, `Supplier_Name`, `Supplier_Type`, `Supplier_Phone`, `Supplier_Mobile`, `Supplier_Email`, `Supplier_OfficePhone`, `Supplier_Address`, `contact_person`, `District_SlNo`, `Country_SlNo`, `Supplier_Web`, `previous_due`, `image_name`, `Status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Supplier_brinchid`) VALUES
(1, 'S00001', 'WALTON HI TECH IN', '', '', '01619001600', '', '', 'DH', 'WALTON', 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-15 17:57:44', NULL, NULL, 1),
(2, 'S00002', 'Beximco Communications Limited -Akash Dth', '', '', '01730404137', 'corporate@beximco.net', '', 'Beximco communications Ltd Level 10, Sam Tower, plot 4, Road 22, Gulshan-1, Dhaka 1212, Bangladesh', 'Akash Dth', 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-15 20:28:03', NULL, NULL, 2),
(3, 'S00003', 'Walton Hi-Tech Industries Limited (Vatable)', '', '', '0912121321', 'inf@walton.com', '', 'Chanda,Kaliakoir,Gazipur', 'SMART HOME ', 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-16 17:35:28', NULL, NULL, 2),
(4, 'S00004', 'Beximco Communications Limited -Akash Dth', '', '', '8801730404137', 'corporate@beximco.net', '', 'Beximco communications Ltd Level 10, Sam Tower, plot 4, Road 22, Gulshan-1, Dhaka 1212, Bangladesh', 'Akash Dth', 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-18 15:37:33', 'Admin', '2019-12-18 17:58:53', 1),
(5, 'S00005', 'Dream Park International', '', '', '01713449106', 'N/A', '', 'Holding No 00013,Block-B, Building No 03, 3rd Floor , Ward No 02, Baroichuti ,Kaliakoir, Gazipur', 'Walton', 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-19 16:32:42', 'Admin', '2019-12-19 17:16:09', 4),
(6, 'S00006', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:22:52', NULL, NULL, 1),
(7, 'S00007', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:24:10', NULL, NULL, 1),
(8, 'S00008', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:26:54', NULL, NULL, 1),
(9, 'S00009', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:27:30', NULL, NULL, 1),
(10, 'S00010', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:49:04', NULL, NULL, 1),
(11, 'S00011', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:49:29', NULL, NULL, 1),
(12, 'S00012', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:51:57', NULL, NULL, 1),
(13, 'S00013', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:52:30', NULL, NULL, 1),
(14, 'S00014', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:53:30', NULL, NULL, 1),
(15, 'S00015', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 20:55:40', NULL, NULL, 1),
(16, 'S00016', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:03:25', NULL, NULL, 1),
(17, 'S00017', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:05:12', NULL, NULL, 1),
(18, 'S00018', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:06:57', NULL, NULL, 1),
(19, 'S00019', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:07:13', NULL, NULL, 1),
(20, 'S00020', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:07:36', NULL, NULL, 1),
(21, 'S00021', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:08:29', NULL, NULL, 1),
(22, 'S00022', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:18:19', NULL, NULL, 1),
(23, 'S00023', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 21:18:42', NULL, NULL, 1),
(24, 'S00024', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 22:11:32', NULL, NULL, 1),
(25, 'S00025', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 22:12:48', NULL, NULL, 1),
(26, 'S00026', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 22:13:32', NULL, NULL, 1),
(27, 'S00027', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 22:14:25', NULL, NULL, 1),
(28, 'S00028', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 22:14:41', NULL, NULL, 1),
(29, 'S00029', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-24 22:24:20', NULL, NULL, 1),
(30, 'S00030', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 01:55:23', NULL, NULL, 1),
(31, 'S00031', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 09:28:14', NULL, NULL, 1),
(32, 'S00032', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 09:48:16', NULL, NULL, 1),
(33, 'S00033', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 09:52:03', 'Admin', '2019-12-25 10:31:29', 1),
(34, 'S00034', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 10:32:34', 'Admin', '2019-12-25 10:44:34', 1),
(35, 'S00035', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 10:55:33', 'Admin', '2019-12-25 10:55:53', 1),
(36, 'S00036', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 11:10:01', 'Admin', '2019-12-25 11:11:40', 1),
(37, 'S00037', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 11:14:56', NULL, NULL, 1),
(38, 'S00038', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 19:57:13', NULL, NULL, 1),
(39, 'S00039', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 20:17:33', NULL, NULL, 1),
(40, 'S00040', '', 'G', '', '', '', '', '', NULL, 0, 0, '', '0.00', NULL, 'a', 'Admin', '2019-12-25 21:54:11', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier_payment`
--

DROP TABLE IF EXISTS `tbl_supplier_payment`;
CREATE TABLE IF NOT EXISTS `tbl_supplier_payment` (
  `SPayment_id` int(11) NOT NULL AUTO_INCREMENT,
  `SPayment_date` date DEFAULT NULL,
  `SPayment_invoice` varchar(20) DEFAULT NULL,
  `SPayment_customerID` varchar(20) DEFAULT NULL,
  `SPayment_TransactionType` varchar(25) DEFAULT NULL,
  `SPayment_amount` decimal(18,2) DEFAULT NULL,
  `SPayment_Paymentby` varchar(20) DEFAULT NULL,
  `SPayment_notes` varchar(225) DEFAULT NULL,
  `SPayment_brunchid` int(11) DEFAULT NULL,
  `SPayment_status` varchar(2) DEFAULT NULL,
  `SPayment_Addby` varchar(100) DEFAULT NULL,
  `SPayment_AddDAte` date DEFAULT NULL,
  `update_by` int(11) DEFAULT NULL,
  `SPayment_UpdateDAte` date DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`SPayment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transferdetails`
--

DROP TABLE IF EXISTS `tbl_transferdetails`;
CREATE TABLE IF NOT EXISTS `tbl_transferdetails` (
  `transferdetails_id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` float NOT NULL,
  PRIMARY KEY (`transferdetails_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transfermaster`
--

DROP TABLE IF EXISTS `tbl_transfermaster`;
CREATE TABLE IF NOT EXISTS `tbl_transfermaster` (
  `transfer_id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_date` date NOT NULL,
  `transfer_by` int(11) NOT NULL,
  `transfer_from` int(11) NOT NULL,
  `transfer_to` int(11) NOT NULL,
  `note` varchar(500) DEFAULT NULL,
  `added_by` int(11) NOT NULL,
  `added_datetime` datetime NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`transfer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

DROP TABLE IF EXISTS `tbl_unit`;
CREATE TABLE IF NOT EXISTS `tbl_unit` (
  `Unit_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `Unit_Name` varchar(150) NOT NULL,
  `status` char(1) NOT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`Unit_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`Unit_SlNo`, `Unit_Name`, `status`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`) VALUES
(1, 'Pcs', 'a', NULL, NULL, 'Admin', '2019-12-15 20:17:30'),
(2, 'Meter', 'a', 'Admin', '2019-12-15 20:01:06', NULL, NULL),
(3, 'Kg', 'a', 'Admin', '2019-12-16 23:28:55', NULL, NULL),
(4, 'Combo', 'a', 'Admin', '2019-12-16 23:29:23', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `User_SlNo` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` varchar(50) NOT NULL,
  `FullName` varchar(150) NOT NULL,
  `User_Name` varchar(150) NOT NULL,
  `UserEmail` varchar(200) NOT NULL,
  `userBrunch_id` int(11) NOT NULL,
  `User_Password` varchar(50) NOT NULL,
  `UserType` varchar(50) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'a',
  `verifycode` int(11) NOT NULL,
  `image_name` varchar(1000) DEFAULT NULL,
  `AddBy` varchar(50) DEFAULT NULL,
  `AddTime` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT NULL,
  `Brunch_ID` int(11) NOT NULL,
  PRIMARY KEY (`User_SlNo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`User_SlNo`, `User_ID`, `FullName`, `User_Name`, `UserEmail`, `userBrunch_id`, `User_Password`, `UserType`, `status`, `verifycode`, `image_name`, `AddBy`, `AddTime`, `UpdateBy`, `UpdateTime`, `Brunch_ID`) VALUES
(1, 'U0001', 'Admin', 'admin', 'hello.tareq.teknaf@gmail.com', 1, 'c4ca4238a0b923820dcc509a6f75849b', 'm', 'a', 0, '1.jpg', NULL, '2019-12-15 16:49:04', NULL, NULL, 1),
(2, '', 'user', 'user', 'user@gmail.com', 1, 'e10adc3949ba59abbe56e057f20f883e', 'e', 'a', 0, NULL, NULL, '2019-10-12 12:17:27', NULL, NULL, 1),
(3, '', 'Md Riaz', 'riaz', 'riazhahsan86@gmail.com', 1, '45c48cce2e2d7fbdea1afc51c7c6ad26', 'u', 'a', 0, NULL, NULL, '2019-12-15 16:54:38', NULL, NULL, 1),
(4, '', 'Abdul Mobin Hero', 'Mobin', 'hero@gmail.com', 1, '45c48cce2e2d7fbdea1afc51c7c6ad26', 'a', 'a', 0, NULL, NULL, '2019-12-18 19:45:32', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_access`
--

DROP TABLE IF EXISTS `tbl_user_access`;
CREATE TABLE IF NOT EXISTS `tbl_user_access` (
  `access_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `access` text NOT NULL,
  `saved_by` int(11) NOT NULL,
  `saved_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user_access`
--

INSERT INTO `tbl_user_access` (`access_id`, `user_id`, `access`, `saved_by`, `saved_datetime`) VALUES
(1, 2, '[\"sales\\/product\",\"bank_transaction_report\"]', 1, '2019-10-12 16:17:49'),
(2, 3, '[\"sales\\/product\",\"price_list\",\"product\",\"productlist\",\"sales\\/service\",\"emplists\",\"employee\",\"salarypayment\",\"designation\",\"month\",\"employeesalaryreport\",\"unit\",\"category\",\"customer\",\"purchaseInvoice\",\"supplierDue\"]', 1, '2019-12-15 21:58:36'),
(3, 4, '[\"sales\\/product\",\"sales\\/service\",\"purchase\",\"salesinvoice\",\"product\",\"productlist\",\"damageEntry\",\"unit\",\"category\"]', 1, '2019-12-15 22:44:10');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
