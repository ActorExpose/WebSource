<?php
include('config.php');
if(isset($_POST['submit']))
{

  $name=$_POST['name'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $city=$_POST['city'];
  $country=$_POST['country'];
  $neet=$_POST['neet'];
  $applycourse=$_POST['applycourse'];
  $message=$_POST['message'];



  $sql="INSERT INTO vnmu_lead(name,email,mobile_no,city,country,neet_score,course_name,message)VALUES('$name','$email','$phone','$city','$country','$neet','$applycourse','$message')";

  if($data=mysqli_query($conn,$sql))
  {
     
        $to = ""; // this is your Email address

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: Quote Request \r\n";
        $headers .= "Reply-To: " . $name . " <" . $email . ">\r\n";



        $subject = "Form Request";

        $message = '
    <html>
    <head>
      <title>Form Submission</title>
    </head>
    <body>
    <h2 style="margin-bottom: 7px;">Form Request Details</h2>
     <table border="1" style="border-collapse:collapse">
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">First Name</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $name . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">Email Adress</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $email . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">Phone Number</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $phone . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">City</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $city . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">Country</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $country . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">NEET Score</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $neet . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">Course Applying</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $applycourse . '</td></tr>
     <tr><th style="padding:6px; text-align:left; padding-left:0px;">Message</th><td style="padding:6px; text-align:left; padding-left:0px;">' . $message . '</td></tr>
     
	</table>
    </body>
    </html>
	';
        /*Time Out for address page*/
		
        if (mail($to, $subject, $message, $headers)) {

			echo "<script>
                alert('Form Submitted')
                </script>";
            echo "<script>window.location.href = 'https://www.vnmuedu.com/admission2020/';</script>";
            // Redirect browser 
            
			} else {
            echo "<script>
                alert('mail not sent')
                </script>";
        }
     
      
   // header("location:index.php");
  }
  
 

}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="">
<meta name="description" content="">
<title>LeadPage - Landing Page Template</title>

<!-- Loading Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Loading Template CSS -->
<link href="css/style.css" rel="stylesheet">
<link href="css/animate.css" rel="stylesheet">
<link rel="stylesheet" href="css/pe-icon-7-stroke.css">
<link href="css/style-magnific-popup.css" rel="stylesheet">

<!-- Awsome Fonts -->
<link rel="stylesheet" href="css/all.min.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500&amp;display=swap" rel="stylesheet">

<!-- Font Favicon -->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="stylesheet" href="css/lightbox.min.css">
 <script src="js/lightbox-plus-jquery.min.js"></script>
</head>

<body>

<!--begin header -->
<header class="header"> 
  
  <!--begin navbar-fixed-top -->
  <nav class="navbar navbar-default navbar-fixed-top"> 
    
    <!--begin container -->
    <div class="container"> 
      
      <!--begin navbar -->
      <nav class="navbar navbar-expand-lg"> 
        
        <!--begin logo --> 
        <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a> 
        <!--end logo --> 
        
        <!--begin navbar-toggler -->
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span> </button>
        <!--end navbar-toggler --> 
        
        <!--begin navbar-collapse -->
        <div class="navbar-collapse collapse" id="navbarCollapse" style=""> 
          
          <!--begin navbar-nav -->
          <ul class="navbar-nav ml-auto">
            <li><a href="#home">About</a></li>
            <li><a href="#services">Overview</a></li>
            <li><a href="#testimonials">Gallery</a></li>
            <li><a href="#features">Contact</a></li>
          </ul>
          <!--end navbar-nav --> 
          
        </div>
        <!--end navbar-collapse --> 
        
      </nav>
      <!--end navbar --> 
      
    </div>
    <!--end container --> 
    
  </nav>
  <!--end navbar-fixed-top --> 
  
</header>
<!--end header --> 

<!--begin home section -->
<div id="intro"> <img src="images/intro-bg.jpg" class="desktop-img" alt="intro.jpg"> <img src="images/intro-bg-mobile.jpg" class="mobile-img" alt="intro.jpg">
  <div class="intro-body"> </div>
</div>

<!--end home section --> 

<!--begin top-cta-blue -->
<section class="top-cta-blue small-paddings"> 
  
  <!--begin container -->
  <div class="container"> 
    
    <!--begin row -->
    <div class="row"> 
      
      <!--begin col-md-3 -->
      <div class="col-md-3"> <span><i class="far fa-clock"></i></span>
        <h5 class="white-text">Opening Hours</h5>
        <p class="white-text">Mon–Fri: 09:00 – 15:00</p>
      </div>
      <!--end col-md-3 --> 
      
      <!--begin col-md-3 -->
      <div class="col-md-3"> <span><i class="fas fa-phone"></i></span>
        <h5 class="white-text">Phone Number</h5>
        <p class="white-text">+38(099)072-1963</p>
      </div>
      
      <!--begin col-md-3 -->
      
      <!--end col-md-3 --> 
      
      <!--begin col-md-3 -->
      <div class="col-md-3"> <span><i class="far fa-envelope-open"></i></span>
        <h5 class="white-text">Email Address</h5>
        <p class="white-text">vnnmu.com@gmail.com</p>
      </div>
      <!--end col-md-3 --> 
      
      <!--begin col-md-3 -->
      <div class="col-md-3"> <span><i class="fas fa-map-marker-alt"></i></span>
        <h5 class="white-text">Our Location</h5>
        <p class="white-text">56, Pirogova Str., 21018,<br> Vinnytsya, Ukraine</p>
      </div>
      <!--end col-md-3 --> 
      
    </div>
    <!--end row --> 
    
  </div>
  <!--end container --> 
  
</section>
<!--end top-cta-blue --> 

<!--begin section-grey -->
<section class="section-grey" id="services"> 
  
  <!--begin container -->
  <div class="container"> 
    
    <!--begin row -->
    <div class="row"> 
      
      <!--begin col-md-12 -->
      <div class="col-md-12 text-center">
        <h2 class="section-title">Admission requirements</h2>
      </div>
      <!--end col-md-12 --> 
      
    </div>
    <!--end row --> 
    
  </div>
  <!--end container --> 
  
  <!--begin services-wrapper -->
  <div class="services-wrapper"> 
    
    <!--begin container -->
    <div class="container"> 
      
      <!--begin row -->
      <div class="row"> 
        
        <!--begin col-md-4 -->
        <div class="col-md-4">
          <div class="main-services"> <img src="images/services1.jpg" class="width-100" alt="pic">
            <h3>A minimum of 50% score in English in 10+2.</h3>
          </div>
        </div>
        <!--end col-md-4 --> 
        
        <!--begin col-md-4 -->
        <div class="col-md-4">
          <div class="main-services"> <img src="images/services2.jpg" class="width-100" alt="pic">
            <h3>A minimum of 50% score in Physics, Chemistry and Biology taken together.</h3>
          </div>
        </div>
        <!--end col-md-4 --> 
        
        <!--begin col-md-4 -->
        <div class="col-md-4">
          <div class="main-services"> <img src="images/services3.jpg" class="width-100" alt="pic">
            <h3>Neet should be Qualified.</h3>
          </div>
        </div>
        <!--end col-md-4 --> 
        
      </div>
      <!--end row --> 
      
    </div>
    <!--end container --> 
    
  </div>
  <!--end services-wrapper --> 
  
</section>
<!--end section-grey --> 

<!--begin section-white -->
<section class="section-white"> 
  
  <!--begin container-->
  <div class="container"> 
    
    <!--begin row-->
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="section-title">Vinnytsia National Medical University</h2>
        <p class="section-subtitle">Salient Features</p>
      </div>
      <!--begin col-md-6-->
      <div class="col-md-8 padding-top-30">
        <ul class="benefits">
          <li><i class="fas fa-check"></i>Founded in 1922 and named after famous surgeon Nikolay Pirogov in 1960</li>
          <li><i class="fas fa-check"></i>4th level of accreditation and National University status</li>
          <li><i class="fas fa-check"></i>6 faculties with 55 departments and 33 specialties</li>
          <li><i class="fas fa-check"></i>More than 11000 students study at VNMU annually</li>
          <li><i class="fas fa-check"></i>812 teachers including 120 doctors of science, 75 professors, 17 academicians and 5 members correspondents of academies of science.</li>
          <li><i class="fas fa-check"></i>7 labs and the vivarium for scientific work</li>
          <li><i class="fas fa-check"></i>Rich library with 6 licensed labs</li>
          <li><i class="fas fa-check"></i>MCI passing percentage 2019- 36.57%</li>
          <li><i class="fas fa-check"></i>Only medical university in Ukraine to have their own football ground.</li>
        </ul>
      </div>
      <!--end col-md-6--> 
      
      <!--begin col-md-6-->
      <div class="col-md-4"> 
        
        <!--begin video-popup-wrapper-->
        <div class="video-popup-wrapper margin-left-20"> 
          
          <!--begin popup-gallery-->
          <div class="padding-top-30"> <img src="images/communaction-1.jpg" class="width-100 box-shadow top-margins-images" alt="pic"> </div>
          <!--end popup-gallery--> 
          
        </div>
        <!--end video-popup-wrapper--> 
        
      </div>
      <!--end col-sm-6--> 
      
    </div>
    <!--end row--> 
    
  </div>
  <!--end container--> 
  
</section>
<!--end section-white--> 

<!--begin testimonials section --> 

<!--end testimonials section --> 

<!--begin section-white --> 

<!--end section-white --> 

<!--begin section-grey -->
<section class="section-grey" id="features"> 
  
  <!--begin container -->
  <div class="container"> 
    
    <!--begin row -->
    <div class="row"> 
      
      <!--begin col-md-12 -->
      <div class="col-md-12 text-center">
        <h2 class="section-title">Admission process for Indian Students</h2>
      </div>
      <!--end col-md-12 --> 
      
    </div>
    <!--end row --> 
    
  </div>
  <!--end container --> 
  
  <!--begin services-wrapper -->
  <div class="services-wrapper"> 
    
    <!--begin container -->
    <div class="container"> 
      
      <!--begin row -->
      <div class="row"> 
        
        <!--begin col-md-4 -->
        <div class="col-md-3">
          <div class="main-services"> <h2>01</h2>
            <h4>Application</h4>
            <p>Applicants send us scan copies of their educational documents for verification along with NEET Result. The academic council reviews the application and issues an admission confirmation within 1-2 working days.</p>
          </div>
        </div>
        <!--end col-md-4 --> 
        
        <!--begin col-md-4 -->
        <div class="col-md-3">
          <div class="main-services"> <h2>02</h2>
            <h4>Invitation</h4>
            <p>On receipt of scanned copies of all the educational documents along with NEET results as well as passport data pages an invitation to study is issued. It generally takes 3-4 working days.</p>
          </div>
        </div>
        <!--end col-md-4 --> 
        
        <!--begin col-md-4 -->
        <div class="col-md-3">
          <div class="main-services"> <h2>03</h2>
            <h4>Visa</h4>
            <p>On receipt of original invitation letter any of our authorized representative shall help you procure a visa to study in Ukraine, It should generally take 15-20 working days for successful application.</p>
          </div>
        </div>
        <!--end col-md-4 --> 
        
        <!--begin col-md-4 -->
        <div class="col-md-3">
          <div class="main-services"> <h2>04</h2>
            <h4>Arrival to Ukraine</h4>
            <p>Once the Visa is receipt you shall be required to inform us a minimum of 3 working days prior to your arrival and you must arrive with all documents as mentioned on your admission letter. Our representative shall meet you at the airport and welcome you on the enticing journey called MEDICINE at 
              VNMU </p>
          </div>
        </div>
        <!--end col-md-4 --> 
        
      </div>
      <!--end row --> 
      
    </div>
    <!--end container --> 
    
  </div>
  <!--end services-wrapper --> 
  
</section>
<!--end section-grey --> 

<section class="section-white"> 
  
  <!--begin container-->
  <div class="container"> 
    
    <!--begin row-->
    <div class="row">
      <div class="col-md-12 text-center">
        <h2 class="section-title">UNIVERSITY CAMPUS AT A GLANCE</h2>
        <p class="section-subtitle">Our mission is to transform and enrich the student's experience, as well as provide a safe and
inviting campus facilities where all the students, alumni, faculty, staff, and community members
cultivate lifelong relationships founded on engagement, learning, multiculturalism, and citizenship.</p>
      </div>
      </div>
      <!--begin col-md-6-->
      <div class="row">
  <div class="portfolio-items padding-top-30">
            <div class="container">
              <div class="row">
                <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/01.jpg" data-lightbox="roadtrip"><img src="images/portfolio/01.jpg" alt="01.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/02.jpg" data-lightbox="roadtrip"><img src="images/portfolio/02.jpg" alt="02.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/03.jpg" data-lightbox="roadtrip"><img src="images/portfolio/03.jpg" alt="03.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/04.jpg" data-lightbox="roadtrip"><img src="images/portfolio/04.jpg" alt="04.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/05.jpg" data-lightbox="roadtrip"><img src="images/portfolio/05.jpg" alt="05.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/06.jpg" data-lightbox="roadtrip"><img src="images/portfolio/06.jpg" alt="06.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/07.jpg" data-lightbox="roadtrip"><img src="images/portfolio/07.jpg" alt="07.jpg"></a>
                </div>
                   <div class="col-md-3 col-sm-6 mb-5">
                  <a href="images/portfolio/08.jpg" data-lightbox="roadtrip"><img src="images/portfolio/08.jpg" alt="08.jpg"></a>
                </div>
                
              </div>
            </div>
          




        </div>
  </div>
      <!--end col-md-6--> 
      
      <!--begin col-md-6-->
      
      <!--end col-sm-6--> 
      
    
    <!--end row--> 
    
  </div>
  <!--end container--> 
  
</section>
<!--begin section-white -->
<section class="section-white"> 
  
  <!--begin container-->
  <div class="container">
    <div class="row"> 
      
      <!--begin col-md-12 -->
      <div class="col-md-12 text-center">
        <h2 class="section-title">LIFE AT VNMU</h2>
        <p class="section-subtitle">VNMU is known nationally and internationally for its high quality of specialist training and was rated
by the International Personnel Academy ranking of schools of higher education as one of the best
institutions in Ukraine.
At present, VNMU has a teaching staff of 812 individuals, with a yearly enrolment of 4,000 students,
including almost 2,000 in postgraduate education, representing different specialties.</p>
      </div>
      <!--end col-md-12 --> 
      
    </div>
    <!--begin row-->
    <div class="row"> 
      <!--begin col-md-6-->
      <div class="col-md-12 padding-top-30">
        <iframe width="100%" height="500" src="https://www.youtube.com/embed/f6SKR1xOduE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
      <!--end col-md-6--> 
      
    </div>
    <!--end row--> 
    
  </div>
  <!--end container--> 
  
</section>
<!--end section-white--> 

<!--begin section-bg-2 -->
<section class="section-bg-2">
  <div class="section-bg-overlay"></div>
  
  <!--begin container-->
  <div class="container"> 
    
    <!--begin row -->
    <div class="row"> 
      
      <!--begin col-md-12-->
      <div class="col-md-12 text-center padding-bottom-10">
        <h3 class="section-title white-text">WANT TO BE A PART OF THE LEADING UNIVERSITY IN UKRAINE?</h3>
        <p class="section-subtitle white margin-bottom-30">FILL THE FORM TO KNOW MORE ABOUT US</p>
        <a href="#contact" class="btn-white scrool">Get Started</a> </div>
      <!--end col-md-12 --> 
      
    </div>
    <!--end row --> 
    
  </div>
  <!--end container--> 
  
</section>
<!--end section-bg-2 --> 

<!--begin contact -->
<section class="section-white section-bottom-border" id="contact"> 
  
  <!--begin container-->
  <div class="container"> 
    
    <div class="row"> 
      
      <!--begin col-md-12 -->
      <div class="col-md-12 text-center">
        <h2 class="section-title">CONTACT US</h2>
        <p class="section-subtitle">Know more about VNMU!<br>Write us your queries and we will get back to you with a solution.
Get a chance to pursue medicine and fulfil your dreams.</p>
      </div>
      <!--end col-md-12 --> 
      
    </div>
    <!--begin row-->
    <div class="row"> 
      
      <!--begin col-md-6 -->
      <div class="col-md-6 padding-top-30">
        
        <!--begin success message -->
        <p class="contact_success_box" style="display:none;">We received your message and you'll hear from us soon. Thank You!</p>
        <!--end success message --> 
        
        <!--begin contact form -->

        <form id="contact-formtt" class="contact" action="" method="POST" enctype="multipart/form-data">
          <input class="contact-input white-input" required="" name="name" placeholder="Full Name*" type="text">
          <input class="contact-input white-input" required="" name="email" placeholder="Email Adress*" type="email">
          <input class="contact-input white-input" required="" name="phone" placeholder="Phone Number*" type="text">
          
          <input class="contact-input white-input" required="" name="city" placeholder="Enter Your City*" type="text">
          <input class="contact-input white-input" required="" name="country" placeholder="Enter Your Country*" type="text">
          <input class="contact-input white-input" required="" name="neet" placeholder="Enter your NEET Score (For Indian Nationals)*" type="text">
          <select class="contact-input white-input" required="" name="applycourse">
                                      <option selected="" value="" name="course">Please select a Course Applying For</option>
                                      <option value="Medical">Medical</option>
                                      <option value="Nursing">Nursing</option>
                                      <option value="Dentistry">Dentistry</option>
                                      <option value="Pharmacy">Pharmacy</option>
                                  </select>
          <textarea  class="contact-commnent white-input" rows="2" cols="20" name="message" placeholder="Your Message..."></textarea>
          <input type="submit" value="submit" name=submit class="contacttt-submit" >
        </form>

        <!--end contact form --> 
        
      </div>
      <!--end col-md-6 --> 
      
      <!--begin col-md-6 -->
      <div class="col-md-6 responsive-bottom-margins padding-top-30">
        <iframe class="contact-maps wow slideInRight" data-wow-delay="0.25s" style="visibility: visible; animation-delay: 0.25s; animation-name: slideInRight;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.9050207912896!2d-0.14675028449633118!3d51.514958479636384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761ad554c335c1%3A0xda2164b934c67c1a!2sOxford+St%2C+London%2C+UK!5e0!3m2!1sen!2sro!4v1485889312335" width="600" height="540" style="border:0" allowfullscreen="">
        </iframe>
      </div>
      <!--end col-md-6 --> 
      
    </div>
    <!--end row--> 
    
  </div>
  <!--end container--> 
  
</section>
<!--end contact--> 

<!--begin footer -->
<div class="footer"> 
  
  <!--begin container -->
  <div class="container footer-top"> 
    
    <!--begin row -->
    <div class="row"> 
      
      <!--begin col-md-4 -->
      <div class="col-md-4 text-center"> 
       &nbsp;
      </div>
      <!--end col-md-4 --> 
      
      <!--begin col-md-4 -->
      <div class="col-md-4 text-center"> <i class="pe-7s-map-2"></i>
         <h5>Get In Touch</h5>
        <p>56, Pirogova Str., 21018, Vinnytsya, Ukraine</p>
        <p><a href="mailto:vnnmu.com@gmail.com">vnnmu.com@gmail.com</a></p>
        <p>+38(099)072-1963</p>
        <!--end footer_social --> 
        
      </div>
      <!--end col-md-4 --> 
      
      <!--begin col-md-4 -->
      <div class="col-md-4 text-center">&nbsp;</div>
      <!--end col-md-4 --> 
      
    </div>
    <!--end row --> 
    
  </div>
  <!--end container --> 
  
  <!--begin container -->
  <div class="container-fluid footer-bottom px-0"> 
    
    <!--begin row -->
    <div class="row no-gutters mx-0"> 
      
      <!--begin col-md-12 -->
      <div class="col-md-12 text-center">
        <p>All copyrights reserved © 2020</p>
      </div>
      <!--end col-md-6 --> 
      
    </div>
    <!--end row --> 
    
  </div>
  <!--end container --> 
  
</div>
<!--end footer --> 

<!-- Load JS here for greater good =============================--> 
<script src="js/jquery-3.3.1.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.scrollTo-min.js"></script> 
<script src="js/jquery.magnific-popup.min.js"></script> 
<script src="js/jquery.nav.js"></script> 
<script src="js/wow.js"></script> 
<script src="js/plugins.js"></script> 
<script src="js/custom.js"></script>

<!-- Javascripts
    ================================================== --> 
<script type="text/javascript" src="js/main.js"></script>
<script>
    lightbox.option({
      'resizeDuration': 200,
      'wrapAround': true
    })
  </script>
</body>
</html>