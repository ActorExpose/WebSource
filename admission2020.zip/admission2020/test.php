<?php
include('config.php');
if(isset($_POST['submit']))
{
	echo "<pre>";
	print_r($_POST);
	die();

	$name=$_POST['name'];
	$gender=$_POST['gender'];
	$vehicle1=$_POST['vehicle'];
	$vehicle=implode(",",$vehicle1);
	$car=$_POST['cars'];

	$file=$_FILES['image'];
	/*echo "<pre>";
	print_r($_FILES);
	die();*/
	$filename=time().$_FILES['image']['name'];
	$filelocation=$_FILES['image']['tmp_name'];
	$fileup=move_uploaded_file($filelocation, "image/".$filename);


	$sql="INSERT INTO user(name,gender,vehicle,car,image)VALUES('$name','$gender','$vehicle','$car','$filename')";
	
	if($data=mysqli_query($conn,$sql))
	{
		header("location:view.php");
	}

}

?>
<form id="contact-formtt" class="contact" action="" method="POST" enctype="multipart/form-data">
          <input class="contact-input white-input" required="" name="name" placeholder="Full Name*" type="text">
          <input class="contact-input white-input" required="" name="email" placeholder="Email Adress*" type="email">
          <input class="contact-input white-input" required="" name="phone" placeholder="Phone Number*" type="text">
          <input class="contact-input white-input" required="" name="city" placeholder="Enter Your City*" type="text">
          <input class="contact-input white-input" required="" name="country" placeholder="Enter Your Country*" type="text">
          <input class="contact-input white-input" required="" name="neet" placeholder="Enter your NEET Score (For Indian Nationals)*" type="text">
          <select class="contact-input white-input" required="" name="applycourse">
                                    <option selected="" value="" name="course">Please select a Course Applying For</option>
	                                    <option value="Medical">Medical</option>
	                                    <option value="Nursing">Nursing</option>
	                                    <option value="Dentistry">Dentistry</option>
	                                    <option value="Pharmacy">Pharmacy</option>
	                                </select>
          <textarea  class="contact-commnent white-input" rows="2" cols="20" name="message" placeholder="Your Message..."></textarea>
          <input type="submit" value="submit" name=submit class="contacttt-submit" >
        </form>