<?php

$con = new mysqli("localhost","vnmuedu_leads","YOo[_B6ka@*d", "vnmuedu_vnmu_leads");


// Check connection
if ($con -> connect_errno)
 {
  echo "Failed to connect to MySQL: " . $con -> connect_error;
  exit();
}

?>