<?php

	
	require_once	'config.php';
	
	if($_SESSION['UserName']=="" || $_SESSION['Password']== NULL)
	{
		header('Location:login.php');
	}
	else if($_SESSION['UserName']=="" || $_SESSION['UserName']==NULL)
	{
		header('Location:login.php');
	}

	?>			
			<div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            
                            
                            <li class="nav-item">
                                <a class="nav-link" href="agent-details"><i class="fas fa-fw fa-table"></i>User Details</a>
                                
                            </li>
							
                        </ul>
                    </div>
                </nav>
            </div>
        </div>	



