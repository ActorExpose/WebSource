<?php
session_start();

unset($_SESSION['UserId']);
unset($_SESSION['Name']);

session_destroy();

header('Location:index.php');

?>