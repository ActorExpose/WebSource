<?php  include('config.php');

$sql=mysqli_query($con,"select * from vnmu_lead");
 
echo "<pre>";
print_r($sql);
echo $sql['password'];
die();

?>